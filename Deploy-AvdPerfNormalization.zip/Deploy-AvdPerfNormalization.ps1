﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Deploys the Perf_Normalized workspace function and the DE/EN AVD session host workbook.
.DESCRIPTION
    German (localized) Windows session hosts write localized performance counter names
    (e.g. "Prozessorinformationen" / "Prozessorzeit (%)") into the Perf table. The AVD
    Sessionhosts Monitoring 2.0 workbook filters on English names and therefore shows NaN
    for those hosts.

    This script
      1. creates or updates a saved KQL function "Perf_Normalized" in the Log Analytics
         workspace that maps the German counter names to English,
      2. verifies the function with a test query,
      3. creates or updates the adapted workbook (all Perf references replaced by
         Perf_Normalized) as a shared workbook in the monitoring resource group.

    Everything is done with Azure CLI (az rest against the ARM REST API). No portal steps.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-27
    Version     : 1.0.1
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Deploy-AvdPerfNormalization.ps1
#>

# =============================================================================
# [ PARAMETERS ] - adjust here, not via command line
# =============================================================================
$ScriptVersion          = "1.0.1"
$PowerShellMode         = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = 7.x only

$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"
$ResourceGroupName      = "rg-AVDmgmt"
$WorkspaceName          = "law-LDK-AVDSessionHosts"
$Location               = "westeurope"

# Saved function
$FunctionAlias          = "Perf_Normalized"
$FunctionCategory       = "AVD Monitoring"
$SavedSearchId          = "avd-monitoring-perf-normalized"

# Workbook
$DeployWorkbook         = $true
$WorkbookDisplayName    = "AVD Session Hosts - Extended"
$WorkbookJsonPath       = Join-Path $PSScriptRoot "avd-sessionhosts-monitoring-2.0-de-en.workbook.json"

# API versions
$ApiSavedSearch         = "2020-08-01"
$ApiWorkbook            = "2022-04-01"

# =============================================================================
# [ RUNTIME SETUP ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# Umlauts for KQL text (source stays ASCII)
$Ch_ae = [System.Char]::ConvertFromUtf32(0x00E4)
$Ch_oe = [System.Char]::ConvertFromUtf32(0x00F6)
$Ch_ue = [System.Char]::ConvertFromUtf32(0x00FC)
$Ch_Ue = [System.Char]::ConvertFromUtf32(0x00DC)

function Write-Line { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$Title) Write-Host "[ $Title ]" -ForegroundColor White }
function Write-Log {
    param([string]$Symbol, [string]$Message, [string]$Color = "Cyan")
    $stamp = Get-Date -Format "HH:mm:ss"
    Write-Host ("[{0}] {1}  {2}" -f $stamp, $Symbol, $Message) -ForegroundColor $Color
}
$script:AzLastError = ""
function Assert-AzSuccess {
    param([string]$Message)
    if ($LASTEXITCODE -ne 0) {
        Write-Log $SymErr $Message "Red"
        if ($script:AzLastError -ne "") {
            foreach ($line in ($script:AzLastError -split "`n")) {
                if ($line.Trim() -ne "") { Write-Host ("    " + $line.Trim()) -ForegroundColor Red }
            }
        }
        Write-Line
        exit 1
    }
}
function Invoke-AzQuiet {
    # Runs az, keeps stderr off the console but stores it for Assert-AzSuccess.
    # Arguments are passed as an array; query parameters for az rest go via
    # --uri-parameters, never inside the URL (az.cmd on Windows breaks on '&').
    param([string[]]$Arguments)
    $script:AzLastError = ""
    $mixed = & az @Arguments 2>&1
    $stdout = New-Object System.Collections.Generic.List[string]
    $stderr = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($mixed)) {
        if ($item -is [System.Management.Automation.ErrorRecord]) {
            $stderr.Add($item.ToString())
        } else {
            $stdout.Add([string]$item)
        }
    }
    $script:AzLastError = ($stderr -join "`n")
    return $stdout.ToArray()
}
function Write-Utf8NoBom {
    param([string]$Path, [string]$Content)
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $enc)
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Line
Write-Section "PRE-CHECK"

# PowerShell version / mode
$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Log $SymInfo ("PowerShell {0}.{1}, Mode: {2}" -f $psMajor, $psMinor, $PowerShellMode)
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Log $SymErr "Script requires PowerShell 7.x (Mode Seven)" "Red"
    Write-Line
    exit 1
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Log $SymInfo "PSNativeCommandUseErrorActionPreference set to false"
}

# Azure CLI present
Write-Log $SymInfo "Checking Azure CLI..."
$azCmd = Get-Command az -ErrorAction SilentlyContinue
if (-not $azCmd) {
    Write-Log $SymErr "Azure CLI not found. Install: https://aka.ms/installazurecli" "Red"
    Write-Line
    exit 1
}
$azVersionRaw = Invoke-AzQuiet @("version", "--output", "json")
Assert-AzSuccess "az version failed"
$azVersionJson = ($azVersionRaw -join "`n") | ConvertFrom-Json
$azVersion = [string]$azVersionJson.'azure-cli'
Write-Log $SymOk "Azure CLI found: $azVersion" "Green"

# Azure CLI up to date (best effort, no hard failure)
try {
    $latest = (Invoke-RestMethod -Uri "https://pypi.org/pypi/azure-cli/json" -TimeoutSec 10).info.version
    if ([version]$azVersion -lt [version]$latest) {
        Write-Log $SymWarn "Newer Azure CLI available: $latest (run: az upgrade)" "Yellow"
    } else {
        Write-Log $SymOk "Azure CLI is up to date" "Green"
    }
} catch {
    Write-Log $SymInfo "Could not check latest Azure CLI version (run: az upgrade)"
}

# Azure login
Write-Log $SymInfo "Checking Azure login..."
$accountRaw = Invoke-AzQuiet @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Log $SymRun "No login found, starting az login..."
    & az login --output none
    Assert-AzSuccess "az login failed"
    $accountRaw = Invoke-AzQuiet @("account", "show", "--output", "json")
    Assert-AzSuccess "az account show failed after login"
}
$account = ($accountRaw -join "`n") | ConvertFrom-Json
Write-Log $SymOk ("Login found: {0}" -f $account.user.name) "Green"

& az account set --subscription $SubscriptionId --output none
Assert-AzSuccess "Could not select subscription $SubscriptionId"
Write-Log $SymOk "Subscription set: $SubscriptionId" "Green"

Write-Line
Write-Host "Script version: $ScriptVersion" -ForegroundColor White
Write-Line

$armBase     = "https://management.azure.com"
$workspaceId = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.OperationalInsights/workspaces/$WorkspaceName"
$tempDir     = Join-Path $env:TEMP ("avd-perf-norm-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

# =============================================================================
# [ WORKSPACE ]
# =============================================================================
Write-Section "WORKSPACE"
Write-Log $SymRun "Reading workspace $WorkspaceName..."
$wsRaw = Invoke-AzQuiet @("monitor", "log-analytics", "workspace", "show",
    "--resource-group", $ResourceGroupName, "--workspace-name", $WorkspaceName, "--output", "json")
Assert-AzSuccess "Workspace $WorkspaceName not found in $ResourceGroupName"
$ws = ($wsRaw -join "`n") | ConvertFrom-Json
$wsCustomerId = [string]$ws.customerId
Write-Log $SymOk "Workspace found, customerId: $wsCustomerId" "Green"
Write-Line

# =============================================================================
# [ FUNCTION Perf_Normalized ]
# =============================================================================
Write-Section "FUNCTION $FunctionAlias"

# KQL text with placeholders, replaced at runtime (source stays ASCII)
$kqlTemplate = @'
Perf
| where ObjectName in (
    "Processor Information", "Prozessorinformationen",
    "Memory", "Arbeitsspeicher",
    "User Input Delay per Session", "Benutzereingabeverz{oe}gerung pro Sitzung",
    "User Input Delay per Process", "Benutzereingabeverz{oe}gerung pro Prozess",
    "LogicalDisk", "Logischer Datentr{ae}ger",
    "PhysicalDisk", "Physikalischer Datentr{ae}ger",
    "Network Interface", "Netzwerkschnittstelle",
    "RemoteFX Graphics", "RemoteFX-Grafik",
    "System",
    "Terminal Services")
| extend ObjectName = case(
    ObjectName == "Prozessorinformationen", "Processor Information",
    ObjectName == "Arbeitsspeicher", "Memory",
    ObjectName == "Benutzereingabeverz{oe}gerung pro Sitzung", "User Input Delay per Session",
    ObjectName == "Benutzereingabeverz{oe}gerung pro Prozess", "User Input Delay per Process",
    ObjectName == "Logischer Datentr{ae}ger", "LogicalDisk",
    ObjectName == "Physikalischer Datentr{ae}ger", "PhysicalDisk",
    ObjectName == "Netzwerkschnittstelle", "Network Interface",
    ObjectName == "RemoteFX-Grafik", "RemoteFX Graphics",
    ObjectName)
| extend CounterName = case(
    CounterName == "Prozessorzeit (%)", "% Processor Time",
    CounterName == "Verf{ue}gbare MB", "Available MBytes",
    CounterName == "Zugesicherte verwendete Bytes (%)", "% Committed Bytes In Use",
    CounterName == "Zugesicherte Bytes", "Committed Bytes",
    CounterName == "Seiten/s", "Pages/sec",
    CounterName == "Seitenfehler/s", "Page Faults/sec",
    CounterName == "Max. Eingabeverz{oe}gerung", "Max Input Delay",
    CounterName == "Freier Speicherplatz (%)", "% Free Space",
    CounterName == "Aktuelle Warteschlangenl{ae}nge", "Current Disk Queue Length",
    CounterName == "Durchschnittl. Warteschlangenl{ae}nge des Datentr{ae}gers", "Avg. Disk Queue Length",
    CounterName == "Mittlere Sek./{Ue}bertragung", "Avg. Disk sec/Transfer",
    CounterName == "Mittlere Sek./Lesevorg{ae}nge", "Avg. Disk sec/Read",
    CounterName == "Mittlere Sek./Schreibvorg{ae}nge", "Avg. Disk sec/Write",
    CounterName == "Gesamtanzahl Bytes/s", "Bytes Total/sec",
    CounterName == "Prozessor-Warteschlangenl{ae}nge", "Processor Queue Length",
    CounterName == "Ausgabeframes/Sekunde", "Output Frames/Second",
    CounterName == "{Ue}bersprungene Frames/Sekunde - Unzureichende Clientressourcen", "Frames Skipped/Second - Insufficient Client Resources",
    CounterName == "{Ue}bersprungene Frames/Sekunde - Unzureichende Netzwerkressourcen", "Frames Skipped/Second - Insufficient Network Resources",
    CounterName == "{Ue}bersprungene Frames/Sekunde - Unzureichende Serverressourcen", "Frames Skipped/Second - Insufficient Server Resources",
    CounterName)
'@

$kqlFunction = $kqlTemplate.Replace("{ae}", $Ch_ae).Replace("{oe}", $Ch_oe).Replace("{ue}", $Ch_ue).Replace("{Ue}", $Ch_Ue)

$savedSearchBody = @{
    properties = @{
        category      = $FunctionCategory
        displayName   = $FunctionAlias
        functionAlias = $FunctionAlias
        query         = $kqlFunction
        version       = 2
    }
}
$savedSearchFile = Join-Path $tempDir "savedsearch.json"
Write-Utf8NoBom -Path $savedSearchFile -Content ($savedSearchBody | ConvertTo-Json -Depth 5 -Compress)

$savedSearchUrl = "$armBase$workspaceId/savedSearches/$SavedSearchId"
Write-Log $SymRun "Creating/updating saved function $FunctionAlias..."
$ssResult = Invoke-AzQuiet @("rest", "--method", "put", "--url", $savedSearchUrl,
    "--uri-parameters", "api-version=$ApiSavedSearch",
    "--body", "@$savedSearchFile", "--output", "json")
Assert-AzSuccess "Saved search PUT failed ($SavedSearchId)"
$ssJson = ($ssResult -join "`n") | ConvertFrom-Json
Write-Log $SymOk ("Function stored: {0} (alias {1})" -f $ssJson.name, $ssJson.properties.functionAlias) "Green"

# Verification query (function may take a moment to become resolvable)
Write-Log $SymRun "Verifying function with a test query..."
$testQuery = "$FunctionAlias | where TimeGenerated > ago(1h) | summarize Records = count(), Hosts = dcount(Computer) by ObjectName | order by ObjectName asc"
$verified = $false
for ($attempt = 1; $attempt -le 4; $attempt++) {
    $qRaw = Invoke-AzQuiet @("monitor", "log-analytics", "query", "--workspace", $wsCustomerId,
        "--analytics-query", $testQuery, "--output", "json")
    if ($LASTEXITCODE -eq 0) {
        $verified = $true
        break
    }
    Write-Log $SymInfo "Function not resolvable yet, retry $attempt/4 in 15s..."
    Start-Sleep -Seconds 15
}
if ($verified) {
    $qRows = ($qRaw -join "`n") | ConvertFrom-Json
    Write-Log $SymOk ("Function resolves. Objects in last hour: {0}" -f @($qRows).Count) "Green"
    foreach ($row in $qRows) {
        Write-Host ("    {0,-32} Records: {1,8}  Hosts: {2,4}" -f $row.ObjectName, $row.Records, $row.Hosts) -ForegroundColor Cyan
    }
} else {
    Write-Log $SymWarn "Function stored but test query failed. Check later in Logs: $FunctionAlias | take 10" "Yellow"
}
Write-Line

# =============================================================================
# [ WORKBOOK ]
# =============================================================================
Write-Section "WORKBOOK"
if (-not $DeployWorkbook) {
    Write-Log $SymInfo "DeployWorkbook = false, skipping"
} elseif (-not (Test-Path $WorkbookJsonPath)) {
    Write-Log $SymErr "Workbook JSON not found: $WorkbookJsonPath" "Red"
} else {
    $workbookJson = Get-Content -Path $WorkbookJsonPath -Raw -Encoding UTF8
    # Validate it is JSON before sending
    $null = $workbookJson | ConvertFrom-Json
    Write-Log $SymOk ("Workbook JSON loaded ({0} chars)" -f $workbookJson.Length) "Green"

    # Look up existing workbook by display name
    Write-Log $SymRun "Looking for existing workbook '$WorkbookDisplayName' in $ResourceGroupName..."
    $listUrl = "$armBase/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Insights/workbooks"
    $listRaw = Invoke-AzQuiet @("rest", "--method", "get", "--url", $listUrl,
        "--uri-parameters", "api-version=$ApiWorkbook", "category=workbook",
        "--output", "json")
    Assert-AzSuccess "Could not list workbooks in $ResourceGroupName"
    $listJson = ($listRaw -join "`n") | ConvertFrom-Json
    $existing = @($listJson.value | Where-Object { $_.properties.displayName -eq $WorkbookDisplayName })

    if ($existing.Count -gt 1) {
        Write-Log $SymErr ("{0} workbooks with display name '{1}' found, cannot decide which to update" -f $existing.Count, $WorkbookDisplayName) "Red"
        Write-Line
        exit 1
    }
    if ($existing.Count -eq 1) {
        $workbookName = [string]$existing[0].name
        $workbookLocation = [string]$existing[0].location
        Write-Log $SymInfo "Existing workbook found, will update: $workbookName"
    } else {
        $workbookName = [guid]::NewGuid().ToString()
        $workbookLocation = $Location
        Write-Log $SymInfo "No existing workbook, will create: $workbookName"
    }

    $workbookBody = @{
        location = $workbookLocation
        kind     = "shared"
        properties = @{
            displayName    = $WorkbookDisplayName
            category       = "workbook"
            sourceId       = "azure monitor"
            version        = "Notebook/1.0"
            serializedData = $workbookJson
        }
    }
    $workbookFile = Join-Path $tempDir "workbook.json"
    Write-Utf8NoBom -Path $workbookFile -Content ($workbookBody | ConvertTo-Json -Depth 5 -Compress)

    $wbUrl = "$armBase/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Insights/workbooks/$workbookName"
    Write-Log $SymRun "Deploying workbook..."
    $wbResult = Invoke-AzQuiet @("rest", "--method", "put", "--url", $wbUrl,
        "--uri-parameters", "api-version=$ApiWorkbook",
        "--body", "@$workbookFile", "--output", "json")
    Assert-AzSuccess "Workbook PUT failed ($workbookName)"
    $wbJson = ($wbResult -join "`n") | ConvertFrom-Json
    Write-Log $SymOk ("Workbook deployed: {0}" -f $wbJson.properties.displayName) "Green"
    Write-Host ("    Resource: {0}" -f $wbJson.id) -ForegroundColor Cyan
}
Write-Line

# =============================================================================
# [ CLEANUP ]
# =============================================================================
Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Log $SymOk "Done" "Green"
Write-Line
