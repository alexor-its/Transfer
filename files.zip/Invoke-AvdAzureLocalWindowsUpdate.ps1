﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Windows Update Runbook fuer Azure Virtual Desktop Session Hosts auf Azure Local
    mit Koexistenz zu nativen AVD Scaling Plans (Power Management Autoscale).
.DESCRIPTION
    Das Runbook laeuft auf einem Azure Automation Hybrid Runbook Worker und patcht
    die Session Hosts der konfigurierten Host Pools per Azure Arc Run Command.

    Ablauf pro Host Pool:
      1. Scaling Plan fuer den Host Pool deaktivieren (nur wenn aktiv, Zustand wird gemerkt)
      2. Session Hosts des Host Pools ermitteln und auf die Arc-Maschine mappen
      3. Power-State der Azure Local VMs ermitteln, ausgeschaltete Hosts parallel starten
      4. Auf Azure Arc Verbindung warten
      5. Hosts mit aktiven Sessions ueberspringen, alle anderen in Drain Mode setzen
      6. Windows Update per Arc Run Command in Batches parallel ausfuehren
      7. Bei RebootRequired: Neustart ueber die Azure Local VM API, auf Arc warten
      8. Drain Mode auf den vorherigen Zustand zuruecksetzen
      9. Hosts, die vom Runbook gestartet wurden, wieder herunterfahren
     10. Scaling Plan wieder aktivieren (auch im Fehlerfall ueber finally)
     11. HTML Report per Mail versenden

    Authentifizierung: Managed Identity des Hybrid Workers (Standard) oder
    Service Principal mit Secret aus einer verschluesselten Automation Variable.

    Alle Azure Aufrufe erfolgen ueber die Azure CLI: az stack-hci-vm (Azure Local VMs),
    az rest (AVD Session Hosts, Scaling Plan, Arc, Run Commands). Es werden keine
    Az PowerShell Module benoetigt.

    Azure Automation: Im Runbook "Log verbose records" aktivieren, damit die
    Detailmeldungen aus den Funktionen (Warteschleifen, Statuswechsel) in der
    Job-Historie erscheinen. Der Hauptablauf und die Zusammenfassung stehen immer
    im Output-Stream, Warnungen und Fehler in den jeweiligen Streams.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 24.09.2026
    Version     : 3.1.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Versionshistorie
      3.1.0  Fix: Log-Ausgabe im Azure Automation Job verfaelschte Funktions-
             Rueckgabewerte (Write-Output in Funktionen). Jetzt Output-Stream nur
             aus dem Hauptablauf, Verbose-Stream aus Funktionen, Warning-/Error-
             Stream fuer Warnungen und Fehler.
             Azure Local VM Start/Stop/Restart/Show ueber die GA Extension
             az stack-hci-vm statt az rest (sauberer Guest-Shutdown, offizieller
             Supportpfad). Extension-Pruefung im Pre-Check.
      3.0.1  Identitaetsdiagnose im Pre-Check (oid/appid des Tokens, MI-Umgebungsvariablen)
      3.0.0  Neuentwicklung: Autoscale-Koexistenz (Scaling Plan disable/enable),
             Start/Patch/Stop ueber Azure Local VM API, Drain Mode, Skip bei
             aktiven Sessions, parallele Run Commands in Batches, Managed Identity,
             korrigierter Fehlerblock im Report, Run Command Cleanup.
      2.0.0  Vorgaengerversion (sequentiell, Service Principal, Tag-basierte Discovery)

    Benoetigte RBAC fuer die Identitaet (Subscription- oder RG-Scope):
      - Azure Connected Machine Resource Administrator   (Arc Run Commands)
      - Azure Stack HCI VM Contributor                   (Start/Stop/Restart der VMs)
      - Desktop Virtualization Session Host Operator     (Drain Mode)
      - Desktop Virtualization Contributor auf dem Scaling Plan (Enable/Disable)
.EXAMPLE
    .\Invoke-AvdAzureLocalWindowsUpdate.ps1
#>

# =========================================================================
# [ GRUNDEINSTELLUNGEN ]
# =========================================================================

$ScriptVersion  = "3.1.0"
$ScriptName     = "Invoke-AvdAzureLocalWindowsUpdate"

# "Compat" = Windows PowerShell 5.1 und PowerShell 7.x
# "Seven"  = nur PowerShell 7.x (Abbruch unter 5.1)
$PowerShellMode = "Compat"

$ErrorActionPreference = "Continue"

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =========================================================================
# [ PARAMETER ]  (alle Werte hier hinterlegen, kein Aufruf mit Parametern)
# =========================================================================

# --- Azure ---------------------------------------------------------------
$SubscriptionId = "33207861-9482-4afb-9786-eba3a0265bef"

# Region fuer Arc Run Command Ressourcen (Region der Arc-Maschinen)
$ArcLocation = "westeurope"

# --- Authentifizierung ---------------------------------------------------
# "ManagedIdentity"  : System-assigned MI des Hybrid Workers (az login --identity)
# "ServicePrincipal" : Secret aus verschluesselter Automation Variable (kein Secret im Code)
$AuthMode = "ManagedIdentity"

# Nur bei User-assigned Managed Identity: Client ID eintragen, sonst leer lassen
$ManagedIdentityClientId = ""

# Nur bei AuthMode = ServicePrincipal (Werte aus Automation Variables)
$SpTenantIdVariable     = "AVDPatch-TenantId"
$SpClientIdVariable     = "AVDPatch-ClientId"
$SpClientSecretVariable = "AVDPatch-ClientSecret"

# --- Host Pools ----------------------------------------------------------
# Pro Host Pool ein Eintrag. Scaling Plan liegt in rg-AVDmgmt.
# SessionHostResourceGroup = Resource Group der Arc-Maschinen / Azure Local VMs
# (wird nur als Fallback genutzt, wenn der Session Host keine resourceId liefert)
$HostPools = @(
    @{
        Name                     = "<HOSTPOOL-NAME>"
        ResourceGroup            = "<HOSTPOOL-RG>"
        SessionHostResourceGroup = "rg-AzLocalkkr4-AVD-SessionHosts"
        ScalingPlanName          = "<SCALINGPLAN-NAME>"
        ScalingPlanResourceGroup = "rg-AVDmgmt"
    }
)

# --- Verhalten -----------------------------------------------------------
$DryRun                     = $false   # $true = nur ermitteln und anzeigen, keine Aenderungen
$BatchSize                  = 10       # Hosts, die gleichzeitig gepatcht werden
$SkipHostsWithSessions      = $true    # Hosts mit aktiven/getrennten Sessions ueberspringen
$RebootBeforeStop           = $true    # vom Runbook gestartete Hosts vor dem Stop neu starten, wenn noetig
$StopHostsStartedByRunbook  = $true    # Hosts, die vorher aus waren, wieder herunterfahren
$CleanupRunCommands         = $true    # Run Command Ressourcen nach Auswertung loeschen

# --- Zeitlimits (Sekunden) ---------------------------------------------
$MaxRuntimeMinutes          = 180
$RunCommandTimeoutSeconds   = 3600     # Timeout im Run Command selbst
$RunCommandPollSeconds      = 20
$VmPowerTimeoutSeconds      = 600      # Warten auf Running/Stopped nach Start/Stop
$VmPowerPollSeconds         = 15
$ArcConnectTimeoutSeconds   = 900      # Warten auf Arc "Connected"
$ArcConnectPollSeconds      = 15
$RebootSettleSeconds        = 60       # Wartezeit nach Restart, bevor Arc geprueft wird

# --- API Versionen -------------------------------------------------------
$ApiVersionAvd       = "2024-04-03"   # Microsoft.DesktopVirtualization
$ApiVersionArc       = "2024-07-10"   # Microsoft.HybridCompute/machines
$ApiVersionRunCmd    = "2025-01-13"   # Microsoft.HybridCompute/machines/runCommands

# --- Mail ----------------------------------------------------------------
$SmtpServer   = "10.130.0.3"
$MailFrom     = "AzureAutomation@lahn-dill-kreis.de"
$MailTo       = @("basis@lahn-dill-kreis.de")
$MailSubjectPrefix = "Windows Updates AVD Azure Local"
$SendMail     = $true

# --- Azure CLI -----------------------------------------------------------
$MinAzCliVersion = "2.70.0"
$RequiredExtensions = @("stack-hci-vm")   # GA Extension fuer Azure Local VM Start/Stop/Restart/Show
$UpdateExtensions   = $false              # $true = Extensions bei jedem Lauf auf den neuesten Stand bringen
# Fester Extension-Pfad, damit Extensions nicht im temporaeren AZURE_CONFIG_DIR landen
# und bei jedem Lauf neu installiert werden muessen
$AzExtensionDir     = Join-Path $env:ProgramData "AzureCLI\cliextensions"

# =========================================================================
# [ LAUFZEITVARIABLEN ]  (nicht aendern)
# =========================================================================

$RunbookStart      = Get-Date
$AllHosts          = New-Object System.Collections.ArrayList
$ScalingPlanChanges = New-Object System.Collections.ArrayList
$RunbookFatalError = $null
$AzConfigDir       = Join-Path $env:TEMP ("AzureCLI_" + $PID)
$TempDir           = Join-Path $env:TEMP ("AvdPatch_" + $PID)
$LoggedIn          = $false

# Ausgabe-Modus:
#   "Host"       : interaktiv, Write-Host mit Farben
#   "Automation" : Azure Automation Job. Write-Host wird dort nicht angezeigt.
#                  Meldungen aus dem Hauptablauf gehen in den Output-Stream,
#                  Meldungen aus Funktionen in den Verbose-Stream (sonst wuerden
#                  sie den Rueckgabewert der Funktion verfaelschen), Warnungen und
#                  Fehler in den Warning-/Error-Stream.
#                  Im Runbook "Log verbose records" aktivieren, damit die
#                  Verbose-Zeilen in der Job-Historie erscheinen.
$script:LogMode = "Host"
$AutomationMeta = Get-Variable -Name PSPrivateMetadata -ErrorAction SilentlyContinue
if ($AutomationMeta -and $AutomationMeta.Value -and $AutomationMeta.Value.JobId)
{
    $script:LogMode = "Automation"
    $VerbosePreference = "Continue"
}
$script:BaseStackDepth = (Get-PSCallStack).Count

# =========================================================================
# [ HILFSFUNKTIONEN ]
# =========================================================================

function Write-Log
{
    param(
        [string]$Message = "",
        [ValidateSet("Ok", "Err", "Warn", "Info", "Run", "Head", "Sep", "Plain")]
        [string]$Level = "Info",
        [int]$Indent = 0
    )

    $Symbol = ""
    $Color  = "White"

    switch ($Level)
    {
        "Ok"    { $Symbol = $SymOk;   $Color = "Green" }
        "Err"   { $Symbol = $SymErr;  $Color = "Red" }
        "Warn"  { $Symbol = $SymWarn; $Color = "Yellow" }
        "Info"  { $Symbol = $SymInfo; $Color = "Cyan" }
        "Run"   { $Symbol = $SymRun;  $Color = "Cyan" }
        "Head"  { $Color = "White" }
        "Sep"   { $Color = "White" }
        "Plain" { $Color = "Gray" }
    }

    $Pad = ""
    if ($Indent -gt 0) { $Pad = (" " * (4 * $Indent)) }

    $Line = ""
    if ($Level -eq "Sep")
    {
        $Line = ("=" * 60)
    }
    elseif ($Level -eq "Head")
    {
        $Line = "[ $Message ]"
    }
    elseif ($Level -eq "Plain")
    {
        $Line = $Pad + $Message
    }
    else
    {
        $Stamp = "[" + (Get-Date -Format "HH:mm:ss") + "] "
        $Line  = $Stamp + $Pad + $Symbol + "  " + $Message
    }

    if ($script:LogMode -ne "Automation")
    {
        Write-Host $Line -ForegroundColor $Color
        return
    }

    # Azure Automation: Streams nach Level und Aufrufort waehlen
    if ($Level -eq "Warn")
    {
        Write-Warning -Message $Line
        return
    }
    if ($Level -eq "Err")
    {
        Write-Error -Message $Line
        return
    }

    # Aufruf direkt aus dem Skript (nicht aus einer Funktion)?
    $Depth = (Get-PSCallStack).Count
    if ($Depth -le ($script:BaseStackDepth + 1))
    {
        Write-Output $Line
    }
    else
    {
        Write-Verbose -Message $Line -Verbose
    }
}

function Invoke-AzQuiet
{
    <#
        Fuehrt az mit Argument-Array aus, unterdrueckt stderr auf der Konsole,
        liefert ExitCode, Output (Text), Data (JSON-Objekt bei -AsJson) und Error (stderr-Text).
    #>
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [switch]$AsJson
    )

    $ErrFile = Join-Path $TempDir ("az_err_" + [guid]::NewGuid().ToString("N") + ".txt")
    $Raw = $null

    $Raw = & az @Arguments 2> $ErrFile
    $Code = $LASTEXITCODE

    $ErrText = ""
    if (Test-Path $ErrFile)
    {
        $ErrText = (Get-Content $ErrFile -Raw -ErrorAction SilentlyContinue)
        Remove-Item $ErrFile -Force -ErrorAction SilentlyContinue
    }
    if ($null -eq $ErrText) { $ErrText = "" }
    $ErrText = $ErrText.Trim()

    $Text = ""
    if ($null -ne $Raw)
    {
        $Text = ($Raw | Out-String)
    }
    $Text = $Text.Trim()

    $Data = $null
    if ($AsJson -and $Code -eq 0 -and $Text.Length -gt 0)
    {
        try
        {
            $Data = $Text | ConvertFrom-Json
        }
        catch
        {
            $Data = $null
        }
    }

    return [PSCustomObject]@{
        ExitCode = $Code
        Output   = $Text
        Data     = $Data
        Error    = $ErrText
    }
}

function Assert-AzSuccess
{
    <#
        Prueft das Ergebnis eines Invoke-AzQuiet Aufrufs. Liefert $true/$false.
        Mit -Fatal wird ein Fehler geworfen.
    #>
    param(
        [Parameter(Mandatory = $true)]$Result,
        [Parameter(Mandatory = $true)][string]$Context,
        [switch]$Fatal,
        [int]$Indent = 1
    )

    if ($Result.ExitCode -eq 0)
    {
        return $true
    }

    $Detail = $Result.Error
    if (-not $Detail) { $Detail = $Result.Output }
    if ($Detail -and $Detail.Length -gt 400) { $Detail = $Detail.Substring(0, 400) + "..." }

    Write-Log -Level Err -Indent $Indent -Message ("{0} fehlgeschlagen (ExitCode {1}): {2}" -f $Context, $Result.ExitCode, $Detail)

    if ($Fatal)
    {
        throw "$Context fehlgeschlagen (ExitCode $($Result.ExitCode))."
    }

    return $false
}

function Invoke-AzRest
{
    <#
        az rest Wrapper. Body wird als Datei uebergeben (Encoding-sicher).
    #>
    param(
        [Parameter(Mandatory = $true)][ValidateSet("GET", "PUT", "PATCH", "POST", "DELETE")][string]$Method,
        [Parameter(Mandatory = $true)][string]$Url,
        $Body = $null
    )

    $AzArgs = @("rest", "--method", $Method, "--url", $Url, "--output", "json")

    $BodyFile = $null
    if ($null -ne $Body)
    {
        $BodyFile = Join-Path $TempDir ("body_" + [guid]::NewGuid().ToString("N") + ".json")
        $Json = $Body | ConvertTo-Json -Depth 20
        [System.IO.File]::WriteAllText($BodyFile, $Json, (New-Object System.Text.UTF8Encoding($false)))
        $AzArgs += @("--body", ("@" + $BodyFile))
    }

    $Result = Invoke-AzQuiet -Arguments $AzArgs -AsJson

    if ($BodyFile -and (Test-Path $BodyFile))
    {
        Remove-Item $BodyFile -Force -ErrorAction SilentlyContinue
    }

    return $Result
}

function Get-ArmUrl
{
    param([Parameter(Mandatory = $true)][string]$ResourceId, [Parameter(Mandatory = $true)][string]$ApiVersion)
    return ("https://management.azure.com{0}?api-version={1}" -f $ResourceId, $ApiVersion)
}

function Test-RuntimeExceeded
{
    $Elapsed = (Get-Date) - $RunbookStart
    return ($Elapsed.TotalMinutes -ge $MaxRuntimeMinutes)
}

function Get-RuntimeMinutes
{
    return [math]::Round(((Get-Date) - $RunbookStart).TotalMinutes, 2)
}

function Test-PlaceholderValue
{
    param([string]$Value)
    if (-not $Value) { return $true }
    if ($Value -match "^<.*>$") { return $true }
    return $false
}

function Compare-Version
{
    # -1 wenn A < B, 0 wenn gleich, 1 wenn A > B
    param([string]$A, [string]$B)
    try
    {
        $VA = [version]$A
        $VB = [version]$B
        return $VA.CompareTo($VB)
    }
    catch
    {
        return 0
    }
}

# --- AVD -----------------------------------------------------------------

function Get-HostPoolArmPath
{
    param($Pool)
    return ("/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.DesktopVirtualization/hostPools/{2}" -f $SubscriptionId, $Pool.ResourceGroup, $Pool.Name)
}

function Get-ScalingPlanId
{
    param($Pool)
    return ("/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.DesktopVirtualization/scalingPlans/{2}" -f $SubscriptionId, $Pool.ScalingPlanResourceGroup, $Pool.ScalingPlanName)
}

function Set-ScalingPlanHostPoolState
{
    <#
        Setzt scalingPlanEnabled fuer genau einen Host Pool im Scaling Plan.
        Liefert den vorherigen Zustand ($true/$false) oder $null, wenn der
        Host Pool dem Plan nicht zugewiesen ist.
    #>
    param(
        [Parameter(Mandatory = $true)]$Pool,
        [Parameter(Mandatory = $true)][bool]$Enabled
    )

    $PlanId  = Get-ScalingPlanId -Pool $Pool
    $PlanUrl = Get-ArmUrl -ResourceId $PlanId -ApiVersion $ApiVersionAvd
    $HpPath  = Get-HostPoolArmPath -Pool $Pool

    $Get = Invoke-AzRest -Method GET -Url $PlanUrl
    if (-not (Assert-AzSuccess -Result $Get -Context "Scaling Plan lesen ($($Pool.ScalingPlanName))"))
    {
        return $null
    }

    $Refs = @()
    if ($Get.Data.properties -and $Get.Data.properties.hostPoolReferences)
    {
        $Refs = @($Get.Data.properties.hostPoolReferences)
    }

    $Previous = $null
    $NewRefs  = @()

    foreach ($Ref in $Refs)
    {
        if ($Ref.hostPoolArmPath -and ($Ref.hostPoolArmPath.ToLower() -eq $HpPath.ToLower()))
        {
            $Previous = [bool]$Ref.scalingPlanEnabled
            $NewRefs += @{
                hostPoolArmPath    = $Ref.hostPoolArmPath
                scalingPlanEnabled = $Enabled
            }
        }
        else
        {
            $NewRefs += @{
                hostPoolArmPath    = $Ref.hostPoolArmPath
                scalingPlanEnabled = [bool]$Ref.scalingPlanEnabled
            }
        }
    }

    if ($null -eq $Previous)
    {
        Write-Log -Level Warn -Indent 1 -Message "Host Pool $($Pool.Name) ist dem Scaling Plan $($Pool.ScalingPlanName) nicht zugewiesen."
        return $null
    }

    if ($Previous -eq $Enabled)
    {
        return $Previous
    }

    $Body = @{ properties = @{ hostPoolReferences = $NewRefs } }
    $Patch = Invoke-AzRest -Method PATCH -Url $PlanUrl -Body $Body
    if (-not (Assert-AzSuccess -Result $Patch -Context "Scaling Plan aktualisieren ($($Pool.ScalingPlanName))"))
    {
        return $null
    }

    return $Previous
}

function Get-SessionHosts
{
    param($Pool)

    $HpPath = Get-HostPoolArmPath -Pool $Pool
    $Url = Get-ArmUrl -ResourceId ($HpPath + "/sessionHosts") -ApiVersion $ApiVersionAvd

    $Result = Invoke-AzRest -Method GET -Url $Url
    if (-not (Assert-AzSuccess -Result $Result -Context "Session Hosts lesen ($($Pool.Name))"))
    {
        return $null
    }

    $Items = @()
    if ($Result.Data.value) { $Items = @($Result.Data.value) }
    return $Items
}

function Set-SessionHostAllowNewSession
{
    param(
        [Parameter(Mandatory = $true)]$HostEntry,
        [Parameter(Mandatory = $true)][bool]$Allow
    )

    $Url = Get-ArmUrl -ResourceId $HostEntry.SessionHostId -ApiVersion $ApiVersionAvd
    $Body = @{ properties = @{ allowNewSession = $Allow } }
    $Result = Invoke-AzRest -Method PATCH -Url $Url -Body $Body
    return (Assert-AzSuccess -Result $Result -Context "Drain Mode setzen ($($HostEntry.ArcName), allowNewSession=$Allow)")
}

function Get-SessionHostSessionCount
{
    param([Parameter(Mandatory = $true)]$HostEntry)

    $Url = Get-ArmUrl -ResourceId $HostEntry.SessionHostId -ApiVersion $ApiVersionAvd
    $Result = Invoke-AzRest -Method GET -Url $Url
    if ($Result.ExitCode -ne 0 -or -not $Result.Data) { return -1 }

    $Count = 0
    if ($null -ne $Result.Data.properties.sessions) { $Count = [int]$Result.Data.properties.sessions }
    return $Count
}

# --- Azure Local VM / Arc ------------------------------------------------

function Get-AzLocalVmPowerState
{
    <#
        Liefert Running / Stopped / Deallocated / Paused / Saved / Starting / Stopping / Unknown
        Quelle: az stack-hci-vm show (Extension stack-hci-vm, GA)
    #>
    param($HostEntry)

    $Result = Invoke-AzQuiet -Arguments @("stack-hci-vm", "show", "--name", $HostEntry.ArcName, "--resource-group", $HostEntry.ArcRg, "--output", "json") -AsJson

    if ($Result.ExitCode -ne 0 -or -not $Result.Data)
    {
        return "Unknown"
    }

    $D = $Result.Data
    $State = $null
    if ($D.properties -and $D.properties.status -and $D.properties.status.powerState)
    {
        $State = $D.properties.status.powerState
    }
    elseif ($D.status -and $D.status.powerState)
    {
        $State = $D.status.powerState
    }
    if (-not $State) { $State = "Unknown" }
    return [string]$State
}

function Invoke-AzLocalVmAction
{
    <#
        start / stop / restart ueber az stack-hci-vm (GA). Die Befehle blockieren,
        bis der Vorgang abgeschlossen ist. stop faehrt das Gastsystem sauber herunter
        (kein --skip-shutdown).
    #>
    param(
        [Parameter(Mandatory = $true)]$HostEntry,
        [Parameter(Mandatory = $true)][ValidateSet("start", "stop", "restart")][string]$Action
    )

    $AzArgs = @("stack-hci-vm", $Action, "--name", $HostEntry.ArcName, "--resource-group", $HostEntry.ArcRg, "--output", "none")
    $Result = Invoke-AzQuiet -Arguments $AzArgs
    return (Assert-AzSuccess -Result $Result -Context ("VM {0} ({1})" -f $Action, $HostEntry.ArcName))
}

function Wait-AzLocalVmPowerState
{
    <#
        Wartet parallel fuer eine Liste von Hosts auf den Zielzustand.
        Liefert die Liste der Hosts, die den Zustand NICHT erreicht haben.
    #>
    param(
        $Entries = @(),
        [Parameter(Mandatory = $true)][string]$TargetState,
        [int]$TimeoutSeconds = $VmPowerTimeoutSeconds
    )

    $Pending = New-Object System.Collections.ArrayList
    if ($null -ne $Entries) { foreach ($E in @($Entries)) { [void]$Pending.Add($E) } }

    $Elapsed = 0
    while ($Pending.Count -gt 0 -and $Elapsed -lt $TimeoutSeconds)
    {
        if (Test-RuntimeExceeded) { break }

        Start-Sleep -Seconds $VmPowerPollSeconds
        $Elapsed += $VmPowerPollSeconds

        $Done = @()
        foreach ($E in $Pending)
        {
            $State = Get-AzLocalVmPowerState -HostEntry $E
            $E.PowerStateCurrent = $State
            if ($State -eq $TargetState)
            {
                $Done += $E
                Write-Log -Level Ok -Indent 1 -Message ("{0}: {1} ({2}s)" -f $E.ArcName, $State, $Elapsed)
            }
        }
        foreach ($D in $Done) { $Pending.Remove($D) }

        if ($Pending.Count -gt 0)
        {
            Write-Log -Level Run -Indent 1 -Message ("Warte auf {0}: {1} Host(s) ausstehend ({2}s)" -f $TargetState, $Pending.Count, $Elapsed)
        }
    }

    return @($Pending)
}

function Get-ArcStatus
{
    param($HostEntry)

    $Url = Get-ArmUrl -ResourceId $HostEntry.ArcMachineId -ApiVersion $ApiVersionArc
    $Result = Invoke-AzRest -Method GET -Url $Url
    if ($Result.ExitCode -ne 0 -or -not $Result.Data) { return "Unknown" }

    $Status = $null
    if ($Result.Data.properties -and $Result.Data.properties.status) { $Status = $Result.Data.properties.status }
    if (-not $Status) { $Status = "Unknown" }
    return [string]$Status
}

function Wait-ArcConnected
{
    <#
        Wartet parallel, bis alle uebergebenen Hosts Arc-Status "Connected" melden.
        Liefert die Liste der Hosts, die es nicht geschafft haben.
    #>
    param(
        $Entries = @(),
        [int]$TimeoutSeconds = $ArcConnectTimeoutSeconds
    )

    $Pending = New-Object System.Collections.ArrayList
    if ($null -ne $Entries) { foreach ($E in @($Entries)) { [void]$Pending.Add($E) } }

    $Elapsed = 0
    while ($Pending.Count -gt 0 -and $Elapsed -lt $TimeoutSeconds)
    {
        if (Test-RuntimeExceeded) { break }

        Start-Sleep -Seconds $ArcConnectPollSeconds
        $Elapsed += $ArcConnectPollSeconds

        $Done = @()
        foreach ($E in $Pending)
        {
            $Status = Get-ArcStatus -HostEntry $E
            if ($Status -eq "Connected")
            {
                $Done += $E
                Write-Log -Level Ok -Indent 1 -Message ("{0}: Arc Connected ({1}s)" -f $E.ArcName, $Elapsed)
            }
        }
        foreach ($D in $Done) { $Pending.Remove($D) }

        if ($Pending.Count -gt 0)
        {
            Write-Log -Level Run -Indent 1 -Message ("Warte auf Arc: {0} Host(s) ausstehend ({1}s)" -f $Pending.Count, $Elapsed)
        }
    }

    return @($Pending)
}

# --- Run Command ---------------------------------------------------------

function New-RunCommandUrl
{
    param($HostEntry, [string]$RunCommandName)
    return (Get-ArmUrl -ResourceId ($HostEntry.ArcMachineId + "/runCommands/" + $RunCommandName) -ApiVersion $ApiVersionRunCmd)
}

function Start-WindowsUpdateRunCommand
{
    param($HostEntry)

    $Name = "ArcWU_" + (Get-Date -Format "yyyyMMddHHmmss") + "_" + $HostEntry.ArcName
    $Url  = New-RunCommandUrl -HostEntry $HostEntry -RunCommandName $Name

    $Body = @{
        location   = $ArcLocation
        properties = @{
            timeoutInSeconds = $RunCommandTimeoutSeconds
            source           = @{ script = $UpdatePayload }
        }
    }

    $Result = Invoke-AzRest -Method PUT -Url $Url -Body $Body
    if (-not (Assert-AzSuccess -Result $Result -Context "Run Command erstellen ($($HostEntry.ArcName))"))
    {
        return $false
    }

    $HostEntry.RunCommandName = $Name
    $HostEntry.RunCommandUrl  = $Url
    $HostEntry.PatchStart     = Get-Date
    return $true
}

function Get-RunCommandState
{
    param($HostEntry)

    $Result = Invoke-AzRest -Method GET -Url $HostEntry.RunCommandUrl
    if ($Result.ExitCode -ne 0 -or -not $Result.Data)
    {
        return [PSCustomObject]@{ ExecutionState = "Unknown"; ProvisioningState = "Unknown"; Output = ""; Error = "" }
    }

    $Exec = "Unknown"
    $Prov = "Unknown"
    $Out  = ""
    $Err  = ""

    if ($Result.Data.properties)
    {
        if ($Result.Data.properties.provisioningState) { $Prov = $Result.Data.properties.provisioningState }
        if ($Result.Data.properties.instanceView)
        {
            $IV = $Result.Data.properties.instanceView
            if ($IV.executionState) { $Exec = $IV.executionState }
            if ($IV.output) { $Out = [string]$IV.output }
            if ($IV.error) { $Err = [string]$IV.error }
        }
    }

    return [PSCustomObject]@{ ExecutionState = $Exec; ProvisioningState = $Prov; Output = $Out; Error = $Err }
}

function Remove-RunCommand
{
    param($HostEntry)
    if (-not $HostEntry.RunCommandUrl) { return }
    $Result = Invoke-AzRest -Method DELETE -Url $HostEntry.RunCommandUrl
    if ($Result.ExitCode -ne 0)
    {
        Write-Log -Level Warn -Indent 1 -Message "Run Command $($HostEntry.RunCommandName) konnte nicht geloescht werden."
    }
}

function Set-HostResult
{
    param($HostEntry, [string]$Action, [string]$Status, [string]$Message = "")
    $HostEntry.Action  = $Action
    $HostEntry.Status  = $Status
    $HostEntry.Message = $Message
}

function Read-UpdateResult
{
    <#
        Parst das JSON aus der Run Command Ausgabe in den Host Eintrag.
    #>
    param($HostEntry, [string]$OutputText)

    if (-not $OutputText)
    {
        Set-HostResult -HostEntry $HostEntry -Action "Failed" -Status "NoOutput" -Message "Keine Ausgabe vom Run Command erhalten"
        $HostEntry.FailedCount = 1
        return
    }

    $JsonStart = $OutputText.IndexOf("{")
    $JsonEnd   = $OutputText.LastIndexOf("}")
    if ($JsonStart -lt 0 -or $JsonEnd -lt $JsonStart)
    {
        Set-HostResult -HostEntry $HostEntry -Action "Failed" -Status "NoJson" -Message "Kein JSON Ergebnis in der Ausgabe"
        $HostEntry.FailedCount = 1
        return
    }

    $Json = $OutputText.Substring($JsonStart, ($JsonEnd - $JsonStart + 1))
    $Data = $null
    try
    {
        $Data = $Json | ConvertFrom-Json
    }
    catch
    {
        Set-HostResult -HostEntry $HostEntry -Action "Failed" -Status "JsonError" -Message "JSON Ergebnis nicht lesbar (evtl. Ausgabe abgeschnitten)"
        $HostEntry.FailedCount = 1
        return
    }

    $Installed = @()
    if ($Data.InstalledUpdates) { $Installed = @($Data.InstalledUpdates) }
    $Failed = @()
    if ($Data.FailedUpdates) { $Failed = @($Data.FailedUpdates) }

    $HostEntry.UpdatesFound     = [int]$Data.UpdatesFound
    $HostEntry.InstalledCount   = $Installed.Count
    $HostEntry.FailedCount      = $Failed.Count
    $HostEntry.RebootRequired   = [bool]$Data.RebootRequired
    $HostEntry.InstalledUpdates = @($Installed | ForEach-Object { [string]$_.Title })
    $HostEntry.FailedUpdates    = @($Failed | ForEach-Object { [string]$_ })

    $Status = [string]$Data.Status
    switch ($Status)
    {
        "NoUpdates"           { Set-HostResult -HostEntry $HostEntry -Action "NoUpdates" -Status $Status }
        "Completed"           { Set-HostResult -HostEntry $HostEntry -Action "Patched"   -Status $Status }
        "CompletedWithErrors" { Set-HostResult -HostEntry $HostEntry -Action "Failed"    -Status $Status -Message ("Fehlgeschlagene Updates: " + ($HostEntry.FailedUpdates -join "; ")) }
        default
        {
            $Msg = [string]$Data.Error
            Set-HostResult -HostEntry $HostEntry -Action "Failed" -Status $Status -Message $Msg
            if ($HostEntry.FailedCount -eq 0) { $HostEntry.FailedCount = 1 }
        }
    }
}

function New-HostEntry
{
    param($Pool, $SessionHost)

    $FullName = [string]$SessionHost.name
    $Fqdn = $FullName
    if ($FullName.Contains("/")) { $Fqdn = $FullName.Split("/")[-1] }

    $ShortName = $Fqdn
    if ($Fqdn.Contains(".")) { $ShortName = $Fqdn.Split(".")[0] }
    $ShortName = $ShortName.ToUpper()

    $ArcId = $null
    $ArcRg = $Pool.SessionHostResourceGroup
    $ArcName = $ShortName

    $ResId = $null
    if ($SessionHost.properties -and $SessionHost.properties.resourceId) { $ResId = [string]$SessionHost.properties.resourceId }

    if ($ResId -and ($ResId -match "(?i)/providers/Microsoft\.HybridCompute/machines/([^/]+)"))
    {
        $ArcName = $Matches[1]
        $ArcId   = $ResId
        if ($ResId -match "(?i)/resourceGroups/([^/]+)/") { $ArcRg = $Matches[1] }
    }
    else
    {
        $ArcId = "/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.HybridCompute/machines/{2}" -f $SubscriptionId, $ArcRg, $ArcName
    }

    $Allow = $true
    if ($null -ne $SessionHost.properties.allowNewSession) { $Allow = [bool]$SessionHost.properties.allowNewSession }

    $Sessions = 0
    if ($null -ne $SessionHost.properties.sessions) { $Sessions = [int]$SessionHost.properties.sessions }

    $AvdStatus = ""
    if ($SessionHost.properties.status) { $AvdStatus = [string]$SessionHost.properties.status }

    $ShId = (Get-HostPoolArmPath -Pool $Pool) + "/sessionHosts/" + $Fqdn

    return [PSCustomObject]@{
        HostPool              = $Pool.Name
        HostPoolRg            = $Pool.ResourceGroup
        SessionHostFqdn       = $Fqdn
        SessionHostId         = $ShId
        ArcName               = $ArcName
        ArcRg                 = $ArcRg
        ArcMachineId          = $ArcId
        AvdStatus             = $AvdStatus
        AllowNewSessionBefore = $Allow
        DrainedByRunbook      = $false
        Sessions              = $Sessions
        PowerStateBefore      = "Unknown"
        PowerStateCurrent     = "Unknown"
        StartedByRunbook      = $false
        StoppedByRunbook      = $false
        Action                = "NotProcessed"
        Status                = ""
        Message               = ""
        UpdatesFound          = 0
        InstalledCount        = 0
        FailedCount           = 0
        RebootRequired        = $false
        RebootDone            = $false
        InstalledUpdates      = @()
        FailedUpdates         = @()
        RunCommandName        = ""
        RunCommandUrl         = ""
        PatchStart            = $null
        RuntimeMinutes        = 0
    }
}

# =========================================================================
# [ WINDOWS UPDATE PAYLOAD ]  (wird auf dem Session Host ausgefuehrt)
# =========================================================================
# Die Ausgabe besteht ausschliesslich aus dem JSON Ergebnis, damit die
# Run Command Output-Grenze nicht durch Zwischenmeldungen belegt wird.

$UpdatePayload = @'
$ErrorActionPreference = "Stop"

$Result = [ordered]@{
    ComputerName     = $env:COMPUTERNAME
    StartTime        = (Get-Date).ToString("s")
    UpdatesFound     = 0
    InstalledUpdates = @()
    FailedUpdates    = @()
    RebootRequired   = $false
    Status           = "Unknown"
    Error            = ""
}

try
{
    $Session  = New-Object -ComObject Microsoft.Update.Session
    $Searcher = $Session.CreateUpdateSearcher()
    $SearchResult = $Searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")

    $Result.UpdatesFound = $SearchResult.Updates.Count

    if ($SearchResult.Updates.Count -eq 0)
    {
        $Result.Status = "NoUpdates"
    }
    else
    {
        $UpdatesToInstall = New-Object -ComObject Microsoft.Update.UpdateColl
        foreach ($Update in $SearchResult.Updates)
        {
            if (-not $Update.EulaAccepted) { $Update.AcceptEula() | Out-Null }
            $null = $UpdatesToInstall.Add($Update)
        }

        $Downloader = $Session.CreateUpdateDownloader()
        $Downloader.Updates = $UpdatesToInstall
        $DownloadResult = $Downloader.Download()

        if ($DownloadResult.ResultCode -ne 2)
        {
            throw ("Download fehlgeschlagen (ResultCode " + $DownloadResult.ResultCode + ").")
        }

        $Installer = $Session.CreateUpdateInstaller()
        $Installer.Updates = $UpdatesToInstall
        $InstallResult = $Installer.Install()

        $Result.RebootRequired = [bool]$InstallResult.RebootRequired

        for ($i = 0; $i -lt $UpdatesToInstall.Count; $i++)
        {
            $UpdateResult = $InstallResult.GetUpdateResult($i)
            $UpdateObject = $UpdatesToInstall.Item($i)

            if ($UpdateResult.ResultCode -eq 2)
            {
                $Result.InstalledUpdates += @{
                    Title = $UpdateObject.Title
                    KB    = ($UpdateObject.KBArticleIDs -join ",")
                }
            }
            else
            {
                $Result.FailedUpdates += ($UpdateObject.Title + " (ResultCode " + $UpdateResult.ResultCode + ")")
            }
        }

        if ($Result.FailedUpdates.Count -eq 0) { $Result.Status = "Completed" }
        else { $Result.Status = "CompletedWithErrors" }
    }

    $PendingReboot =
        (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") -or
        (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") -or
        ($null -ne (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue))

    $Result.RebootRequired = $Result.RebootRequired -or $PendingReboot
}
catch
{
    $Result.Status = "Failed"
    $Result.Error  = $_.Exception.Message
}

$Result.EndTime = (Get-Date).ToString("s")
$Result | ConvertTo-Json -Depth 5 -Compress
'@

# =========================================================================
# [ PRE-CHECK ]
# =========================================================================

New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

Write-Log -Level Sep
Write-Log -Level Head -Message "PRE-CHECK"

# --- PowerShell Version --------------------------------------------------
$PsVer = $PSVersionTable.PSVersion
Write-Log -Level Info -Message ("PowerShell Version: {0} (Modus: {1})" -f $PsVer.ToString(), $PowerShellMode)

if ($PowerShellMode -eq "Seven" -and $PsVer.Major -lt 7)
{
    Write-Log -Level Err -Message "PowerShellMode 'Seven' erfordert PowerShell 7.x."
    throw "PowerShell 7.x erforderlich."
}

if ($PsVer.Major -gt 7 -or ($PsVer.Major -eq 7 -and $PsVer.Minor -ge 3))
{
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Log -Level Info -Message "PSNativeCommandUseErrorActionPreference = false gesetzt."
}

if ($script:LogMode -eq "Automation")
{
    Write-Log -Level Info -Message "Azure Automation Job erkannt: Hauptablauf -> Output-Stream, Funktionsdetails -> Verbose-Stream."
}

# --- Azure CLI vorhanden -------------------------------------------------
Write-Log -Level Info -Message "Pruefe Azure CLI..."

$AzCmd = Get-Command az -ErrorAction SilentlyContinue
if (-not $AzCmd)
{
    Write-Log -Level Err -Message "Azure CLI (az) nicht gefunden."
    throw "Azure CLI nicht installiert."
}

New-Item -ItemType Directory -Path $AzConfigDir -Force | Out-Null
$env:AZURE_CONFIG_DIR = $AzConfigDir
New-Item -ItemType Directory -Path $AzExtensionDir -Force | Out-Null
$env:AZURE_EXTENSION_DIR = $AzExtensionDir

$VerResult = Invoke-AzQuiet -Arguments @("version", "--output", "json") -AsJson
Assert-AzSuccess -Result $VerResult -Context "az version" -Fatal -Indent 0 | Out-Null

$AzCliVersion = "0.0.0"
if ($VerResult.Data -and $VerResult.Data.'azure-cli') { $AzCliVersion = [string]$VerResult.Data.'azure-cli' }

Write-Log -Level Ok -Message "Azure CLI gefunden: $AzCliVersion"

# --- Azure CLI aktuell ---------------------------------------------------
if ((Compare-Version -A $AzCliVersion -B $MinAzCliVersion) -lt 0)
{
    Write-Log -Level Warn -Message "Azure CLI $AzCliVersion ist aelter als die empfohlene Mindestversion $MinAzCliVersion. Bitte 'az upgrade' ausfuehren."
}
else
{
    Write-Log -Level Ok -Message "Azure CLI Version erfuellt Mindestversion $MinAzCliVersion."
}
Write-Log -Level Info -Message "Hinweis: Neuere CLI Versionen ggf. mit 'az upgrade' auf dem Hybrid Worker einspielen."

Invoke-AzQuiet -Arguments @("config", "set", "extension.use_dynamic_install=no") | Out-Null
Invoke-AzQuiet -Arguments @("config", "set", "core.only_show_errors=true") | Out-Null

# --- Azure CLI Extensions ------------------------------------------------
Write-Log -Level Info -Message "Pruefe Azure CLI Extensions..."
$ExtList = Invoke-AzQuiet -Arguments @("extension", "list", "--output", "json") -AsJson
$Installed = @()
if ($ExtList.ExitCode -eq 0 -and $ExtList.Data) { $Installed = @($ExtList.Data) }

foreach ($ExtName in $RequiredExtensions)
{
    $Ext = $Installed | Where-Object { $_.name -eq $ExtName } | Select-Object -First 1
    if (-not $Ext)
    {
        Write-Log -Level Run -Indent 1 -Message "Installiere Extension $ExtName..."
        $Add = Invoke-AzQuiet -Arguments @("extension", "add", "--name", $ExtName, "--yes", "--output", "none")
        Assert-AzSuccess -Result $Add -Context "az extension add $ExtName" -Fatal -Indent 1 | Out-Null
        Write-Log -Level Ok -Indent 1 -Message "Extension $ExtName installiert."
    }
    else
    {
        Write-Log -Level Ok -Indent 1 -Message ("Extension {0} vorhanden: {1}" -f $ExtName, $Ext.version)
        if ($UpdateExtensions)
        {
            $Upd = Invoke-AzQuiet -Arguments @("extension", "update", "--name", $ExtName, "--output", "none")
            if ($Upd.ExitCode -eq 0) { Write-Log -Level Ok -Indent 1 -Message "Extension $ExtName aktualisiert." }
            else { Write-Log -Level Warn -Indent 1 -Message "Extension $ExtName konnte nicht aktualisiert werden (Lauf wird fortgesetzt)." }
        }
    }
}

# --- Azure Login ---------------------------------------------------------
Write-Log -Level Info -Message "Pruefe Azure Login ($AuthMode)..."

$Account = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json") -AsJson
if ($Account.ExitCode -ne 0)
{
    Write-Log -Level Run -Message "Kein Login vorhanden, melde an..."

    if ($AuthMode -eq "ManagedIdentity")
    {
        $LoginArgs = @("login", "--identity", "--allow-no-subscriptions", "--output", "none")
        if ($ManagedIdentityClientId)
        {
            $LoginArgs += @("--client-id", $ManagedIdentityClientId)
        }
        $Login = Invoke-AzQuiet -Arguments $LoginArgs
        Assert-AzSuccess -Result $Login -Context "az login --identity" -Fatal -Indent 0 | Out-Null
    }
    elseif ($AuthMode -eq "ServicePrincipal")
    {
        if (-not (Get-Command Get-AutomationVariable -ErrorAction SilentlyContinue))
        {
            throw "AuthMode ServicePrincipal erfordert Azure Automation (Get-AutomationVariable nicht verfuegbar)."
        }
        $SpTenant = Get-AutomationVariable -Name $SpTenantIdVariable
        $SpClient = Get-AutomationVariable -Name $SpClientIdVariable
        $SpSecret = Get-AutomationVariable -Name $SpClientSecretVariable
        if (-not $SpTenant -or -not $SpClient -or -not $SpSecret)
        {
            throw "Service Principal Automation Variables unvollstaendig."
        }
        $Login = Invoke-AzQuiet -Arguments @("login", "--service-principal", "--tenant", $SpTenant, "--username", $SpClient, "--password", $SpSecret, "--output", "none")
        $SpSecret = $null
        Assert-AzSuccess -Result $Login -Context "az login --service-principal" -Fatal -Indent 0 | Out-Null
    }
    else
    {
        throw "Unbekannter AuthMode: $AuthMode"
    }

    $Account = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json") -AsJson
    Assert-AzSuccess -Result $Account -Context "az account show" -Fatal -Indent 0 | Out-Null
}

$LoggedIn = $true

$SubSet = Invoke-AzQuiet -Arguments @("account", "set", "--subscription", $SubscriptionId)
Assert-AzSuccess -Result $SubSet -Context "az account set" -Fatal -Indent 0 | Out-Null

$Account = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json") -AsJson
$LoginUser = "unbekannt"
if ($Account.Data -and $Account.Data.user -and $Account.Data.user.name) { $LoginUser = [string]$Account.Data.user.name }
Write-Log -Level Ok -Message "Login vorhanden: $LoginUser"
Write-Log -Level Ok -Message "Subscription: $SubscriptionId"

# --- Identitaetsdiagnose (welche Managed Identity wurde verwendet?) ------
$MiEnvVars = @()
foreach ($EnvName in @("IDENTITY_ENDPOINT", "IDENTITY_HEADER", "IMDS_ENDPOINT", "MSI_ENDPOINT", "MSI_SECRET"))
{
    $EnvItem = Get-Item -Path ("Env:" + $EnvName) -ErrorAction SilentlyContinue
    if ($EnvItem) { $MiEnvVars += $EnvName }
}
if ($MiEnvVars.Count -gt 0)
{
    Write-Log -Level Info -Message ("Managed Identity Umgebungsvariablen gesetzt: " + ($MiEnvVars -join ", "))
}
else
{
    Write-Log -Level Info -Message "Keine Managed Identity Umgebungsvariablen gesetzt (Standard: IMDS / Arc HIMDS)."
}

$TokenResult = Invoke-AzQuiet -Arguments @("account", "get-access-token", "--output", "json") -AsJson
if ($TokenResult.ExitCode -eq 0 -and $TokenResult.Data -and $TokenResult.Data.accessToken)
{
    try
    {
        $TokenParts = ([string]$TokenResult.Data.accessToken).Split(".")
        if ($TokenParts.Count -ge 2)
        {
            $Payload = $TokenParts[1].Replace("-", "+").Replace("_", "/")
            while (($Payload.Length % 4) -ne 0) { $Payload += "=" }
            $Claims = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Payload)) | ConvertFrom-Json
            Write-Log -Level Info -Message ("Identitaet: oid={0}  appid={1}  idtyp={2}" -f $Claims.oid, $Claims.appid, $Claims.idtyp)
            Write-Log -Level Info -Indent 1 -Message "Die oid muss mit der Object (principal) ID der Managed Identity uebereinstimmen, der die RBAC-Rollen zugewiesen sind."
        }
    }
    catch
    {
        Write-Log -Level Warn -Message "Token Claims konnten nicht gelesen werden (nur Diagnose, kein Abbruch)."
    }
    $TokenResult = $null
}
else
{
    Write-Log -Level Warn -Message "Access Token fuer Identitaetsdiagnose konnte nicht abgerufen werden."
}

# --- Konfiguration validieren --------------------------------------------
$ConfigErrors = 0
if (Test-PlaceholderValue $SubscriptionId) { Write-Log -Level Err -Message "SubscriptionId nicht gesetzt."; $ConfigErrors++ }
if ($HostPools.Count -eq 0) { Write-Log -Level Err -Message "Keine Host Pools konfiguriert."; $ConfigErrors++ }
foreach ($P in $HostPools)
{
    foreach ($Key in @("Name", "ResourceGroup", "SessionHostResourceGroup", "ScalingPlanName", "ScalingPlanResourceGroup"))
    {
        if (Test-PlaceholderValue ([string]$P[$Key]))
        {
            Write-Log -Level Err -Message ("Host Pool Konfiguration unvollstaendig: {0} = '{1}'" -f $Key, $P[$Key])
            $ConfigErrors++
        }
    }
}
if ($ConfigErrors -gt 0)
{
    throw "Konfiguration unvollstaendig ($ConfigErrors Fehler). Bitte Parameterblock pruefen."
}
Write-Log -Level Ok -Message ("Konfiguration geprueft: {0} Host Pool(s), Batchgroesse {1}, DryRun={2}" -f $HostPools.Count, $BatchSize, $DryRun)

Write-Log -Level Sep

# =========================================================================
# [ VERSION ]
# =========================================================================

Write-Log -Level Head -Message "SCRIPT"
Write-Log -Level Info -Message "$ScriptName Version $ScriptVersion"
Write-Log -Level Info -Message ("Start: {0}" -f $RunbookStart.ToString("dd.MM.yyyy HH:mm:ss"))
Write-Log -Level Info -Message ("Maximale Laufzeit: {0} Minuten" -f $MaxRuntimeMinutes)
if ($DryRun) { Write-Log -Level Warn -Message "DRY RUN aktiv: es werden keine Aenderungen vorgenommen." }
Write-Log -Level Sep

# =========================================================================
# [ HAUPTABLAUF ]
# =========================================================================

try
{
    foreach ($Pool in $HostPools)
    {
        Write-Log -Level Head -Message ("HOST POOL " + $Pool.Name)

        if (Test-RuntimeExceeded)
        {
            Write-Log -Level Err -Message "Maximale Laufzeit erreicht, Host Pool $($Pool.Name) wird nicht verarbeitet."
            continue
        }

        # ---------------------------------------------------------------
        # 1. Session Hosts ermitteln
        # ---------------------------------------------------------------
        Write-Log -Level Run -Message "Ermittle Session Hosts..."

        $RawHosts = Get-SessionHosts -Pool $Pool
        if ($null -eq $RawHosts)
        {
            Write-Log -Level Err -Message "Session Hosts konnten nicht gelesen werden, Host Pool wird uebersprungen."
            continue
        }
        if ($RawHosts.Count -eq 0)
        {
            Write-Log -Level Warn -Message "Host Pool enthaelt keine Session Hosts."
            continue
        }

        $PoolHosts = @()
        foreach ($Raw in ($RawHosts | Sort-Object { $_.name }))
        {
            $Entry = New-HostEntry -Pool $Pool -SessionHost $Raw
            $PoolHosts += $Entry
            [void]$AllHosts.Add($Entry)
        }

        Write-Log -Level Ok -Message ("{0} Session Host(s) gefunden:" -f $PoolHosts.Count)
        foreach ($H in $PoolHosts)
        {
            Write-Log -Level Plain -Indent 1 -Message ("{0,-22} Arc: {1,-20} AVD: {2,-12} Sessions: {3}  AllowNewSession: {4}" -f $H.SessionHostFqdn, $H.ArcName, $H.AvdStatus, $H.Sessions, $H.AllowNewSessionBefore)
        }

        # ---------------------------------------------------------------
        # 2. Power-State ermitteln
        # ---------------------------------------------------------------
        Write-Log -Level Run -Message "Ermittle Power-State der Azure Local VMs..."
        foreach ($H in $PoolHosts)
        {
            $State = Get-AzLocalVmPowerState -HostEntry $H
            $H.PowerStateBefore  = $State
            $H.PowerStateCurrent = $State
            if ($State -eq "Unknown")
            {
                Write-Log -Level Warn -Indent 1 -Message ("{0}: Power-State unbekannt (Ressource nicht lesbar?)" -f $H.ArcName)
            }
            else
            {
                Write-Log -Level Plain -Indent 1 -Message ("{0,-20} {1}" -f $H.ArcName, $State)
            }
        }

        if ($DryRun)
        {
            foreach ($H in $PoolHosts) { Set-HostResult -HostEntry $H -Action "DryRun" -Status "Skipped" -Message "DryRun" }
            Write-Log -Level Warn -Message "DryRun: Host Pool $($Pool.Name) nur analysiert."
            continue
        }

        # ---------------------------------------------------------------
        # 3. Scaling Plan deaktivieren
        # ---------------------------------------------------------------
        Write-Log -Level Run -Message ("Deaktiviere Scaling Plan {0} fuer Host Pool..." -f $Pool.ScalingPlanName)
        $Previous = Set-ScalingPlanHostPoolState -Pool $Pool -Enabled $false
        if ($null -eq $Previous)
        {
            Write-Log -Level Warn -Indent 1 -Message "Scaling Plan Zustand konnte nicht gesetzt werden. Fortsetzung ohne Autoscale-Sperre ist riskant, Host Pool wird uebersprungen."
            foreach ($H in $PoolHosts) { Set-HostResult -HostEntry $H -Action "Failed" -Status "ScalingPlanError" -Message "Scaling Plan konnte nicht deaktiviert werden"; $H.FailedCount = 1 }
            continue
        }
        [void]$ScalingPlanChanges.Add([PSCustomObject]@{ Pool = $Pool; PreviousEnabled = $Previous; Restored = $false })
        if ($Previous) { Write-Log -Level Ok -Indent 1 -Message "Scaling Plan war aktiv und ist jetzt deaktiviert." }
        else { Write-Log -Level Info -Indent 1 -Message "Scaling Plan war bereits deaktiviert." }

        # ---------------------------------------------------------------
        # 4. Ausgeschaltete Hosts starten
        # ---------------------------------------------------------------
        $ToStart = @($PoolHosts | Where-Object { $_.PowerStateBefore -in @("Stopped", "Deallocated", "Paused", "Saved") })
        $Unknown = @($PoolHosts | Where-Object { $_.PowerStateBefore -notin @("Running", "Stopped", "Deallocated", "Paused", "Saved") })

        foreach ($H in $Unknown)
        {
            Set-HostResult -HostEntry $H -Action "Failed" -Status "PowerStateUnknown" -Message ("Power-State '" + $H.PowerStateBefore + "' nicht verarbeitbar")
            $H.FailedCount = 1
        }

        if ($ToStart.Count -gt 0)
        {
            Write-Log -Level Run -Message ("Starte {0} ausgeschaltete Host(s)..." -f $ToStart.Count)
            $Started = @()
            foreach ($H in $ToStart)
            {
                if (Invoke-AzLocalVmAction -HostEntry $H -Action "start")
                {
                    $H.StartedByRunbook = $true
                    $Started += $H
                    Write-Log -Level Ok -Indent 1 -Message ("{0}: Start ausgeloest" -f $H.ArcName)
                }
                else
                {
                    Set-HostResult -HostEntry $H -Action "Failed" -Status "StartFailed" -Message "VM Start fehlgeschlagen"
                    $H.FailedCount = 1
                }
            }

            $NotRunning = Wait-AzLocalVmPowerState -Entries $Started -TargetState "Running"
            foreach ($H in $NotRunning)
            {
                Set-HostResult -HostEntry $H -Action "Failed" -Status "StartTimeout" -Message ("VM nicht innerhalb von " + $VmPowerTimeoutSeconds + "s gestartet")
                $H.FailedCount = 1
            }
        }
        else
        {
            Write-Log -Level Info -Message "Alle Hosts laufen bereits."
        }

        # ---------------------------------------------------------------
        # 5. Arc Verbindung pruefen (alle Kandidaten)
        # ---------------------------------------------------------------
        $Candidates = @($PoolHosts | Where-Object { $_.Action -eq "NotProcessed" })
        if ($Candidates.Count -gt 0)
        {
            Write-Log -Level Run -Message ("Pruefe Arc Verbindung fuer {0} Host(s)..." -f $Candidates.Count)
            $NoArc = Wait-ArcConnected -Entries $Candidates
            foreach ($H in $NoArc)
            {
                Set-HostResult -HostEntry $H -Action "Failed" -Status "ArcNotConnected" -Message "Azure Arc nicht verbunden"
                $H.FailedCount = 1
            }
        }

        # ---------------------------------------------------------------
        # 6. Sessions pruefen, Drain Mode setzen
        # ---------------------------------------------------------------
        $Candidates = @($PoolHosts | Where-Object { $_.Action -eq "NotProcessed" })
        Write-Log -Level Run -Message "Pruefe Sessions und setze Drain Mode..."
        foreach ($H in $Candidates)
        {
            $Count = Get-SessionHostSessionCount -HostEntry $H
            if ($Count -lt 0) { $Count = $H.Sessions }
            $H.Sessions = $Count

            if ($SkipHostsWithSessions -and $Count -gt 0)
            {
                Set-HostResult -HostEntry $H -Action "Skipped" -Status "ActiveSessions" -Message ("Uebersprungen: " + $Count + " Session(s) vorhanden")
                Write-Log -Level Warn -Indent 1 -Message ("{0}: {1} Session(s), wird uebersprungen" -f $H.ArcName, $Count)
                continue
            }

            if ($H.AllowNewSessionBefore)
            {
                if (Set-SessionHostAllowNewSession -HostEntry $H -Allow $false)
                {
                    $H.DrainedByRunbook = $true
                }
                else
                {
                    Set-HostResult -HostEntry $H -Action "Failed" -Status "DrainFailed" -Message "Drain Mode konnte nicht gesetzt werden"
                    $H.FailedCount = 1
                }
            }
            else
            {
                Write-Log -Level Info -Indent 1 -Message ("{0}: war bereits im Drain Mode" -f $H.ArcName)
            }
        }

        # ---------------------------------------------------------------
        # 7. Windows Update in Batches
        # ---------------------------------------------------------------
        $PatchList = @($PoolHosts | Where-Object { $_.Action -eq "NotProcessed" })
        Write-Log -Level Info -Message ("{0} Host(s) werden gepatcht (Batchgroesse {1})." -f $PatchList.Count, $BatchSize)

        $BatchIndex = 0
        for ($Offset = 0; $Offset -lt $PatchList.Count; $Offset += $BatchSize)
        {
            $BatchIndex++
            $End = [math]::Min($Offset + $BatchSize, $PatchList.Count) - 1
            $Batch = @($PatchList[$Offset..$End])

            if (Test-RuntimeExceeded)
            {
                foreach ($H in $Batch)
                {
                    Set-HostResult -HostEntry $H -Action "Timeout" -Status "RunbookTimeout" -Message ("Runbook Timeout nach " + $MaxRuntimeMinutes + " Minuten vor Patch-Start")
                    $H.FailedCount = 1
                }
                Write-Log -Level Err -Message "Maximale Laufzeit erreicht, weitere Batches werden nicht gestartet."
                continue
            }

            Write-Log -Level Run -Message ("Batch {0}: {1} Host(s): {2}" -f $BatchIndex, $Batch.Count, (($Batch | ForEach-Object { $_.ArcName }) -join ", "))

            # Run Commands parallel absetzen
            $Pending = New-Object System.Collections.ArrayList
            foreach ($H in $Batch)
            {
                if (Start-WindowsUpdateRunCommand -HostEntry $H)
                {
                    [void]$Pending.Add($H)
                }
                else
                {
                    Set-HostResult -HostEntry $H -Action "Failed" -Status "RunCommandCreateFailed" -Message "Run Command konnte nicht erstellt werden"
                    $H.FailedCount = 1
                }
            }

            # Pollen bis alle fertig sind
            $Elapsed = 0
            $BatchTimeout = $RunCommandTimeoutSeconds + 300
            while ($Pending.Count -gt 0 -and $Elapsed -lt $BatchTimeout)
            {
                if (Test-RuntimeExceeded)
                {
                    Write-Log -Level Err -Indent 1 -Message "Maximale Laufzeit erreicht waehrend Batch $BatchIndex."
                    break
                }

                Start-Sleep -Seconds $RunCommandPollSeconds
                $Elapsed += $RunCommandPollSeconds

                $Done = @()
                foreach ($H in $Pending)
                {
                    $State = Get-RunCommandState -HostEntry $H
                    switch ($State.ExecutionState)
                    {
                        "Succeeded"
                        {
                            Read-UpdateResult -HostEntry $H -OutputText $State.Output
                            $Done += $H
                        }
                        "Failed"
                        {
                            $Msg = $State.Error
                            if (-not $Msg) { $Msg = "Run Command Failed" }
                            if ($State.Output) { Read-UpdateResult -HostEntry $H -OutputText $State.Output }
                            if ($H.Action -ne "Failed") { Set-HostResult -HostEntry $H -Action "Failed" -Status "RunCommandFailed" -Message $Msg }
                            if ($H.FailedCount -eq 0) { $H.FailedCount = 1 }
                            $Done += $H
                        }
                        "TimedOut"
                        {
                            Set-HostResult -HostEntry $H -Action "Failed" -Status "RunCommandTimedOut" -Message "Run Command Timeout auf dem Host"
                            $H.FailedCount = 1
                            $Done += $H
                        }
                        "Canceled"
                        {
                            Set-HostResult -HostEntry $H -Action "Failed" -Status "RunCommandCanceled" -Message "Run Command abgebrochen"
                            $H.FailedCount = 1
                            $Done += $H
                        }
                        default { }
                    }
                }

                foreach ($D in $Done)
                {
                    $Pending.Remove($D)
                    $D.RuntimeMinutes = [math]::Round(((Get-Date) - $D.PatchStart).TotalMinutes, 2)
                    $Level = "Ok"
                    if ($D.Action -eq "Failed") { $Level = "Err" }
                    Write-Log -Level $Level -Indent 1 -Message ("{0}: {1} | gefunden {2} | installiert {3} | Fehler {4} | Neustart {5} | {6} min" -f $D.ArcName, $D.Status, $D.UpdatesFound, $D.InstalledCount, $D.FailedCount, $D.RebootRequired, $D.RuntimeMinutes)
                }

                if ($Pending.Count -gt 0)
                {
                    Write-Log -Level Run -Indent 1 -Message ("Batch {0}: {1} Host(s) laufen noch ({2}s)" -f $BatchIndex, $Pending.Count, $Elapsed)
                }
            }

            foreach ($H in $Pending)
            {
                Set-HostResult -HostEntry $H -Action "Timeout" -Status "PollTimeout" -Message "Keine Rueckmeldung vom Run Command innerhalb des Zeitlimits"
                $H.FailedCount = 1
                $H.RuntimeMinutes = [math]::Round(((Get-Date) - $H.PatchStart).TotalMinutes, 2)
            }

            if ($CleanupRunCommands)
            {
                foreach ($H in $Batch)
                {
                    if ($H.RunCommandUrl -and $H.Action -ne "Timeout") { Remove-RunCommand -HostEntry $H }
                }
            }
        }

        # ---------------------------------------------------------------
        # 8. Neustarts
        # ---------------------------------------------------------------
        $RebootList = @($PoolHosts | Where-Object { $_.RebootRequired -and $_.Action -in @("Patched", "NoUpdates") })
        if (-not $RebootBeforeStop)
        {
            $RebootList = @($RebootList | Where-Object { -not $_.StartedByRunbook })
        }

        if ($RebootList.Count -gt 0 -and -not (Test-RuntimeExceeded))
        {
            Write-Log -Level Run -Message ("Neustart fuer {0} Host(s)..." -f $RebootList.Count)
            $Restarted = @()
            foreach ($H in $RebootList)
            {
                if (Invoke-AzLocalVmAction -HostEntry $H -Action "restart")
                {
                    $Restarted += $H
                    Write-Log -Level Ok -Indent 1 -Message ("{0}: Neustart ausgeloest" -f $H.ArcName)
                }
                else
                {
                    $H.Message = ($H.Message + " Neustart konnte nicht ausgeloest werden.").Trim()
                    Write-Log -Level Warn -Indent 1 -Message ("{0}: Neustart fehlgeschlagen, Updates werden beim naechsten Boot abgeschlossen" -f $H.ArcName)
                }
            }

            if ($Restarted.Count -gt 0)
            {
                Write-Log -Level Run -Indent 1 -Message ("Warte {0}s, bis die Neustarts durchlaufen sind..." -f $RebootSettleSeconds)
                Start-Sleep -Seconds $RebootSettleSeconds

                $NotUp = Wait-AzLocalVmPowerState -Entries $Restarted -TargetState "Running"
                $NotUpNames = @($NotUp | ForEach-Object { $_.ArcName })
                $Up = @($Restarted | Where-Object { $NotUpNames -notcontains $_.ArcName })
                $NoArc = Wait-ArcConnected -Entries $Up
                $NoArcNames = @($NoArc | ForEach-Object { $_.ArcName })

                foreach ($H in $Restarted)
                {
                    if (($NotUpNames -contains $H.ArcName) -or ($NoArcNames -contains $H.ArcName))
                    {
                        Set-HostResult -HostEntry $H -Action "Failed" -Status "RebootFailed" -Message "Host nach Neustart nicht wieder erreichbar"
                        $H.FailedCount = 1
                    }
                    else
                    {
                        $H.RebootDone = $true
                    }
                }
            }
        }
        elseif ($RebootList.Count -gt 0)
        {
            Write-Log -Level Warn -Message "Maximale Laufzeit erreicht, Neustarts werden uebersprungen (Updates werden beim naechsten Boot abgeschlossen)."
        }
        else
        {
            Write-Log -Level Info -Message "Keine Neustarts erforderlich."
        }

        # ---------------------------------------------------------------
        # 9. Drain Mode zuruecksetzen
        # ---------------------------------------------------------------
        $Drained = @($PoolHosts | Where-Object { $_.DrainedByRunbook })
        if ($Drained.Count -gt 0)
        {
            Write-Log -Level Run -Message ("Hebe Drain Mode fuer {0} Host(s) auf..." -f $Drained.Count)
            foreach ($H in $Drained)
            {
                if (Set-SessionHostAllowNewSession -HostEntry $H -Allow $true)
                {
                    $H.DrainedByRunbook = $false
                }
            }
        }

        # ---------------------------------------------------------------
        # 10. Vom Runbook gestartete Hosts herunterfahren
        # ---------------------------------------------------------------
        $ToStop = @($PoolHosts | Where-Object { $_.StartedByRunbook -and -not $_.StoppedByRunbook })
        if ($StopHostsStartedByRunbook -and $ToStop.Count -gt 0)
        {
            Write-Log -Level Run -Message ("Fahre {0} Host(s) wieder herunter..." -f $ToStop.Count)
            $Stopping = @()
            foreach ($H in $ToStop)
            {
                if (Invoke-AzLocalVmAction -HostEntry $H -Action "stop")
                {
                    $Stopping += $H
                    Write-Log -Level Ok -Indent 1 -Message ("{0}: Stop ausgeloest" -f $H.ArcName)
                }
                else
                {
                    $H.Message = ($H.Message + " Stop fehlgeschlagen, Host laeuft weiter.").Trim()
                }
            }
            $NotStopped = Wait-AzLocalVmPowerState -Entries $Stopping -TargetState "Stopped"
            $NotStoppedNames = @($NotStopped | ForEach-Object { $_.ArcName })
            foreach ($H in $Stopping)
            {
                if ($NotStoppedNames -contains $H.ArcName)
                {
                    $H.Message = ($H.Message + " Stop nicht bestaetigt.").Trim()
                    Write-Log -Level Warn -Indent 1 -Message ("{0}: Stop nicht innerhalb des Zeitlimits bestaetigt" -f $H.ArcName)
                }
                else
                {
                    $H.StoppedByRunbook = $true
                }
            }
        }

        # ---------------------------------------------------------------
        # 11. Scaling Plan wieder aktivieren
        # ---------------------------------------------------------------
        $Change = $ScalingPlanChanges | Where-Object { $_.Pool.Name -eq $Pool.Name -and -not $_.Restored }
        foreach ($C in $Change)
        {
            if ($C.PreviousEnabled)
            {
                Write-Log -Level Run -Message ("Aktiviere Scaling Plan {0} fuer Host Pool wieder..." -f $Pool.ScalingPlanName)
                $R = Set-ScalingPlanHostPoolState -Pool $Pool -Enabled $true
                if ($null -ne $R)
                {
                    $C.Restored = $true
                    Write-Log -Level Ok -Indent 1 -Message "Scaling Plan wieder aktiv."
                }
            }
            else
            {
                $C.Restored = $true
            }
        }

        Write-Log -Level Sep
    }
}
catch
{
    $RunbookFatalError = $_.Exception.Message
    Write-Log -Level Err -Message ("Unerwarteter Fehler im Hauptablauf: " + $RunbookFatalError)
}
finally
{
    # ---------------------------------------------------------------
    # Sicherheitsnetz: Drain Mode, gestartete Hosts, Scaling Plans
    # ---------------------------------------------------------------
    if ($LoggedIn -and -not $DryRun)
    {
        Write-Log -Level Head -Message "ABSCHLUSS / SICHERHEITSNETZ"

        foreach ($H in @($AllHosts | Where-Object { $_.DrainedByRunbook }))
        {
            Write-Log -Level Warn -Indent 1 -Message ("{0}: Drain Mode wird nachtraeglich aufgehoben" -f $H.ArcName)
            if (Set-SessionHostAllowNewSession -HostEntry $H -Allow $true) { $H.DrainedByRunbook = $false }
        }

        if ($StopHostsStartedByRunbook)
        {
            $Late = @($AllHosts | Where-Object { $_.StartedByRunbook -and -not $_.StoppedByRunbook })
            $Stopping = @()
            foreach ($H in $Late)
            {
                Write-Log -Level Warn -Indent 1 -Message ("{0}: wird nachtraeglich heruntergefahren" -f $H.ArcName)
                if (Invoke-AzLocalVmAction -HostEntry $H -Action "stop") { $Stopping += $H }
            }
            if ($Stopping.Count -gt 0)
            {
                $NotStopped = Wait-AzLocalVmPowerState -Entries $Stopping -TargetState "Stopped" -TimeoutSeconds 300
                $NotStoppedNames = @($NotStopped | ForEach-Object { $_.ArcName })
                foreach ($H in $Stopping) { if ($NotStoppedNames -notcontains $H.ArcName) { $H.StoppedByRunbook = $true } }
            }
        }

        foreach ($C in @($ScalingPlanChanges | Where-Object { -not $_.Restored -and $_.PreviousEnabled }))
        {
            Write-Log -Level Warn -Indent 1 -Message ("Scaling Plan {0} fuer Host Pool {1} wird nachtraeglich aktiviert" -f $C.Pool.ScalingPlanName, $C.Pool.Name)
            $R = Set-ScalingPlanHostPoolState -Pool $C.Pool -Enabled $true
            if ($null -ne $R) { $C.Restored = $true }
        }

        $Unrestored = @($ScalingPlanChanges | Where-Object { -not $_.Restored -and $_.PreviousEnabled })
        if ($Unrestored.Count -gt 0)
        {
            Write-Log -Level Err -Message ("ACHTUNG: {0} Scaling Plan Zuweisung(en) konnten NICHT reaktiviert werden. Manuell pruefen!" -f $Unrestored.Count)
        }
        else
        {
            Write-Log -Level Ok -Message "Alle Scaling Plan Zuweisungen sind im urspruenglichen Zustand."
        }
        Write-Log -Level Sep
    }
}

# =========================================================================
# [ ZUSAMMENFASSUNG ]
# =========================================================================

$Results = @($AllHosts)
$Runtime = Get-RuntimeMinutes

$TotalHosts   = $Results.Count
$PatchedHosts = @($Results | Where-Object { $_.Action -eq "Patched" }).Count
$NoUpdateHosts = @($Results | Where-Object { $_.Action -eq "NoUpdates" }).Count
$SkippedHosts = @($Results | Where-Object { $_.Action -in @("Skipped", "DryRun") }).Count
$FailedHosts  = @($Results | Where-Object { $_.Action -in @("Failed", "Timeout", "NotProcessed") })
$ErrorCount   = $FailedHosts.Count
$RebootCount  = @($Results | Where-Object { $_.RebootDone }).Count
$InstalledTotal = 0
foreach ($R in $Results) { $InstalledTotal += [int]$R.InstalledCount }
$UnrestoredPlans = @($ScalingPlanChanges | Where-Object { -not $_.Restored -and $_.PreviousEnabled }).Count

Write-Log -Level Head -Message "ZUSAMMENFASSUNG"
Write-Log -Level Plain -Message ("{0,-14} {1,-22} {2,-10} {3,-10} {4,-20} {5,6} {6,6} {7,8} {8,8}" -f "Host Pool", "Host", "Vorher", "Aktion", "Status", "Found", "Inst", "Reboot", "Min")
foreach ($R in $Results)
{
    Write-Log -Level Plain -Message ("{0,-14} {1,-22} {2,-10} {3,-10} {4,-20} {5,6} {6,6} {7,8} {8,8}" -f $R.HostPool, $R.ArcName, $R.PowerStateBefore, $R.Action, $R.Status, $R.UpdatesFound, $R.InstalledCount, $R.RebootDone, $R.RuntimeMinutes)
}
Write-Log -Level Plain -Message ""
Write-Log -Level Info -Message ("Hosts gesamt: {0} | gepatcht: {1} | ohne Updates: {2} | uebersprungen: {3} | Fehler: {4} | Neustarts: {5} | Updates installiert: {6}" -f $TotalHosts, $PatchedHosts, $NoUpdateHosts, $SkippedHosts, $ErrorCount, $RebootCount, $InstalledTotal)
Write-Log -Level Info -Message ("Gesamtlaufzeit: {0} Minuten" -f $Runtime)

# =========================================================================
# [ MAIL ]
# =========================================================================

function ConvertTo-HtmlText
{
    param([string]$Text)
    if ($null -eq $Text) { return "" }
    return [System.Net.WebUtility]::HtmlEncode($Text)
}

if ($SendMail)
{
    $Date = (Get-Date).ToString("dd.MM.yyyy HH:mm:ss")

    if ($RunbookFatalError -or $ErrorCount -gt 0 -or $UnrestoredPlans -gt 0)
    {
        $Subject = "{0} - FEHLER ({1} Hosts | {2} Fehler | {3} uebersprungen)" -f $MailSubjectPrefix, $TotalHosts, $ErrorCount, $SkippedHosts
    }
    else
    {
        $Subject = "{0} - OK ({1} Hosts | {2} gepatcht | {3} Neustarts | {4} uebersprungen)" -f $MailSubjectPrefix, $TotalHosts, $PatchedHosts, $RebootCount, $SkippedHosts
    }
    if ($DryRun) { $Subject = "[DRYRUN] " + $Subject }

    $Rows = @()
    foreach ($R in $Results)
    {
        $Reboot = "Nein"
        if ($R.RebootDone) { $Reboot = "Ja" }
        elseif ($R.RebootRequired) { $Reboot = "Ausstehend" }

        $RowColor = ""
        switch ($R.Action)
        {
            "Failed"  { $RowColor = " style='background-color:#f8d7da;'" }
            "Timeout" { $RowColor = " style='background-color:#f8d7da;'" }
            "NotProcessed" { $RowColor = " style='background-color:#f8d7da;'" }
            "Skipped" { $RowColor = " style='background-color:#fff3cd;'" }
            default   { $RowColor = "" }
        }

        $Rows += ("<tr{0}><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td align='center'>{6}</td><td align='center'>{7}</td><td align='center'>{8}</td><td align='right'>{9}</td></tr>" -f `
            $RowColor,
            (ConvertTo-HtmlText $R.HostPool),
            (ConvertTo-HtmlText $R.ArcName),
            (ConvertTo-HtmlText $R.PowerStateBefore),
            (ConvertTo-HtmlText $R.Action),
            (ConvertTo-HtmlText $R.Status),
            $R.UpdatesFound,
            $R.InstalledCount,
            $Reboot,
            $R.RuntimeMinutes)
    }
    $ResultTable = $Rows -join "`n"

    $InstalledItems = @()
    foreach ($R in @($Results | Where-Object { $_.InstalledCount -gt 0 }))
    {
        $Sub = ($R.InstalledUpdates | ForEach-Object { "<li>" + (ConvertTo-HtmlText $_) + "</li>" }) -join ""
        $InstalledItems += ("<li><b>{0}</b> - {1} Update(s)<ul>{2}</ul></li>" -f (ConvertTo-HtmlText $R.ArcName), $R.InstalledCount, $Sub)
    }
    $InstalledList = "<li>Keine</li>"
    if ($InstalledItems.Count -gt 0) { $InstalledList = $InstalledItems -join "`n" }

    $FailedItems = @()
    foreach ($R in $FailedHosts)
    {
        $Detail = $R.Message
        if (-not $Detail) { $Detail = $R.Status }
        $Sub = ""
        if ($R.FailedUpdates.Count -gt 0)
        {
            $Sub = "<ul>" + (($R.FailedUpdates | ForEach-Object { "<li>" + (ConvertTo-HtmlText $_) + "</li>" }) -join "") + "</ul>"
        }
        $FailedItems += ("<li><b>{0}</b> - {1}: {2}{3}</li>" -f (ConvertTo-HtmlText $R.ArcName), (ConvertTo-HtmlText $R.Action), (ConvertTo-HtmlText $Detail), $Sub)
    }
    if ($RunbookFatalError)
    {
        $FailedItems += ("<li><b>Runbook</b> - " + (ConvertTo-HtmlText $RunbookFatalError) + "</li>")
    }
    if ($UnrestoredPlans -gt 0)
    {
        $FailedItems += ("<li><b>Scaling Plan</b> - {0} Zuweisung(en) konnten nicht reaktiviert werden. Bitte manuell pr&uuml;fen!</li>" -f $UnrestoredPlans)
    }
    $FailedList = "<li>Keine</li>"
    if ($FailedItems.Count -gt 0) { $FailedList = $FailedItems -join "`n" }

    $SkippedItems = @()
    foreach ($R in @($Results | Where-Object { $_.Action -in @("Skipped", "DryRun") }))
    {
        $SkippedItems += ("<li><b>{0}</b> - {1}</li>" -f (ConvertTo-HtmlText $R.ArcName), (ConvertTo-HtmlText $R.Message))
    }
    $SkippedList = "<li>Keine</li>"
    if ($SkippedItems.Count -gt 0) { $SkippedList = $SkippedItems -join "`n" }

    $RebootItems = @()
    foreach ($R in @($Results | Where-Object { $_.RebootDone }))
    {
        $RebootItems += ("<li>" + (ConvertTo-HtmlText $R.ArcName) + "</li>")
    }
    $RebootListHtml = "<li>Keine</li>"
    if ($RebootItems.Count -gt 0) { $RebootListHtml = $RebootItems -join "`n" }

    $PoolNames = ($HostPools | ForEach-Object { ConvertTo-HtmlText $_.Name }) -join ", "

    $Body = @"
<html>
<head>
<meta charset="UTF-8">
<style>
body { font-family: Segoe UI, Arial, sans-serif; font-size: 10pt; }
table { border-collapse: collapse; margin-bottom: 15px; }
th { background-color: #eeeeee; padding: 6px; border: 1px solid #999999; }
td { padding: 6px; border: 1px solid #999999; }
h2 { margin-bottom: 10px; }
h3 { margin-top: 20px; }
</style>
</head>
<body>
<h2>Azure Local Windows Update Report</h2>
<p>Der Windows Update Lauf f&uuml;r die Azure Virtual Desktop Session Hosts auf Azure Local wurde abgeschlossen.</p>
<ul>
<li>Host Pools: $PoolNames</li>
<li>Verarbeitete Session Hosts: $TotalHosts</li>
<li>Hosts mit installierten Updates: $PatchedHosts</li>
<li>Hosts ohne Updates: $NoUpdateHosts</li>
<li>&Uuml;bersprungen (aktive Sessions): $SkippedHosts</li>
<li>Neustarts durchgef&uuml;hrt: $RebootCount</li>
<li>Fehler: $ErrorCount</li>
<li>Installierte Updates gesamt: $InstalledTotal</li>
<li>Gesamtlaufzeit: $Runtime Minuten</li>
<li>Zeitpunkt: $Date</li>
<li>Runbook: $ScriptName v$ScriptVersion</li>
</ul>
<h3>Session Hosts</h3>
<table>
<tr>
<th>Host Pool</th><th>Host</th><th>Zustand vorher</th><th>Aktion</th><th>Status</th><th>Gefunden</th><th>Installiert</th><th>Neustart</th><th>Laufzeit (min)</th>
</tr>
$ResultTable
</table>
<h3>Installierte Updates</h3>
<ul>
$InstalledList
</ul>
<h3>Fehler</h3>
<ul>
$FailedList
</ul>
<h3>&Uuml;bersprungen</h3>
<ul>
$SkippedList
</ul>
<h3>Neustart durchgef&uuml;hrt</h3>
<ul>
$RebootListHtml
</ul>
<p style="color:#666666;font-size:8pt;">Hosts mit Zustand "Stopped" wurden vom Runbook gestartet, gepatcht und wieder heruntergefahren. Hosts mit Zustand "Running" wurden im laufenden Betrieb (Drain Mode) gepatcht und laufen weiter.</p>
</body>
</html>
"@

    try
    {
        Send-MailMessage -From $MailFrom -To $MailTo -SmtpServer $SmtpServer -Subject $Subject -Body $Body -BodyAsHtml -Encoding UTF8 -ErrorAction Stop
        Write-Log -Level Ok -Message "E-Mail versendet: $Subject"
    }
    catch
    {
        Write-Log -Level Err -Message ("E-Mail Versand fehlgeschlagen: " + $_.Exception.Message)
    }
}

# =========================================================================
# [ CLEANUP ]
# =========================================================================

Write-Log -Level Head -Message "CLEANUP"

if ($LoggedIn)
{
    Invoke-AzQuiet -Arguments @("logout") | Out-Null
    Write-Log -Level Ok -Message "Azure CLI Logout durchgefuehrt."
}

if (Test-Path $AzConfigDir) { Remove-Item $AzConfigDir -Recurse -Force -ErrorAction SilentlyContinue }
if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue }
Write-Log -Level Ok -Message "Temporaere Dateien entfernt."

Write-Log -Level Sep
Write-Log -Level Head -Message "ERGEBNIS"
Write-Log -Level Info -Message ("{0} v{1} beendet nach {2} Minuten." -f $ScriptName, $ScriptVersion, (Get-RuntimeMinutes))

if ($RunbookFatalError -or $ErrorCount -gt 0 -or $UnrestoredPlans -gt 0)
{
    Write-Log -Level Err -Message ("Runbook beendet mit Fehlern ({0} Host-Fehler)." -f $ErrorCount)
    Write-Log -Level Sep
    throw "Runbook beendet mit Fehlern."
}
else
{
    Write-Log -Level Ok -Message "Runbook erfolgreich beendet."
    Write-Log -Level Sep
}
