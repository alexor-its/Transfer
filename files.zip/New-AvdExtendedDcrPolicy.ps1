﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Erstellt die AVD "Extended" Data Collection Rule (DCR), weist die Built-in Azure Policy
    fuer die DCR-Zuordnung der Session Hosts zu (Insights- und Extended-DCR) und bietet
    einen Cleanup-Modus, der alles wieder entfernt.

.DESCRIPTION
    Basiert auf dem Paket "AVD Sessionhosts Monitoring 2.0" (GitHub: GetToThe-Cloud/Website,
    Ordner AzureVirtualDesktop-SessionhostMonitoring). Die dort "Day 2" genannten Bausteine
    heissen in diesem Script "Extended".

    MODUS "Deploy" (Standard)
      1. Voraussetzung: Insights-DCR "microsoft-avdi-<region>" muss existieren (sonst Abbruch)
      2. Session-Host-Resource-Groups automatisch aus den Host Pools ermitteln (az rest)
      3. User-assigned Managed Identity pruefen / erstellen und Rollen vergeben
      4. Extended-DCR "dcr-avd-extended-<region>" per ARM-Deployment erstellen/aktualisieren
      5. Built-in Policy "Configure Windows Machines to be associated with a Data Collection
         Rule or a Data Collection Endpoint" je Scope zuweisen:
            a) avd-insights-dcr-assoc   -> Insights-DCR   (identisch zu Set-AvdInsightsDcrPolicy.ps1)
            b) avd-extended-dcr-assoc   -> Extended-DCR
         Bestehende Zuweisungen werden wiederverwendet, fehlende MI nachgeruestet.
      6. Remediation Task je Zuweisung (Modus "Auto": neu -> ReEvaluateCompliance,
         bestehend -> ExistingNonCompliant); kein blockierender Compliance-Scan
      7. Extended-Workbook aus dem Repo laden (Raw-URL) und als Shared Workbook deployen
      8. Optional: Host-Pool-Diagnostic-Settings (allLogs)

    MODUS "Cleanup"
      - Entfernt Extended-Policy-Zuweisungen inkl. Remediation Tasks je Scope
      - Entfernt die DCR-Associations der Extended-DCR von allen Maschinen
      - Entfernt die Extended-DCR und das Extended-Workbook
      - Optional: Insights-Zuweisungen, Insights-Associations, Managed Identity

    PFLICHT-BEREINIGUNG (in jedem Modus, ohne Schalter)
      Obsolete Objekte frueherer Script-Versionen werden immer entfernt: Zuweisungen mit
      Suffix (-NN) bzw. altem Namen (avd-day2-*), die DCR dcr-avd-day2-<region> inkl.
      Associations, Diagnostic Setting diag-avd-day2, abgeschlossene Remediation Tasks.

    Alle Policy-, Remediation- und Association-Operationen laufen ueber az rest (ARM-API),
    da das az-policy-Modul Built-in-Definitionen nicht zuverlaessig aufloest.

.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-20
    Version     : 2.2.2
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Quelle der Monitoring-Inhalte: Alex ter Neuzen / GetToTheCloud
    (AVD Sessionhosts Monitoring 2.0, September 2026)

    Changelog
    2.2.2  Remediation-Loeschung wartet per Polling auf den Endzustand nach Cancel
    2.2.1  Subscription immer aus dem aktiven az-Login-Kontext (kein Hardcoding)
    2.2.0  Workbook wird direkt aus dem Repo heruntergeladen, validiert und deployt
           (lokale Datei nur noch als Fallback)
    2.1.1  Fix: leere ARM-Listen sind kein Fehler; Lesefehler zeigen die az-Meldung;
           Zuweisungslisten ohne $filter, Scope-Abgleich clientseitig
    2.1.0  Pflicht-Bereinigung obsoleter Objekte in jedem Modus (kein Schalter mehr),
           Entfernung abgeschlossener Remediation Tasks vor jeder neuen Remediation
    2.0.0  Umbenennung Day-2 -> Extended (DCR, Policy, Workbook, Script), Cleanup-Modus,
           optionales Workbook-Deployment, Legacy-Bereinigung der Day-2-Objekte
    1.5.0  Remediation-Modus "Auto", kein blockierender Scan, Zuweisungsnamen ohne Suffix
    1.4.0  Angleichung an Set-AvdInsightsDcrPolicy.ps1 (Subscription aus Login-Kontext, RG-Ermittlung)
    1.3.0  Remediation-Modus konfigurierbar, Arc-aware Ausgabe
    1.2.0  Policy-Operationen ueber az rest (ARM-API), korrekte Built-in-GUID
    1.1.0  Insights-DCR-Pruefung, User-assigned MI, mehrere RGs / Subscription-Scope
    1.0.0  Erstversion

.EXAMPLE
    .\New-AvdExtendedDcrPolicy.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - Parameter werden im Script hinterlegt
# =============================================================================
$ScriptName     = "New-AvdExtendedDcrPolicy.ps1"
$ScriptVersion  = "2.2.2"
$PowerShellMode = "Compat"      # "Compat" = PS 5.1 + 7.x | "Seven" = nur PS 7.x

# --- Betriebsmodus ------------------------------------------------------------
$Mode = "Deploy"                # "Deploy" | "Cleanup"

# --- Azure Ziel ---------------------------------------------------------------
# Subscription: aktuelle Subscription des az-Login-Kontexts
$Location                    = "westeurope"               # ARM-Kurzname, bestimmt die DCR-Namen
$MonitoringResourceGroupName = "rg-avdmgmt"               # hier landen Extended-DCR, Workbook und Managed Identity
$WorkspaceResourceGroupName  = "rg-avdmgmt"               # Log Analytics Workspace
$WorkspaceName               = "law-LDK-AVDSessionHosts"

# --- Policy-Scope -------------------------------------------------------------
# "ResourceGroup" : je Session-Host-RG eine Zuweisung; RGs werden automatisch aus den
#                   Host Pools ermittelt (oder manuell ueber $ManualResourceGroupNames)
# "Subscription"  : eine Zuweisung auf Subscription-Ebene, trifft ALLE Windows-Maschinen
#                   der Subscription (ausser $PolicyNotScopes)
$PolicyScopeMode                 = "ResourceGroup"
$HostPoolNameFilter              = @()          # leer = alle Host Pools; sonst z.B. @("HostPool1-Test")
$ManualResourceGroupNames        = @()          # gesetzt = keine automatische Ermittlung
$UseHostPoolRgIfNoSessionHosts   = $true        # Host Pool ohne Session Hosts -> RG des Host Pools verwenden
$DesktopVirtualizationApiVersion = "2024-04-03"
$PolicyNotScopes                 = @()          # nur bei "Subscription", z.B. @("/subscriptions/<id>/resourceGroups/rg-infra")

# --- Insights-DCR (Voraussetzung) --------------------------------------------
$InsightsDcrName              = "microsoft-avdi-$Location"   # Name ist durch AVD Insights vorgegeben
$InsightsDcrResourceGroupName = "rg-avdmgmt"                 # leer lassen = subscriptionweit suchen
$AssignInsightsPolicy         = $true                        # Insights-Zuweisung mitpflegen (idempotent)

# --- Extended Data Collection Rule ------------------------------------------
$ExtendedDcrName            = "dcr-avd-extended-$Location"
$SamplingFrequencyInSeconds = 60                            # 60s laut Blog (Trends, nicht Alarmierung)

# --- Managed Identity (user-assigned, fuer alle Policy-Zuweisungen) ----------
$ManagedIdentityName              = "id-avd-dcr-policy"
$ManagedIdentityResourceGroupName = "rg-avdmgmt"

# --- Azure Policy -------------------------------------------------------------
$InsightsPolicyAssignmentName        = "avd-insights-dcr-assoc"
$InsightsPolicyAssignmentDisplayName = "AVD Insights - Session Hosts mit Insights-DCR verknuepfen"
$ExtendedPolicyAssignmentName        = "avd-extended-dcr-assoc"
$ExtendedPolicyAssignmentDisplayName = "AVD Extended - Session Hosts mit Extended-DCR verknuepfen"
$RemediationNamePrefix               = "rem-avd-dcr"
$CreateRemediationTask               = $true
$RemediationDiscoveryMode            = "Auto"      # "Auto": neue Zuweisung -> ReEvaluateCompliance (laeuft serverseitig),
                                                   #         bestehende Zuweisung -> ExistingNonCompliant
                                                   # oder fest: "ExistingNonCompliant" | "ReEvaluateCompliance"
$TriggerComplianceScanFirst          = $false      # optional: Scan je RG asynchron anstossen (az rest, NICHT blockierend)

$DcrPolicyDisplayName    = "Configure Windows Machines to be associated with a Data Collection Rule or a Data Collection Endpoint"
$DcrPolicyDefinitionGuid = "eab1f514-22e3-42e3-9a1f-e1dc9199355c"   # Fallback: Suche per DisplayName
$PolicyApiVersion        = "2023-04-01"      # Microsoft.Authorization/policyAssignments + policyDefinitions
$RemediationApiVersion   = "2021-10-01"      # Microsoft.PolicyInsights/remediations
$DcrApiVersion           = "2022-06-01"      # Microsoft.Insights/dataCollectionRules(+Associations)
$WorkbookApiVersion      = "2022-04-01"      # Microsoft.Insights/workbooks
$PolicyRoleNames         = @("Monitoring Contributor", "Log Analytics Contributor")

# --- Extended-Workbook (Download aus dem Repo + sofortiges Deployment) ------
$DeployWorkbook      = $true
$WorkbookDisplayName = "AVD Session Hosts - Extended"
# Download-Kandidaten (werden der Reihe nach probiert; erster Treffer mit gueltigem Workbook-JSON gewinnt)
$WorkbookSourceUrls  = @(
    "https://raw.githubusercontent.com/GetToThe-Cloud/Website/main/AzureVirtualDesktop-SessionhostMonitoring/workbook/avd-sessionhosts-monitoring-2.0.workbook.json",
    "https://raw.githubusercontent.com/GetToThe-Cloud/Website/main/AVD-Sessionhosts-Monitoring-2.0/workbook/avd-sessionhosts-monitoring-2.0.workbook.json"
)
$WorkbookJsonPath    = ""     # Fallback: lokale Datei, wird genutzt wenn der Download scheitert (leer = kein Fallback)

# --- Optional: Host Pool Diagnostic Settings ----------------------------------
$ConfigureHostPoolDiagnostics = $false
$DiagnosticHostPoolNames      = @()             # leer = alle automatisch ermittelten Host Pools
$DiagnosticSettingName        = "diag-avd-extended"

# --- Pflicht-Bereinigung (laeuft in JEDEM Modus, kein Schalter) ---------------
# Obsolete Objekte frueherer Script-Versionen werden immer entfernt:
#   - Policy-Zuweisungen mit Suffix: avd-insights-dcr-assoc-NN, avd-day2-dcr-assoc(-NN), avd-extended-dcr-assoc-NN
#   - DCR dcr-avd-day2-<region> inkl. aller Associations
#   - Diagnostic Setting diag-avd-day2 auf Host Pools
#   - Remediation Tasks im Endzustand (Succeeded/Failed/Canceled) der eigenen Zuweisungen
$LegacyDcrName               = "dcr-avd-day2-$Location"
$LegacyDiagnosticSettingName = "diag-avd-day2"
$LegacyAssignmentPattern     = "^(avd-(insights|day2|extended)-dcr-assoc-\d{2}|avd-day2-dcr-assoc)$"

# --- Cleanup-Optionen (nur bei Mode = "Cleanup") ------------------------------
$CleanupRemoveExtendedAssignments = $true       # avd-extended-dcr-assoc je Scope inkl. Remediations
$CleanupRemoveExtendedAssociations = $true      # DCR-Associations der Extended-DCR auf allen Maschinen
$CleanupRemoveExtendedDcr          = $true      # dcr-avd-extended-<region>
$CleanupRemoveWorkbook             = $true      # Workbook mit $WorkbookDisplayName in der Monitoring-RG
$CleanupRemoveInsightsAssignments  = $false     # avd-insights-dcr-assoc (gehoert zu Set-AvdInsightsDcrPolicy.ps1)
$CleanupRemoveInsightsAssociations = $false     # Associations zur Insights-DCR (Vorsicht: Insights-Daten stoppen)
$CleanupRemoveManagedIdentity      = $false     # id-avd-dcr-policy inkl. Rollenzuweisungen (wird von beiden Scripts genutzt)

# --- Arbeitsverzeichnis -------------------------------------------------------
$WorkDirectory = Join-Path ([System.IO.Path]::GetTempPath()) "avd-extended-dcr-policy"

# =============================================================================
# [ GRUNDEINSTELLUNGEN ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Get-Timestamp { return (Get-Date -Format "HH:mm:ss") }
function Write-Line    { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$Title) Write-Host "[ $Title ]" -ForegroundColor White }
function Write-Ok      { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymOk,   $Message) -ForegroundColor Green }
function Write-Err     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymErr,  $Message) -ForegroundColor Red }
function Write-Warn    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymWarn, $Message) -ForegroundColor Yellow }
function Write-Info    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymInfo, $Message) -ForegroundColor Cyan }
function Write-Run     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymRun,  $Message) -ForegroundColor Cyan }
function Write-Sub     { param([string]$Message) Write-Host ("    {0}" -f $Message) -ForegroundColor Cyan }
function Write-SubErr  { param([string]$Message) Write-Host ("    {0}" -f $Message) -ForegroundColor Red }

# Wrapper: az-Aufruf mit unterdruecktem stderr, Argumente als Array
function Invoke-AzQuiet {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $output = & az @Arguments 2>$null
    return $output
}

# Prueft $LASTEXITCODE nach externem Aufruf
function Assert-AzSuccess {
    param([Parameter(Mandatory = $true)][string]$Action, [switch]$Fatal)
    if ($LASTEXITCODE -ne 0) {
        Write-Err "$Action fehlgeschlagen (ExitCode: $LASTEXITCODE)"
        if ($Fatal) { Write-Line; exit 1 }
        return $false
    }
    return $true
}

function Write-JsonFile {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Content)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function ConvertFrom-AzJson {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return $null }
    $text = ($RawOutput -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    return ($text | ConvertFrom-Json)
}

function ConvertFrom-AzText {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return "" }
    return (($RawOutput -join "")).Trim()
}

function Get-ResourceGroupFromId {
    param([string]$ResourceId)
    if ($ResourceId -match "/resourceGroups/([^/]+)/") { return $Matches[1] }
    return $null
}

# ARM-GET ueber az rest inkl. Paging (nextLink)
# Liefert IMMER ein Array (auch leer); $null nur bei einem echten Fehler (Meldung wird ausgegeben)
function Invoke-ArmGetAll {
    param([Parameter(Mandatory = $true)][string]$Url)
    $items = @()
    $nextUrl = $Url
    while (-not [string]::IsNullOrWhiteSpace($nextUrl)) {
        $raw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--url", $nextUrl, "--output", "json")
        if ($LASTEXITCODE -ne 0) {
            # Fehler sichtbar machen: Aufruf wiederholen, stderr diesmal anzeigen
            Write-Sub "ARM GET fehlgeschlagen: $nextUrl"
            & az rest --method get --url $nextUrl --output none
            return $null
        }
        $page = ConvertFrom-AzJson -RawOutput $raw
        if ($null -ne $page -and $null -ne $page.value) {
            foreach ($v in $page.value) { $items += $v }
        }
        $nextUrl = ""
        if ($null -ne $page -and $null -ne $page.nextLink) { $nextUrl = [string]$page.nextLink }
    }
    return ,$items
}

# ARM-GET einer einzelnen Ressource; $null wenn nicht vorhanden
function Invoke-ArmGet {
    param([Parameter(Mandatory = $true)][string]$Url)
    $raw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--url", $Url, "--output", "json")
    if ($LASTEXITCODE -ne 0) { return $null }
    return (ConvertFrom-AzJson -RawOutput $raw)
}

# ARM-Schreibzugriff (PUT/PATCH) ueber az rest mit Body-Datei; liefert Antwortobjekt oder $null
function Invoke-ArmWrite {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][hashtable]$Body,
        [Parameter(Mandatory = $true)][string]$BodyFilePath,
        [Parameter(Mandatory = $true)][string]$Action
    )
    Write-JsonFile -Path $BodyFilePath -Content ($Body | ConvertTo-Json -Depth 10)
    $raw = & az rest --method $Method --url $Url --body "@$BodyFilePath" --headers "Content-Type=application/json" --output json
    if (-not (Assert-AzSuccess -Action $Action)) { return $null }
    return (ConvertFrom-AzJson -RawOutput $raw)
}

# ARM-DELETE / POST ohne Body ueber az rest
function Invoke-ArmAction {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$Action
    )
    & az rest --method $Method --url $Url --output none
    return (Assert-AzSuccess -Action $Action)
}

# Built-in Policy-Definition per GUID (ARM-GET) oder DisplayName ermitteln
function Get-BuiltinPolicyDefinitionId {
    param([string]$DefinitionGuid, [Parameter(Mandatory = $true)][string]$DisplayName)
    $definitionId = $null
    if (-not [string]::IsNullOrWhiteSpace($DefinitionGuid)) {
        $url = "https://management.azure.com/providers/Microsoft.Authorization/policyDefinitions/${DefinitionGuid}?api-version=$PolicyApiVersion"
        $def = Invoke-ArmGet -Url $url
        if ($null -ne $def -and -not [string]::IsNullOrWhiteSpace([string]$def.id)) {
            $definitionId = [string]$def.id
            Write-Sub "Built-in: $($def.properties.displayName)"
        }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) {
        Write-Sub "GUID-Lookup ohne Treffer - suche per DisplayName (kann etwas dauern)..."
        $query = "[?displayName=='$DisplayName'].id | [0]"
        $raw = Invoke-AzQuiet -Arguments @("policy", "definition", "list", "--query", $query, "--output", "tsv")
        if ($LASTEXITCODE -eq 0) { $definitionId = ConvertFrom-AzText -RawOutput $raw }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) { return $null }
    return $definitionId
}

# Rollenzuweisung mit Retry (Managed Identity braucht Zeit zur Replikation)
function Set-RoleAssignmentWithRetry {
    param(
        [Parameter(Mandatory = $true)][string]$PrincipalId,
        [Parameter(Mandatory = $true)][string]$RoleName,
        [Parameter(Mandatory = $true)][string]$Scope,
        [int]$MaxAttempts = 6,
        [int]$DelaySeconds = 15
    )
    $attempt = 0
    $done = $false
    while (-not $done -and $attempt -lt $MaxAttempts) {
        $attempt++
        Invoke-AzQuiet -Arguments @(
            "role", "assignment", "create",
            "--assignee-object-id", $PrincipalId,
            "--assignee-principal-type", "ServicePrincipal",
            "--role", $RoleName,
            "--scope", $Scope,
            "--output", "none"
        ) | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $done = $true
            Write-Ok "Rolle '$RoleName' auf: $Scope"
        }
        else {
            Write-Warn "Rollenzuweisung '$RoleName' Versuch $attempt/$MaxAttempts fehlgeschlagen - warte $DelaySeconds s"
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $done
}

# Policy-Zuweisung anlegen oder wiederverwenden (ARM-API via az rest); MI nachruesten falls fehlend
function Invoke-DcrPolicyAssignment {
    param(
        [Parameter(Mandatory = $true)][string]$AssignmentName,
        [Parameter(Mandatory = $true)][string]$DisplayName,
        [Parameter(Mandatory = $true)][string]$Description,
        [Parameter(Mandatory = $true)][string]$Scope,
        [Parameter(Mandatory = $true)][string]$PolicyDefinitionId,
        [Parameter(Mandatory = $true)][string]$IdentityResourceId,
        [Parameter(Mandatory = $true)][hashtable]$PolicyParameters,
        [string[]]$NotScopes = @()
    )
    $assignmentUrl = "https://management.azure.com${Scope}/providers/Microsoft.Authorization/policyAssignments/${AssignmentName}?api-version=$PolicyApiVersion"
    $bodyPath = Join-Path $WorkDirectory ("assignment-" + $AssignmentName + ".json")
    $identityBlock = @{
        type                   = "UserAssigned"
        userAssignedIdentities = @{ $IdentityResourceId = @{} }
    }

    Write-Run "Pruefe Policy-Zuweisung '$AssignmentName'..."
    $assignment = Invoke-ArmGet -Url $assignmentUrl

    if ($null -ne $assignment -and -not [string]::IsNullOrWhiteSpace([string]$assignment.id)) {
        Write-Warn "Zuweisung existiert bereits - wird wiederverwendet (Parameter werden nicht aktualisiert)"
        $script:LastAssignmentWasNew = $false
        $identityType = ""
        if ($null -ne $assignment.identity -and $null -ne $assignment.identity.type) { $identityType = [string]$assignment.identity.type }
        if ([string]::IsNullOrWhiteSpace($identityType) -or $identityType -eq "None") {
            Write-Warn "Zuweisung hat KEINE Managed Identity - ruestet User-assigned MI nach (PATCH)..."
            $patchBody = @{ location = $Location; identity = $identityBlock }
            $patched = Invoke-ArmWrite -Method "patch" -Url $assignmentUrl -Body $patchBody -BodyFilePath $bodyPath -Action "Identity nachruesten ($AssignmentName)"
            if ($null -ne $patched) {
                Write-Ok "Managed Identity an Zuweisung angehaengt"
                $assignment = $patched
            }
        }
        else {
            Write-Ok "Zuweisung hat bereits eine Managed Identity ($identityType)"
        }
        return $assignment
    }

    Write-Run "Erstelle Policy-Zuweisung '$AssignmentName' (ARM PUT, User-assigned MI)..."
    $props = @{
        displayName        = $DisplayName
        description        = $Description
        policyDefinitionId = $PolicyDefinitionId
        parameters         = $PolicyParameters
        enforcementMode    = "Default"
    }
    if ($NotScopes.Count -gt 0) { $props["notScopes"] = $NotScopes }
    $body = @{ location = $Location; identity = $identityBlock; properties = $props }
    $assignment = Invoke-ArmWrite -Method "put" -Url $assignmentUrl -Body $body -BodyFilePath $bodyPath -Action "Policy-Zuweisung erstellen ($AssignmentName)"
    if ($null -eq $assignment) { return $null }
    $script:LastAssignmentWasNew = $true
    Write-Ok "Policy-Zuweisung erstellt: $AssignmentName"
    Write-Sub "ID: $($assignment.id)"
    return $assignment
}

# Remediation Task starten (ARM-API via az rest); ohne ResourceGroupName = Subscription-Scope
function Start-PolicyRemediation {
    param(
        [Parameter(Mandatory = $true)][string]$NamePrefix,
        [Parameter(Mandatory = $true)][string]$AssignmentId,
        [string]$ResourceGroupName = "",
        [bool]$AssignmentIsNew = $false
    )
    $remediationName = $NamePrefix + "-" + (Get-Date -Format "yyyyMMddHHmmss")
    $baseUrl = "https://management.azure.com/subscriptions/$SubscriptionId"
    if (-not [string]::IsNullOrWhiteSpace($ResourceGroupName)) { $baseUrl += "/resourceGroups/$ResourceGroupName" }

    $mode = $RemediationDiscoveryMode
    if ($mode -eq "Auto") {
        if ($AssignmentIsNew) { $mode = "ReEvaluateCompliance" } else { $mode = "ExistingNonCompliant" }
    }

    if ($TriggerComplianceScanFirst -and $mode -eq "ExistingNonCompliant") {
        $scanUrl = "$baseUrl/providers/Microsoft.PolicyInsights/policyStates/latest/triggerEvaluation?api-version=2019-10-01"
        Invoke-AzQuiet -Arguments @("rest", "--method", "post", "--url", $scanUrl, "--output", "none") | Out-Null
        if ($LASTEXITCODE -eq 0) { Write-Info "Compliance-Scan asynchron angestossen (laeuft im Hintergrund)" }
        else { Write-Warn "Compliance-Scan konnte nicht angestossen werden" }
    }

    # Obsolete Remediations dieser Zuweisung (Endzustand) entfernen, laufende bleiben
    $existingRems = Invoke-ArmGetAll -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations?api-version=$RemediationApiVersion"
    if ($null -ne $existingRems) {
        foreach ($rem in $existingRems) {
            if (([string]$rem.properties.policyAssignmentId).ToLower() -ne $AssignmentId.ToLower()) { continue }
            $remState = [string]$rem.properties.provisioningState
            if ($remState -notin @("Succeeded", "Failed", "Canceled")) { continue }
            $oldName = [string]$rem.name
            if (Invoke-ArmAction -Method "delete" -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${oldName}?api-version=$RemediationApiVersion" -Action "Alte Remediation loeschen ($oldName)") {
                Write-Info "Alte Remediation entfernt: $oldName ($remState)"
            }
        }
    }

    $url = "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${remediationName}?api-version=$RemediationApiVersion"
    $body = @{
        properties = @{
            policyAssignmentId    = $AssignmentId
            resourceDiscoveryMode = $mode
        }
    }
    $bodyPath = Join-Path $WorkDirectory ("remediation-" + $remediationName + ".json")
    Write-Run "Starte Remediation '$remediationName' (Modus: $mode)..."
    $rem = Invoke-ArmWrite -Method "put" -Url $url -Body $body -BodyFilePath $bodyPath -Action "Remediation erstellen ($remediationName)"
    if ($null -ne $rem) {
        Write-Ok "Remediation Task gestartet: $remediationName"
        if ($mode -eq "ReEvaluateCompliance") { Write-Sub "Status 'Evaluating' ist normal - Auswertung laeuft serverseitig (ca. 10-30 Min bei Arc)" }
        return $remediationName
    }
    return $null
}

# --- Cleanup-Hilfsfunktionen --------------------------------------------------

# Wartet, bis eine Remediation einen Endzustand erreicht; liefert den letzten provisioningState
function Wait-RemediationTerminal {
    param([Parameter(Mandatory = $true)][string]$RemediationUrl, [int]$TimeoutSeconds = 120, [int]$PollSeconds = 5)
    $elapsed = 0
    $state = ""
    while ($elapsed -lt $TimeoutSeconds) {
        Start-Sleep -Seconds $PollSeconds
        $elapsed += $PollSeconds
        $rem = Invoke-ArmGet -Url $RemediationUrl
        if ($null -eq $rem) { return "Unknown" }
        $state = [string]$rem.properties.provisioningState
        if ($state -in @("Succeeded", "Failed", "Canceled")) { return $state }
        Write-Sub "warte auf Endzustand... ($state, ${elapsed}s)"
    }
    return $state
}

# Entfernt eine Policy-Zuweisung inkl. zugehoeriger Remediation Tasks; liefert $true wenn etwas entfernt wurde
function Remove-PolicyAssignmentWithRemediations {
    param(
        [Parameter(Mandatory = $true)][string]$AssignmentName,
        [Parameter(Mandatory = $true)][string]$Scope,
        [string]$ResourceGroupName = ""
    )
    $assignmentUrl = "https://management.azure.com${Scope}/providers/Microsoft.Authorization/policyAssignments/${AssignmentName}?api-version=$PolicyApiVersion"
    $assignment = Invoke-ArmGet -Url $assignmentUrl
    if ($null -eq $assignment -or [string]::IsNullOrWhiteSpace([string]$assignment.id)) {
        Write-Sub "Zuweisung '$AssignmentName' nicht vorhanden - uebersprungen"
        return $false
    }
    $assignmentId = [string]$assignment.id

    # Remediations am Scope, die zu dieser Zuweisung gehoeren
    $baseUrl = "https://management.azure.com/subscriptions/$SubscriptionId"
    if (-not [string]::IsNullOrWhiteSpace($ResourceGroupName)) { $baseUrl += "/resourceGroups/$ResourceGroupName" }
    $remediations = Invoke-ArmGetAll -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations?api-version=$RemediationApiVersion"
    if ($null -ne $remediations) {
        foreach ($rem in $remediations) {
            $remAssignment = [string]$rem.properties.policyAssignmentId
            if ($remAssignment.ToLower() -ne $assignmentId.ToLower()) { continue }
            $remName  = [string]$rem.name
            $remState = [string]$rem.properties.provisioningState
            $remUrl   = "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${remName}?api-version=$RemediationApiVersion"
            if ($remState -notin @("Succeeded", "Failed", "Canceled")) {
                if ($remState -ne "Canceling") {
                    Write-Run "Breche Remediation '$remName' ab ($remState)..."
                    Invoke-ArmAction -Method "post" -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${remName}/cancel?api-version=$RemediationApiVersion" -Action "Remediation abbrechen ($remName)" | Out-Null
                }
                # Auf Endzustand warten (Azure loescht nur Succeeded/Failed/Canceled)
                $remState = Wait-RemediationTerminal -RemediationUrl $remUrl -TimeoutSeconds 120
            }
            if ($remState -notin @("Succeeded", "Failed", "Canceled")) {
                Write-Warn "Remediation '$remName' noch im Zustand '$remState' - wird uebersprungen (spaeter erneut ausfuehren)"
                continue
            }
            Write-Run "Loesche Remediation '$remName' ($remState)..."
            if (Invoke-ArmAction -Method "delete" -Url $remUrl -Action "Remediation loeschen ($remName)") {
                Write-Ok "Remediation geloescht: $remName"
            }
        }
    }

    Write-Run "Loesche Policy-Zuweisung '$AssignmentName'..."
    if (Invoke-ArmAction -Method "delete" -Url $assignmentUrl -Action "Policy-Zuweisung loeschen ($AssignmentName)") {
        Write-Ok "Policy-Zuweisung geloescht: $AssignmentName"
        return $true
    }
    return $false
}

# Entfernt alle DCR-Associations einer DCR; liefert Anzahl
function Remove-DcrAssociations {
    param([Parameter(Mandatory = $true)][string]$DcrResourceId)
    $assocs = Invoke-ArmGetAll -Url "https://management.azure.com${DcrResourceId}/associations?api-version=$DcrApiVersion"
    if ($null -eq $assocs) {
        Write-Warn "Associations konnten nicht gelesen werden"
        return 0
    }
    if ($assocs.Count -eq 0) {
        Write-Info "Keine Associations vorhanden"
        return 0
    }
    $removed = 0
    foreach ($assoc in $assocs) {
        $assocId = [string]$assoc.id
        $machineId = ($assocId -split "(?i)/providers/Microsoft\.Insights/")[0]
        $machineName = ($machineId -split "/")[-1]
        if (Invoke-ArmAction -Method "delete" -Url "https://management.azure.com${assocId}?api-version=$DcrApiVersion" -Action "Association loeschen ($machineName)") {
            $removed++
            Write-Ok "Association entfernt: $machineName"
        }
    }
    return $removed
}

# Entfernt eine DCR anhand ihrer Resource-ID
function Remove-Dcr {
    param([Parameter(Mandatory = $true)][string]$DcrResourceId, [Parameter(Mandatory = $true)][string]$Label)
    Write-Run "Loesche DCR '$Label'..."
    if (Invoke-ArmAction -Method "delete" -Url "https://management.azure.com${DcrResourceId}?api-version=$DcrApiVersion" -Action "DCR loeschen ($Label)") {
        Write-Ok "DCR geloescht: $Label"
        return $true
    }
    return $false
}

# Workbooks in einer RG nach DisplayName suchen
function Get-WorkbooksByDisplayName {
    param([Parameter(Mandatory = $true)][string]$ResourceGroupName, [Parameter(Mandatory = $true)][string]$DisplayName)
    $url = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Insights/workbooks?api-version=$WorkbookApiVersion&category=workbook"
    $all = Invoke-ArmGetAll -Url $url
    $hits = @()
    if ($null -ne $all) {
        foreach ($wb in $all) {
            if ([string]$wb.properties.displayName -eq $DisplayName) { $hits += $wb }
        }
    }
    return $hits
}

# Deterministische GUID aus einem Text (fuer idempotente Workbook-Namen)
function Get-DeterministicGuid {
    param([Parameter(Mandatory = $true)][string]$Text)
    $md5 = [System.Security.Cryptography.MD5]::Create()
    $hash = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Text))
    return ([System.Guid]::new($hash)).ToString()
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Line
Write-Section "PRE-CHECK"

$psVersion = $PSVersionTable.PSVersion
Write-Info "PowerShell Version: $psVersion (Modus: $PowerShellMode)"
if ($psVersion.Major -lt 5 -or ($psVersion.Major -eq 5 -and $psVersion.Minor -lt 1)) {
    Write-Err "PowerShell 5.1 oder hoeher wird benoetigt."; Write-Line; exit 1
}
if ($PowerShellMode -eq "Seven" -and $psVersion.Major -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - aktuell: $psVersion"; Write-Line; exit 1
}
if (($psVersion.Major -gt 7) -or ($psVersion.Major -eq 7 -and $psVersion.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PS 7.3+ erkannt: PSNativeCommandUseErrorActionPreference = false"
}

Write-Info "Pruefe Azure CLI..."
$azCommand = Get-Command az -ErrorAction SilentlyContinue
if ($null -eq $azCommand) {
    Write-Err "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"; Write-Line; exit 1
}
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
Assert-AzSuccess -Action "az version" -Fatal | Out-Null
$azVersionObj = ConvertFrom-AzJson -RawOutput $azVersionRaw
$azCliVersion = [string]$azVersionObj.'azure-cli'
Write-Ok "Azure CLI gefunden: $azCliVersion"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $latestInfo    = Invoke-RestMethod -Uri "https://pypi.org/pypi/azure-cli/json" -TimeoutSec 10 -ErrorAction Stop
    $latestVersion = [string]$latestInfo.info.version
    if ([Version]$azCliVersion -lt [Version]$latestVersion) {
        Write-Warn "Neuere Version verfuegbar: $latestVersion (Update mit: az upgrade)"
    }
    else {
        Write-Ok "Azure CLI ist aktuell"
    }
}
catch {
    Write-Warn "Versionsvergleich nicht moeglich - bitte manuell pruefen (az upgrade)"
}

Write-Info "Pruefe Azure Login..."
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Kein Login vorhanden - starte az login..."
    & az login --output none
    Assert-AzSuccess -Action "az login" -Fatal | Out-Null
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess -Action "az account show" -Fatal | Out-Null
}
$account = ConvertFrom-AzJson -RawOutput $accountRaw
Write-Ok "Login vorhanden: $($account.user.name)"

$SubscriptionId = [string]$account.id
Write-Ok "Aktive Subscription: $($account.name) ($SubscriptionId)"

if ($Mode -ne "Deploy" -and $Mode -ne "Cleanup") {
    Write-Err "Ungueltiger Mode '$Mode' - erlaubt: Deploy | Cleanup"; Write-Line; exit 1
}
if ($PolicyScopeMode -ne "ResourceGroup" -and $PolicyScopeMode -ne "Subscription") {
    Write-Err "Ungueltiger PolicyScopeMode '$PolicyScopeMode' - erlaubt: ResourceGroup | Subscription"; Write-Line; exit 1
}
if (-not (Test-Path -Path $WorkDirectory)) { New-Item -Path $WorkDirectory -ItemType Directory -Force | Out-Null }

Write-Line
Write-Section "SCRIPT-VERSION"
Write-Info "$ScriptName - Version $ScriptVersion"
Write-Info "Modus: $Mode | Policy-Scope: $PolicyScopeMode"
Write-Line

# =============================================================================
# [ ZUSAMMENFASSUNG REPO ]  (nur Deploy)
# =============================================================================
if ($Mode -eq "Deploy") {
    Write-Section "ZUSAMMENFASSUNG: AVD SESSIONHOSTS MONITORING 2.0 (EXTENDED)"
    Write-Info "Quelle: GetToThe-Cloud/Website - AzureVirtualDesktop-SessionhostMonitoring"
    Write-Sub "Blog: https://www.gettothe.cloud/azure-virtual-desktop-sessionhost-monitoring-2-0/"
    Write-Host ""
    Write-Info "Architektur:"
    Write-Sub "- Insights-DCR (microsoft-avdi-<region>) bleibt unveraendert"
    Write-Sub "- Alles Zusaetzliche in separater Extended-DCR 'dcr-avd-extended-<region>' (keine Duplikate)"
    Write-Sub "- Beide DCRs werden per Azure Policy mit den Session Hosts verknuepft (Azure-VMs und Arc)"
    Write-Sub "- Host-Pool-Diagnostic-Settings senden WVD*-Tabellen in denselben Workspace"
    Write-Host ""
    Write-Info "Inhalt der Extended-DCR (Sampling 60s):"
    Write-Sub "- RemoteFX Graphics(*): Frames Skipped (Server/Network/Client), Output Frames/Second"
    Write-Sub "- Network Interface(*)\Bytes Total/sec, System\Processor Queue Length, Memory\Committed Bytes"
    Write-Sub "- Eventlog: Microsoft-Windows-User Profile Service/Operational (Level 1-3)"
    Write-Host ""
    Write-Info "Extended-Workbook (7 Tabs): Overview, Session host health, Capacity and density,"
    Write-Sub "User experience, Connections and errors, FSLogix, Data quality"
    Write-Info "Alerts (bewusst nur zwei): Host 15 Min nicht Available; P95 Input Delay > 200 ms"
    Write-Line
}

# =============================================================================
# [ VORAUSSETZUNG: INSIGHTS-DCR ]
# =============================================================================
Write-Section "VORAUSSETZUNG: AVD INSIGHTS DCR"
$insightsDcrResourceId = ""
if (-not [string]::IsNullOrWhiteSpace($InsightsDcrResourceGroupName)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' in RG '$InsightsDcrResourceGroupName'..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $InsightsDcrResourceGroupName, "--name", $InsightsDcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' subscriptionweit..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "list", "--resource-type", "Microsoft.Insights/dataCollectionRules", "--name", $InsightsDcrName, "--query", "[0].id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    if ($Mode -eq "Cleanup") {
        Write-Warn "Insights-DCR '$InsightsDcrName' nicht gefunden - Insights-bezogene Cleanup-Schritte entfallen"
        $insightsDcrResourceGroupName = ""
    }
    else {
        Write-Err "Insights-DCR '$InsightsDcrName' NICHT gefunden - Abbruch."
        Write-SubErr "Dieser Schritt ist zuerst notwendig:"
        Write-SubErr "  1. Azure Portal > Azure Virtual Desktop > Insights > Konfigurations-Workbook (CheckAMAConfiguration)"
        Write-SubErr "  2. Workspace und DCR-Resource-Group waehlen, 'Create data collection rule' klicken"
        Write-SubErr "  3. Dabei entsteht die DCR '$InsightsDcrName'"
        Write-SubErr "  4. Anschliessend dieses Script erneut starten"
        Write-Line
        exit 1
    }
}
else {
    $insightsDcrResourceGroupName = Get-ResourceGroupFromId -ResourceId $insightsDcrResourceId
    Write-Ok "Insights-DCR gefunden: $InsightsDcrName (RG: $insightsDcrResourceGroupName)"
    Write-Sub "ID: $insightsDcrResourceId"
}
Write-Line

# =============================================================================
# [ HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS ]
# =============================================================================
Write-Section "HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS"

$targetRgMap = @{}   # RG-Name -> Liste der Host Pools, die dort Session Hosts haben
$discoveredHostPools = @()

if ($ManualResourceGroupNames.Count -gt 0) {
    Write-Info "Manuelle Resource-Group-Liste wird verwendet - keine automatische Ermittlung."
    foreach ($rg in $ManualResourceGroupNames) { $targetRgMap[$rg] = @("manuell") }
}
else {
    Write-Run "Ermittle AVD Host Pools in der Subscription..."
    $hpUrl = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.DesktopVirtualization/hostPools?api-version=$DesktopVirtualizationApiVersion"
    $hostPools = Invoke-ArmGetAll -Url $hpUrl
    if ($null -eq $hostPools) {
        Write-Err "Host Pools konnten nicht abgefragt werden (az rest)."; Write-Line; exit 1
    }
    if ($hostPools.Count -eq 0) {
        Write-Err "Keine Host Pools in der Subscription gefunden."; Write-Line; exit 1
    }
    Write-Ok "$($hostPools.Count) Host Pool(s) gefunden"

    foreach ($hp in $hostPools) {
        $hpName = [string]$hp.name
        $hpRg   = Get-ResourceGroupFromId -ResourceId ([string]$hp.id)
        $discoveredHostPools += New-Object PSObject -Property @{ Name = $hpName; Id = [string]$hp.id; ResourceGroup = $hpRg }

        if ($HostPoolNameFilter.Count -gt 0 -and $HostPoolNameFilter -notcontains $hpName) {
            Write-Sub "Uebersprungen (Filter): $hpName"
            continue
        }

        Write-Run "Host Pool '$hpName' (RG: $hpRg) - lese Session Hosts..."
        $shUrl = "https://management.azure.com$($hp.id)/sessionHosts?api-version=$DesktopVirtualizationApiVersion"
        $sessionHosts = Invoke-ArmGetAll -Url $shUrl
        if ($null -eq $sessionHosts) {
            Write-Warn "Session Hosts von '$hpName' konnten nicht gelesen werden - uebersprungen"
            continue
        }

        $rgsOfPool = @()
        $arcHosts = 0
        $azureHosts = 0
        foreach ($sh in $sessionHosts) {
            $vmId = ""
            if ($null -ne $sh.properties -and $null -ne $sh.properties.resourceId) { $vmId = [string]$sh.properties.resourceId }
            if ([string]::IsNullOrWhiteSpace($vmId)) { continue }
            $vmRg = Get-ResourceGroupFromId -ResourceId $vmId
            if ($vmId -match "(?i)/Microsoft\.HybridCompute/machines/") { $arcHosts++ } else { $azureHosts++ }
            if (-not [string]::IsNullOrWhiteSpace($vmRg) -and $rgsOfPool -notcontains $vmRg) { $rgsOfPool += $vmRg }
        }

        if ($rgsOfPool.Count -eq 0) {
            if ($UseHostPoolRgIfNoSessionHosts) {
                Write-Warn "'$hpName' hat keine Session Hosts mit Resource-ID - verwende Host-Pool-RG '$hpRg'"
                $rgsOfPool += $hpRg
            }
            else {
                Write-Warn "'$hpName' hat keine Session Hosts - uebersprungen"
                continue
            }
        }
        else {
            Write-Ok "'$hpName': $($sessionHosts.Count) Session Host(s) [$arcHosts Arc, $azureHosts Azure-VM] in RG: $($rgsOfPool -join ', ')"
        }

        foreach ($rg in $rgsOfPool) {
            if (-not $targetRgMap.ContainsKey($rg)) { $targetRgMap[$rg] = @() }
            $targetRgMap[$rg] += $hpName
        }
    }
}

$targetResourceGroups = @($targetRgMap.Keys | Sort-Object)
if ($targetResourceGroups.Count -eq 0) {
    Write-Err "Keine Ziel-Resource-Groups ermittelt."; Write-Line; exit 1
}
Write-Host ""
Write-Info "Session-Host-Resource-Groups ($($targetResourceGroups.Count)):"
foreach ($rg in $targetResourceGroups) {
    Write-Sub "- $rg  (Host Pools: $(($targetRgMap[$rg] | Sort-Object -Unique) -join ', '))"
}

# Assignment-Scopes je nach Modus
$assignmentScopes = @()
$scopeResourceGroups = @()   # parallel zu $assignmentScopes: RG-Name oder "" (Subscription)
if ($PolicyScopeMode -eq "ResourceGroup") {
    foreach ($rg in $targetResourceGroups) {
        $assignmentScopes += "/subscriptions/$SubscriptionId/resourceGroups/$rg"
        $scopeResourceGroups += $rg
    }
}
else {
    $assignmentScopes += "/subscriptions/$SubscriptionId"
    $scopeResourceGroups += ""
    Write-Warn "Subscription-Scope: Policy trifft ALLE Windows-Maschinen der Subscription"
    if ($PolicyNotScopes.Count -gt 0) { Write-Sub "Ausgenommen (not-scopes): $($PolicyNotScopes -join ', ')" }
}
Write-Line

# =============================================================================
# [ BEREINIGUNG OBSOLETER OBJEKTE ]  (Pflichtschritt, in jedem Modus)
# =============================================================================
Write-Section "BEREINIGUNG OBSOLETER OBJEKTE"
$obsoleteRemoved = 0

# a) Policy-Zuweisungen mit altem Namensschema je Scope
foreach ($i in 0..($assignmentScopes.Count - 1)) {
    $scope  = $assignmentScopes[$i]
    $rgName = $scopeResourceGroups[$i]
    $listUrl = "https://management.azure.com${scope}/providers/Microsoft.Authorization/policyAssignments?api-version=$PolicyApiVersion"
    $allAssignments = Invoke-ArmGetAll -Url $listUrl
    if ($null -eq $allAssignments) { Write-Warn "Zuweisungen an $scope konnten nicht gelesen werden"; continue }
    foreach ($pa in $allAssignments) {
        $paName = [string]$pa.name
        if (([string]$pa.properties.scope).ToLower() -ne $scope.ToLower()) { continue }   # nur exakt dieser Scope (keine geerbten)
        if ($paName -notmatch $LegacyAssignmentPattern) { continue }
        Write-Warn "Obsolete Zuweisung: $paName @ $scope"
        if (Remove-PolicyAssignmentWithRemediations -AssignmentName $paName -Scope $scope -ResourceGroupName $rgName) { $obsoleteRemoved++ }
    }
}

# b) Legacy-DCR inkl. Associations
$legacyDcrId = ConvertFrom-AzText -RawOutput (Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $MonitoringResourceGroupName, "--name", $LegacyDcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv"))
if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($legacyDcrId)) {
    Write-Warn "Obsolete DCR: $LegacyDcrName"
    $n = Remove-DcrAssociations -DcrResourceId $legacyDcrId
    if ($n -gt 0) { Write-Ok "$n Association(s) der Legacy-DCR entfernt"; $obsoleteRemoved += $n }
    if (Remove-Dcr -DcrResourceId $legacyDcrId -Label $LegacyDcrName) { $obsoleteRemoved++ }
}

# c) Legacy-Diagnostic-Setting auf Host Pools
foreach ($hp in $discoveredHostPools) {
    $dsUrl = "https://management.azure.com$($hp.Id)/providers/Microsoft.Insights/diagnosticSettings/${LegacyDiagnosticSettingName}?api-version=2021-05-01-preview"
    $ds = Invoke-ArmGet -Url $dsUrl
    if ($null -ne $ds -and -not [string]::IsNullOrWhiteSpace([string]$ds.id)) {
        Write-Warn "Obsoletes Diagnostic Setting '$LegacyDiagnosticSettingName' auf Host Pool '$($hp.Name)'"
        if (Invoke-ArmAction -Method "delete" -Url $dsUrl -Action "Diagnostic Setting loeschen ($($hp.Name))") {
            Write-Ok "Diagnostic Setting entfernt: $($hp.Name)"
            $obsoleteRemoved++
        }
    }
}

if ($obsoleteRemoved -eq 0) { Write-Ok "Keine obsoleten Objekte vorhanden" }
else { Write-Ok "$obsoleteRemoved obsolete(s) Objekt(e) entfernt" }
Write-Line

# #############################################################################
# ######################         MODUS: CLEANUP          ######################
# #############################################################################
if ($Mode -eq "Cleanup") {

    $cleanupSummary = @()

    # ---------------------------------------------------------------------
    # [ CLEANUP: POLICY-ZUWEISUNGEN ]
    # ---------------------------------------------------------------------
    Write-Section "CLEANUP: POLICY-ZUWEISUNGEN"
    for ($i = 0; $i -lt $assignmentScopes.Count; $i++) {
        $scope = $assignmentScopes[$i]
        $rgName = $scopeResourceGroups[$i]
        Write-Host ""
        Write-Info "Scope: $scope"

        if ($CleanupRemoveExtendedAssignments) {
            if (Remove-PolicyAssignmentWithRemediations -AssignmentName $ExtendedPolicyAssignmentName -Scope $scope -ResourceGroupName $rgName) {
                $cleanupSummary += "Policy '$ExtendedPolicyAssignmentName' @ $scope"
            }
        }
        if ($CleanupRemoveInsightsAssignments) {
            if (Remove-PolicyAssignmentWithRemediations -AssignmentName $InsightsPolicyAssignmentName -Scope $scope -ResourceGroupName $rgName) {
                $cleanupSummary += "Policy '$InsightsPolicyAssignmentName' @ $scope"
            }
        }
    }
    Write-Line

    # ---------------------------------------------------------------------
    # [ CLEANUP: DCR-ASSOCIATIONS UND DCRs ]
    # ---------------------------------------------------------------------
    Write-Section "CLEANUP: DCR-ASSOCIATIONS UND DCRs"
    $dcrsToClean = @()
    $extendedDcrId = ConvertFrom-AzText -RawOutput (Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $MonitoringResourceGroupName, "--name", $ExtendedDcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv"))
    if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($extendedDcrId)) {
        $dcrsToClean += New-Object PSObject -Property @{ Id = $extendedDcrId; Label = $ExtendedDcrName; RemoveAssoc = $CleanupRemoveExtendedAssociations; RemoveDcr = $CleanupRemoveExtendedDcr }
    }
    else {
        Write-Info "Extended-DCR '$ExtendedDcrName' nicht vorhanden"
    }
    if ($CleanupRemoveInsightsAssociations -and -not [string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
        Write-Warn "Insights-Associations werden entfernt - AVD Insights erhaelt danach keine Perf-/Event-Daten mehr!"
        $dcrsToClean += New-Object PSObject -Property @{ Id = $insightsDcrResourceId; Label = $InsightsDcrName; RemoveAssoc = $true; RemoveDcr = $false }
    }

    foreach ($d in $dcrsToClean) {
        Write-Host ""
        Write-Info "DCR: $($d.Label)"
        if ($d.RemoveAssoc) {
            Write-Run "Entferne Associations..."
            $n = Remove-DcrAssociations -DcrResourceId $d.Id
            Write-Ok "$n Association(s) entfernt"
            if ($n -gt 0) { $cleanupSummary += "$n Association(s) von '$($d.Label)'" }
        }
        if ($d.RemoveDcr) {
            if (Remove-Dcr -DcrResourceId $d.Id -Label $d.Label) { $cleanupSummary += "DCR '$($d.Label)'" }
        }
    }
    Write-Line

    # ---------------------------------------------------------------------
    # [ CLEANUP: WORKBOOK ]
    # ---------------------------------------------------------------------
    if ($CleanupRemoveWorkbook) {
        Write-Section "CLEANUP: WORKBOOK"
        $wbHits = Get-WorkbooksByDisplayName -ResourceGroupName $MonitoringResourceGroupName -DisplayName $WorkbookDisplayName
        if ($wbHits.Count -eq 0) {
            Write-Info "Kein Workbook '$WorkbookDisplayName' in '$MonitoringResourceGroupName' vorhanden"
        }
        foreach ($wb in $wbHits) {
            Write-Run "Loesche Workbook '$WorkbookDisplayName' ($($wb.name))..."
            if (Invoke-ArmAction -Method "delete" -Url "https://management.azure.com$($wb.id)?api-version=$WorkbookApiVersion" -Action "Workbook loeschen") {
                Write-Ok "Workbook geloescht"
                $cleanupSummary += "Workbook '$WorkbookDisplayName'"
            }
        }
        Write-Line
    }

    # ---------------------------------------------------------------------
    # [ CLEANUP: MANAGED IDENTITY ]
    # ---------------------------------------------------------------------
    if ($CleanupRemoveManagedIdentity) {
        Write-Section "CLEANUP: MANAGED IDENTITY"
        $miRaw = Invoke-AzQuiet -Arguments @("identity", "show", "--name", $ManagedIdentityName, "--resource-group", $ManagedIdentityResourceGroupName, "--output", "json")
        if ($LASTEXITCODE -eq 0 -and $null -ne $miRaw) {
            $mi = ConvertFrom-AzJson -RawOutput $miRaw
            $miPrincipal = [string]$mi.principalId
            Write-Run "Entferne Rollenzuweisungen der MI ($miPrincipal)..."
            $raList = Invoke-AzQuiet -Arguments @("role", "assignment", "list", "--assignee", $miPrincipal, "--all", "--query", "[].id", "--output", "tsv")
            if ($LASTEXITCODE -eq 0 -and $null -ne $raList) {
                foreach ($raId in @($raList)) {
                    if ([string]::IsNullOrWhiteSpace($raId)) { continue }
                    Invoke-AzQuiet -Arguments @("role", "assignment", "delete", "--ids", $raId.Trim(), "--output", "none") | Out-Null
                    if ($LASTEXITCODE -eq 0) { Write-Ok "Rollenzuweisung entfernt: $(Split-Path -Leaf $raId.Trim())" }
                }
            }
            Write-Run "Loesche Managed Identity '$ManagedIdentityName'..."
            & az identity delete --name $ManagedIdentityName --resource-group $ManagedIdentityResourceGroupName --output none
            if (Assert-AzSuccess -Action "az identity delete") {
                Write-Ok "Managed Identity geloescht"
                $cleanupSummary += "Managed Identity '$ManagedIdentityName'"
            }
        }
        else {
            Write-Info "Managed Identity '$ManagedIdentityName' nicht vorhanden"
        }
        Write-Line
    }

    # ---------------------------------------------------------------------
    # [ ERGEBNIS ]
    # ---------------------------------------------------------------------
    Write-Section "ERGEBNIS CLEANUP"
    if ($cleanupSummary.Count -eq 0) {
        Write-Info "Nichts entfernt - keine passenden Objekte gefunden."
    }
    else {
        Write-Ok "$($cleanupSummary.Count) Objekt(e) entfernt:"
        foreach ($c in $cleanupSummary) { Write-Sub "- $c" }
    }
    Write-Info "Nicht entfernt (bewusst): Insights-DCR, Log Analytics Workspace, Host-Pool-Diagnostic-Settings"
    Write-Line
    exit 0
}

# #############################################################################
# ######################         MODUS: DEPLOY           ######################
# #############################################################################

# =============================================================================
# [ VORBEREITUNG ]
# =============================================================================
Write-Section "VORBEREITUNG"
Write-Run "Pruefe Resource Group '$MonitoringResourceGroupName'..."
$rgExistsRaw = Invoke-AzQuiet -Arguments @("group", "exists", "--name", $MonitoringResourceGroupName)
Assert-AzSuccess -Action "az group exists" -Fatal | Out-Null
if ((ConvertFrom-AzText -RawOutput $rgExistsRaw) -eq "true") {
    Write-Ok "Resource Group vorhanden: $MonitoringResourceGroupName"
}
else {
    Write-Run "Erstelle Resource Group '$MonitoringResourceGroupName' in $Location..."
    & az group create --name $MonitoringResourceGroupName --location $Location --output none
    Assert-AzSuccess -Action "az group create" -Fatal | Out-Null
    Write-Ok "Resource Group erstellt: $MonitoringResourceGroupName"
}

$WorkspaceResourceId = "/subscriptions/$SubscriptionId/resourceGroups/$WorkspaceResourceGroupName/providers/Microsoft.OperationalInsights/workspaces/$WorkspaceName"
Write-Run "Pruefe Log Analytics Workspace '$WorkspaceName'..."
$wsNameRaw = Invoke-AzQuiet -Arguments @("resource", "show", "--ids", $WorkspaceResourceId, "--query", "name", "--output", "tsv")
if (-not (Assert-AzSuccess -Action "Workspace-Pruefung")) {
    Write-Err "Workspace nicht gefunden: $WorkspaceResourceId"; Write-Line; exit 1
}
Write-Ok "Workspace gefunden: $(ConvertFrom-AzText -RawOutput $wsNameRaw)"
Write-Line

# =============================================================================
# [ MANAGED IDENTITY ]
# =============================================================================
Write-Section "MANAGED IDENTITY"
Write-Run "Pruefe User-assigned Managed Identity '$ManagedIdentityName'..."
$miRaw = Invoke-AzQuiet -Arguments @("identity", "show", "--name", $ManagedIdentityName, "--resource-group", $ManagedIdentityResourceGroupName, "--output", "json")
$managedIdentity = $null
if ($LASTEXITCODE -eq 0 -and $null -ne $miRaw) { $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw }
$identityIsNew = $false
if ($null -ne $managedIdentity) {
    Write-Ok "Managed Identity vorhanden: $ManagedIdentityName"
}
else {
    Write-Warn "Managed Identity nicht vorhanden - wird erstellt..."
    $miRaw = & az identity create --name $ManagedIdentityName --resource-group $ManagedIdentityResourceGroupName --location $Location --output json
    Assert-AzSuccess -Action "az identity create" -Fatal | Out-Null
    $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw
    $identityIsNew = $true
    Write-Ok "Managed Identity erstellt: $ManagedIdentityName"
}
$identityResourceId  = [string]$managedIdentity.id
$identityPrincipalId = [string]$managedIdentity.principalId
Write-Sub "Resource-ID : $identityResourceId"
Write-Sub "Principal-ID: $identityPrincipalId"
if ($identityIsNew) {
    Write-Info "Warte 20 s auf Replikation der neuen Identity..."
    Start-Sleep -Seconds 20
}

# Rollen: Assignment-Scopes (DCRA anlegen) + Monitoring-RG + RG der Insights-DCR (DCR lesen)
Write-Run "Vergebe Rollen an die Managed Identity..."
$roleScopes = @()
foreach ($s in $assignmentScopes) { $roleScopes += $s }
if ($PolicyScopeMode -eq "ResourceGroup") {
    $extraRgs = @($MonitoringResourceGroupName)
    if (-not [string]::IsNullOrWhiteSpace($insightsDcrResourceGroupName) -and $extraRgs -notcontains $insightsDcrResourceGroupName) { $extraRgs += $insightsDcrResourceGroupName }
    foreach ($rg in $extraRgs) {
        $rgScope = "/subscriptions/$SubscriptionId/resourceGroups/$rg"
        if ($roleScopes -notcontains $rgScope) { $roleScopes += $rgScope }
    }
}
$roleErrors = 0
foreach ($roleScope in $roleScopes) {
    foreach ($roleName in $PolicyRoleNames) {
        if (-not (Set-RoleAssignmentWithRetry -PrincipalId $identityPrincipalId -RoleName $roleName -Scope $roleScope)) { $roleErrors++ }
    }
}
if ($roleErrors -gt 0) { Write-Warn "$roleErrors Rollenzuweisung(en) fehlgeschlagen - Remediation wird moeglicherweise scheitern." }
Write-Line

# =============================================================================
# [ DATA COLLECTION RULE (EXTENDED) ]
# =============================================================================
Write-Section "DATA COLLECTION RULE (EXTENDED)"

$dcrTemplatePath = Join-Path $WorkDirectory "dcr-avd-extended.template.json"

# ARM-Template entspricht dem Bicep aus dem Repo (Microsoft.Insights/dataCollectionRules@2022-06-01)
$dcrTemplate = @'
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "dcrName": { "type": "string" },
    "location": { "type": "string" },
    "workspaceResourceId": { "type": "string" },
    "samplingFrequencyInSeconds": { "type": "int", "defaultValue": 60 }
  },
  "resources": [
    {
      "type": "Microsoft.Insights/dataCollectionRules",
      "apiVersion": "2022-06-01",
      "name": "[parameters('dcrName')]",
      "location": "[parameters('location')]",
      "kind": "Windows",
      "tags": {
        "purpose": "avd-extended-monitoring",
        "source": "GetToTheCloud Sessionhost monitoring 2.0"
      },
      "properties": {
        "description": "AVD Extended DCR. Supplements the microsoft-avdi Insights DCR without duplicating it.",
        "dataSources": {
          "performanceCounters": [
            {
              "name": "avdExtendedPerf",
              "streams": [ "Microsoft-Perf" ],
              "samplingFrequencyInSeconds": "[parameters('samplingFrequencyInSeconds')]",
              "counterSpecifiers": [
                "\\RemoteFX Graphics(*)\\Frames Skipped/Second - Insufficient Server Resources",
                "\\RemoteFX Graphics(*)\\Frames Skipped/Second - Insufficient Network Resources",
                "\\RemoteFX Graphics(*)\\Frames Skipped/Second - Insufficient Client Resources",
                "\\RemoteFX Graphics(*)\\Output Frames/Second",
                "\\Network Interface(*)\\Bytes Total/sec",
                "\\System\\Processor Queue Length",
                "\\Memory\\Committed Bytes"
              ]
            }
          ],
          "windowsEventLogs": [
            {
              "name": "avdExtendedEvents",
              "streams": [ "Microsoft-Event" ],
              "xPathQueries": [
                "Microsoft-Windows-User Profile Service/Operational!*[System[(Level=1 or Level=2 or Level=3)]]"
              ]
            }
          ]
        },
        "destinations": {
          "logAnalytics": [
            {
              "name": "logAnalyticsWorkspace",
              "workspaceResourceId": "[parameters('workspaceResourceId')]"
            }
          ]
        },
        "dataFlows": [
          {
            "streams": [ "Microsoft-Perf", "Microsoft-Event" ],
            "destinations": [ "logAnalyticsWorkspace" ]
          }
        ]
      }
    }
  ],
  "outputs": {
    "dcrResourceId": {
      "type": "string",
      "value": "[resourceId('Microsoft.Insights/dataCollectionRules', parameters('dcrName'))]"
    }
  }
}
'@

Write-JsonFile -Path $dcrTemplatePath -Content $dcrTemplate
Write-Info "ARM-Template geschrieben: $dcrTemplatePath"

$deploymentName = "avd-extended-dcr-" + (Get-Date -Format "yyyyMMddHHmmss")
Write-Run "Deploye DCR '$ExtendedDcrName' nach '$MonitoringResourceGroupName'..."
$dcrIdRaw = & az deployment group create `
    --resource-group $MonitoringResourceGroupName `
    --name $deploymentName `
    --template-file $dcrTemplatePath `
    --parameters "dcrName=$ExtendedDcrName" "location=$Location" "workspaceResourceId=$WorkspaceResourceId" "samplingFrequencyInSeconds=$SamplingFrequencyInSeconds" `
    --query "properties.outputs.dcrResourceId.value" `
    --output tsv
Assert-AzSuccess -Action "az deployment group create (DCR)" -Fatal | Out-Null
$extendedDcrResourceId = ConvertFrom-AzText -RawOutput $dcrIdRaw
if ([string]::IsNullOrWhiteSpace($extendedDcrResourceId)) {
    $dcrIdRaw = Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $MonitoringResourceGroupName, "--name", $ExtendedDcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv")
    Assert-AzSuccess -Action "az resource show (DCR)" -Fatal | Out-Null
    $extendedDcrResourceId = ConvertFrom-AzText -RawOutput $dcrIdRaw
}
Write-Ok "DCR bereit: $ExtendedDcrName"
Write-Sub "ID: $extendedDcrResourceId"
Write-Line

# =============================================================================
# [ AZURE POLICY - DCR ASSOCIATION ]
# =============================================================================
Write-Section "AZURE POLICY - DCR ASSOCIATION"

Write-Run "Ermittle Built-in Policy-Definition..."
$dcrPolicyDefinitionId = Get-BuiltinPolicyDefinitionId -DefinitionGuid $DcrPolicyDefinitionGuid -DisplayName $DcrPolicyDisplayName
if ($null -eq $dcrPolicyDefinitionId) {
    Write-Err "Policy-Definition '$DcrPolicyDisplayName' nicht gefunden."; Write-Line; exit 1
}
Write-Ok "Policy-Definition gefunden"
Write-Sub "$dcrPolicyDefinitionId"

$paramsInsights = @{
    dcrResourceId = @{ value = $insightsDcrResourceId }
    resourceType  = @{ value = "Microsoft.Insights/dataCollectionRules" }
    effect        = @{ value = "DeployIfNotExists" }
}
$paramsExtended = @{
    dcrResourceId = @{ value = $extendedDcrResourceId }
    resourceType  = @{ value = "Microsoft.Insights/dataCollectionRules" }
    effect        = @{ value = "DeployIfNotExists" }
}

$policyResults = @()
for ($i = 0; $i -lt $assignmentScopes.Count; $i++) {
    $scope = $assignmentScopes[$i]
    $remediationRg = $scopeResourceGroups[$i]
    Write-Host ""
    Write-Info "Scope $($i + 1)/$($assignmentScopes.Count): $scope"

    # --- a) Insights-DCR (identisch zu Set-AvdInsightsDcrPolicy.ps1, idempotent) ---
    if ($AssignInsightsPolicy) {
        $insightsAssignment = Invoke-DcrPolicyAssignment `
            -AssignmentName $InsightsPolicyAssignmentName `
            -DisplayName $InsightsPolicyAssignmentDisplayName `
            -Description "Verknuepft Windows Session Hosts mit der AVD-Insights-DCR ($InsightsDcrName)." `
            -Scope $scope `
            -PolicyDefinitionId $dcrPolicyDefinitionId `
            -IdentityResourceId $identityResourceId `
            -PolicyParameters $paramsInsights `
            -NotScopes $PolicyNotScopes
        if ($null -ne $insightsAssignment) {
            $remName = $null
            if ($CreateRemediationTask) {
                $remName = Start-PolicyRemediation -NamePrefix ($RemediationNamePrefix + "-insights") -AssignmentId ([string]$insightsAssignment.id) -ResourceGroupName $remediationRg -AssignmentIsNew $script:LastAssignmentWasNew
            }
            $policyResults += New-Object PSObject -Property @{ Scope = $scope; Dcr = $InsightsDcrName; Assignment = [string]$insightsAssignment.name; Remediation = $remName }
        }
    }

    # --- b) Extended-DCR ---
    $extendedAssignment = Invoke-DcrPolicyAssignment `
        -AssignmentName $ExtendedPolicyAssignmentName `
        -DisplayName $ExtendedPolicyAssignmentDisplayName `
        -Description "Verknuepft Windows Session Hosts mit der AVD Extended-DCR ($ExtendedDcrName) - GetToTheCloud Sessionhost monitoring 2.0." `
        -Scope $scope `
        -PolicyDefinitionId $dcrPolicyDefinitionId `
        -IdentityResourceId $identityResourceId `
        -PolicyParameters $paramsExtended `
        -NotScopes $PolicyNotScopes
    if ($null -ne $extendedAssignment) {
        $remName = $null
        if ($CreateRemediationTask) {
            $remName = Start-PolicyRemediation -NamePrefix ($RemediationNamePrefix + "-extended") -AssignmentId ([string]$extendedAssignment.id) -ResourceGroupName $remediationRg -AssignmentIsNew $script:LastAssignmentWasNew
        }
        $policyResults += New-Object PSObject -Property @{ Scope = $scope; Dcr = $ExtendedDcrName; Assignment = [string]$extendedAssignment.name; Remediation = $remName }
    }
}
if (-not $CreateRemediationTask) { Write-Info "Remediation Tasks uebersprungen (CreateRemediationTask = false)" }
Write-Line

# =============================================================================
# [ OPTIONAL: EXTENDED-WORKBOOK ]
# =============================================================================
$workbookDeployed = $false
if ($DeployWorkbook) {
    Write-Section "EXTENDED-WORKBOOK"
    $workbookJson = ""
    $workbookDownloadPath = Join-Path $WorkDirectory "avd-sessionhosts-monitoring-extended.workbook.json"

    # a) Download aus dem Repo
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
    foreach ($url in $WorkbookSourceUrls) {
        Write-Run "Lade Workbook: $url"
        try {
            $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
            $candidate = [string]$resp.Content
            $parsed = $candidate | ConvertFrom-Json -ErrorAction Stop
            if ($null -eq $parsed.items) { throw "Kein Workbook-JSON (Feld 'items' fehlt)" }
            $workbookJson = $candidate
            Write-JsonFile -Path $workbookDownloadPath -Content $workbookJson
            Write-Ok "Workbook geladen ($([math]::Round($workbookJson.Length / 1KB)) KB) -> $workbookDownloadPath"
            break
        }
        catch {
            Write-Warn "Download fehlgeschlagen: $($_.Exception.Message)"
        }
    }

    # b) Fallback: lokale Datei
    if ([string]::IsNullOrWhiteSpace($workbookJson) -and -not [string]::IsNullOrWhiteSpace($WorkbookJsonPath)) {
        if (Test-Path -Path $WorkbookJsonPath) {
            Write-Info "Verwende lokale Datei: $WorkbookJsonPath"
            $workbookJson = [System.IO.File]::ReadAllText($WorkbookJsonPath)
        }
        else {
            Write-Warn "Lokale Workbook-Datei nicht gefunden: $WorkbookJsonPath"
        }
    }

    if ([string]::IsNullOrWhiteSpace($workbookJson)) {
        Write-Err "Workbook konnte weder heruntergeladen noch lokal gelesen werden - Deployment uebersprungen."
        Write-SubErr "Pruefe die Raw-URL im Repo (WorkbookSourceUrls) oder lege die Datei lokal ab (WorkbookJsonPath)."
    }
    else {
        $workbookName = Get-DeterministicGuid -Text ("avd-extended-workbook|" + $WorkbookDisplayName + "|" + $MonitoringResourceGroupName)
        $wbTemplatePath = Join-Path $WorkDirectory "workbook.template.json"
        $wbParamsPath   = Join-Path $WorkDirectory "workbook.parameters.json"
        $wbTemplate = @'
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "workbookName": { "type": "string" },
    "displayName": { "type": "string" },
    "location": { "type": "string" },
    "sourceId": { "type": "string" },
    "serializedData": { "type": "string" }
  },
  "resources": [
    {
      "type": "Microsoft.Insights/workbooks",
      "apiVersion": "2022-04-01",
      "name": "[parameters('workbookName')]",
      "location": "[parameters('location')]",
      "kind": "shared",
      "tags": { "purpose": "avd-extended-monitoring" },
      "properties": {
        "displayName": "[parameters('displayName')]",
        "category": "workbook",
        "sourceId": "[parameters('sourceId')]",
        "serializedData": "[parameters('serializedData')]",
        "version": "1.0"
      }
    }
  ]
}
'@
        $wbParams = @{
            '$schema'      = "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#"
            contentVersion = "1.0.0.0"
            parameters     = @{
                workbookName   = @{ value = $workbookName }
                displayName    = @{ value = $WorkbookDisplayName }
                location       = @{ value = $Location }
                sourceId       = @{ value = $WorkspaceResourceId }
                serializedData = @{ value = $workbookJson }
            }
        }
        Write-JsonFile -Path $wbTemplatePath -Content $wbTemplate
        Write-JsonFile -Path $wbParamsPath   -Content ($wbParams | ConvertTo-Json -Depth 6)
        Write-Run "Deploye Workbook '$WorkbookDisplayName' ($workbookName)..."
        & az deployment group create `
            --resource-group $MonitoringResourceGroupName `
            --name ("avd-extended-workbook-" + (Get-Date -Format "yyyyMMddHHmmss")) `
            --template-file $wbTemplatePath `
            --parameters "@$wbParamsPath" `
            --output none
        if (Assert-AzSuccess -Action "az deployment group create (Workbook)") {
            Write-Ok "Workbook bereit: $WorkbookDisplayName"
            Write-Sub "Azure Monitor > Workbooks > '$WorkbookDisplayName' (RG: $MonitoringResourceGroupName)"
            $workbookDeployed = $true
        }
    }
    Write-Line
}

# =============================================================================
# [ OPTIONAL: HOST POOL DIAGNOSTIC SETTINGS ]
# =============================================================================
if ($ConfigureHostPoolDiagnostics) {
    Write-Section "HOST POOL DIAGNOSTIC SETTINGS"
    $logsPath = Join-Path $WorkDirectory "diag-logs-alllogs.json"
    Write-JsonFile -Path $logsPath -Content '[ { "categoryGroup": "allLogs", "enabled": true } ]'
    if ($discoveredHostPools.Count -eq 0) {
        Write-Warn "Keine Host Pools ermittelt (manuelle RG-Liste?) - Diagnostic Settings uebersprungen"
    }
    foreach ($hp in $discoveredHostPools) {
        if ($DiagnosticHostPoolNames.Count -gt 0 -and $DiagnosticHostPoolNames -notcontains $hp.Name) { continue }
        Write-Run "Host Pool '$($hp.Name)'..."
        & az monitor diagnostic-settings create `
            --name $DiagnosticSettingName `
            --resource $hp.Id `
            --workspace $WorkspaceResourceId `
            --logs "@$logsPath" `
            --output none
        if (Assert-AzSuccess -Action "Diagnostic Setting '$($hp.Name)'") {
            Write-Ok "Diagnostic Setting '$DiagnosticSettingName' gesetzt (allLogs): $($hp.Name)"
        }
    }
    Write-Line
}

# =============================================================================
# [ ERGEBNIS ]
# =============================================================================
Write-Section "ERGEBNIS"
Write-Ok "Insights-DCR     : $InsightsDcrName"
Write-Sub $insightsDcrResourceId
Write-Ok "Extended-DCR     : $ExtendedDcrName"
Write-Sub $extendedDcrResourceId
Write-Ok "Managed Identity : $ManagedIdentityName"
Write-Sub $identityResourceId
if ($workbookDeployed) { Write-Ok "Workbook         : $WorkbookDisplayName" }
Write-Host ""
Write-Info "Policy-Zuweisungen ($($policyResults.Count)):"
foreach ($r in $policyResults) {
    $remText = "keine"
    if (-not [string]::IsNullOrWhiteSpace($r.Remediation)) { $remText = $r.Remediation }
    Write-Sub "- $($r.Assignment)  ->  $($r.Dcr)"
    Write-Sub "  Scope      : $($r.Scope)"
    Write-Sub "  Remediation: $remText"
}
Write-Host ""
Write-Info "Validierung (Resource Graph) - jeder Session Host sollte BEIDE DCRs haben:"
Write-Sub "insightsresources"
Write-Sub "| where type == 'microsoft.insights/datacollectionruleassociations'"
Write-Sub "| extend Machine = tolower(tostring(split(id, '/providers/Microsoft.Insights/')[0])), Dcr = tostring(split(tostring(properties.dataCollectionRuleId), '/')[-1])"
Write-Sub "| where Machine contains '/machines/' or Machine contains '/virtualmachines/'"
Write-Sub "| summarize Rules = make_set(Dcr) by Machine"
Write-Sub "| where array_length(Rules) < 2"
Write-Host ""
if (-not $DeployWorkbook) {
    Write-Info "Workbook: DeployWorkbook = true setzen - wird dann aus dem Repo geladen und sofort deployt"
}
Write-Info "Cleanup: Mode = 'Cleanup' setzen - entfernt Extended-Policy, Associations, DCR und Workbook (Insights bleibt)"
Write-Info "Obsolete Objekte frueherer Versionen werden bei jedem Lauf automatisch entfernt"
Write-Line
