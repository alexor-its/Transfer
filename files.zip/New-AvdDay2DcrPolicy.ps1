﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Prueft die AVD-Insights-DCR, erstellt die supplementaere AVD Day-2 DCR und weist
    die Built-in Azure Policy fuer die DCR-Zuordnung der Session Hosts zu (beide DCRs).

.DESCRIPTION
    Dieses Script setzt die Kernpunkte des Pakets "AVD Sessionhosts Monitoring 2.0"
    (GitHub: GetToThe-Cloud/Website, Ordner AzureVirtualDesktop-SessionhostMonitoring,
    Blog: https://www.gettothe.cloud/azure-virtual-desktop-sessionhost-monitoring-2-0/)
    mit der Azure CLI um:

      1. Zusammenfassung der Kernpunkte des Repos in der Konsole
      2. HARTE VORAUSSETZUNG: Die Insights-DCR "microsoft-avdi-<region>" muss existieren
         (wird ueber das AVD-Insights-Konfigurations-Workbook erzeugt). Fehlt sie,
         bricht das Script mit Hinweis ab.
      3. User-assigned Managed Identity fuer die Policy-Zuweisungen pruefen bzw. erstellen
      4. Erstellung der supplementaeren DCR "dcr-avd-day2-<region>" per ARM-Deployment
      5. Zwei Zuweisungen der Built-in Policy
         "Configure Windows Machines to be associated with a Data Collection Rule
          or a Data Collection Endpoint" (DeployIfNotExists):
            a) fuer die Insights-DCR   (microsoft-avdi-<region>)
            b) fuer die Day-2-DCR      (dcr-avd-day2-<region>)
         Scope wahlweise pro Session-Host-Resource-Group (automatisch aus den Host Pools
         ermittelt) oder einmal auf Subscription-Ebene
      6. Rollenzuweisungen (Monitoring Contributor, Log Analytics Contributor)
         fuer die Managed Identity auf allen benoetigten Scopes
      7. Remediation Tasks fuer bestehende Session Hosts
      8. Optional: Diagnostic Settings (allLogs) fuer Host Pools
      9. Optional: Policy zur Installation des Azure Monitor Agents

    Alle Azure-Aufrufe erfolgen ueber die Azure CLI (az) in PowerShell.

.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-20
    Version     : 1.4.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Quelle der Monitoring-Inhalte: Alex ter Neuzen / GetToTheCloud
    (AVD Sessionhosts Monitoring 2.0, September 2026)

    Changelog
    1.4.0  Angleichung an Set-AvdInsightsDcrPolicy.ps1: Subscription per Name,
           Workspace per RG+Name, Session-Host-RGs automatisch aus den Host Pools
           (az rest), Insights-DCR-Suche zuerst in der konfigurierten RG
    1.3.0  Remediation-Modus konfigurierbar (Standard ExistingNonCompliant),
           optionaler Compliance-Scan vor der Remediation, Arc-aware Ausgabe
    1.2.0  Policy-Zuweisung, Identity-Nachruestung und Remediation ueber az rest
           (ARM-API) statt az policy (aaz-Bug bei Built-in-Definitionen); korrekte GUID
    1.1.0  Insights-DCR-Pruefung (Abbruch wenn fehlend), zweite Policy fuer die
           Insights-DCR, User-assigned Managed Identity (pruefen/erstellen),
           mehrere Session-Host-RGs bzw. Subscription-Scope, Identity-Nachruestung
           bei bestehenden Zuweisungen
    1.0.0  Erstversion

.EXAMPLE
    .\New-AvdDay2DcrPolicy.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - Parameter werden im Script hinterlegt
# =============================================================================
$ScriptName     = "New-AvdDay2DcrPolicy.ps1"
$ScriptVersion  = "1.4.0"
$PowerShellMode = "Compat"      # "Compat" = PS 5.1 + 7.x | "Seven" = nur PS 7.x

# --- Azure Ziel ---------------------------------------------------------------
$Subscription                = "Azure Local"              # Subscription-Name oder -ID (ID wird zur Laufzeit aufgeloest)
$Location                    = "westeurope"               # ARM-Kurzname, bestimmt die DCR-Namen
$MonitoringResourceGroupName = "rg-avdmgmt"               # hier landen Day-2-DCR und Managed Identity
$WorkspaceResourceGroupName  = "rg-avdmgmt"               # Log Analytics Workspace
$WorkspaceName               = "law-LDK-AVDSessionHosts"

# --- Policy-Scope -------------------------------------------------------------
# "ResourceGroup" : je Session-Host-RG eine Zuweisung; RGs werden automatisch aus den
#                   Host Pools ermittelt (oder manuell ueber $ManualResourceGroupNames)
# "Subscription"  : eine Zuweisung auf Subscription-Ebene, trifft ALLE Windows-Maschinen
#                   der Subscription (ausser $PolicyNotScopes)
$PolicyScopeMode               = "ResourceGroup"
$HostPoolNameFilter            = @()            # leer = alle Host Pools; sonst z.B. @("HostPool1-Test")
$ManualResourceGroupNames      = @()            # gesetzt = keine automatische Ermittlung
$UseHostPoolRgIfNoSessionHosts = $true          # Host Pool ohne Session Hosts -> RG des Host Pools verwenden
$DesktopVirtualizationApiVersion = "2024-04-03"
$PolicyNotScopes               = @()            # nur bei "Subscription", z.B. @("/subscriptions/<id>/resourceGroups/rg-infra")

# --- Insights-DCR (Voraussetzung) --------------------------------------------
$InsightsDcrName              = "microsoft-avdi-$Location"   # Name ist durch AVD Insights vorgegeben
$InsightsDcrResourceGroupName = "rg-avdmgmt"                 # leer lassen = subscriptionweit suchen

# --- Day-2 Data Collection Rule ----------------------------------------------
$DcrName                    = "dcr-avd-day2-$Location"
$SamplingFrequencyInSeconds = 60                            # 60s laut Blog (Trends, nicht Alarmierung)

# --- Managed Identity (user-assigned, fuer alle Policy-Zuweisungen) ----------
$ManagedIdentityName              = "id-avd-dcr-policy"
$ManagedIdentityResourceGroupName = "rg-avdmgmt"

# --- Azure Policy -------------------------------------------------------------
$InsightsPolicyAssignmentName        = "avd-insights-dcr-assoc"   # max. 64 Zeichen (RG/Sub-Scope)
$InsightsPolicyAssignmentDisplayName = "AVD Insights - Session Hosts mit Insights-DCR verknuepfen"
$Day2PolicyAssignmentName            = "avd-day2-dcr-assoc"
$Day2PolicyAssignmentDisplayName     = "AVD Day2 - Session Hosts mit Day-2-DCR verknuepfen"
$RemediationNamePrefix               = "rem-avd-dcr"
$CreateRemediationTask               = $true
$RemediationDiscoveryMode            = "ExistingNonCompliant"   # oder "ReEvaluateCompliance" (bei Arc oft sehr langsam)
$TriggerComplianceScanFirst          = $true                   # Compliance-Scan je Scope vor der Remediation ausloesen

# Built-in Policy: DCR-Association fuer Windows-Maschinen
$DcrPolicyDisplayName    = "Configure Windows Machines to be associated with a Data Collection Rule or a Data Collection Endpoint"
$DcrPolicyDefinitionGuid = "eab1f514-22e3-42e3-9a1f-e1dc9199355c"   # Fallback: Suche per DisplayName
$PolicyApiVersion        = "2023-04-01"      # Microsoft.Authorization/policyAssignments + policyDefinitions
$RemediationApiVersion   = "2021-10-01"      # Microsoft.PolicyInsights/remediations
$PolicyRoleNames         = @("Monitoring Contributor", "Log Analytics Contributor")

# --- Optional: AMA-Installations-Policy ---------------------------------------
$AssignAmaInstallPolicy  = $false
$AmaPolicyDisplayName    = "Configure Windows virtual machines to run Azure Monitor Agent using system-assigned managed identity"
$AmaPolicyAssignmentName = "avd-ama-install"
$AmaPolicyRoleNames      = @("Virtual Machine Contributor")

# --- Optional: Host Pool Diagnostic Settings ----------------------------------
$ConfigureHostPoolDiagnostics = $false
$DiagnosticHostPoolNames      = @()             # leer = alle automatisch ermittelten Host Pools
$DiagnosticSettingName        = "diag-avd-day2"

# --- Arbeitsverzeichnis fuer temporaere JSON-Dateien --------------------------
$WorkDirectory = Join-Path ([System.IO.Path]::GetTempPath()) "avd-day2-dcr-policy"

# =============================================================================
# [ GRUNDEINSTELLUNGEN ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Get-Timestamp {
    return (Get-Date -Format "HH:mm:ss")
}

function Write-Line {
    Write-Host ("=" * 60) -ForegroundColor White
}

function Write-Section {
    param([string]$Title)
    Write-Host "[ $Title ]" -ForegroundColor White
}

function Write-Ok {
    param([string]$Message)
    Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymOk, $Message) -ForegroundColor Green
}

function Write-Err {
    param([string]$Message)
    Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymErr, $Message) -ForegroundColor Red
}

function Write-Warn {
    param([string]$Message)
    Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymWarn, $Message) -ForegroundColor Yellow
}

function Write-Info {
    param([string]$Message)
    Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymInfo, $Message) -ForegroundColor Cyan
}

function Write-Run {
    param([string]$Message)
    Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymRun, $Message) -ForegroundColor Cyan
}

function Write-Sub {
    param([string]$Message)
    Write-Host ("    {0}" -f $Message) -ForegroundColor Cyan
}

function Write-SubErr {
    param([string]$Message)
    Write-Host ("    {0}" -f $Message) -ForegroundColor Red
}

# Wrapper: az-Aufruf mit unterdruecktem stderr, Argumente als Array
function Invoke-AzQuiet {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )
    $output = & az @Arguments 2>$null
    return $output
}

# Prueft $LASTEXITCODE nach externem Aufruf
function Assert-AzSuccess {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Action,
        [switch]$Fatal
    )
    if ($LASTEXITCODE -ne 0) {
        Write-Err "$Action fehlgeschlagen (ExitCode: $LASTEXITCODE)"
        if ($Fatal) {
            Write-Line
            exit 1
        }
        return $false
    }
    return $true
}

# JSON-Datei ohne BOM schreiben (az CLI mag kein BOM in Eingabedateien)
function Write-JsonFile {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

# az-JSON-Ausgabe (String-Array) in Objekt wandeln
function ConvertFrom-AzJson {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return $null }
    $text = ($RawOutput -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    return ($text | ConvertFrom-Json)
}

# tsv-Ausgabe in getrimmten String wandeln
function ConvertFrom-AzText {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return "" }
    return (($RawOutput -join "")).Trim()
}

# Resource-Group-Namen aus einer Resource-ID extrahieren
function Get-ResourceGroupFromId {
    param([string]$ResourceId)
    if ($ResourceId -match "/resourceGroups/([^/]+)/") {
        return $Matches[1]
    }
    return $null
}

# ARM-GET ueber az rest inkl. Paging (nextLink)
function Invoke-ArmGetAll {
    param([Parameter(Mandatory = $true)][string]$Url)
    $items = @()
    $nextUrl = $Url
    while (-not [string]::IsNullOrWhiteSpace($nextUrl)) {
        $raw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--url", $nextUrl, "--output", "json")
        if ($LASTEXITCODE -ne 0) { return $null }
        $page = ConvertFrom-AzJson -RawOutput $raw
        if ($null -ne $page -and $null -ne $page.value) {
            foreach ($v in $page.value) { $items += $v }
        }
        $nextUrl = ""
        if ($null -ne $page -and $null -ne $page.nextLink) { $nextUrl = [string]$page.nextLink }
    }
    return $items
}

# ARM-Schreibzugriff (PUT/PATCH) ueber az rest mit Body-Datei; liefert Antwortobjekt oder $null
function Invoke-ArmWrite {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][hashtable]$Body,
        [Parameter(Mandatory = $true)][string]$BodyFilePath,
        [Parameter(Mandatory = $true)][string]$Action
    )
    Write-JsonFile -Path $BodyFilePath -Content ($Body | ConvertTo-Json -Depth 10)
    $raw = & az rest --method $Method --url $Url --body "@$BodyFilePath" --headers "Content-Type=application/json" --output json
    if (-not (Assert-AzSuccess -Action $Action)) { return $null }
    return (ConvertFrom-AzJson -RawOutput $raw)
}

# Built-in Policy-Definition per GUID (ARM-GET) oder DisplayName ermitteln
# Hinweis: Bewusst ueber az rest, da das az-policy-Modul (aaz) Built-in-Definitionen
# in einigen CLI-Versionen nicht korrekt aufloest (PolicyDefinitionNotFound + NoneType-Traceback).
function Get-BuiltinPolicyDefinitionId {
    param([string]$DefinitionGuid, [Parameter(Mandatory = $true)][string]$DisplayName)
    $definitionId = $null
    if (-not [string]::IsNullOrWhiteSpace($DefinitionGuid)) {
        $url = "https://management.azure.com/providers/Microsoft.Authorization/policyDefinitions/${DefinitionGuid}?api-version=$PolicyApiVersion"
        $raw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--url", $url, "--output", "json")
        if ($LASTEXITCODE -eq 0) {
            $def = ConvertFrom-AzJson -RawOutput $raw
            if ($null -ne $def -and -not [string]::IsNullOrWhiteSpace([string]$def.id)) {
                $definitionId = [string]$def.id
                Write-Sub "Built-in: $($def.properties.displayName)"
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) {
        Write-Sub "GUID-Lookup ohne Treffer - suche per DisplayName (kann etwas dauern)..."
        $query = "[?displayName=='$DisplayName'].id | [0]"
        $raw = Invoke-AzQuiet -Arguments @("policy", "definition", "list", "--query", $query, "--output", "tsv")
        if ($LASTEXITCODE -eq 0) { $definitionId = ConvertFrom-AzText -RawOutput $raw }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) { return $null }
    return $definitionId
}

# Rollenzuweisung mit Retry (Managed Identity braucht Zeit zur Replikation)
function Set-RoleAssignmentWithRetry {
    param(
        [Parameter(Mandatory = $true)][string]$PrincipalId,
        [Parameter(Mandatory = $true)][string]$RoleName,
        [Parameter(Mandatory = $true)][string]$Scope,
        [int]$MaxAttempts = 6,
        [int]$DelaySeconds = 15
    )
    $attempt = 0
    $done = $false
    while (-not $done -and $attempt -lt $MaxAttempts) {
        $attempt++
        Invoke-AzQuiet -Arguments @(
            "role", "assignment", "create",
            "--assignee-object-id", $PrincipalId,
            "--assignee-principal-type", "ServicePrincipal",
            "--role", $RoleName,
            "--scope", $Scope,
            "--output", "none"
        ) | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $done = $true
            Write-Ok "Rolle '$RoleName' auf: $Scope"
        }
        else {
            Write-Warn "Rollenzuweisung '$RoleName' Versuch $attempt/$MaxAttempts fehlgeschlagen - warte $DelaySeconds s"
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $done
}

# Policy-Zuweisung anlegen oder wiederverwenden (ARM-API via az rest); MI nachruesten falls fehlend
function Invoke-DcrPolicyAssignment {
    param(
        [Parameter(Mandatory = $true)][string]$AssignmentName,
        [Parameter(Mandatory = $true)][string]$DisplayName,
        [Parameter(Mandatory = $true)][string]$Description,
        [Parameter(Mandatory = $true)][string]$Scope,
        [Parameter(Mandatory = $true)][string]$PolicyDefinitionId,
        [Parameter(Mandatory = $true)][string]$IdentityResourceId,
        [Parameter(Mandatory = $true)][hashtable]$PolicyParameters,
        [string[]]$NotScopes = @()
    )
    $assignmentUrl = "https://management.azure.com${Scope}/providers/Microsoft.Authorization/policyAssignments/${AssignmentName}?api-version=$PolicyApiVersion"
    $bodyPath = Join-Path $WorkDirectory ("assignment-" + $AssignmentName + ".json")
    $identityBlock = @{
        type                   = "UserAssigned"
        userAssignedIdentities = @{ $IdentityResourceId = @{} }
    }

    Write-Run "Pruefe Policy-Zuweisung '$AssignmentName'..."
    $existingRaw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--url", $assignmentUrl, "--output", "json")
    $assignment = $null
    if ($LASTEXITCODE -eq 0) { $assignment = ConvertFrom-AzJson -RawOutput $existingRaw }

    if ($null -ne $assignment -and -not [string]::IsNullOrWhiteSpace([string]$assignment.id)) {
        Write-Warn "Zuweisung existiert bereits - wird wiederverwendet (Parameter werden nicht aktualisiert)"
        $identityType = ""
        if ($null -ne $assignment.identity -and $null -ne $assignment.identity.type) { $identityType = [string]$assignment.identity.type }
        if ([string]::IsNullOrWhiteSpace($identityType) -or $identityType -eq "None") {
            Write-Warn "Zuweisung hat KEINE Managed Identity - ruestet User-assigned MI nach (PATCH)..."
            $patchBody = @{ location = $Location; identity = $identityBlock }
            $patched = Invoke-ArmWrite -Method "patch" -Url $assignmentUrl -Body $patchBody -BodyFilePath $bodyPath -Action "Identity nachruesten ($AssignmentName)"
            if ($null -ne $patched) {
                Write-Ok "Managed Identity an Zuweisung angehaengt"
                $assignment = $patched
            }
        }
        else {
            Write-Ok "Zuweisung hat bereits eine Managed Identity ($identityType)"
        }
        return $assignment
    }

    Write-Run "Erstelle Policy-Zuweisung '$AssignmentName' (ARM PUT, User-assigned MI)..."
    $props = @{
        displayName        = $DisplayName
        description        = $Description
        policyDefinitionId = $PolicyDefinitionId
        parameters         = $PolicyParameters
        enforcementMode    = "Default"
    }
    if ($NotScopes.Count -gt 0) { $props["notScopes"] = $NotScopes }
    $body = @{ location = $Location; identity = $identityBlock; properties = $props }
    $assignment = Invoke-ArmWrite -Method "put" -Url $assignmentUrl -Body $body -BodyFilePath $bodyPath -Action "Policy-Zuweisung erstellen ($AssignmentName)"
    if ($null -eq $assignment) { return $null }
    Write-Ok "Policy-Zuweisung erstellt: $AssignmentName"
    Write-Sub "ID: $($assignment.id)"
    return $assignment
}

# Remediation Task starten (ARM-API via az rest); ohne ResourceGroupName = Subscription-Scope
function Start-PolicyRemediation {
    param(
        [Parameter(Mandatory = $true)][string]$NamePrefix,
        [Parameter(Mandatory = $true)][string]$AssignmentId,
        [string]$ResourceGroupName = ""
    )
    $remediationName = $NamePrefix + "-" + (Get-Date -Format "yyyyMMddHHmmss")
    $baseUrl = "https://management.azure.com/subscriptions/$SubscriptionId"
    if (-not [string]::IsNullOrWhiteSpace($ResourceGroupName)) { $baseUrl += "/resourceGroups/$ResourceGroupName" }
    $url = "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${remediationName}?api-version=$RemediationApiVersion"
    if ($TriggerComplianceScanFirst) {
        Write-Run "Loese Compliance-Scan aus (kann einige Minuten dauern)..."
        $scanArgs = @("policy", "state", "trigger-scan", "--output", "none")
        if (-not [string]::IsNullOrWhiteSpace($ResourceGroupName)) { $scanArgs += @("--resource-group", $ResourceGroupName) }
        & az @scanArgs
        if ($LASTEXITCODE -eq 0) { Write-Ok "Compliance-Scan abgeschlossen" }
        else { Write-Warn "Compliance-Scan konnte nicht ausgeloest werden - fahre trotzdem fort" }
    }
    $body = @{
        properties = @{
            policyAssignmentId    = $AssignmentId
            resourceDiscoveryMode = $RemediationDiscoveryMode
        }
    }
    $bodyPath = Join-Path $WorkDirectory ("remediation-" + $remediationName + ".json")
    Write-Run "Starte Remediation '$remediationName' (Modus: $RemediationDiscoveryMode)..."
    $rem = Invoke-ArmWrite -Method "put" -Url $url -Body $body -BodyFilePath $bodyPath -Action "Remediation erstellen ($remediationName)"
    if ($null -ne $rem) {
        Write-Ok "Remediation Task gestartet: $remediationName"
        return $remediationName
    }
    return $null
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Line
Write-Section "PRE-CHECK"

# --- PowerShell-Version -------------------------------------------------------
$psVersion = $PSVersionTable.PSVersion
Write-Info "PowerShell Version: $psVersion (Modus: $PowerShellMode)"
if ($psVersion.Major -lt 5 -or ($psVersion.Major -eq 5 -and $psVersion.Minor -lt 1)) {
    Write-Err "PowerShell 5.1 oder hoeher wird benoetigt."
    Write-Line
    exit 1
}
if ($PowerShellMode -eq "Seven" -and $psVersion.Major -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - aktuell: $psVersion"
    Write-Line
    exit 1
}
if (($psVersion.Major -gt 7) -or ($psVersion.Major -eq 7 -and $psVersion.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PS 7.3+ erkannt: PSNativeCommandUseErrorActionPreference = false"
}

# --- Azure CLI vorhanden? -----------------------------------------------------
Write-Info "Pruefe Azure CLI..."
$azCommand = Get-Command az -ErrorAction SilentlyContinue
if ($null -eq $azCommand) {
    Write-Err "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    Write-Line
    exit 1
}
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
Assert-AzSuccess -Action "az version" -Fatal | Out-Null
$azVersionObj = ConvertFrom-AzJson -RawOutput $azVersionRaw
$azCliVersion = [string]$azVersionObj.'azure-cli'
Write-Ok "Azure CLI gefunden: $azCliVersion"

# --- Azure CLI aktuell? -------------------------------------------------------
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $latestInfo    = Invoke-RestMethod -Uri "https://pypi.org/pypi/azure-cli/json" -TimeoutSec 10 -ErrorAction Stop
    $latestVersion = [string]$latestInfo.info.version
    if ([Version]$azCliVersion -lt [Version]$latestVersion) {
        Write-Warn "Neuere Version verfuegbar: $latestVersion (Update mit: az upgrade)"
    }
    else {
        Write-Ok "Azure CLI ist aktuell"
    }
}
catch {
    Write-Warn "Versionsvergleich nicht moeglich - bitte manuell pruefen (az upgrade)"
}

# --- Azure Login vorhanden? ---------------------------------------------------
Write-Info "Pruefe Azure Login..."
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Kein Login vorhanden - starte az login..."
    & az login --output none
    Assert-AzSuccess -Action "az login" -Fatal | Out-Null
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess -Action "az account show" -Fatal | Out-Null
}
$account = ConvertFrom-AzJson -RawOutput $accountRaw
Write-Ok "Login vorhanden: $($account.user.name)"

# --- Subscription setzen ------------------------------------------------------
Write-Run "Setze Subscription '$Subscription'..."
& az account set --subscription $Subscription --output none
Assert-AzSuccess -Action "az account set" -Fatal | Out-Null
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
Assert-AzSuccess -Action "az account show" -Fatal | Out-Null
$account = ConvertFrom-AzJson -RawOutput $accountRaw
$SubscriptionId = [string]$account.id
Write-Ok "Aktive Subscription: $($account.name) ($SubscriptionId)"

Write-Line
Write-Section "SCRIPT-VERSION"
Write-Info "$ScriptName - Version $ScriptVersion"
Write-Line

# =============================================================================
# [ ZUSAMMENFASSUNG REPO ]
# =============================================================================
Write-Section "ZUSAMMENFASSUNG: AVD SESSIONHOSTS MONITORING 2.0"
Write-Info "Quelle: GetToThe-Cloud/Website - AzureVirtualDesktop-SessionhostMonitoring"
Write-Sub "Blog: https://www.gettothe.cloud/azure-virtual-desktop-sessionhost-monitoring-2-0/"
Write-Host ""
Write-Info "Was seit 2024 anders ist:"
Write-Sub "- Log Analytics Agent seit 31.08.2024 abgekuendigt -> nur noch Azure Monitor Agent (AMA)"
Write-Sub "- AVD Insights nutzt eine DCR mit Prefix 'microsoft-avdi-<region>' (Name ist Pflicht)"
Write-Sub "- RTT kommt aus WVDConnectionNetworkData statt aus RemoteFX-Countern"
Write-Host ""
Write-Info "Sechs Dinge, die auf einem Session Host ueberwacht werden:"
Write-Sub "1. AVD-Agent-Health (WVDAgentHealthStatus, Health Checks, NeedsAssistance)"
Write-Sub "2. Kapazitaet / Dichte (Sessions pro Host, CPU + RAM pro Session)"
Write-Sub "3. User Experience (User Input Delay, Round Trip Time)"
Write-Sub "4. Connection Success (WVDConnections / WVDErrors)"
Write-Sub "5. FSLogix (Operational/Admin-Logs, Warnung und hoeher)"
Write-Sub "6. Datenqualitaet (Heartbeat, Counter-Frische, Hosts ohne Daten)"
Write-Host ""
Write-Info "Architektur:"
Write-Sub "- Insights-DCR (microsoft-avdi-<region>) bleibt unveraendert"
Write-Sub "- Alles Zusaetzliche in separater DCR 'dcr-avd-day2-<region>' (keine Duplikate)"
Write-Sub "- Beide DCRs werden per Azure Policy mit den Session Hosts verknuepft"
Write-Sub "- Host-Pool-Diagnostic-Settings senden WVD*-Tabellen in denselben Workspace"
Write-Host ""
Write-Info "Inhalt der Day-2 DCR (Sampling 60s):"
Write-Sub "- RemoteFX Graphics(*): Frames Skipped (Server/Network/Client), Output Frames/Second"
Write-Sub "- Network Interface(*)\Bytes Total/sec"
Write-Sub "- System\Processor Queue Length"
Write-Sub "- Memory\Committed Bytes"
Write-Sub "- Eventlog: Microsoft-Windows-User Profile Service/Operational (Level 1-3)"
Write-Host ""
Write-Info "Deployment-Empfehlung (Produktion):"
Write-Sub "- Built-in Policy 'Configure Windows Machines to be associated with a DCR or DCE'"
Write-Sub "  auf die Session-Host-RG zuweisen, DCR-ID als Parameter, Remediation Task erstellen"
Write-Sub "- Neue Hosts aus Scaling Plan / Image Pipeline erhalten die Zuordnung automatisch"
Write-Host ""
Write-Info "Paket-Inhalt im Repo:"
Write-Sub "- bicep/ (main.bicep: DCR-, Association- und Alert-Module, main.bicepparam)"
Write-Sub "- arm/ (kompilierte ARM-Templates)"
Write-Sub "- workbook/avd-sessionhosts-monitoring-2.0.workbook.json (7 Tabs)"
Write-Sub "- scripts/ (Deploy-AvdDay2Monitoring.ps1, Set-AvdHostPoolDiagnostics.ps1)"
Write-Sub "- queries/ (Validierungs-Queries + KQL hinter jedem Tab)"
Write-Host ""
Write-Info "Alerts (bewusst nur zwei):"
Write-Sub "- Session Host 15 Minuten nicht 'Available' (WVDAgentHealthStatus)"
Write-Sub "- P95 Input Delay > 200 ms (15-min-Intervall, 30-min-Fenster)"
Write-Line

# =============================================================================
# [ VORBEREITUNG ]
# =============================================================================
Write-Section "VORBEREITUNG"

if (-not (Test-Path -Path $WorkDirectory)) {
    New-Item -Path $WorkDirectory -ItemType Directory -Force | Out-Null
}
Write-Info "Arbeitsverzeichnis: $WorkDirectory"

# Scope-Modus validieren
if ($PolicyScopeMode -ne "ResourceGroup" -and $PolicyScopeMode -ne "Subscription") {
    Write-Err "Ungueltiger PolicyScopeMode '$PolicyScopeMode' - erlaubt: ResourceGroup | Subscription"
    Write-Line
    exit 1
}
Write-Info "Policy-Scope-Modus: $PolicyScopeMode"

# Monitoring-RG vorhanden?
Write-Run "Pruefe Resource Group '$MonitoringResourceGroupName'..."
$rgExistsRaw = Invoke-AzQuiet -Arguments @("group", "exists", "--name", $MonitoringResourceGroupName)
Assert-AzSuccess -Action "az group exists" -Fatal | Out-Null
if ((ConvertFrom-AzText -RawOutput $rgExistsRaw) -eq "true") {
    Write-Ok "Resource Group vorhanden: $MonitoringResourceGroupName"
}
else {
    Write-Run "Erstelle Resource Group '$MonitoringResourceGroupName' in $Location..."
    & az group create --name $MonitoringResourceGroupName --location $Location --output none
    Assert-AzSuccess -Action "az group create" -Fatal | Out-Null
    Write-Ok "Resource Group erstellt: $MonitoringResourceGroupName"
}

# Workspace-ID zusammensetzen und pruefen
$WorkspaceResourceId = "/subscriptions/$SubscriptionId/resourceGroups/$WorkspaceResourceGroupName/providers/Microsoft.OperationalInsights/workspaces/$WorkspaceName"
Write-Run "Pruefe Log Analytics Workspace '$WorkspaceName'..."
$wsNameRaw = Invoke-AzQuiet -Arguments @("resource", "show", "--ids", $WorkspaceResourceId, "--query", "name", "--output", "tsv")
if (-not (Assert-AzSuccess -Action "Workspace-Pruefung")) {
    Write-Err "Workspace nicht gefunden: $WorkspaceResourceId"
    Write-Line
    exit 1
}
Write-Ok "Workspace gefunden: $(ConvertFrom-AzText -RawOutput $wsNameRaw)"
Write-Line

# =============================================================================
# [ VORAUSSETZUNG: INSIGHTS-DCR ]
# =============================================================================
Write-Section "VORAUSSETZUNG: AVD INSIGHTS DCR"

$insightsDcrResourceId = ""
if (-not [string]::IsNullOrWhiteSpace($InsightsDcrResourceGroupName)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' in RG '$InsightsDcrResourceGroupName'..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $InsightsDcrResourceGroupName, "--name", $InsightsDcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' subscriptionweit..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "list", "--resource-type", "Microsoft.Insights/dataCollectionRules", "--name", $InsightsDcrName, "--query", "[0].id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    Write-Err "Insights-DCR '$InsightsDcrName' NICHT gefunden - Abbruch."
    Write-SubErr "Dieser Schritt ist zuerst notwendig:"
    Write-SubErr "  1. Azure Portal > Azure Virtual Desktop > Insights > Konfigurations-Workbook (CheckAMAConfiguration)"
    Write-SubErr "  2. Workspace und DCR-Resource-Group waehlen, 'Create data collection rule' klicken"
    Write-SubErr "  3. Dabei entsteht die DCR '$InsightsDcrName'"
    Write-SubErr "  4. Anschliessend dieses Script erneut starten"
    Write-Line
    exit 1
}
$insightsDcrResourceGroupName = Get-ResourceGroupFromId -ResourceId $insightsDcrResourceId
Write-Ok "Insights-DCR gefunden: $InsightsDcrName (RG: $insightsDcrResourceGroupName)"
Write-Sub "ID: $insightsDcrResourceId"
Write-Line

# =============================================================================
# [ HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS ]
# =============================================================================
Write-Section "HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS"

$targetRgMap = @{}   # RG-Name -> Liste der Host Pools, die dort Session Hosts haben
$discoveredHostPools = @()

if ($ManualResourceGroupNames.Count -gt 0) {
    Write-Info "Manuelle Resource-Group-Liste wird verwendet - keine automatische Ermittlung."
    foreach ($rg in $ManualResourceGroupNames) { $targetRgMap[$rg] = @("manuell") }
}
else {
    Write-Run "Ermittle AVD Host Pools in der Subscription..."
    $hpUrl = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.DesktopVirtualization/hostPools?api-version=$DesktopVirtualizationApiVersion"
    $hostPools = Invoke-ArmGetAll -Url $hpUrl
    if ($null -eq $hostPools) {
        Write-Err "Host Pools konnten nicht abgefragt werden (az rest)."; Write-Line; exit 1
    }
    if ($hostPools.Count -eq 0) {
        Write-Err "Keine Host Pools in der Subscription gefunden."; Write-Line; exit 1
    }
    Write-Ok "$($hostPools.Count) Host Pool(s) gefunden"

    foreach ($hp in $hostPools) {
        $hpName = [string]$hp.name
        $hpRg   = Get-ResourceGroupFromId -ResourceId ([string]$hp.id)
        $discoveredHostPools += New-Object PSObject -Property @{ Name = $hpName; Id = [string]$hp.id; ResourceGroup = $hpRg }

        if ($HostPoolNameFilter.Count -gt 0 -and $HostPoolNameFilter -notcontains $hpName) {
            Write-Sub "Uebersprungen (Filter): $hpName"
            continue
        }

        Write-Run "Host Pool '$hpName' (RG: $hpRg) - lese Session Hosts..."
        $shUrl = "https://management.azure.com$($hp.id)/sessionHosts?api-version=$DesktopVirtualizationApiVersion"
        $sessionHosts = Invoke-ArmGetAll -Url $shUrl
        if ($null -eq $sessionHosts) {
            Write-Warn "Session Hosts von '$hpName' konnten nicht gelesen werden - uebersprungen"
            continue
        }

        $rgsOfPool = @()
        $arcHosts = 0
        $azureHosts = 0
        foreach ($sh in $sessionHosts) {
            $vmId = ""
            if ($null -ne $sh.properties -and $null -ne $sh.properties.resourceId) { $vmId = [string]$sh.properties.resourceId }
            if ([string]::IsNullOrWhiteSpace($vmId)) { continue }
            $vmRg = Get-ResourceGroupFromId -ResourceId $vmId
            if ($vmId -match "(?i)/Microsoft\.HybridCompute/machines/") { $arcHosts++ } else { $azureHosts++ }
            if (-not [string]::IsNullOrWhiteSpace($vmRg) -and $rgsOfPool -notcontains $vmRg) { $rgsOfPool += $vmRg }
        }

        if ($rgsOfPool.Count -eq 0) {
            if ($UseHostPoolRgIfNoSessionHosts) {
                Write-Warn "'$hpName' hat keine Session Hosts mit VM-Resource-ID - verwende Host-Pool-RG '$hpRg'"
                $rgsOfPool += $hpRg
            }
            else {
                Write-Warn "'$hpName' hat keine Session Hosts - uebersprungen"
                continue
            }
        }
        else {
            Write-Ok "'$hpName': $($sessionHosts.Count) Session Host(s) [$arcHosts Arc, $azureHosts Azure-VM] in RG: $($rgsOfPool -join ', ')"
        }

        foreach ($rg in $rgsOfPool) {
            if (-not $targetRgMap.ContainsKey($rg)) { $targetRgMap[$rg] = @() }
            $targetRgMap[$rg] += $hpName
        }
    }
}

$targetResourceGroups = @($targetRgMap.Keys | Sort-Object)
if ($targetResourceGroups.Count -eq 0) {
    Write-Err "Keine Ziel-Resource-Groups ermittelt."; Write-Line; exit 1
}
Write-Host ""
Write-Info "Session-Host-Resource-Groups ($($targetResourceGroups.Count)):"
foreach ($rg in $targetResourceGroups) {
    Write-Sub "- $rg  (Host Pools: $(($targetRgMap[$rg] | Sort-Object -Unique) -join ', '))"
}

# Assignment-Scopes je nach Modus
$assignmentScopes = @()
if ($PolicyScopeMode -eq "ResourceGroup") {
    foreach ($rg in $targetResourceGroups) { $assignmentScopes += "/subscriptions/$SubscriptionId/resourceGroups/$rg" }
}
else {
    $assignmentScopes += "/subscriptions/$SubscriptionId"
    Write-Warn "Subscription-Scope: Policy trifft ALLE Windows-Maschinen der Subscription"
    if ($PolicyNotScopes.Count -gt 0) { Write-Sub "Ausgenommen (not-scopes): $($PolicyNotScopes -join ', ')" }
}
Write-Line

# =============================================================================
# [ MANAGED IDENTITY ]
# =============================================================================
Write-Section "MANAGED IDENTITY"
Write-Run "Pruefe User-assigned Managed Identity '$ManagedIdentityName'..."
$miRaw = Invoke-AzQuiet -Arguments @("identity", "show", "--name", $ManagedIdentityName, "--resource-group", $ManagedIdentityResourceGroupName, "--output", "json")
$managedIdentity = $null
if ($LASTEXITCODE -eq 0 -and $null -ne $miRaw) {
    $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw
}
$identityIsNew = $false
if ($null -ne $managedIdentity) {
    Write-Ok "Managed Identity vorhanden: $ManagedIdentityName"
}
else {
    Write-Warn "Managed Identity nicht vorhanden - wird erstellt..."
    $miRaw = & az identity create `
        --name $ManagedIdentityName `
        --resource-group $ManagedIdentityResourceGroupName `
        --location $Location `
        --output json
    Assert-AzSuccess -Action "az identity create" -Fatal | Out-Null
    $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw
    $identityIsNew = $true
    Write-Ok "Managed Identity erstellt: $ManagedIdentityName"
}
$identityResourceId = [string]$managedIdentity.id
$identityPrincipalId = [string]$managedIdentity.principalId
Write-Sub "Resource-ID : $identityResourceId"
Write-Sub "Principal-ID: $identityPrincipalId"
if ($identityIsNew) {
    Write-Info "Warte 20 s auf Replikation der neuen Identity..."
    Start-Sleep -Seconds 20
}

# Rollen: auf allen Assignment-Scopes (DCRA anlegen) + Monitoring-RG + RG der Insights-DCR (DCR lesen)
Write-Run "Vergebe Rollen an die Managed Identity..."
$roleScopes = @()
foreach ($s in $assignmentScopes) { $roleScopes += $s }
$extraRgs = @($MonitoringResourceGroupName)
if (-not [string]::IsNullOrWhiteSpace($insightsDcrResourceGroupName) -and $insightsDcrResourceGroupName -ne $MonitoringResourceGroupName) {
    $extraRgs += $insightsDcrResourceGroupName
}
if ($PolicyScopeMode -eq "ResourceGroup") {
    foreach ($rg in $extraRgs) {
        $rgScope = "/subscriptions/$SubscriptionId/resourceGroups/$rg"
        if ($roleScopes -notcontains $rgScope) { $roleScopes += $rgScope }
    }
}
# Im Subscription-Modus deckt der Subscription-Scope bereits alle RGs ab.

$roleErrors = 0
foreach ($roleScope in $roleScopes) {
    foreach ($roleName in $PolicyRoleNames) {
        $result = Set-RoleAssignmentWithRetry -PrincipalId $identityPrincipalId -RoleName $roleName -Scope $roleScope
        if (-not $result) {
            $roleErrors++
            Write-Err "Rolle '$roleName' konnte auf $roleScope nicht zugewiesen werden."
        }
    }
}
if ($roleErrors -gt 0) {
    Write-Warn "$roleErrors Rollenzuweisung(en) fehlgeschlagen - Remediation wird moeglicherweise scheitern."
}
Write-Line

# =============================================================================
# [ DATA COLLECTION RULE (DAY-2) ]
# =============================================================================
Write-Section "DATA COLLECTION RULE (DAY-2)"

$dcrTemplatePath = Join-Path $WorkDirectory "dcr-avd-day2.template.json"

# ARM-Template entspricht dem Bicep aus dem Repo (Microsoft.Insights/dataCollectionRules@2022-06-01)
$dcrTemplate = @'
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "dcrName": { "type": "string" },
    "location": { "type": "string" },
    "workspaceResourceId": { "type": "string" },
    "samplingFrequencyInSeconds": { "type": "int", "defaultValue": 60 }
  },
  "resources": [
    {
      "type": "Microsoft.Insights/dataCollectionRules",
      "apiVersion": "2022-06-01",
      "name": "[parameters('dcrName')]",
      "location": "[parameters('location')]",
      "kind": "Windows",
      "tags": {
        "purpose": "avd-day2-monitoring",
        "source": "GetToTheCloud Sessionhost monitoring 2.0"
      },
      "properties": {
        "description": "Supplemental AVD Day-2 DCR. Does not duplicate the microsoft-avdi Insights DCR.",
        "dataSources": {
          "performanceCounters": [
            {
              "name": "avdDay2Perf",
              "streams": [ "Microsoft-Perf" ],
              "samplingFrequencyInSeconds": "[parameters('samplingFrequencyInSeconds')]",
              "counterSpecifiers": [
                "\\RemoteFX Graphics(*)\\Frames Skipped/Second - Insufficient Server Resources",
                "\\RemoteFX Graphics(*)\\Frames Skipped/Second - Insufficient Network Resources",
                "\\RemoteFX Graphics(*)\\Frames Skipped/Second - Insufficient Client Resources",
                "\\RemoteFX Graphics(*)\\Output Frames/Second",
                "\\Network Interface(*)\\Bytes Total/sec",
                "\\System\\Processor Queue Length",
                "\\Memory\\Committed Bytes"
              ]
            }
          ],
          "windowsEventLogs": [
            {
              "name": "avdDay2Events",
              "streams": [ "Microsoft-Event" ],
              "xPathQueries": [
                "Microsoft-Windows-User Profile Service/Operational!*[System[(Level=1 or Level=2 or Level=3)]]"
              ]
            }
          ]
        },
        "destinations": {
          "logAnalytics": [
            {
              "name": "logAnalyticsWorkspace",
              "workspaceResourceId": "[parameters('workspaceResourceId')]"
            }
          ]
        },
        "dataFlows": [
          {
            "streams": [ "Microsoft-Perf", "Microsoft-Event" ],
            "destinations": [ "logAnalyticsWorkspace" ]
          }
        ]
      }
    }
  ],
  "outputs": {
    "dcrResourceId": {
      "type": "string",
      "value": "[resourceId('Microsoft.Insights/dataCollectionRules', parameters('dcrName'))]"
    }
  }
}
'@

Write-JsonFile -Path $dcrTemplatePath -Content $dcrTemplate
Write-Info "ARM-Template geschrieben: $dcrTemplatePath"

$deploymentName = "avd-day2-dcr-" + (Get-Date -Format "yyyyMMddHHmmss")
Write-Run "Deploye DCR '$DcrName' nach '$MonitoringResourceGroupName'..."
$dcrIdRaw = & az deployment group create `
    --resource-group $MonitoringResourceGroupName `
    --name $deploymentName `
    --template-file $dcrTemplatePath `
    --parameters "dcrName=$DcrName" "location=$Location" "workspaceResourceId=$WorkspaceResourceId" "samplingFrequencyInSeconds=$SamplingFrequencyInSeconds" `
    --query "properties.outputs.dcrResourceId.value" `
    --output tsv
Assert-AzSuccess -Action "az deployment group create (DCR)" -Fatal | Out-Null

$dcrResourceId = ConvertFrom-AzText -RawOutput $dcrIdRaw
if ([string]::IsNullOrWhiteSpace($dcrResourceId)) {
    # Fallback: ID ueber az resource show ermitteln
    $dcrIdRaw = Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $MonitoringResourceGroupName, "--name", $DcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv")
    Assert-AzSuccess -Action "az resource show (DCR)" -Fatal | Out-Null
    $dcrResourceId = ConvertFrom-AzText -RawOutput $dcrIdRaw
}
Write-Ok "DCR bereit: $DcrName"
Write-Sub "ID: $dcrResourceId"
Write-Line

# =============================================================================
# [ AZURE POLICY - DCR ASSOCIATION ]
# =============================================================================
Write-Section "AZURE POLICY - DCR ASSOCIATION"

Write-Run "Ermittle Built-in Policy-Definition..."
$dcrPolicyDefinitionId = Get-BuiltinPolicyDefinitionId -DefinitionGuid $DcrPolicyDefinitionGuid -DisplayName $DcrPolicyDisplayName
if ($null -eq $dcrPolicyDefinitionId) {
    Write-Err "Policy-Definition '$DcrPolicyDisplayName' nicht gefunden."
    Write-Line
    exit 1
}
Write-Ok "Policy-Definition gefunden"
Write-Sub "$dcrPolicyDefinitionId"

# Parameter-Dateien (eine je DCR)
$paramsInsights = @{
    dcrResourceId = @{ value = $insightsDcrResourceId }
    resourceType  = @{ value = "Microsoft.Insights/dataCollectionRules" }
    effect        = @{ value = "DeployIfNotExists" }
}
$paramsDay2 = @{
    dcrResourceId = @{ value = $dcrResourceId }
    resourceType  = @{ value = "Microsoft.Insights/dataCollectionRules" }
    effect        = @{ value = "DeployIfNotExists" }
}

# Zuweisungen je Scope: Insights-DCR + Day-2-DCR
$policyResults = @()
$scopeIndex = 0
foreach ($scope in $assignmentScopes) {
    $scopeIndex++
    $suffix = ""
    $remediationRg = ""
    if ($PolicyScopeMode -eq "ResourceGroup") {
        # Namen bleiben je RG eindeutig und lesbar
        $suffix = "-" + $scopeIndex.ToString("00")
        $remediationRg = $targetResourceGroups[$scopeIndex - 1]
    }
    Write-Host ""
    Write-Info "Scope $scopeIndex/$($assignmentScopes.Count): $scope"

    # --- a) Insights-DCR ---
    $insightsAssignment = Invoke-DcrPolicyAssignment `
        -AssignmentName ($InsightsPolicyAssignmentName + $suffix) `
        -DisplayName $InsightsPolicyAssignmentDisplayName `
        -Description "Verknuepft Windows Session Hosts mit der AVD-Insights-DCR ($InsightsDcrName)." `
        -Scope $scope `
        -PolicyDefinitionId $dcrPolicyDefinitionId `
        -IdentityResourceId $identityResourceId `
        -PolicyParameters $paramsInsights `
        -NotScopes $PolicyNotScopes
    if ($null -ne $insightsAssignment) {
        $remName = $null
        if ($CreateRemediationTask) {
            $remName = Start-PolicyRemediation -NamePrefix ($RemediationNamePrefix + "-insights" + $suffix) -AssignmentId ([string]$insightsAssignment.id) -ResourceGroupName $remediationRg
        }
        $policyResults += New-Object PSObject -Property @{
            Scope       = $scope
            Dcr         = $InsightsDcrName
            Assignment  = [string]$insightsAssignment.name
            Remediation = $remName
        }
    }

    # --- b) Day-2-DCR ---
    $day2Assignment = Invoke-DcrPolicyAssignment `
        -AssignmentName ($Day2PolicyAssignmentName + $suffix) `
        -DisplayName $Day2PolicyAssignmentDisplayName `
        -Description "Verknuepft Windows Session Hosts mit der supplementaeren AVD Day-2-DCR ($DcrName) - GetToTheCloud Sessionhost monitoring 2.0." `
        -Scope $scope `
        -PolicyDefinitionId $dcrPolicyDefinitionId `
        -IdentityResourceId $identityResourceId `
        -PolicyParameters $paramsDay2 `
        -NotScopes $PolicyNotScopes
    if ($null -ne $day2Assignment) {
        $remName = $null
        if ($CreateRemediationTask) {
            $remName = Start-PolicyRemediation -NamePrefix ($RemediationNamePrefix + "-day2" + $suffix) -AssignmentId ([string]$day2Assignment.id) -ResourceGroupName $remediationRg
        }
        $policyResults += New-Object PSObject -Property @{
            Scope       = $scope
            Dcr         = $DcrName
            Assignment  = [string]$day2Assignment.name
            Remediation = $remName
        }
    }
}
if (-not $CreateRemediationTask) {
    Write-Info "Remediation Tasks uebersprungen (CreateRemediationTask = false)"
}
Write-Line

# =============================================================================
# [ OPTIONAL: AMA-INSTALLATIONS-POLICY ]
# =============================================================================
if ($AssignAmaInstallPolicy) {
    Write-Section "AZURE POLICY - AZURE MONITOR AGENT"
    Write-Run "Ermittle Policy-Definition '$AmaPolicyDisplayName'..."
    $amaPolicyDefinitionId = Get-BuiltinPolicyDefinitionId -DefinitionGuid "" -DisplayName $AmaPolicyDisplayName
    if ($null -eq $amaPolicyDefinitionId) {
        Write-Warn "AMA-Policy nicht gefunden - Abschnitt wird uebersprungen."
    }
    else {
        Write-Ok "Policy-Definition gefunden"
        # VM Contributor fuer die Extension-Installation
        foreach ($roleScope in $assignmentScopes) {
            foreach ($roleName in $AmaPolicyRoleNames) {
                Set-RoleAssignmentWithRetry -PrincipalId $identityPrincipalId -RoleName $roleName -Scope $roleScope | Out-Null
            }
        }
        $scopeIndex = 0
        foreach ($scope in $assignmentScopes) {
            $scopeIndex++
            $suffix = ""
            $remediationRg = ""
            if ($PolicyScopeMode -eq "ResourceGroup") {
                $suffix = "-" + $scopeIndex.ToString("00")
                $remediationRg = $targetResourceGroups[$scopeIndex - 1]
            }
            $amaName = $AmaPolicyAssignmentName + $suffix
            $amaAssignment = Invoke-DcrPolicyAssignment `
                -AssignmentName $amaName `
                -DisplayName "AVD - Azure Monitor Agent installieren" `
                -Description "Installiert den Azure Monitor Agent auf Windows-VMs (System-assigned MI der VM)." `
                -Scope $scope `
                -PolicyDefinitionId $amaPolicyDefinitionId `
                -IdentityResourceId $identityResourceId `
                -PolicyParameters @{} `
                -NotScopes $PolicyNotScopes
            if ($null -ne $amaAssignment -and $CreateRemediationTask) {
                Start-PolicyRemediation -NamePrefix ($RemediationNamePrefix + "-ama" + $suffix) -AssignmentId ([string]$amaAssignment.id) -ResourceGroupName $remediationRg | Out-Null
            }
        }
    }
    Write-Line
}

# =============================================================================
# [ OPTIONAL: HOST POOL DIAGNOSTIC SETTINGS ]
# =============================================================================
if ($ConfigureHostPoolDiagnostics) {
    Write-Section "HOST POOL DIAGNOSTIC SETTINGS"
    $logsPath = Join-Path $WorkDirectory "diag-logs-alllogs.json"
    Write-JsonFile -Path $logsPath -Content '[ { "categoryGroup": "allLogs", "enabled": true } ]'

    if ($discoveredHostPools.Count -eq 0) {
        Write-Warn "Keine Host Pools ermittelt (manuelle RG-Liste?) - Diagnostic Settings uebersprungen"
    }
    foreach ($hp in $discoveredHostPools) {
        if ($DiagnosticHostPoolNames.Count -gt 0 -and $DiagnosticHostPoolNames -notcontains $hp.Name) { continue }
        Write-Run "Host Pool '$($hp.Name)'..."
        & az monitor diagnostic-settings create `
            --name $DiagnosticSettingName `
            --resource $hp.Id `
            --workspace $WorkspaceResourceId `
            --logs "@$logsPath" `
            --output none
        if (Assert-AzSuccess -Action "Diagnostic Setting '$($hp.Name)'") {
            Write-Ok "Diagnostic Setting '$DiagnosticSettingName' gesetzt (allLogs): $($hp.Name)"
        }
    }
    Write-Line
}

# =============================================================================
# [ ERGEBNIS ]
# =============================================================================
Write-Section "ERGEBNIS"
Write-Ok "Insights-DCR     : $InsightsDcrName"
Write-Sub $insightsDcrResourceId
Write-Ok "Day-2-DCR        : $DcrName"
Write-Sub $dcrResourceId
Write-Ok "Managed Identity : $ManagedIdentityName"
Write-Sub $identityResourceId
Write-Host ""
Write-Info "Policy-Zuweisungen ($($policyResults.Count)):"
foreach ($r in $policyResults) {
    $remText = "keine"
    if (-not [string]::IsNullOrWhiteSpace($r.Remediation)) { $remText = $r.Remediation }
    Write-Sub "- $($r.Assignment)  ->  $($r.Dcr)"
    Write-Sub "  Scope      : $($r.Scope)"
    Write-Sub "  Remediation: $remText"
}
Write-Host ""
Write-Info "Naechste Schritte laut Repo:"
Write-Sub "1. Workbook aus workbook/avd-sessionhosts-monitoring-2.0.workbook.json importieren"
Write-Sub "   (Azure Monitor > Workbooks > Neu > Advanced Editor </> > JSON einfuegen)"
Write-Sub "2. Validieren: Resource Graph - jeder Host sollte BEIDE DCRs haben:"
Write-Sub "   insightsresources | where type == 'microsoft.insights/datacollectionruleassociations'"
Write-Sub "   (Arc-Maschinen: ID enthaelt '/microsoft.hybridcompute/machines/', Azure-VMs '/virtualmachines/')"
Write-Sub "3. Heartbeat / Counter-Frische ueber Tab 'Data quality' bzw. queries/ pruefen"
Write-Sub "4. Zwei Alerts anlegen: Host nicht Available (15 min), P95 Input Delay > 200 ms"
Write-Sub "5. Zwei Wochen Baseline sammeln, dann Schwellwerte anpassen"
Write-Host ""
Write-Info "Remediation-Status: az policy remediation list --resource-group <rg> --output table"
Write-Line
