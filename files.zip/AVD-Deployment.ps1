﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Runner fuer den AVD Deployment Wizard - liest avd-config.json und fuehrt die Phasen aus.
.DESCRIPTION
    Liest die vom HTML-Wizard erzeugte avd-config.json und steuert das Deployment:
      - Pre-Check: Azure CLI vorhanden + aktuell, Login, Extensions
      - Legt pro Host Pool eine eigene Resource Group an (idempotent)
      - Fuehrt die Phasen non-interaktiv aus (Subnet, Infra, AppGroup, LogA, NSG, optional SessionHosts)
      - VNet/Subnet werden in der VNet-Resource-Group (general.vnetResourceGroup) verarbeitet
      - Passwoerter (Admin/Domain Join) entweder zur Laufzeit sicher abgefragt ODER aus einem Key Vault gelesen (sessionhost.adminPwSource/djPwSource) - Klartext-Passwoerter werden NIE in der Config gespeichert
      - Session Hosts: Deployment auf Azure Local per OFFIZIELLEM AVD-Template (Microsoft 'azurestackhci-vm.json' via az deployment group create --template-uri) in die waehlbare Ziel-RG (sessionhost.targetResourceGroup). Erzeugt VM + Domain Join + AVD-Agent-Registrierung (CustomScriptExtension) + azmonitor, registriert die Hosts ueber den automatisch erzeugten Registration Token. Template-/Artefakt-URLs sind config-ueberschreibbar (sessionhost.armTemplateUri / scriptFileUri / configurationZipUri).
      - Optional: traegt ein Zusatz-Subnet idempotent als Address Space in ein Local Network Gateway ein (localGateway.autoUpdate)
      - Optional: Entra ID SSO am Host Pool (sso.enableSso -> enablerdsaadauth=1 in den RDP-Properties); die einmaligen Tenant-Voraussetzungen werden als offene Punkte ausgegeben
    Bruecke zwischen dem HTML-Wizard und der Azure CLI (Azure CLI in PowerShell, keine Az-Module).
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-06-16
    Version     : 1.8.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\AVD-Deployment.ps1 -ConfigFile .\avd-config.json
.EXAMPLE
    .\AVD-Deployment.ps1 -ConfigFile .\avd-config.json -WhatIf
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigFile,
    [switch]$WhatIf   # Nur anzeigen was getan wuerde, nichts ausfuehren
)

# UTF-8 Ausgabe (fuer Symbole/Emoji in der Konsole)
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

# ============================================================
#  LOGGING / AUSGABE
# ============================================================
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile = "$PSScriptRoot\AVD-Deployment_$timestamp.log"
$manualTasks = @()   # offene, manuell zu erledigende Punkte (z.B. wegen fehlender Berechtigungen)

function Write-Log {
    param([string]$Message,[ValidateSet("INFO","WARN","ERROR","OK","STEP")][string]$Level="INFO")
    $ts = Get-Date -Format "HH:mm:ss"
    switch ($Level) {
        "OK"    { $sym = "✅"; $col = "Green" }
        "ERROR" { $sym = "❌"; $col = "Red" }
        "WARN"  { $sym = "⚠️ "; $col = "Yellow" }
        "STEP"  { $sym = "🔄"; $col = "Cyan" }
        default { $sym = "ℹ️ "; $col = "Cyan" }
    }
    Write-Host "[$ts] $sym $Message" -ForegroundColor $col
    Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$Level] $Message"
}
function Write-Divider { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$T); Write-Host ""; Write-Divider; Write-Host "[ $T ]" -ForegroundColor White; Write-Divider }

# Fuehrt az-Befehl aus oder zeigt ihn nur (WhatIf). Bricht bei Fehler SOFORT ab.
function Invoke-Az {
    param([string]$Desc,[scriptblock]$Cmd)
    if ($WhatIf) { Write-Log "[WhatIf] $Desc" "INFO"; return $true }
    Write-Log "$Desc" "STEP"
    $out = & $Cmd 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log "Fehler: $Desc" "ERROR"
        $msg = ($out | Out-String).Trim()
        if ($msg) {
            foreach ($ln in ($msg -split "`r?`n")) { if ($ln.Trim()) { Write-Host "    $($ln.Trim())" -ForegroundColor DarkYellow } }
            Add-Content -Path $logFile -Value "[az-Fehler] $msg"
        }
        Write-Log "Script wird abgebrochen (siehe Fehler oben). Log: $logFile" "ERROR"
        exit 1
    }
    Write-Log "$Desc" "OK"
    return $true
}

# Wie Invoke-Az, aber bricht NICHT ab - fuer optionale Schritte (z.B. Flag von der CLI nicht unterstuetzt)
function Invoke-AzSoft {
    param([string]$Desc,[scriptblock]$Cmd,[string]$Hint,[string]$Manual)
    if ($WhatIf) { Write-Log "[WhatIf] $Desc" "INFO"; return }
    Write-Log "$Desc" "STEP"
    $out = & $Cmd 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log "Uebersprungen (nicht kritisch): $Desc" "WARN"
        $msg = ($out | Out-String).Trim()
        if ($msg) { foreach ($ln in ($msg -split "`r?`n")) { if ($ln.Trim()) { Write-Host "    $($ln.Trim())" -ForegroundColor DarkYellow } } }
        if ($Hint) { Write-Log "    Hinweis: $Hint" "INFO" }
        if ($Manual) { $script:manualTasks += $Manual }
    } else { Write-Log "$Desc" "OK" }
}

# Passwort beschaffen: entweder aus Key Vault (source=keyvault) oder sichere Laufzeit-Abfrage.
# Liefert das Passwort als Klartext-String zurueck (nur im Speicher, nie in der Config/Log).
function Resolve-Password {
    param(
        [string]$Source,      # "keyvault" | "runtime" (alles andere => runtime)
        [string]$KvId,        # Resource-ID des Key Vaults (/subscriptions/.../vaults/<name>)
        [string]$SecretName,  # Name des Secrets im Key Vault
        [string]$Prompt       # Text fuer die Laufzeit-Abfrage
    )
    if ($Source -eq "keyvault") {
        if (-not $KvId -or -not $SecretName) {
            Write-Log "Key-Vault-Quelle gewaehlt, aber Vault-ID oder Secret-Name fehlt - falle auf Abfrage zurueck." "WARN"
        } else {
            $vaultName = ($KvId -split '/')[-1]
            Write-Log "Lese Passwort aus Key Vault '$vaultName' (Secret '$SecretName')..." "STEP"
            $val = az keyvault secret show --vault-name $vaultName --name $SecretName --query "value" -o tsv 2>$null
            if ($LASTEXITCODE -eq 0 -and $val) { Write-Log "Secret '$SecretName' aus Key Vault '$vaultName' gelesen." "OK"; return $val }
            Write-Log "Secret '$SecretName' konnte nicht aus Key Vault '$vaultName' gelesen werden (Berechtigung/Name pruefen) - falle auf Abfrage zurueck." "WARN"
        }
    }
    $sec = Read-Host $Prompt -AsSecureString
    return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
}
# ============================================================
#  PRE-CHECK
# ============================================================
Write-Section "PRE-CHECK"

# 1) Azure CLI vorhanden?
Write-Log "Pruefe Azure CLI..." "INFO"
$azVersion = az version 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
if (-not $azVersion) { Write-Log "Azure CLI nicht gefunden. Bitte installieren: https://aka.ms/installazurecli" "ERROR"; exit 1 }
$azCli = $azVersion.'azure-cli'
Write-Log "Azure CLI gefunden: $azCli" "OK"

# 2) Azure CLI aktuell? (Versionsvergleich / Hinweis)
$azMin = "2.50.0"
try {
    if ([version]$azCli -lt [version]$azMin) {
        Write-Log "Aeltere CLI-Version ($azCli < $azMin). 'az upgrade' wird empfohlen." "WARN"
    } else {
        Write-Log "CLI-Version ist aktuell genug (Empfehlung: gelegentlich 'az upgrade')." "OK"
    }
} catch { Write-Log "Versionsvergleich nicht moeglich - Hinweis: 'az upgrade' fuer die neueste Version." "WARN" }

# 3) Config laden
if (-not (Test-Path $ConfigFile)) { Write-Log "Config-Datei '$ConfigFile' nicht gefunden." "ERROR"; exit 1 }
try {
    $c = Get-Content $ConfigFile -Raw | ConvertFrom-Json
    Write-Log "Config geladen: $ConfigFile" "OK"
} catch {
    Write-Log "Config-Datei ist kein gueltiges JSON: $($_.Exception.Message)" "ERROR"; exit 1
}

# Logfile auf Host-Pool-Namen umstellen (bisherige Pre-Check-Zeilen werden mitgenommen)
if ($c.hostpool -and $c.hostpool.name) {
    $newLog = "$PSScriptRoot\AVD-Deployment_$($c.hostpool.name)_$timestamp.log"
    if (Test-Path $logFile) { Move-Item -Path $logFile -Destination $newLog -Force -ErrorAction SilentlyContinue }
    $logFile = $newLog
    Write-Log "Logfile: $logFile" "INFO"
}

# 4) Login vorhanden?
$account = az account show 2>$null | ConvertFrom-Json
if (-not $account) { Write-Log "Kein Azure-Login - starte 'az login'..." "WARN"; az login | Out-Null; $account = az account show 2>$null | ConvertFrom-Json }
if (-not $account) { Write-Log "Login fehlgeschlagen." "ERROR"; exit 1 }
Write-Log "Login vorhanden: $($account.user.name) / $($account.name)" "OK"

# 5) Extensions
foreach ($ext in @("desktopvirtualization")) {
    if (-not (az extension list --query "[?name=='$ext']" 2>$null | ConvertFrom-Json)) {
        Write-Log "Installiere Extension '$ext'..." "INFO"
        az extension add --name $ext 2>$null | Out-Null
    }
}
if ($c.phases.sessionhost) {
    if (-not (az extension list --query "[?name=='stack-hci-vm']" 2>$null | ConvertFrom-Json)) {
        Write-Log "Installiere Extension 'stack-hci-vm'..." "INFO"
        az extension add --name stack-hci-vm 2>$null | Out-Null
    }
}

# 6) Resource Provider registrieren (idempotent) - sonst scheitern Workspace/Host Pool sofort
$providers = @("Microsoft.DesktopVirtualization")
if ($c.phases.sessionhost) { $providers += "Microsoft.AzureStackHCI" }
foreach ($prov in $providers) {
    $pstate = az provider show --namespace $prov --query "registrationState" -o tsv 2>$null
    if ($pstate -eq "Registered") { Write-Log "Provider '$prov' registriert." "OK" }
    else {
        Write-Log "Registriere Provider '$prov' (kann 1-2 Min dauern)..." "WARN"
        az provider register --namespace $prov --output none 2>$null
        for ($i=0; $i -lt 24 -and $pstate -ne "Registered"; $i++) { Start-Sleep -Seconds 5; $pstate = az provider show --namespace $prov --query "registrationState" -o tsv 2>$null }
        if ($pstate -eq "Registered") { Write-Log "Provider '$prov' registriert." "OK" }
        else { Write-Log "Provider '$prov' Status '$pstate' - Workspace/Host Pool koennen sonst fehlschlagen." "WARN" }
    }
}

# ============================================================
#  VARIABLEN
# ============================================================
$rg       = $c.general.resourceGroup            # Pool-RG (pro Host Pool, wird angelegt)
$vnet     = $c.general.vnet                      # bestehendes, geteiltes VNet
$vnetRg   = $c.general.vnetResourceGroup         # RG in der das VNet liegt (Subnet-Ziel)
$location = $c.general.location
$rgDns    = $c.dns.rgDns                         # geteilte RG fuer DNS Private Zones

# Entra ID SSO am Host Pool: Wizard-Option 'sso.enableSso' (ab Wizard 2.1.0).
# Aeltere Configs nutzen 'sessionhost.enableSso' (nur bei aktiver Session-Host-Phase).
$ssoOn = $false
if ($c.PSObject.Properties['sso'] -and $c.sso -and $c.sso.PSObject.Properties['enableSso'] -and $c.sso.enableSso) { $ssoOn = $true }
if ($c.phases.sessionhost -and $c.PSObject.Properties['sessionhost'] -and $c.sessionhost -and $c.sessionhost.enableSso) { $ssoOn = $true }

if (-not $rg)     { Write-Log "general.resourceGroup (Pool-RG) fehlt in der Config." "ERROR"; exit 1 }
if (-not $vnet)   { Write-Log "general.vnet fehlt in der Config." "ERROR"; exit 1 }
if (-not $vnetRg) { $vnetRg = $rg; Write-Log "general.vnetResourceGroup fehlt - nutze Pool-RG als Fallback fuer VNet." "WARN" }

# VNet auslesen (in der VNet-RG, nicht der Pool-RG)
$vnetObj = az network vnet show --resource-group $vnetRg --name $vnet 2>$null | ConvertFrom-Json
if (-not $vnetObj) { Write-Log "VNet '$vnet' in RG '$vnetRg' nicht gefunden." "ERROR"; exit 1 }
$vnetId = $vnetObj.id
if (-not $location) { $location = $vnetObj.location; Write-Log "Region aus VNet uebernommen: $location" "INFO" }
Write-Log "VNet ausgelesen: $vnet (RG: $vnetRg, Region: $($vnetObj.location))" "OK"

# ============================================================
#  UEBERSICHT
# ============================================================
Write-Section "DEPLOYMENT-PLAN"
Write-Log "Pool Resource Group : $rg  (wird angelegt, falls nicht vorhanden)" "INFO"
Write-Log "Region              : $location" "INFO"
Write-Log "VNet / VNet-RG      : $vnet / $vnetRg" "INFO"
Write-Log "DNS-Zonen-RG        : $rgDns" "INFO"
Write-Log "Host Pool           : $($c.hostpool.name)" "INFO"
Write-Host ""
Write-Log "Geplante Ressourcen (nur aktive Phasen):" "INFO"

# --- Subnet ---
if ($c.phases.subnet) {
    if ($c.subnet.useExisting) {
        Write-Log "  [Subnet]  VORHANDEN nutzen: '$($c.subnet.name)' in VNet '$vnet' / RG '$vnetRg' (kein Anlegen)" "OK"
    } else {
        Write-Log "  [Subnet]  NEU anlegen: '$($c.subnet.name)' ($($c.subnet.cidr)) in VNet '$vnet' / RG '$vnetRg'" "OK"
        Write-Log "            private-endpoint-network-policies = Disabled" "INFO"
    }
}

# --- Infra: DNS-Zonen, Workspace, Host Pool, Private Endpoints ---
if ($c.phases.infra) {
    Write-Log "  [Infra]   DNS Private Zones (RG '$rgDns', idempotent, je + VNet-Link):" "OK"
    Write-Log "              - $($c.dns.zoneFeed)" "INFO"
    Write-Log "              - $($c.dns.zoneGlobal)" "INFO"
    Write-Log "            Workspace : '$($c.workspace.name)' (RG '$rg')" "OK"
    Write-Log "            Host Pool : '$($c.hostpool.name)' [Typ=$($c.hostpool.type), LB=$($c.hostpool.loadBalancer), maxSessions=$($c.hostpool.maxSessions), Validation=$($c.hostpool.validationEnv)]" "OK"
    Write-Log "            Private Endpoints (RG '$rg'):" "OK"
    Write-Log "              - PE-AVD-$($c.workspace.name)-feed  -> Feed-Discovery  ($($c.dns.zoneFeed))" "INFO"
    Write-Log "              - PE-AVD-$($c.hostpool.name)  -> Host-Pool-Connection  ($($c.dns.zoneFeed))" "INFO"
    Write-Log "              - PE-AVD-global  -> Global-Feed  ($($c.dns.zoneGlobal), nur falls noch nicht vorhanden)" "INFO"
    if ($ssoOn) { Write-Log "            Entra ID SSO : AN (enablerdsaadauth=1 am Host Pool - Tenant-Voraussetzungen siehe offene Punkte am Ende)" "WARN" }
    else        { Write-Log "            Entra ID SSO : AUS (enablerdsaadauth=0)" "INFO" }
}

# --- App Group ---
if ($c.phases.appgroup) {
    Write-Log "  [AppGrp]  App Group : '$($c.appgroup.name)' [Typ=$($c.appgroup.type)] (RG '$rg', mit Workspace verknuepft)" "OK"
    if ($c.appgroup.assignGroup) {
        Write-Log "            Rollenzuweisung 'Desktop Virtualization User' an Entra-Gruppe '$($c.appgroup.assignGroup)'" "INFO"
    } else {
        Write-Log "            keine Gruppenzuweisung (appgroup.assignGroup ist leer)" "INFO"
    }
}

# --- Log Analytics ---
if ($c.phases.loganalytics) {
    Write-Log "  [LogA]    Diagnostic Settings -> LAW '$($c.loganalytics.workspaceName)' (RG '$($c.loganalytics.resourceGroup)')" "OK"
    Write-Log "            angewendet auf Workspace '$($c.workspace.name)' und Host Pool '$($c.hostpool.name)'" "INFO"
}

# --- NSG ---
if ($c.phases.nsg) {
    if ($c.subnet.useExisting) {
        Write-Log "  [NSG]     VORHANDENES Subnet -> KEINE eigene NSG (bestehende Bindung bleibt; nur Hinweis auf benoetigte Regeln)" "WARN"
    } else {
        $planOnprem = $c.nsg.onprem
        if ($c.PSObject.Properties['localGateway'] -and $c.localGateway.needsExtraSubnet -and $c.localGateway.extraSubnet) {
            $planOnprem = "$($c.nsg.onprem),$($c.localGateway.extraSubnet)"
        }
        Write-Log "  [NSG]     NEU anlegen: 'nsg-$($c.subnet.name)' (RG '$rg'), gebunden an Subnet '$($c.subnet.name)'" "OK"
        Write-Log "            Allow Inbound TCP 1-65535 von: $planOnprem" "INFO"
        Write-Log "            Allow Inbound UDP 3390 (RDP Shortpath) von: $planOnprem" "INFO"
        if ($c.nsg.observeMode) {
            Write-Log "            Deny-All-Inbound: NEIN (Beobachtungsmodus aktiv)" "WARN"
        } else {
            Write-Log "            Deny-All-Inbound: JA (Prio 4000)" "INFO"
        }
    }
}

# --- Session Hosts ---
if ($c.phases.sessionhost -and $c.sessionhost) {
    $shRgPlan = if ($c.sessionhost.targetResourceGroup) { $c.sessionhost.targetResourceGroup } else { $rg }
    $shLastNum = [int]$c.sessionhost.countStart + [int]$c.sessionhost.count - 1
    $shFirst = "$($c.sessionhost.prefix)-$((("$($c.sessionhost.countStart)")).PadLeft([int]$c.sessionhost.padding,'0'))"
    $shLast  = "$($c.sessionhost.prefix)-$((("$shLastNum")).PadLeft([int]$c.sessionhost.padding,'0'))"
    Write-Log "  [Hosts]   $($c.sessionhost.count) Session Host VM(s): $shFirst .. $shLast (Ziel-RG '$shRgPlan', Azure Local)" "OK"
    $imgTypePlan = if ($c.sessionhost.imageType -eq "custom") { "Custom-Image" } else { "Marketplace-Image" }
    Write-Log "            $($c.sessionhost.cpu) vCPU / $([math]::Round([int]$c.sessionhost.memoryMB/1024,0)) GB, $imgTypePlan, Domain-Join '$($c.sessionhost.domainName)'" "INFO"
    $regPlan = if ($c.sessionhost.PSObject.Properties['autoRegistrationKey'] -and -not $c.sessionhost.autoRegistrationKey) { "NEIN (manuell)" } else { "JA (automatisch erstellt & uebergeben)" }
    Write-Log "            Registration Key automatisch: $regPlan" "INFO"
    $adminSrc = if ($c.sessionhost.adminPwSource -eq "keyvault") { "Key Vault ($($c.sessionhost.adminKvSecret))" } else { "Laufzeit-Abfrage" }
    $djSrc    = if ($c.sessionhost.djPwSource -eq "keyvault") { "Key Vault ($($c.sessionhost.djKvSecret))" } else { "Laufzeit-Abfrage" }
    Write-Log "            Admin-Passwort: $adminSrc / Domain-Join-Passwort: $djSrc" "INFO"
    if ($c.sessionhost.enableSso) {
        Write-Log "            Entra ID SSO: AN (greift nur bei Entra-ID-gesynctem Computerkonto)" "INFO"
    } else {
        Write-Log "            Entra ID SSO: AUS" "INFO"
    }
}

# --- Uebersprungene Phasen ---
$skipped = @($c.phases.PSObject.Properties | Where-Object { -not $_.Value } | ForEach-Object { $_.Name })
if ($skipped.Count -gt 0) { Write-Log "  Uebersprungen: $($skipped -join ', ')" "INFO" }

# --- Zusaetzliches lokales Subnet (Local Network Gateway) ---
if ($c.PSObject.Properties['localGateway'] -and $c.localGateway.needsExtraSubnet -and $c.localGateway.extraSubnet) {
    $lngAuto = ($c.localGateway.PSObject.Properties['autoUpdate'] -and $c.localGateway.autoUpdate -and $c.localGateway.gatewayName)
    if ($lngAuto) {
        Write-Log "  [LNG]     Address Space '$($c.localGateway.extraSubnet)' wird im Local Network Gateway '$($c.localGateway.gatewayName)' (RG '$($c.localGateway.gatewayResourceGroup)') ergaenzt, falls noch nicht vorhanden" "OK"
    } else {
        Write-Log "  [LNG]     Hinweis: lokales Subnet '$($c.localGateway.extraSubnet)' muss im Local Network Gateway als Address Space vorhanden sein (Auto-Eintrag aus -> manuell setzen)" "WARN"
    }
}
if ($WhatIf) { Write-Log "WhatIf-Modus: es werden KEINE Aenderungen vorgenommen." "WARN" }
Write-Host ""
$confirm = Read-Host "Deployment mit dieser Config starten? (j/n)"
if ($confirm -ne "j") { Write-Log "Abbruch durch Benutzer." "WARN"; exit 0 }

# ============================================================
#  POOL-RESOURCE-GROUP (idempotent)
# ============================================================
Write-Section "RESOURCE GROUP"
if (az group exists --name $rg 2>$null | Select-String -Quiet "true") {
    Write-Log "Pool-RG '$rg' existiert bereits." "OK"
} else {
    Invoke-Az "Pool-RG '$rg' in '$location' anlegen" {
        az group create --name $rg --location $location --output none
    } | Out-Null
    Write-Log "Pool-RG '$rg' bereit." "OK"
}

# ============================================================
#  LOCAL NETWORK GATEWAY (Zusatz-Subnet idempotent eintragen)
# ============================================================
if ($c.PSObject.Properties['localGateway'] -and $c.localGateway.needsExtraSubnet -and $c.localGateway.extraSubnet `
    -and $c.localGateway.PSObject.Properties['autoUpdate'] -and $c.localGateway.autoUpdate) {
    Write-Section "LOCAL NETWORK GATEWAY"
    $lngName = $c.localGateway.gatewayName
    $lngRg   = $c.localGateway.gatewayResourceGroup
    $lngNew  = "$($c.localGateway.extraSubnet)".Trim()
    if (-not $lngName -or -not $lngRg) {
        Write-Log "Auto-Eintrag aktiv, aber Gateway-Name/RG fehlt - Address Space '$lngNew' bitte manuell eintragen." "WARN"
        $manualTasks += "Address Space '$lngNew' im Local Network Gateway manuell eintragen (Name/RG fehlte in der Config)."
    } else {
        $lng = az network local-gateway show --resource-group $lngRg --name $lngName 2>$null | ConvertFrom-Json
        if (-not $lng) {
            Write-Log "Local Network Gateway '$lngName' in RG '$lngRg' nicht gefunden - Address Space '$lngNew' bitte manuell eintragen." "WARN"
            $manualTasks += "Local Network Gateway '$lngName' (RG '$lngRg') nicht gefunden - Address Space '$lngNew' manuell eintragen."
        } else {
            $existing = @($lng.localNetworkAddressSpace.addressPrefixes)
            if ($existing -contains $lngNew) {
                Write-Log "Address Space '$lngNew' bereits im Gateway '$lngName' vorhanden - keine Aenderung." "OK"
            } else {
                $all = @($existing + $lngNew)
                Write-Log "Vorhandene Address Spaces: $($existing -join ', ')" "INFO"
                Write-Log "Ergaenze: $lngNew" "INFO"
                Invoke-AzSoft "Local Network Gateway '$lngName' um '$lngNew' ergaenzen" {
                    az network local-gateway update --resource-group $lngRg --name $lngName --local-address-prefixes $all --output none
                } -Hint "LNG-Update fehlgeschlagen (Berechtigung/Lock?) - Address Space manuell ergaenzen." `
                  -Manual "Address Space '$lngNew' im Local Network Gateway '$lngName' (RG '$lngRg') manuell eintragen."
            }
        }
    }
}

# ============================================================
#  PHASE 1: SUBNET (im VNet, also in $vnetRg)
# ============================================================
if ($c.phases.subnet) {
    Write-Section "PHASE 1: PE-SUBNET"
    $sn = az network vnet subnet show --resource-group $vnetRg --vnet-name $vnet --name $c.subnet.name 2>$null | ConvertFrom-Json
    if ($c.subnet.useExisting) {
        # Vorhandenes Subnet nutzen - es wird NICHT angelegt (und vom Cleanup NICHT geloescht)
        if ($sn) {
            Write-Log "Vorhandenes Subnet '$($c.subnet.name)' wird genutzt ($($sn.addressPrefix)) - kein Anlegen." "OK"
        } else {
            Write-Log "useExisting=true, aber Subnet '$($c.subnet.name)' existiert nicht im VNet '$vnet' (RG '$vnetRg')." "ERROR"
            Write-Log "Entweder ein vorhandenes Subnet waehlen oder im Wizard auf 'neues Subnet' umstellen." "ERROR"
            exit 1
        }
    }
    elseif ($sn) { Write-Log "Subnet '$($c.subnet.name)' existiert bereits ($($sn.addressPrefix)) - wird weiterverwendet." "WARN" }
    elseif (-not $c.subnet.cidr) {
        Write-Log "Kein subnet.cidr in der Config - im Wizard 'Auslesen' nutzen oder CIDR eintragen (z.B. 10.0.4.0/24)." "ERROR"
    } else {
        Invoke-Az "Subnet '$($c.subnet.name)' ($($c.subnet.cidr)) erstellen" {
            az network vnet subnet create --resource-group $vnetRg --vnet-name $vnet `
                --name $c.subnet.name --address-prefixes $c.subnet.cidr `
                --private-endpoint-network-policies Disabled --output none
        } | Out-Null
        Write-Log "Subnet '$($c.subnet.name)' verarbeitet." "OK"
    }
}

# Subnet-Resource-ID (fuer Private Endpoints) - wird mehrfach gebraucht
$subnetId = az network vnet subnet show --resource-group $vnetRg --vnet-name $vnet --name $c.subnet.name --query "id" -o tsv 2>$null

# ============================================================
#  PHASE 2: INFRASTRUKTUR
# ============================================================
function Ensure-DnsZone {
    param([string]$Zone)
    if (-not (az network private-dns zone show --resource-group $rgDns --name $Zone 2>$null | ConvertFrom-Json)) {
        Invoke-Az "DNS Zone '$Zone' erstellen" { az network private-dns zone create --resource-group $rgDns --name $Zone --output none } | Out-Null
    } else { Write-Log "DNS Zone '$Zone' vorhanden." "OK" }
    $link = "link-$vnet"
    $existingLinks = az network private-dns link vnet list --resource-group $rgDns --zone-name $Zone 2>$null | ConvertFrom-Json
    $alreadyLinked = $null
    foreach ($lk in $existingLinks) { if ($lk.virtualNetwork.id -eq $vnetId) { $alreadyLinked = $lk.name } }
    if ($alreadyLinked) {
        Write-Log "VNet bereits mit '$Zone' verknuepft (Link '$alreadyLinked')." "OK"
    } else {
        Invoke-Az "VNet-Link fuer '$Zone'" { az network private-dns link vnet create --resource-group $rgDns --zone-name $Zone --name $link --virtual-network $vnetId --registration-enabled false --output none } | Out-Null
    }
}
function New-Pe {
    param([string]$Name,[string]$ResId,[string]$Grp,[string]$Zone,[string]$Conn)
    if (-not (az network private-endpoint show --resource-group $rg --name $Name 2>$null | ConvertFrom-Json)) {
        Invoke-Az "Private Endpoint '$Name' ($Grp) erstellen" {
            az network private-endpoint create --resource-group $rg --name $Name --location $location `
                --subnet $subnetId --private-connection-resource-id $ResId `
                --group-id $Grp --connection-name $Conn --output none
        } | Out-Null
    } else { Write-Log "Private Endpoint '$Name' vorhanden." "WARN" }
    if (-not (az network private-endpoint dns-zone-group list --resource-group $rg --endpoint-name $Name 2>$null | ConvertFrom-Json)) {
        $zid = az network private-dns zone show --resource-group $rgDns --name $Zone --query "id" -o tsv
        Invoke-Az "DNS-Zone-Group '$Name'" {
            az network private-endpoint dns-zone-group create --resource-group $rg --endpoint-name $Name --name default --private-dns-zone $zid --zone-name ($Zone.Replace('.','-')) --output none
        } | Out-Null
    }
}

if ($c.phases.infra) {
    Write-Section "PHASE 2: INFRASTRUKTUR"
    Ensure-DnsZone $c.dns.zoneFeed
    Ensure-DnsZone $c.dns.zoneGlobal

    if (-not (az desktopvirtualization workspace show --resource-group $rg --name $c.workspace.name 2>$null | ConvertFrom-Json)) {
        $wsArgs = @("desktopvirtualization","workspace","create","--resource-group",$rg,"--name",$c.workspace.name,"--location",$location,"--output","none")
        if ($c.workspace.friendlyName) { $wsArgs += @("--friendly-name",$c.workspace.friendlyName) }
        if ($c.workspace.description)  { $wsArgs += @("--description",$c.workspace.description) }
        Invoke-Az "Workspace '$($c.workspace.name)'" { az @wsArgs } | Out-Null
    } else { Write-Log "Workspace vorhanden." "WARN" }

    if (-not (az desktopvirtualization hostpool show --resource-group $rg --name $c.hostpool.name 2>$null | ConvertFrom-Json)) {
        $ve = if ($c.hostpool.validationEnv) { "true" } else { "false" }
        $hpArgs = @("desktopvirtualization","hostpool","create","--resource-group",$rg,"--name",$c.hostpool.name,"--location",$location,
                    "--host-pool-type",$c.hostpool.type,"--load-balancer-type",$c.hostpool.loadBalancer,
                    "--max-session-limit",$c.hostpool.maxSessions,"--preferred-app-group-type","Desktop",
                    "--validation-environment",$ve,"--output","none")
        if ($c.hostpool.friendlyName) { $hpArgs += @("--friendly-name",$c.hostpool.friendlyName) }
        if ($c.hostpool.description)  { $hpArgs += @("--description",$c.hostpool.description) }
        Invoke-Az "Host Pool '$($c.hostpool.name)'" { az @hpArgs } | Out-Null
    } else { Write-Log "Host Pool vorhanden." "WARN" }

    # RDP-Properties (Device Redirection) setzen.
    # Quelle: die 5 Schalter aus dem Wizard ($c.rdp) -> identischer String wie die Wizard-Vorschau.
    # Manueller Override: 'hostpool.customRdpProperty' (falls explizit gesetzt) gewinnt.
    # enablerdsaadauth (Entra-SSO): Standard 0; bei aktivem SSO-Schalter ($ssoOn) wird der Wert unten auf 1 gesetzt.
    function Get-RdpFlag { param($r,$name,$default)
        if ($r -and $r.PSObject.Properties[$name]) { return [bool]$r.$name }
        return $default
    }
    $r = if ($c.PSObject.Properties['rdp']) { $c.rdp } else { $null }
    $drive = if (Get-RdpFlag $r 'driveStorage' $false) { "drivestoredirect:s:*" }    else { "drivestoredirect:s:" }
    $usb   = if (Get-RdpFlag $r 'usb'          $false) { "usbdevicestoredirect:s:*" } else { "usbdevicestoredirect:s:" }
    $clip  = if (Get-RdpFlag $r 'clipboard'    $false) { "redirectclipboard:i:1" }    else { "redirectclipboard:i:0" }
    $print = if (Get-RdpFlag $r 'printer'      $true)  { "redirectprinters:i:1" }     else { "redirectprinters:i:0" }
    $smart = if (Get-RdpFlag $r 'smartcard'    $false) { "redirectsmartcards:i:1" }   else { "redirectsmartcards:i:0" }
    $rdpBase = "redirectcomports:i:0;devicestoredirect:s:;audiomode:i:0;audiocapturemode:i:0;videoplaybackmode:i:1;camerastoredirect:s:;redirectwebauthn:i:1;enablecredsspsupport:i:1;use multimon:i:1;autoreconnection enabled:i:1;enablerdsaadauth:i:0"
    $rdpBuilt = "$drive;$usb;$clip;$print;$smart;$rdpBase"
    $rdpProps = if ($c.hostpool.PSObject.Properties['customRdpProperty'] -and $c.hostpool.customRdpProperty) { $c.hostpool.customRdpProperty } else { $rdpBuilt }
    if ($ssoOn) {
        $rdpParts = @()
        foreach ($rp in ($rdpProps -split ";")) { if ($rp -and ($rp -notmatch "^enablerdsaadauth")) { $rdpParts += $rp } }
        $rdpParts += "enablerdsaadauth:i:1"
        $rdpProps = ($rdpParts -join ";")
    }
    Write-Log "RDP-Redirection: Laufwerk=$(if(Get-RdpFlag $r 'driveStorage' $false){'an'}else{'aus'}) Clipboard=$(if(Get-RdpFlag $r 'clipboard' $false){'an'}else{'aus'}) Drucker=$(if(Get-RdpFlag $r 'printer' $true){'an'}else{'aus'}) Smartcard=$(if(Get-RdpFlag $r 'smartcard' $false){'an'}else{'aus'}) USB=$(if(Get-RdpFlag $r 'usb' $false){'an'}else{'aus'})" "INFO"
    Invoke-Az "RDP-Properties setzen" { az desktopvirtualization hostpool update --resource-group $rg --name $c.hostpool.name --custom-rdp-property $rdpProps --output none } | Out-Null
    if ($ssoOn) {
        if (-not $WhatIf) { Write-Log "Entra ID SSO am Host Pool gesetzt (enablerdsaadauth=1)." "OK" }
        Write-Log "    Wirksam erst, wenn die Tenant-Voraussetzungen erfuellt sind (siehe offene Punkte am Ende)." "WARN"
        $manualTasks += "Entra ID SSO - einmalige Voraussetzungen pruefen: (1) Microsoft-Entra-Authentifizierung fuer RDP im Tenant aktivieren, (2) Session Hosts muessen Entra joined oder Entra hybrid joined sein (nur AD-Join reicht nicht), (3) bei hybrid joined Hosts ein Kerberos Server Object anlegen, (4) Conditional-Access-Richtlinien pruefen. Doku: https://learn.microsoft.com/azure/virtual-desktop/configure-single-sign-on"
    } else {
        Write-Log "Entra ID SSO am Host Pool: aus (enablerdsaadauth=0)." "INFO"
    }

    $wsId = az desktopvirtualization workspace show --resource-group $rg --name $c.workspace.name --query "id" -o tsv
    $hpId = az desktopvirtualization hostpool show --resource-group $rg --name $c.hostpool.name --query "id" -o tsv

    New-Pe "PE-AVD-$($c.workspace.name)-feed" $wsId "feed" $c.dns.zoneFeed "conn-feed"
    New-Pe "PE-AVD-$($c.hostpool.name)" $hpId "connection" $c.dns.zoneFeed "conn-connection"

    # Global-Endpoint nur einmalig im gesamten Tenant/Sub
    $globalExists = $false
    foreach ($pe in (az network private-endpoint list 2>$null | ConvertFrom-Json)) {
        foreach ($cn in $pe.privateLinkServiceConnections) { if ($cn.groupIds -contains "global") { $globalExists = $true } }
    }
    if ($globalExists) { Write-Log "Global-Endpoint bereits vorhanden - kein weiterer." "OK" }
    else { New-Pe "PE-AVD-global" $wsId "global" $c.dns.zoneGlobal "conn-global" }

    # publicNetworkAccess via 'az resource update' setzen - das CLI-Flag --public-network-access
    # fehlt in der desktopvirtualization-Extension (auch in der aktuellsten Version).
    # publicNetworkAccess braucht API-Version 2024-04-03 - sonst meldet 'az resource update'
    # Erfolg, verwirft die Eigenschaft aber (zu alte Default-API-Version).
    # Ziel: voll privater Zugriff - Steuerebene nur ueber Private Endpoints / privates DNS.
    $pnaHint = "Falls dies fehlschlaegt: im Azure-Portal unter 'Networking' setzen."
    Invoke-AzSoft "Host Pool publicNetworkAccess = Disabled (voll privat)" { az resource update --ids $hpId --set properties.publicNetworkAccess=Disabled --api-version 2024-04-03 --output none } $pnaHint "Host Pool publicNetworkAccess auf 'Disabled' setzen (Portal > Networking)."
    Invoke-AzSoft "Workspace publicNetworkAccess = Disabled (voll privat)" { az resource update --ids $wsId --set properties.publicNetworkAccess=Disabled --api-version 2024-04-03 --output none } $pnaHint "Workspace publicNetworkAccess auf 'Disabled' setzen (Portal > Networking)."

    # 'Allow Direct UDP network path with Private Link' = UDP-Transporte ueber Private Link (RDP Shortpath fuer managed networks).
    # GET-Diagnose hat gezeigt: der Portal-Haken liest 'managedPrivateUDP' (nicht nur 'directUDP'),
    # ausserdem muss der oeffentliche Shortpath aus sein. Daher: directUDP+managedPrivateUDP=Enabled, publicUDP=Disabled.
    # Diese Eigenschaften gibt es nur in Preview-API-Versionen -> 2025-04-01-preview. Per REST-PATCH (zuverlaessig).
    $udpApi  = "2025-04-01-preview"
    $udpHint = "Falls dies fehlschlaegt: im Portal unter 'Networking' -> 'Allow Direct UDP network path with Private Link' setzen."
    $udpBody = New-TemporaryFile
    [System.IO.File]::WriteAllText($udpBody.FullName, '{"properties":{"directUDP":"Enabled","managedPrivateUDP":"Enabled","publicUDP":"Disabled"}}', (New-Object System.Text.UTF8Encoding($false)))
    Invoke-AzSoft "Host Pool UDP ueber Private Link aktivieren (managedPrivateUDP=Enabled)" { az rest --method patch --url "$hpId`?api-version=$udpApi" --body "@$($udpBody.FullName)" --output none } $udpHint "Host Pool 'Allow Direct UDP network path with Private Link' aktivieren (Portal > Networking)."
    Invoke-AzSoft "Workspace UDP ueber Private Link aktivieren (managedPrivateUDP=Enabled)" { az rest --method patch --url "$wsId`?api-version=$udpApi" --body "@$($udpBody.FullName)" --output none } $udpHint "Workspace 'Allow Direct UDP network path with Private Link' aktivieren (Portal > Networking)."
    Remove-Item $udpBody.FullName -Force -ErrorAction SilentlyContinue
}

# ============================================================
#  PHASE 3: APP GROUP
# ============================================================
if ($c.phases.appgroup) {
    Write-Section "PHASE 3: APP GROUP"
    $hpId = az desktopvirtualization hostpool show --resource-group $rg --name $c.hostpool.name --query "id" -o tsv
    if (-not (az desktopvirtualization applicationgroup show --resource-group $rg --name $c.appgroup.name 2>$null | ConvertFrom-Json)) {
        Invoke-Az "App Group '$($c.appgroup.name)'" {
            az desktopvirtualization applicationgroup create --resource-group $rg --name $c.appgroup.name --location $location `
                --host-pool-arm-path $hpId --application-group-type $c.appgroup.type --friendly-name "$($c.appgroup.type) - $($c.hostpool.name)" --output none
        } | Out-Null
    } else { Write-Log "App Group vorhanden." "WARN" }

    $agId = az desktopvirtualization applicationgroup show --resource-group $rg --name $c.appgroup.name --query "id" -o tsv
    $wsAgs = az desktopvirtualization workspace show --resource-group $rg --name $c.workspace.name --query "applicationGroupReferences" -o json 2>$null | ConvertFrom-Json
    if (-not ($wsAgs -and ($wsAgs -contains $agId))) {
        $refs = @(); if ($wsAgs) { $refs += $wsAgs }; $refs += $agId
        Invoke-Az "App Group dem Workspace zuordnen" { az desktopvirtualization workspace update --resource-group $rg --name $c.workspace.name --application-group-references $refs --output none } | Out-Null
    } else { Write-Log "App Group bereits zugeordnet." "OK" }

    if ($c.appgroup.assignGroup) {
        $gid = az ad group show --group $c.appgroup.assignGroup --query "id" -o tsv 2>$null
        if ($gid) {
            $manualRole = "Rolle 'Desktop Virtualization User' der Gruppe '$($c.appgroup.assignGroup)' zuweisen:  az role assignment create --assignee $gid --role 'Desktop Virtualization User' --scope $agId"
            Invoke-AzSoft "Rolle 'Desktop Virtualization User' fuer Gruppe '$($c.appgroup.assignGroup)'" { az role assignment create --assignee $gid --role "Desktop Virtualization User" --scope $agId --output none } "Benoetigt 'User Access Administrator' oder 'Owner' auf der App Group." $manualRole
        } else { Write-Log "Gruppe '$($c.appgroup.assignGroup)' nicht gefunden." "WARN" }
    }
}

# ============================================================
#  PHASE 4: LOG ANALYTICS (bestehender Workspace)
# ============================================================
if ($c.phases.loganalytics) {
    Write-Section "PHASE 4: LOG ANALYTICS"
    $laWs = $null
    if ($c.loganalytics.resourceGroup) {
        $laWs = az monitor log-analytics workspace show --resource-group $c.loganalytics.resourceGroup --workspace-name $c.loganalytics.workspaceName 2>$null | ConvertFrom-Json
    }
    if (-not $laWs) {
        # Fallback: Workspace subscription-weit per Namen suchen
        $laWs = az monitor log-analytics workspace list --query "[?name=='$($c.loganalytics.workspaceName)'] | [0]" 2>$null | ConvertFrom-Json
        if ($laWs) { Write-Log "Workspace per Namen gefunden (RG: $($laWs.id.Split('/')[4]))." "INFO" }
    }
    if (-not $laWs) { Write-Log "Log Analytics '$($c.loganalytics.workspaceName)' nicht gefunden." "ERROR" }
    else {
        $laId = $laWs.id
        Write-Log "Log Analytics gefunden (Customer-ID: $($laWs.customerId))." "OK"
        function Set-Diag {
            param([string]$ResId,[string]$Name,[string[]]$Cats)
            $logs = @(); foreach ($cat in $Cats) { $logs += [PSCustomObject]@{ category=$cat; enabled=$true } }
            $tmp = New-TemporaryFile
            Set-Content -Path $tmp.FullName -Value (ConvertTo-Json @($logs) -Compress) -Encoding UTF8
            Invoke-Az "Diagnostic '$Name'" { az monitor diagnostic-settings create --name $Name --resource $ResId --workspace $laId --logs "@$($tmp.FullName)" --output none } | Out-Null
            Remove-Item $tmp.FullName -Force -ErrorAction SilentlyContinue
        }
        $hpId = az desktopvirtualization hostpool show --resource-group $rg --name $c.hostpool.name --query "id" -o tsv
        Set-Diag $hpId "diag-avd-hostpool" @("Connection","Management","Error","Checkpoint")
        $wsId = az desktopvirtualization workspace show --resource-group $rg --name $c.workspace.name --query "id" -o tsv
        Set-Diag $wsId "diag-avd-workspace" @("Checkpoint","Error","Management","Feed")
    }
}

# ============================================================
#  PHASE 5: NSG (NSG in Pool-RG, Subnet-Operationen in VNet-RG)
# ============================================================
# Zusaetzliches lokales Subnet (Local Network Gateway) als weitere NSG-Quelle?
$extraLng = $null
if ($c.PSObject.Properties['localGateway'] -and $c.localGateway.needsExtraSubnet -and $c.localGateway.extraSubnet) {
    $extraLng = "$($c.localGateway.extraSubnet)".Trim()
}
if ($c.phases.nsg -and $c.subnet.useExisting) {
    Write-Section "PHASE 5: NSG-HAERTUNG"
    Write-Log "Vorhandenes Subnet -> eigene NSG wird NICHT erstellt/gebunden (bestehende NSG-Zuordnung bleibt unangetastet)." "WARN"
    $existingNsg = az network vnet subnet show --resource-group $vnetRg --vnet-name $vnet --name $c.subnet.name --query "networkSecurityGroup.id" -o tsv 2>$null
    if ($existingNsg) { Write-Log "Subnet nutzt bereits NSG: $existingNsg" "INFO" }
    else { Write-Log "Achtung: Subnet hat aktuell KEINE NSG gebunden." "WARN" }
    $snPrefix = az network vnet subnet show --resource-group $vnetRg --vnet-name $vnet --name $c.subnet.name --query "addressPrefix" -o tsv
    Write-Log "Bitte sicherstellen, dass folgende Inbound-Regeln fuer '$snPrefix' vorhanden sind:" "INFO"
    $onpremDisplay = $c.nsg.onprem
    if ($extraLng) { $onpremDisplay = "$($c.nsg.onprem),$extraLng" }
    Write-Log "    TCP 1-65535 von On-Prem ($onpremDisplay)" "INFO"
    Write-Log "    UDP 3390 (RDP Shortpath) von On-Prem" "INFO"
}
elseif ($c.phases.nsg) {
    Write-Section "PHASE 5: NSG-HAERTUNG"
    $nsgName = "nsg-$($c.subnet.name)"
    $snPrefix = az network vnet subnet show --resource-group $vnetRg --vnet-name $vnet --name $c.subnet.name --query "addressPrefix" -o tsv
    $onprem = @($c.nsg.onprem.Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if ($extraLng -and ($onprem -notcontains $extraLng)) {
        $onprem += $extraLng
        Write-Log "Zusaetzliches lokales Subnet '$extraLng' wird als NSG-Quelle aufgenommen." "INFO"
    }
    if (-not (az network nsg show --resource-group $rg --name $nsgName 2>$null | ConvertFrom-Json)) {
        Invoke-Az "NSG '$nsgName'" { az network nsg create --resource-group $rg --name $nsgName --location $location --output none } | Out-Null
    }
    Invoke-Az "Regel TCP 1-65535 (von On-Prem)" { az network nsg rule create --resource-group $rg --nsg-name $nsgName --name "Allow-AVD-TCP-Inbound" --priority 100 --direction Inbound --access Allow --protocol Tcp --source-address-prefixes $onprem --destination-address-prefixes $snPrefix --destination-port-ranges "1-65535" --output none } | Out-Null
    Invoke-Az "Regel UDP 3390 (Shortpath)" { az network nsg rule create --resource-group $rg --nsg-name $nsgName --name "Allow-AVD-Shortpath-UDP" --priority 110 --direction Inbound --access Allow --protocol Udp --source-address-prefixes $onprem --destination-address-prefixes $snPrefix --destination-port-ranges "3390" --output none } | Out-Null
    if (-not $c.nsg.observeMode) {
        Invoke-Az "Regel Deny-All-Inbound" { az network nsg rule create --resource-group $rg --nsg-name $nsgName --name "Deny-All-Inbound" --priority 4000 --direction Inbound --access Deny --protocol "*" --source-address-prefixes "*" --destination-address-prefixes "*" --destination-port-ranges "*" --output none } | Out-Null
    } else { Write-Log "Deny-All uebersprungen (Beobachtungsmodus)." "WARN" }
    # NSG liegt im Pool-RG, das Subnet im VNet-RG -> per voller NSG-ID binden (RG-uebergreifend),
    # sonst sucht 'az' die NSG im RG des Subnets und findet sie nicht.
    $nsgId = az network nsg show --resource-group $rg --name $nsgName --query "id" -o tsv
    Invoke-Az "NSG an Subnet binden" { az network vnet subnet update --resource-group $vnetRg --vnet-name $vnet --name $c.subnet.name --network-security-group $nsgId --output none } | Out-Null
}

# ============================================================
#  PHASE 6: SESSION HOSTS (offizielles AVD-Template, Azure Local)
# ============================================================
if ($c.phases.sessionhost) {
    Write-Section "PHASE 6: SESSION HOSTS"

    # Ziel-RG (waehlbar; Fallback = Pool-RG): vorhanden -> nutzen, sonst anlegen
    $shRg = if ($c.sessionhost.targetResourceGroup) { $c.sessionhost.targetResourceGroup } else { $rg }
    if ($shRg -ne $rg) {
        if (az group exists --name $shRg 2>$null | Select-String -Quiet "true") {
            Write-Log "Ziel-RG '$shRg' existiert bereits." "OK"
        } else {
            Invoke-Az "Ziel-RG '$shRg' in '$location' anlegen" { az group create --name $shRg --location $location --output none } | Out-Null
        }
    }
    Write-Log "Session Hosts werden in RG '$shRg' per offiziellem AVD-Template deployt." "INFO"

    # Passwoerter beschaffen: Key Vault ODER sichere Laufzeit-Abfrage (nie aus der Config)
    $adminPw = Resolve-Password -Source $c.sessionhost.adminPwSource -KvId $c.sessionhost.adminKvId -SecretName $c.sessionhost.adminKvSecret -Prompt "Lokales Admin-Passwort"
    $djPw    = Resolve-Password -Source $c.sessionhost.djPwSource    -KvId $c.sessionhost.djKvId    -SecretName $c.sessionhost.djKvSecret    -Prompt "Domain-Join Passwort"

    # Registration Token (fuer das AVD-Template ZWINGEND - es registriert die Hosts ueber den Token)
    $autoReg = -not ($c.sessionhost.PSObject.Properties['autoRegistrationKey'] -and -not $c.sessionhost.autoRegistrationKey)
    $regToken = $null
    if ($autoReg) {
        if ($WhatIf) {
            Write-Log "[WhatIf] Registration Token erstellen und im AVD-Template uebergeben" "INFO"
        } else {
            $expiry = (Get-Date).AddHours(24).ToString("yyyy-MM-ddTHH:mm:ssZ")
            az desktopvirtualization hostpool update --resource-group $rg --name $c.hostpool.name --registration-info expiration-time=$expiry registration-token-operation="Update" --output none 2>$null
            $regToken = az desktopvirtualization hostpool retrieve-registration-token --resource-group $rg --name $c.hostpool.name --query "token" -o tsv 2>$null
            if ($regToken) { Write-Log "Registration Token erzeugt (gueltig 24h)." "OK" }
            else { Write-Log "Registration Token konnte nicht erzeugt werden." "WARN" }
        }
    } else {
        Write-Log "autoRegistrationKey=false - das offizielle AVD-Template benoetigt den Token zwingend." "WARN"
    }

    if (-not $regToken -and -not $WhatIf) {
        Write-Log "Ohne Registration Token kann das AVD-Template die Hosts nicht registrieren - Phase 6 wird uebersprungen." "ERROR"
        $manualTasks += "Session Hosts manuell deployen/registrieren (kein Registration Token verfuegbar - autoRegistrationKey pruefen)."
    } else {
        # SSO am Host Pool (standardmaessig aus; greift nur bei Entra-ID-gesynctem Computerkonto)
        if ($c.sessionhost.enableSso) {
            $cur = az desktopvirtualization hostpool show --resource-group $rg --name $c.hostpool.name --query "customRdpProperty" -o tsv 2>$null
            $parts = @(); foreach ($p in ($cur -split ";")) { if ($p -and ($p -notmatch "^enablerdsaadauth")) { $parts += $p } }
            $parts += "enablerdsaadauth:i:1"
            Invoke-Az "SSO enablerdsaadauth=1" { az desktopvirtualization hostpool update --resource-group $rg --name $c.hostpool.name --custom-rdp-property (($parts -join ";")) --output none } | Out-Null
            Write-Log "Entra ID SSO aktiviert. WICHTIG: greift nur, wenn das Computerkonto mit Entra ID synchronisiert ist (Hybrid Join via Entra Connect Sync)." "WARN"
            Write-Log "Hinweis: Kerberos Server Object + Entra Auth fuer RDP sind einmalige Tenant-Schritte!" "WARN"
        }

        # Offizielle AVD-Template-/Artefakt-URLs (config-ueberschreibbar; Defaults = Portal-Stand aus deployment.json).
        # WARNUNG: Diese URLs sind versionsgepinnt (Hostpool_1.0.xxxxx). Zieht Microsoft die Version zurueck,
        #          per 'armTemplateUri'/'scriptFileUri'/'configurationZipUri' in der Config einen frischen Portal-Export hinterlegen.
        $armTemplateUri = if ($c.sessionhost.PSObject.Properties['armTemplateUri']      -and $c.sessionhost.armTemplateUri)      { $c.sessionhost.armTemplateUri }      else { "https://wvdportalstorageblob.blob.core.windows.net/galleryartifacts/armtemplates/Hostpool_1.0.03391.1266/nestedTemplates/azurestackhci-vm.json" }
        $scriptFileUri  = if ($c.sessionhost.PSObject.Properties['scriptFileUri']        -and $c.sessionhost.scriptFileUri)        { $c.sessionhost.scriptFileUri }        else { "https://wvdportalstorageblob.blob.core.windows.net/galleryartifacts/HCIScripts_1.0.03391.1266/HciCustomScript.ps1" }
        $configZipUri   = if ($c.sessionhost.PSObject.Properties['configurationZipUri']  -and $c.sessionhost.configurationZipUri)  { $c.sessionhost.configurationZipUri }  else { "https://wvdportalstorageblob.blob.core.windows.net/galleryartifacts/Configuration_1.0.03391.1266.zip" }
        $scriptFileName = ($scriptFileUri -split '/')[-1]
        Write-Log "AVD-Template: $armTemplateUri" "INFO"

        # Security-Profil (Default TrustedLaunch wie im Portal; per sessionhost.securityType ueberschreibbar)
        $secType = if ($c.sessionhost.PSObject.Properties['securityType'] -and $c.sessionhost.securityType) { $c.sessionhost.securityType } else { "TrustedLaunch" }
        $tl = ($secType -eq "TrustedLaunch")

        # Host-Pool-Resource-ID fuer die Tags (cm-resource-parent -> Host Pool in der Pool-RG)
        $subId = $account.id
        $hpId  = "/subscriptions/$subId/resourceGroups/$rg/providers/Microsoft.DesktopVirtualization/hostpools/$($c.hostpool.name)"

        # WICHTIG: Das offizielle Template benennt Hosts UNGEPADDET: <rdshPrefix><n> (z.B. avd-sh-1).
        $rdshPrefix = "$($c.sessionhost.prefix)-"
        $indices = @()
        for ($n = $c.sessionhost.countStart; $n -lt ($c.sessionhost.countStart + $c.sessionhost.count); $n++) { $indices += $n }
        Write-Log "Zu erstellende Hosts: $(($indices | ForEach-Object { "$rdshPrefix$_" }) -join ', ')" "INFO"

        foreach ($N in $indices) {
            $vmName = "$rdshPrefix$N"
            Write-Log "=== $vmName ===" "STEP"
            $exists = az resource show --resource-group $shRg --name $vmName --resource-type "Microsoft.HybridCompute/machines" 2>$null | ConvertFrom-Json
            if ($exists) { Write-Log "VM '$vmName' existiert bereits - uebersprungen." "WARN"; continue }
            if ($WhatIf) { Write-Log "[WhatIf] '$vmName' per offiziellem AVD-Template deployen (VM + Domain Join + AVD-Agent-Registrierung)" "INFO"; continue }

            # Parameter-Vertrag exakt nach deployment.json (nur tenant-spezifische Werte ersetzt)
            $tagObj = @{ Role = "Azure Virtual Desktop"; "cm-resource-parent" = $hpId }
            $paramObj = @{
                '$schema'      = "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#"
                contentVersion = "1.0.0.0"
                parameters = @{
                    rdshPrefix                      = @{ value = $rdshPrefix }
                    virtualProcessorCount           = @{ value = [int]$c.sessionhost.cpu }
                    memoryMB                        = @{ value = [int]$c.sessionhost.memoryMB }
                    maximumMemoryMB                 = @{ value = 0 }
                    minimumMemoryMB                 = @{ value = 0 }
                    dynamicMemoryConfig             = @{ value = $false }
                    targetMemoryBuffer              = @{ value = 20 }
                    vmInitialNumber                 = @{ value = [int]$N }
                    networkInterfaceTags            = @{ value = $tagObj }
                    virtualMachineTags              = @{ value = $tagObj }
                    location                        = @{ value = "$location" }
                    customLocationId                = @{ value = "$($c.sessionhost.customLocationId)" }
                    domainAdministratorUsername     = @{ value = "$($c.sessionhost.domainJoinUser)" }
                    domainAdministratorPassword     = @{ value = $djPw }
                    vmAdministratorAccountUsername  = @{ value = "$($c.sessionhost.adminUsername)" }
                    vmAdministratorAccountPassword  = @{ value = $adminPw }
                    logicalNetworkId                = @{ value = "$($c.sessionhost.logicalNetworkId)" }
                    imageId                         = @{ value = "$($c.sessionhost.vmImageId)" }
                    hostpoolName                    = @{ value = "$($c.hostpool.name)" }
                    hostpoolToken                   = @{ value = "$regToken" }
                    SessionHostConfigurationVersion = @{ value = "" }
                    rdshNumberOfInstances           = @{ value = 1 }
                    oUPath                          = @{ value = "$($c.sessionhost.domainOU)" }
                    domain                          = @{ value = "$($c.sessionhost.domainName)" }
                    fileUri                         = @{ value = "$scriptFileUri" }
                    fileName                        = @{ value = "$scriptFileName" }
                    configurationZipUri             = @{ value = "$configZipUri" }
                    aadJoin                         = @{ value = $false }
                    intune                          = @{ value = $false }
                    systemData                      = @{ value = @{ aadJoinPreview = $false; sessionHostConfigurationVersion = ""; firstPartyExtension = $false } }
                    securityType                    = @{ value = "$secType" }
                    secureBootEnabled               = @{ value = [bool]$tl }
                    enableTPM                       = @{ value = [bool]$tl }
                    hciClusterId                    = @{ value = "" }
                    hciClusterAadTenantId           = @{ value = "" }
                    attestationServiceEndpoint      = @{ value = "null" }
                    relyingPartyServiceEndpoint     = @{ value = "null" }
                    hciTrustLaunchBootIntegrity     = @{ value = $false }
                }
            }
            $paramFile = Join-Path $env:TEMP "avd-params-$vmName.json"
            [System.IO.File]::WriteAllText($paramFile, ($paramObj | ConvertTo-Json -Depth 8), (New-Object System.Text.UTF8Encoding $false))

            $depName = "avd-sh-$vmName-$timestamp"
            Write-Log "VM '$vmName' per AVD-Template deployen (RG '$shRg') - kann einige Minuten dauern..." "STEP"
            $depOut = az deployment group create --resource-group $shRg --name $depName --template-uri $armTemplateUri --parameters "@$paramFile" --output none 2>&1
            $depRc = $LASTEXITCODE
            Remove-Item -Path $paramFile -Force -ErrorAction SilentlyContinue   # Secrets sofort entfernen

            if ($depRc -ne 0) {
                Write-Log "Fehler beim AVD-Template-Deployment fuer '$vmName'." "ERROR"
                $msg = ($depOut | Out-String).Trim()
                if ($msg) {
                    foreach ($ln in ($msg -split "`r?`n")) { if ($ln.Trim()) { Write-Host "    $($ln.Trim())" -ForegroundColor DarkYellow } }
                    Add-Content -Path $logFile -Value "[az-Fehler] $msg"
                }
                $adminPw = $null; $djPw = $null; $regToken = $null
                Write-Log "Script wird abgebrochen (siehe Fehler oben). Log: $logFile" "ERROR"
                exit 1
            }
            Write-Log "'$vmName' deployt: Azure-Local-VM + Domain Join + AVD-Agent registriert (Host Pool '$($c.hostpool.name)')." "OK"
        }
    }
    $adminPw = $null; $djPw = $null; $regToken = $null
}
# ============================================================
#  ABSCHLUSS
# ============================================================
Write-Section "ABSCHLUSS"
Write-Log "Runner abgeschlossen." "OK"
if ($manualTasks.Count -gt 0) {
    Write-Host ""
    Write-Divider
    Write-Host "[ OFFENE PUNKTE - BITTE MANUELL ERLEDIGEN ]" -ForegroundColor Yellow
    Write-Divider
    $n = 1
    foreach ($t in $manualTasks) {
        Write-Host "  $n. " -ForegroundColor Yellow -NoNewline
        Write-Host $t -ForegroundColor Yellow
        Add-Content -Path $logFile -Value "[MANUELL] $t"
        $n++
    }
    Write-Host ""
} else {
    Write-Log "Keine offenen manuellen Punkte." "OK"
}
Write-Log "Log: $logFile" "INFO"
