﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Testlauf fuer das Runbook rb_AzureCosts_LDK (myAzureCost LDK 2.x).
.DESCRIPTION
    Das Runbook 2.x hat keine Parameter mehr und versendet regulaer nur am
    Wochen-/Monatstag. Dieses Script erzwingt einen Testversand:
      1. Ermittelt AcsEndpoint und Absenderadresse aus der LDK-Umgebung.
      2. Erzeugt aus der lokalen Runbook-Datei zwei Fassungen:
           TEST : Platzhalter ersetzt + $ReportModeOverride = Testmodus
           PROD : Platzhalter ersetzt + $ReportModeOverride = "Auto"
      3. Laedt TEST hoch, veroeffentlicht, startet den Job (ohne Parameter),
         wartet auf das Ergebnis und zeigt die Job-Ausgabe an.
      4. Stellt IMMER die PROD-Fassung wieder her (auch bei Fehler/Timeout),
         damit die Zeitplaene anschliessend normal laufen.
    Alle Parameter werden im Script gepflegt (Abschnitt PARAMETER).
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 16.09.2026
    Version     : 2.1.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Changelog:
    1.0.0 (16.09.2026): Testlauf fuer Runbook 1.x (Start mit Parametern).
    2.0.0 (23.09.2026): Umbau fuer Runbook 2.x (LDK)
      - Keine Runbook-Parameter mehr; Testversand ueber temporaere
        Testfassung mit $ReportModeOverride, danach Wiederherstellung
      - LDK-Namen, Kundenpruefung, Konsistenz zum Setup
      - Temp-Pfad plattformunabhaengig, az-Fehler sichtbar
    2.1.0 (23.09.2026): Runbook mit festen Werten (2.3.1)
      - Keine Platzhalter-Ersetzung mehr; ACS-Abfragen entfallen
    =========================================================================
    Voraussetzungen:
      - Setup-MyAzureCost_LDK.ps1 wurde bereits erfolgreich ausgefuehrt.
      - RunBk_MyAzureCost_LDK.ps1 liegt im selben Ordner.
.EXAMPLE
    .\Test-MyAzureCost_LDK.ps1
#>

# =========================================================================
# GRUNDKONFIGURATION (Kompatibilitaet / Ausgabe)
# =========================================================================
$ScriptVersion  = "2.1.0"
$PowerShellMode = "Compat"   # "Compat" = 5.1 + 7.x | "Seven" = nur 7.x

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Continue"

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =========================================================================
# PARAMETER - hier anpassen (keine Uebergabe per Aufruf)
# =========================================================================
# !!! Werte muessen zu Setup-MyAzureCost_LDK.ps1 passen !!!
$CustomerName          = "LDK"
$SubscriptionId        = ""                        # leer = aktuelle Subscription
$RGName                = "rg-AzureCostManagement"
$AutomationAccountName = "aa-myazurecost-ldk"
$RunbookName           = "rb_AzureCosts_LDK"
$RunbookFile           = Join-Path $PSScriptRoot "RunBk_MyAzureCost_LDK.ps1"
$RecipientEmail        = "harald.haas@lahn-dill-kreis.de"   # mehrere mit Komma trennen
$TestReportMode        = "Weekly"                  # "Weekly" | "Monthly"
$TimeoutMinutes        = 15                        # max. Wartezeit auf den Job
$AutomationApiVersion  = "2023-11-01"

# =========================================================================
# HILFSFUNKTIONEN
# =========================================================================
function Write-Log {
    param(
        [string]$Symbol,
        [string]$Message,
        [string]$Color,
        [int]$Indent = 0
    )
    $stamp = Get-Date -Format "HH:mm:ss"
    Write-Host ("[{0}] {1}  {2}{3}" -f $stamp, $Symbol, (" " * $Indent), $Message) -ForegroundColor $Color
}

function Write-Section {
    param([string]$Title)
    Write-Host ("=" * 60) -ForegroundColor White
    Write-Host ("[ {0} ]" -f $Title) -ForegroundColor White
}

function Invoke-AzCaptured {
    # Fuehrt az aus, faengt stderr in eine Datei und liefert stdout + stderr.
    param([string[]]$Arguments)
    $errFile = Join-Path ([System.IO.Path]::GetTempPath()) ("myazurecost_az_stderr_{0}.txt" -f [guid]::NewGuid().ToString("N"))
    $stdout  = & az @Arguments 2>$errFile
    $stderr  = ""
    if (Test-Path $errFile) {
        $stderr = [System.IO.File]::ReadAllText($errFile)
        Remove-Item -Path $errFile -ErrorAction SilentlyContinue
    }
    return [pscustomobject]@{ ExitCode = $LASTEXITCODE; StdOut = $stdout; StdErr = $stderr }
}

function Write-AzError {
    param([string]$StdErr)
    foreach ($line in ($StdErr -split "`r?`n")) {
        if (-not [string]::IsNullOrWhiteSpace($line)) {
            Write-Log $SymWarn $line.Trim() "Yellow" 4
        }
    }
}

function Invoke-AzQuiet {
    # Fuehrt az mit unterdrueckter stderr-Ausgabe aus. Argumente als Array.
    param([string[]]$Arguments)
    $result = & az @Arguments 2>$null
    return $result
}

$script:ProdDeployFile = $null
$script:RunbookPatched = $false

function Publish-RunbookContent {
    # Laedt eine Runbook-Fassung hoch und veroeffentlicht sie. $true = Erfolg.
    param([string]$FilePath, [string]$Label)
    $r = Invoke-AzCaptured -Arguments @("automation", "runbook", "replace-content",
        "--automation-account-name", $AutomationAccountName, "--resource-group", $RGName,
        "--name", $RunbookName, "--content", ("@{0}" -f $FilePath), "--output", "none")
    if ($r.ExitCode -ne 0) {
        Write-Log $SymErr ("Upload {0} fehlgeschlagen - az-Meldung:" -f $Label) "Red"
        Write-AzError -StdErr $r.StdErr
        return $false
    }
    $r = Invoke-AzCaptured -Arguments @("automation", "runbook", "publish",
        "--automation-account-name", $AutomationAccountName, "--resource-group", $RGName,
        "--name", $RunbookName, "--output", "none")
    if ($r.ExitCode -ne 0) {
        Write-Log $SymErr ("Veroeffentlichen {0} fehlgeschlagen - az-Meldung:" -f $Label) "Red"
        Write-AzError -StdErr $r.StdErr
        return $false
    }
    return $true
}

function Restore-ProdRunbook {
    # Stellt die Produktivfassung wieder her (Override = Auto).
    if (-not $script:RunbookPatched) { return }
    Write-Log $SymRun "Stelle Produktivfassung des Runbooks wieder her (Override = Auto)..." "Cyan"
    if (Publish-RunbookContent -FilePath $script:ProdDeployFile -Label "PROD") {
        Write-Log $SymOk "Produktivfassung wiederhergestellt" "Green"
        $script:RunbookPatched = $false
    }
    else {
        Write-Log $SymErr "WICHTIG: Wiederherstellung fehlgeschlagen! Im Runbook steht noch der Test-Override." "Red"
        Write-Log $SymErr "Bitte Setup-MyAzureCost_LDK.ps1 erneut ausfuehren (laedt die Produktivfassung hoch)." "Red"
    }
}

function Stop-WithError {
    # Einheitlicher Fehlerausstieg inkl. Wiederherstellung.
    param([string]$Message)
    Write-Log $SymErr $Message "Red"
    Restore-ProdRunbook
    if ($script:ProdDeployFile) { Remove-Item -Path $script:ProdDeployFile -ErrorAction SilentlyContinue }
    Write-Host ("=" * 60) -ForegroundColor White
    exit 1
}

function Assert-AzSuccess {
    param([string]$Action)
    if ($LASTEXITCODE -ne 0) {
        Stop-WithError ("Fehler bei: {0} (ExitCode {1})" -f $Action, $LASTEXITCODE)
    }
}

# =========================================================================
# PRE-CHECK
# =========================================================================
Write-Host ("=" * 60) -ForegroundColor White
Write-Host "[ PRE-CHECK ]" -ForegroundColor White

# --- PowerShell-Version / Modus ---
$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Log $SymErr ("PowerShellMode 'Seven' gesetzt, aber PowerShell {0}.{1} aktiv. Abbruch." -f $psMajor, $psMinor) "Red"
    exit 1
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
}
Write-Log $SymOk ("PowerShell {0}.{1} (Modus: {2})" -f $psMajor, $psMinor, $PowerShellMode) "Green"

# --- Azure CLI vorhanden? ---
Write-Log $SymInfo "Pruefe Azure CLI..." "Cyan"
if (-not (Get-Command -Name "az" -ErrorAction SilentlyContinue)) {
    Write-Log $SymErr "Azure CLI nicht gefunden. Bitte installieren: https://aka.ms/installazurecli" "Red"
    exit 1
}
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $azVersionRaw) {
    Write-Log $SymErr "Azure CLI reagiert nicht ('az version' fehlgeschlagen)." "Red"
    exit 1
}
$azVersion = ((@($azVersionRaw) -join "`n") | ConvertFrom-Json).'azure-cli'
Write-Log $SymOk ("Azure CLI gefunden: {0}" -f $azVersion) "Green"
Write-Log $SymInfo "Aktuellste Version bei Bedarf mit 'az upgrade' installieren" "Cyan" 4

# --- Login vorhanden? ---
Write-Log $SymInfo "Pruefe Azure Login..." "Cyan"
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $accountRaw) {
    Write-Log $SymWarn "Kein Login vorhanden. Starte 'az login'..." "Yellow"
    az login --output none
    Assert-AzSuccess "az login"
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess "az account show"
}
$account = (@($accountRaw) -join "`n") | ConvertFrom-Json
Write-Log $SymOk ("Login vorhanden: {0}" -f $account.user.name) "Green"

# --- Subscription setzen ---
if ([string]::IsNullOrWhiteSpace($SubscriptionId)) {
    $SubscriptionId = [string]$account.id
}
else {
    az account set --subscription $SubscriptionId --output none
    Assert-AzSuccess "az account set"
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess "az account show"
    $account = (@($accountRaw) -join "`n") | ConvertFrom-Json
}
Write-Log $SymOk ("Subscription: {0} ({1})" -f $account.name, $SubscriptionId) "Green"

# --- Erforderliche CLI-Extensions ---
az extension add --name automation --upgrade --only-show-errors --output none
Assert-AzSuccess "Extension 'automation' installieren"
Write-Log $SymOk "CLI-Extensions bereit" "Green"

# --- Runbook-Datei vorhanden + passt zum Kunden? ---
if (-not (Test-Path $RunbookFile)) {
    Write-Log $SymErr ("Runbook-Datei nicht gefunden: {0}" -f $RunbookFile) "Red"
    exit 1
}
$runbookText = [System.IO.File]::ReadAllText($RunbookFile, [System.Text.Encoding]::UTF8)
$rbVersionMatch  = [regex]::Match($runbookText, '\$ScriptVersion\s*=\s*"([0-9\.]+)"')
$rbCustomerMatch = [regex]::Match($runbookText, '\$CustomerName\s*=\s*"([^"]+)"')
$rbOverrideMatch = [regex]::Match($runbookText, '(\$ReportModeOverride\s*=\s*)"([^"]+)"')
if (-not $rbVersionMatch.Success -or -not $rbOverrideMatch.Success) {
    Write-Log $SymErr "Runbook-Datei passt nicht (Version 2.x mit ReportModeOverride erwartet)." "Red"
    exit 1
}
if ($runbookText -match '__[A-Z_]+__') {
    Write-Log $SymErr "Runbook enthaelt noch __Marker__ im Konfigblock (AcsEndpoint/SenderAddress eintragen)." "Red"
    exit 1
}
if (-not $rbCustomerMatch.Success -or $rbCustomerMatch.Groups[1].Value -ne $CustomerName) {
    Write-Log $SymErr ("Runbook gehoert nicht zu Kunde '{0}' (gefunden: '{1}')." -f $CustomerName, $rbCustomerMatch.Groups[1].Value) "Red"
    exit 1
}
Write-Log $SymOk ("Runbook-Datei gefunden: {0} (Version {1}, Kunde {2})" -f $RunbookFile, $rbVersionMatch.Groups[1].Value, $CustomerName) "Green"

if ($TestReportMode -ne "Weekly" -and $TestReportMode -ne "Monthly") {
    Write-Log $SymErr "TestReportMode muss 'Weekly' oder 'Monthly' sein." "Red"
    exit 1
}
Write-Log $SymOk ("Testmodus: {0} | Empfaenger: {1}" -f $TestReportMode, $RecipientEmail) "Green"

$tempDir = [System.IO.Path]::GetTempPath()

# --- Script-Version (unterhalb Pre-Check) ---
Write-Host ("=" * 60) -ForegroundColor White
Write-Log $SymInfo ("Script-Version: {0}" -f $ScriptVersion) "Cyan"

# =========================================================================
# 1. UMGEBUNGSWERTE ERMITTELN (fuer Platzhalter)
# =========================================================================
Write-Section "1/4 RUNBOOK PRUEFEN"

$null = Invoke-AzQuiet -Arguments @("automation", "runbook", "show", "--automation-account-name", $AutomationAccountName, "--resource-group", $RGName, "--name", $RunbookName, "--output", "none")
Assert-AzSuccess ("Runbook '{0}' im Automation Account finden (Setup bereits ausgefuehrt?)" -f $RunbookName)
Write-Log $SymOk ("Runbook '{0}' im Automation Account vorhanden" -f $RunbookName) "Green"

# =========================================================================
# 2. TEST- UND PROD-FASSUNG ERZEUGEN, TESTFASSUNG HOCHLADEN
# =========================================================================
Write-Section "2/4 TESTFASSUNG HOCHLADEN"

$prodText = $runbookText
$overrideRegex = New-Object System.Text.RegularExpressions.Regex('(\$ReportModeOverride\s*=\s*)"[^"]+"')
$testText = $overrideRegex.Replace($prodText, ('$1"{0}"' -f $TestReportMode), 1)
if (-not $testText.Contains(('"{0}"' -f $TestReportMode))) {
    Stop-WithError "ReportModeOverride konnte nicht gesetzt werden."
}

$utf8Bom = New-Object System.Text.UTF8Encoding($true)
$script:ProdDeployFile = Join-Path $tempDir "RunBk_MyAzureCost_LDK_prod.ps1"
$testDeployFile        = Join-Path $tempDir "RunBk_MyAzureCost_LDK_test.ps1"
[System.IO.File]::WriteAllText($script:ProdDeployFile, $prodText, $utf8Bom)
[System.IO.File]::WriteAllText($testDeployFile, $testText, $utf8Bom)

Write-Log $SymRun ("Lade Testfassung hoch (Override = {0})..." -f $TestReportMode) "Cyan"
if (-not (Publish-RunbookContent -FilePath $testDeployFile -Label "TEST")) {
    Stop-WithError "Testfassung konnte nicht veroeffentlicht werden."
}
$script:RunbookPatched = $true
Remove-Item -Path $testDeployFile -ErrorAction SilentlyContinue
Write-Log $SymOk "Testfassung veroeffentlicht" "Green"
Write-Log $SymWarn "Bis zur Wiederherstellung am Ende ist der Test-Override aktiv." "Yellow"

# =========================================================================
# 3. RUNBOOK-JOB STARTEN (ohne Parameter)
# =========================================================================
Write-Section "3/4 JOB STARTEN"

$aaResourceUri = "/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Automation/automationAccounts/{2}" -f $SubscriptionId, $RGName, $AutomationAccountName
$jobName = [guid]::NewGuid().ToString()
$jobBody = @{ properties = @{ runbook = @{ name = $RunbookName } } }
$jobBodyFile = Join-Path $tempDir "myazurecost_testjob.json"
[System.IO.File]::WriteAllText($jobBodyFile, ($jobBody | ConvertTo-Json -Depth 5), (New-Object System.Text.UTF8Encoding($false)))

Write-Log $SymRun ("Starte Runbook '{0}' (Job {1})..." -f $RunbookName, $jobName) "Cyan"
az rest --method put `
    --uri ("https://management.azure.com{0}/jobs/{1}?api-version={2}" -f $aaResourceUri, $jobName, $AutomationApiVersion) `
    --body ("@{0}" -f $jobBodyFile) `
    --headers "Content-Type=application/json" `
    --output none
Assert-AzSuccess "Runbook-Job starten"
Remove-Item -Path $jobBodyFile -ErrorAction SilentlyContinue
Write-Log $SymOk "Job angelegt" "Green"

# =========================================================================
# 4. AUF ERGEBNIS WARTEN + AUSGABE + WIEDERHERSTELLUNG
# =========================================================================
Write-Section "4/4 JOB-STATUS"

$endStates  = @("Completed", "Failed", "Stopped", "Suspended")
$deadline   = (Get-Date).AddMinutes($TimeoutMinutes)
$lastStatus = ""
$jobUri     = "https://management.azure.com{0}/jobs/{1}?api-version={2}" -f $aaResourceUri, $jobName, $AutomationApiVersion

while ($true) {
    Start-Sleep -Seconds 15
    $jobRaw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--uri", $jobUri, "--output", "json")
    if ($LASTEXITCODE -ne 0 -or -not $jobRaw) {
        Write-Log $SymWarn "Statusabfrage fehlgeschlagen, versuche erneut..." "Yellow"
        continue
    }
    $job = (@($jobRaw) -join "`n") | ConvertFrom-Json
    $status = [string]$job.properties.status
    if ($status -ne $lastStatus) {
        Write-Log $SymRun ("Job-Status: {0}" -f $status) "Cyan"
        $lastStatus = $status
    }
    if ($endStates -contains $status) { break }
    if ((Get-Date) -gt $deadline) {
        Write-Log $SymErr ("Timeout nach {0} Minuten. Job laeuft noch (Status: {1})." -f $TimeoutMinutes, $status) "Red"
        Write-Log $SymInfo "Ausgabe spaeter im Portal pruefen: Automation Account -> Jobs" "Cyan"
        Stop-WithError "Testlauf ohne Ergebnis beendet."
    }
}

# --- Job-Ausgabe abrufen ---
Write-Log $SymInfo "Rufe Job-Ausgabe ab..." "Cyan"
$outputUri = "https://management.azure.com{0}/jobs/{1}/output?api-version={2}" -f $aaResourceUri, $jobName, $AutomationApiVersion
$jobOutput = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--uri", $outputUri, "--output", "tsv")
Write-Host ("-" * 60) -ForegroundColor White
if ($jobOutput) {
    foreach ($line in @($jobOutput)) {
        Write-Host ("    {0}" -f $line) -ForegroundColor Gray
    }
}
else {
    Write-Host "    (keine Ausgabe vorhanden)" -ForegroundColor Gray
}
Write-Host ("-" * 60) -ForegroundColor White

# --- Produktivfassung wiederherstellen (immer) ---
Restore-ProdRunbook
Remove-Item -Path $script:ProdDeployFile -ErrorAction SilentlyContinue

# --- Ergebnis bewerten ---
if ($lastStatus -eq "Completed") {
    Write-Log $SymOk ("Testlauf erfolgreich ({0}). Bitte Postfach {1} pruefen (ggf. Spam-Ordner)." -f $TestReportMode, $RecipientEmail) "Green"
    Write-Log $SymInfo "Bitte kontrollieren: Umlaute im Betreff/Text, Farbbalken in Outlook," "Cyan"
    Write-Log $SymInfo "und im Job-Log die Zeilen 'Abfrage 1 erfolgreich (n Zeilen)'." "Cyan" 4
}
else {
    Write-Log $SymErr ("Job endete mit Status: {0}" -f $lastStatus) "Red"
    $jobRaw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--uri", $jobUri, "--output", "json")
    if ($LASTEXITCODE -eq 0 -and $jobRaw) {
        $job = (@($jobRaw) -join "`n") | ConvertFrom-Json
        if ($job.properties.exception) {
            Write-Log $SymErr ("Exception: {0}" -f $job.properties.exception) "Red"
        }
    }
    Write-Log $SymInfo "Details im Portal: Automation Account -> Jobs -> Errors/All Logs" "Cyan"
    Write-Host ("=" * 60) -ForegroundColor White
    exit 1
}
Write-Log $SymInfo ("Script-Version: {0}" -f $ScriptVersion) "Cyan"
Write-Host ("=" * 60) -ForegroundColor White
