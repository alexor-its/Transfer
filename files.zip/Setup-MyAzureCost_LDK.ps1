﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Setup fuer myAzureCost LDK - Wochen- und Monatsreport der Azure-Kosten
    (Sockel vs. dynamisch) per E-Mail aus Azure Automation fuer das LDK.
    Eigenstaendige Variante - nicht fuer die AOIT-Umgebung verwenden.
.DESCRIPTION
    Erstellt bzw. aktualisiert idempotent (Azure CLI):
      1. Resource Group
      2. Email Communication Service + Azure Managed Domain (Absender)
      3. Communication Service (ACS) mit verknuepfter Domain
      4. Automation Account mit System-assigned Managed Identity
      5. Rollenzuweisungen (Cost Management Reader auf Subscription,
         Contributor auf ACS-Ressource fuer den Mailversand per Entra-Token)
      6. Runbook: Platzhalter im Konfigblock werden mit den Werten dieses
         Setups ersetzt, danach Upload + Veroeffentlichung
      7. Zeitplaene: entfernt alte Verknuepfungen/Zeitplaene und legt an:
           - Wochenzeitplan  : jeden Montag 08:00   (Wochenreport)
           - Monatszeitplan  : am 1. des Monats 08:10 (Monatsabschluss)
           - Sperrvariable MyAzureCost_LDK_LastRun (verhindert Doppelmail,
             wenn der 1. auf einen Montag faellt)
    Bereits vorhandene Ressourcen werden erkannt und nicht neu erstellt.
    Alle Parameter werden im Script gepflegt (Abschnitt PARAMETER).
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 16.09.2026
    Version     : 2.2.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Changelog:
    1.0.0 (16.09.2026): Erstversion (taeglicher Report, Runbook-Parameter).
    2.0.0 (23.09.2026): Runbook 2.0.0 (Wochen-/Monatsreport)
      - Konfiguration per Platzhalter-Ersetzung statt Runbook-Parameter
      - Zeitplan taeglich 08:00, Entfernung alter jobSchedules/Zeitplaene
      - Existenzpruefungen (idempotent), Rollenzuweisung nur falls fehlend
      - Zeitplan-Offset aus Zielzeitzone statt lokaler Maschine
      - Temp-Pfad plattformunabhaengig, Versionsvergleich Azure CLI
    2.1.0 (23.09.2026): LDK-Variante
      - Script-, Runbook-, Zeitplan- und Ressourcennamen mit LDK
      - Pruefung: Kundenkennung im Runbook passt zum Setup
      - Bestaetigung der Ziel-Subscription vor Aenderungen
      - Keine automatische Entfernung fremder Alt-Zeitplaene
    2.2.0 (23.09.2026): Zwei Zeitplaene statt Tageszeitplan
      - Wochenzeitplan (Week, weekDays) + Monatszeitplan (Month, monthDays)
      - Erster Lauf = naechstes echtes Vorkommen in der Zielzeitzone
      - Automation-Variable als Sperre (Doppelversand-Schutz)
      - Pruefung: Wochentag/Monatstag/Sperrvariable passen zum Runbook
      - Entfernt den Tageszeitplan aus Version 2.0/2.1 (falls vorhanden)
    =========================================================================
    Voraussetzungen:
      - Azure CLI installiert und aktuell
      - Ausfuehrendes Konto benoetigt Rechte fuer Ressourcen-Erstellung UND
        Rollenzuweisungen (Owner oder User Access Administrator) auf der
        Subscription.
      - RunBk_MyAzureCost_LDK.ps1 (Version 2.2+) liegt im selben Ordner.
.EXAMPLE
    .\Setup-MyAzureCost_LDK.ps1
#>

# =========================================================================
# GRUNDKONFIGURATION (Kompatibilitaet / Ausgabe)
# =========================================================================
$ScriptVersion  = "2.2.0"
$PowerShellMode = "Compat"   # "Compat" = 5.1 + 7.x | "Seven" = nur 7.x

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Continue"

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =========================================================================
# PARAMETER - hier anpassen (keine Uebergabe per Aufruf)
# =========================================================================
# !!! LDK-Werte vor dem ersten Lauf pruefen (Subscription, Namen, Empfaenger) !!!
$CustomerName          = "LDK"                     # muss zu $CustomerName im Runbook passen
$SubscriptionId        = ""                        # LDK-Subscription-ID (leer = aktuelle Subscription)
$ConfirmTarget         = $true                     # Ziel-Subscription vor Aenderungen bestaetigen
$Location              = "westeurope"              # Region fuer Automation Account
$DataLocation          = "Europe"                  # ACS Data Location
$RGName                = "rg-AzureCostManagement"
$EmailServiceName      = "mailsvc-myazurecost-ldk" # Email Communication Service
$AcsName               = "acs-myazurecost-ldk"     # muss global eindeutig sein
$AutomationAccountName = "aa-myazurecost-ldk"
$RunbookName           = "rb_AzureCosts_LDK"
$RunbookFile           = Join-Path $PSScriptRoot "RunBk_MyAzureCost_LDK.ps1"
$RecipientEmail        = "harald.haas@lahn-dill-kreis.de"   # mehrere mit Komma trennen
$WeeklyScheduleName    = "Weekly-Mo-0800-MyAzureCost-LDK"
$WeeklyScheduleDay     = "Monday"                  # muss zu $WeeklyReportDay im Runbook passen
$WeeklyScheduleTime    = "08:00"                   # lokale Uhrzeit (HH:mm)
$MonthlyScheduleName   = "Monthly-01-0810-MyAzureCost-LDK"
$MonthlyScheduleDay    = 1                         # muss zu $MonthlyReportDay im Runbook passen
$MonthlyScheduleTime   = "08:10"                   # versetzt: Schutz vor Doppelmail (1. = Montag)
$LockVariableName      = "MyAzureCost_LDK_LastRun" # Sperrvariable (muss zum Runbook passen)
$ScheduleTimeZone      = "W. Europe Standard Time"
$ScheduleTimeZoneIana  = "Europe/Berlin"           # Fallback unter Linux/macOS
$LegacyScheduleNames   = @("Daily-0800-MyAzureCost-LDK")   # alte Zeitplaene im LDK-Account (werden entfernt)
$AutomationApiVersion  = "2023-11-01"
$MinAzCliVersion       = "2.60.0"

# =========================================================================
# HILFSFUNKTIONEN
# =========================================================================
function Write-Log {
    param(
        [string]$Symbol,
        [string]$Message,
        [string]$Color,
        [int]$Indent = 0
    )
    $stamp = Get-Date -Format "HH:mm:ss"
    Write-Host ("[{0}] {1}  {2}{3}" -f $stamp, $Symbol, (" " * $Indent), $Message) -ForegroundColor $Color
}

function Write-Section {
    param([string]$Title)
    Write-Host ("=" * 60) -ForegroundColor White
    Write-Host ("[ {0} ]" -f $Title) -ForegroundColor White
}

function Assert-AzSuccess {
    param([string]$Action)
    if ($LASTEXITCODE -ne 0) {
        Write-Log $SymErr ("Fehler bei: {0} (ExitCode {1})" -f $Action, $LASTEXITCODE) "Red"
        Write-Host ("=" * 60) -ForegroundColor White
        exit 1
    }
}

function Invoke-AzQuiet {
    # Fuehrt az mit unterdrueckter stderr-Ausgabe aus. Argumente als Array.
    param([string[]]$Arguments)
    $result = & az @Arguments 2>$null
    return $result
}

function Test-AzExists {
    # $true, wenn der az-Aufruf (z.B. "show") erfolgreich ist.
    param([string[]]$Arguments)
    $null = Invoke-AzQuiet -Arguments ($Arguments + @("--output", "none"))
    return ($LASTEXITCODE -eq 0)
}

function Write-JsonFile {
    # Schreibt JSON ohne BOM (fuer az rest --body @datei).
    param([string]$Path, [string]$Json)
    [System.IO.File]::WriteAllText($Path, $Json, (New-Object System.Text.UTF8Encoding($false)))
}

function Get-NextWeekdayTime {
    # Naechstes Vorkommen Wochentag + Uhrzeit (mind. 10 Minuten in der Zukunft).
    param([datetime]$Now, [string]$DayName, [string]$Time)
    $parts  = $Time.Split(":")
    $target = [System.DayOfWeek]$DayName
    for ($i = 0; $i -le 7; $i++) {
        $candidate = $Now.Date.AddDays($i).AddHours([int]$parts[0]).AddMinutes([int]$parts[1])
        if ($candidate.DayOfWeek -eq $target -and $candidate -gt $Now.AddMinutes(10)) { return $candidate }
    }
    return $Now.Date.AddDays(14).AddHours([int]$parts[0]).AddMinutes([int]$parts[1])
}

function Get-NextMonthDayTime {
    # Naechstes Vorkommen Monatstag + Uhrzeit (mind. 10 Minuten in der Zukunft).
    param([datetime]$Now, [int]$Day, [string]$Time)
    $parts     = $Time.Split(":")
    $monthBase = New-Object System.DateTime($Now.Year, $Now.Month, 1)
    for ($m = 0; $m -le 12; $m++) {
        $candidate = $monthBase.AddMonths($m).AddDays($Day - 1).AddHours([int]$parts[0]).AddMinutes([int]$parts[1])
        if ($candidate -gt $Now.AddMinutes(10)) { return $candidate }
    }
    return $monthBase.AddMonths(1).AddDays($Day - 1).AddHours([int]$parts[0]).AddMinutes([int]$parts[1])
}

function ConvertTo-ScheduleIso {
    # Lokale Zeit der Zielzeitzone -> ISO 8601 mit korrektem Offset.
    param([datetime]$LocalTime, [System.TimeZoneInfo]$TimeZone)
    $inv    = [System.Globalization.CultureInfo]::InvariantCulture
    $offset = $TimeZone.GetUtcOffset($LocalTime)
    $sign   = "+"
    if ($offset.Ticks -lt 0) { $sign = "-" }
    return ("{0}T{1}:00{2}{3:D2}:{4:D2}" -f $LocalTime.ToString("yyyy-MM-dd", $inv), $LocalTime.ToString("HH:mm", $inv), $sign, [math]::Abs($offset.Hours), [math]::Abs($offset.Minutes))
}

function Get-TargetTimeZone {
    foreach ($tzId in @($ScheduleTimeZone, $ScheduleTimeZoneIana)) {
        try { return [System.TimeZoneInfo]::FindSystemTimeZoneById($tzId) } catch { }
    }
    return $null
}

# =========================================================================
# PRE-CHECK
# =========================================================================
Write-Host ("=" * 60) -ForegroundColor White
Write-Host "[ PRE-CHECK ]" -ForegroundColor White

# --- PowerShell-Version / Modus ---
$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Log $SymErr ("PowerShellMode 'Seven' gesetzt, aber PowerShell {0}.{1} aktiv. Abbruch." -f $psMajor, $psMinor) "Red"
    exit 1
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
}
Write-Log $SymOk ("PowerShell {0}.{1} (Modus: {2})" -f $psMajor, $psMinor, $PowerShellMode) "Green"

# --- Azure CLI vorhanden? ---
Write-Log $SymInfo "Pruefe Azure CLI..." "Cyan"
if (-not (Get-Command -Name "az" -ErrorAction SilentlyContinue)) {
    Write-Log $SymErr "Azure CLI nicht gefunden. Bitte installieren: https://aka.ms/installazurecli" "Red"
    exit 1
}
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $azVersionRaw) {
    Write-Log $SymErr "Azure CLI reagiert nicht ('az version' fehlgeschlagen)." "Red"
    exit 1
}
$azVersion = ((@($azVersionRaw) -join "`n") | ConvertFrom-Json).'azure-cli'
Write-Log $SymOk ("Azure CLI gefunden: {0}" -f $azVersion) "Green"

# --- Azure CLI aktuell? ---
try {
    if ([version]$azVersion -lt [version]$MinAzCliVersion) {
        Write-Log $SymWarn ("Azure CLI aelter als Mindestversion {0} - bitte 'az upgrade' ausfuehren" -f $MinAzCliVersion) "Yellow"
    }
    else {
        Write-Log $SymOk ("Azure CLI >= Mindestversion {0}" -f $MinAzCliVersion) "Green"
    }
}
catch {
    Write-Log $SymWarn "Versionsvergleich nicht moeglich" "Yellow"
}
Write-Log $SymInfo "Aktuellste Version bei Bedarf mit 'az upgrade' installieren" "Cyan" 4

# --- Login vorhanden? ---
Write-Log $SymInfo "Pruefe Azure Login..." "Cyan"
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $accountRaw) {
    Write-Log $SymWarn "Kein Login vorhanden. Starte 'az login'..." "Yellow"
    az login --output none
    Assert-AzSuccess "az login"
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess "az account show"
}
$account = (@($accountRaw) -join "`n") | ConvertFrom-Json
Write-Log $SymOk ("Login vorhanden: {0}" -f $account.user.name) "Green"

# --- Subscription setzen ---
if ([string]::IsNullOrWhiteSpace($SubscriptionId)) {
    $SubscriptionId = [string]$account.id
}
else {
    az account set --subscription $SubscriptionId --output none
    Assert-AzSuccess "az account set"
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess "az account show"
    $account = (@($accountRaw) -join "`n") | ConvertFrom-Json
}
Write-Log $SymOk ("Subscription: {0} ({1})" -f $account.name, $SubscriptionId) "Green"

# --- Ziel bestaetigen (Schutz vor Deployment in die falsche Umgebung) ---
Write-Log $SymInfo ("Kunde: {0} | Automation Account: {1} | Resource Group: {2}" -f $CustomerName, $AutomationAccountName, $RGName) "Cyan"
if ($ConfirmTarget) {
    $answer = Read-Host ("    Deployment fuer {0} in Subscription '{1}' durchfuehren? (J/N)" -f $CustomerName, $account.name)
    if ($answer -notmatch "^(j|ja|y|yes)$") {
        Write-Log $SymWarn "Abbruch durch Benutzer - keine Aenderungen vorgenommen." "Yellow"
        Write-Host ("=" * 60) -ForegroundColor White
        exit 0
    }
    Write-Log $SymOk "Ziel bestaetigt" "Green"
}

# --- Erforderliche CLI-Extensions ---
Write-Log $SymInfo "Pruefe CLI-Extensions (communication, automation)..." "Cyan"
az extension add --name communication --upgrade --only-show-errors --output none
Assert-AzSuccess "Extension 'communication' installieren"
az extension add --name automation --upgrade --only-show-errors --output none
Assert-AzSuccess "Extension 'automation' installieren"
Write-Log $SymOk "CLI-Extensions bereit" "Green"

# --- Runbook-Datei vorhanden + Version 2.x? ---
if (-not (Test-Path $RunbookFile)) {
    Write-Log $SymErr ("Runbook-Datei nicht gefunden: {0}" -f $RunbookFile) "Red"
    exit 1
}
$runbookText = [System.IO.File]::ReadAllText($RunbookFile, [System.Text.Encoding]::UTF8)
$rbVersionMatch = [regex]::Match($runbookText, '\$ScriptVersion\s*=\s*"([0-9\.]+)"')
if (-not $rbVersionMatch.Success -or -not $runbookText.Contains("__ACS_ENDPOINT__")) {
    Write-Log $SymErr "Runbook-Datei enthaelt keine Platzhalter (Version 2.x erforderlich)." "Red"
    exit 1
}
$rbCustomerMatch = [regex]::Match($runbookText, '\$CustomerName\s*=\s*"([^"]+)"')
if (-not $rbCustomerMatch.Success -or $rbCustomerMatch.Groups[1].Value -ne $CustomerName) {
    Write-Log $SymErr ("Runbook gehoert nicht zu Kunde '{0}' (gefunden: '{1}')." -f $CustomerName, $rbCustomerMatch.Groups[1].Value) "Red"
    exit 1
}
Write-Log $SymOk ("Runbook-Datei gefunden: {0} (Version {1}, Kunde {2})" -f $RunbookFile, $rbVersionMatch.Groups[1].Value, $CustomerName) "Green"

# --- Zeitplan-Werte passen zum Runbook? ---
$rbWeeklyMatch  = [regex]::Match($runbookText, '\$WeeklyReportDay\s*=\s*"([^"]+)"')
$rbMonthlyMatch = [regex]::Match($runbookText, '\$MonthlyReportDay\s*=\s*(\d+)')
$rbLockUsed     = $runbookText.Contains(('Get-AutomationVariable -Name "{0}"' -f $LockVariableName)) -and $runbookText.Contains(('Set-AutomationVariable -Name "{0}"' -f $LockVariableName))
if (-not $rbWeeklyMatch.Success -or $rbWeeklyMatch.Groups[1].Value -ne $WeeklyScheduleDay) {
    Write-Log $SymErr ("WeeklyScheduleDay '{0}' passt nicht zu WeeklyReportDay im Runbook ('{1}')." -f $WeeklyScheduleDay, $rbWeeklyMatch.Groups[1].Value) "Red"
    exit 1
}
if (-not $rbMonthlyMatch.Success -or [int]$rbMonthlyMatch.Groups[1].Value -ne $MonthlyScheduleDay) {
    Write-Log $SymErr ("MonthlyScheduleDay '{0}' passt nicht zu MonthlyReportDay im Runbook ('{1}')." -f $MonthlyScheduleDay, $rbMonthlyMatch.Groups[1].Value) "Red"
    exit 1
}
if (-not $rbLockUsed) {
    Write-Log $SymErr ("Runbook verwendet die Sperrvariable '{0}' nicht." -f $LockVariableName) "Red"
    exit 1
}
if ($MonthlyScheduleDay -lt 1 -or $MonthlyScheduleDay -gt 28) {
    Write-Log $SymErr "MonthlyScheduleDay muss zwischen 1 und 28 liegen (in jedem Monat vorhanden)." "Red"
    exit 1
}
Write-Log $SymOk ("Zeitplan-Werte passen zum Runbook ({0} {1} | Tag {2} {3})" -f $WeeklyScheduleDay, $WeeklyScheduleTime, $MonthlyScheduleDay, $MonthlyScheduleTime) "Green"

# --- Empfaenger gepflegt? ---
if ([string]::IsNullOrWhiteSpace($RecipientEmail) -or $RecipientEmail -like "*example*") {
    Write-Log $SymErr "Bitte RecipientEmail im Parameter-Block anpassen." "Red"
    exit 1
}
Write-Log $SymOk ("Empfaenger: {0}" -f $RecipientEmail) "Green"

# --- Zeitzone fuer Zeitplan ---
$targetTz = Get-TargetTimeZone
if ($null -eq $targetTz) {
    Write-Log $SymErr ("Zeitzone '{0}' nicht gefunden." -f $ScheduleTimeZone) "Red"
    exit 1
}
Write-Log $SymOk ("Zeitzone Zeitplan: {0}" -f $targetTz.Id) "Green"

$tempDir = [System.IO.Path]::GetTempPath()

# --- Script-Version (unterhalb Pre-Check) ---
Write-Host ("=" * 60) -ForegroundColor White
Write-Log $SymInfo ("Script-Version: {0}" -f $ScriptVersion) "Cyan"

# =========================================================================
# 1. RESOURCE GROUP
# =========================================================================
Write-Section "1/7 RESOURCE GROUP"
Write-Log $SymRun ("Stelle Resource Group '{0}' in {1} sicher..." -f $RGName, $Location) "Cyan"
az group create --name $RGName --location $Location --output none
Assert-AzSuccess "Resource Group erstellen"
Write-Log $SymOk "Resource Group bereit" "Green"

# =========================================================================
# 2. EMAIL COMMUNICATION SERVICE + MANAGED DOMAIN
# =========================================================================
Write-Section "2/7 EMAIL SERVICE + DOMAIN"
if (Test-AzExists -Arguments @("communication", "email", "show", "--name", $EmailServiceName, "--resource-group", $RGName)) {
    Write-Log $SymOk ("Email Communication Service '{0}' vorhanden" -f $EmailServiceName) "Green"
}
else {
    Write-Log $SymRun ("Erstelle Email Communication Service '{0}'..." -f $EmailServiceName) "Cyan"
    az communication email create `
        --name $EmailServiceName `
        --resource-group $RGName `
        --location "global" `
        --data-location $DataLocation `
        --output none
    Assert-AzSuccess "Email Communication Service erstellen"
    Write-Log $SymOk "Email Service erstellt" "Green"
}

if (Test-AzExists -Arguments @("communication", "email", "domain", "show", "--domain-name", "AzureManagedDomain", "--email-service-name", $EmailServiceName, "--resource-group", $RGName)) {
    Write-Log $SymOk "Azure Managed Domain vorhanden" "Green"
}
else {
    Write-Log $SymRun "Erstelle Azure Managed Domain (Absender-Domain)..." "Cyan"
    az communication email domain create `
        --domain-name "AzureManagedDomain" `
        --email-service-name $EmailServiceName `
        --resource-group $RGName `
        --location "global" `
        --domain-management "AzureManaged" `
        --output none
    Assert-AzSuccess "Managed Domain erstellen"
    Write-Log $SymOk "Managed Domain erstellt" "Green"
}

$fromDomain = Invoke-AzQuiet -Arguments @("communication", "email", "domain", "show", "--domain-name", "AzureManagedDomain", "--email-service-name", $EmailServiceName, "--resource-group", $RGName, "--query", "fromSenderDomain", "--output", "tsv")
Assert-AzSuccess "Domain abfragen"
$SenderAddress = "DoNotReply@{0}" -f ([string](@($fromDomain)[0])).Trim()
Write-Log $SymOk ("Absenderadresse: {0}" -f $SenderAddress) "Green"

$domainResourceId = Invoke-AzQuiet -Arguments @("communication", "email", "domain", "show", "--domain-name", "AzureManagedDomain", "--email-service-name", $EmailServiceName, "--resource-group", $RGName, "--query", "id", "--output", "tsv")
Assert-AzSuccess "Domain-Ressourcen-ID abfragen"
$domainResourceId = ([string](@($domainResourceId)[0])).Trim()

# =========================================================================
# 3. COMMUNICATION SERVICE (ACS)
# =========================================================================
Write-Section "3/7 COMMUNICATION SERVICE"
if (Test-AzExists -Arguments @("communication", "show", "--name", $AcsName, "--resource-group", $RGName)) {
    Write-Log $SymOk ("Communication Service '{0}' vorhanden" -f $AcsName) "Green"
}
else {
    Write-Log $SymRun ("Erstelle Communication Service '{0}'..." -f $AcsName) "Cyan"
    az communication create `
        --name $AcsName `
        --resource-group $RGName `
        --location "global" `
        --data-location $DataLocation `
        --linked-domains $domainResourceId `
        --output none
    Assert-AzSuccess "Communication Service erstellen"
    Write-Log $SymOk "Communication Service erstellt" "Green"
}

$acsHostName = Invoke-AzQuiet -Arguments @("communication", "show", "--name", $AcsName, "--resource-group", $RGName, "--query", "hostName", "--output", "tsv")
Assert-AzSuccess "ACS Hostname abfragen"
$AcsEndpoint = "https://{0}" -f ([string](@($acsHostName)[0])).Trim()

$acsResourceId = Invoke-AzQuiet -Arguments @("communication", "show", "--name", $AcsName, "--resource-group", $RGName, "--query", "id", "--output", "tsv")
Assert-AzSuccess "ACS Ressourcen-ID abfragen"
$acsResourceId = ([string](@($acsResourceId)[0])).Trim()

$linkedDomains = Invoke-AzQuiet -Arguments @("communication", "show", "--name", $AcsName, "--resource-group", $RGName, "--query", "linkedDomains", "--output", "tsv")
if (-not ((@($linkedDomains) -join " ") -like ("*{0}*" -f $domainResourceId))) {
    Write-Log $SymWarn "Managed Domain ist nicht mit ACS verknuepft - verknuepfe..." "Yellow"
    az communication update --name $AcsName --resource-group $RGName --linked-domains $domainResourceId --output none
    Assert-AzSuccess "Domain mit ACS verknuepfen"
}
Write-Log $SymOk ("ACS Endpoint: {0}" -f $AcsEndpoint) "Green"

# =========================================================================
# 4. AUTOMATION ACCOUNT + MANAGED IDENTITY
# =========================================================================
Write-Section "4/7 AUTOMATION ACCOUNT"
if (Test-AzExists -Arguments @("automation", "account", "show", "--automation-account-name", $AutomationAccountName, "--resource-group", $RGName)) {
    Write-Log $SymOk ("Automation Account '{0}' vorhanden" -f $AutomationAccountName) "Green"
}
else {
    Write-Log $SymRun ("Erstelle Automation Account '{0}'..." -f $AutomationAccountName) "Cyan"
    az automation account create `
        --automation-account-name $AutomationAccountName `
        --resource-group $RGName `
        --location $Location `
        --output none
    Assert-AzSuccess "Automation Account erstellen"
    Write-Log $SymOk "Automation Account erstellt" "Green"
}

$aaResourceUri = "/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Automation/automationAccounts/{2}" -f $SubscriptionId, $RGName, $AutomationAccountName

$principalId = Invoke-AzQuiet -Arguments @("automation", "account", "show", "--automation-account-name", $AutomationAccountName, "--resource-group", $RGName, "--query", "identity.principalId", "--output", "tsv")
Assert-AzSuccess "Principal-ID abfragen"
$principalId = ([string](@($principalId)[0])).Trim()
$identityNew = $false
if ([string]::IsNullOrWhiteSpace($principalId)) {
    Write-Log $SymRun "Aktiviere System-assigned Managed Identity..." "Cyan"
    $identityBodyFile = Join-Path $tempDir "myazurecost_identity.json"
    Write-JsonFile -Path $identityBodyFile -Json '{"identity":{"type":"SystemAssigned"}}'
    az rest --method patch `
        --uri ("https://management.azure.com{0}?api-version={1}" -f $aaResourceUri, $AutomationApiVersion) `
        --body ("@{0}" -f $identityBodyFile) `
        --headers "Content-Type=application/json" `
        --output none
    Assert-AzSuccess "Managed Identity aktivieren"
    Remove-Item -Path $identityBodyFile -ErrorAction SilentlyContinue
    $principalId = Invoke-AzQuiet -Arguments @("automation", "account", "show", "--automation-account-name", $AutomationAccountName, "--resource-group", $RGName, "--query", "identity.principalId", "--output", "tsv")
    Assert-AzSuccess "Principal-ID abfragen"
    $principalId = ([string](@($principalId)[0])).Trim()
    $identityNew = $true
}
Write-Log $SymOk ("Managed Identity aktiv (PrincipalId: {0})" -f $principalId) "Green"

# =========================================================================
# 5. ROLLENZUWEISUNGEN
# =========================================================================
Write-Section "5/7 ROLLENZUWEISUNGEN"
if ($identityNew) {
    Write-Log $SymInfo "Warte 30 Sekunden auf Entra-ID-Replikation der Identity..." "Cyan"
    Start-Sleep -Seconds 30
}

$roleAssignments = @(
    @{ Role = "Cost Management Reader"; Scope = ("/subscriptions/{0}" -f $SubscriptionId); Text = "Subscription" },
    @{ Role = "Contributor";            Scope = $acsResourceId;                             Text = "ACS-Ressource (Mailversand)" }
)
foreach ($ra in $roleAssignments) {
    $countRaw = Invoke-AzQuiet -Arguments @("role", "assignment", "list", "--scope", $ra.Scope, "--role", $ra.Role, "--query", ("length([?principalId=='{0}'])" -f $principalId), "--output", "tsv")
    Assert-AzSuccess ("Rollenzuweisungen lesen ({0})" -f $ra.Role)
    $count = 0
    [void][int]::TryParse(([string](@($countRaw)[0])).Trim(), [ref]$count)
    if ($count -gt 0) {
        Write-Log $SymOk ("'{0}' auf {1} bereits vorhanden" -f $ra.Role, $ra.Text) "Green"
        continue
    }
    Write-Log $SymRun ("Weise '{0}' auf {1} zu..." -f $ra.Role, $ra.Text) "Cyan"
    az role assignment create `
        --assignee-object-id $principalId `
        --assignee-principal-type "ServicePrincipal" `
        --role $ra.Role `
        --scope $ra.Scope `
        --output none
    Assert-AzSuccess ("Rollenzuweisung {0}" -f $ra.Role)
    Write-Log $SymOk ("'{0}' zugewiesen" -f $ra.Role) "Green"
}

# =========================================================================
# 6. RUNBOOK (Platzhalter ersetzen, importieren, veroeffentlichen)
# =========================================================================
Write-Section "6/7 RUNBOOK"
Write-Log $SymRun "Ersetze Platzhalter im Runbook-Konfigblock..." "Cyan"
$placeholders = [ordered]@{
    "__SUBSCRIPTION_ID__" = $SubscriptionId
    "__ACS_ENDPOINT__"    = $AcsEndpoint
    "__SENDER_ADDRESS__"  = $SenderAddress
    "__RECIPIENT_EMAIL__" = $RecipientEmail
}
$deployText = $runbookText
foreach ($ph in $placeholders.Keys) {
    if (-not $deployText.Contains($ph)) {
        Write-Log $SymErr ("Platzhalter {0} fehlt im Runbook." -f $ph) "Red"
        exit 1
    }
    $deployText = $deployText.Replace($ph, [string]$placeholders[$ph])
    Write-Log $SymOk ("{0} -> {1}" -f $ph, $placeholders[$ph]) "Green" 4
}
if ([regex]::IsMatch($deployText, '"__[A-Z_]+__"')) {
    Write-Log $SymErr "Im Runbook sind noch unersetzte Platzhalter vorhanden." "Red"
    exit 1
}
$deployFile = Join-Path $tempDir "RunBk_MyAzureCost_deploy.ps1"
[System.IO.File]::WriteAllText($deployFile, $deployText, (New-Object System.Text.UTF8Encoding($true)))

if (Test-AzExists -Arguments @("automation", "runbook", "show", "--automation-account-name", $AutomationAccountName, "--resource-group", $RGName, "--name", $RunbookName)) {
    Write-Log $SymOk ("Runbook '{0}' vorhanden - Inhalt wird aktualisiert" -f $RunbookName) "Green"
}
else {
    Write-Log $SymRun ("Erstelle Runbook '{0}' (PowerShell 5.1)..." -f $RunbookName) "Cyan"
    az automation runbook create `
        --automation-account-name $AutomationAccountName `
        --resource-group $RGName `
        --name $RunbookName `
        --type "PowerShell" `
        --output none
    Assert-AzSuccess "Runbook erstellen"
}

Write-Log $SymRun "Lade Runbook-Inhalt hoch..." "Cyan"
az automation runbook replace-content `
    --automation-account-name $AutomationAccountName `
    --resource-group $RGName `
    --name $RunbookName `
    --content ("@{0}" -f $deployFile) `
    --output none
Assert-AzSuccess "Runbook-Inhalt hochladen"

az automation runbook publish `
    --automation-account-name $AutomationAccountName `
    --resource-group $RGName `
    --name $RunbookName `
    --output none
Assert-AzSuccess "Runbook veroeffentlichen"
Remove-Item -Path $deployFile -ErrorAction SilentlyContinue
Write-Log $SymOk ("Runbook veroeffentlicht (Version {0})" -f $rbVersionMatch.Groups[1].Value) "Green"

# =========================================================================
# 7. ZEITPLAENE (Altlasten entfernen, Wochen- + Monatszeitplan, Sperrvariable)
# =========================================================================
Write-Section "7/7 ZEITPLAENE"

# --- 7a: bestehende Verknuepfungen des Runbooks entfernen ---
Write-Log $SymRun "Entferne bestehende Zeitplan-Verknuepfungen des Runbooks..." "Cyan"
$jobScheduleIds = Invoke-AzQuiet -Arguments @(
    "rest", "--method", "get",
    "--uri", ("https://management.azure.com{0}/jobSchedules?api-version={1}" -f $aaResourceUri, $AutomationApiVersion),
    "--query", ("value[?properties.runbook.name=='{0}'].properties.jobScheduleId" -f $RunbookName),
    "--output", "tsv")
Assert-AzSuccess "Zeitplan-Verknuepfungen lesen"
$removedLinks = 0
foreach ($jsId in @($jobScheduleIds)) {
    $jsIdText = ([string]$jsId).Trim()
    if ([string]::IsNullOrWhiteSpace($jsIdText)) { continue }
    az rest --method delete `
        --uri ("https://management.azure.com{0}/jobSchedules/{1}?api-version={2}" -f $aaResourceUri, $jsIdText, $AutomationApiVersion) `
        --output none
    Assert-AzSuccess ("Verknuepfung {0} entfernen" -f $jsIdText)
    $removedLinks++
}
Write-Log $SymOk ("{0} Verknuepfung(en) entfernt" -f $removedLinks) "Green"

# --- 7b: alte und gleichnamige Zeitplaene entfernen ---
$schedulesToRemove = @($LegacyScheduleNames + @($WeeklyScheduleName, $MonthlyScheduleName) | Select-Object -Unique)
foreach ($sn in $schedulesToRemove) {
    $scheduleUri = "https://management.azure.com{0}/schedules/{1}?api-version={2}" -f $aaResourceUri, $sn, $AutomationApiVersion
    $null = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--uri", $scheduleUri, "--output", "none")
    if ($LASTEXITCODE -eq 0) {
        az rest --method delete --uri $scheduleUri --output none
        Assert-AzSuccess ("Zeitplan '{0}' entfernen" -f $sn)
        Write-Log $SymOk ("Zeitplan '{0}' entfernt" -f $sn) "Green"
    }
    else {
        Write-Log $SymInfo ("Zeitplan '{0}' nicht vorhanden" -f $sn) "Cyan" 4
    }
}

# --- 7c: Sperrvariable anlegen / zuruecksetzen ---
# Wert muss als JSON-String inkl. Anfuehrungszeichen uebergeben werden;
# Startwert 'none', da PowerShell-Runbooks keine Variable mit Null-Wert lesen koennen.
Write-Log $SymRun ("Lege Sperrvariable '{0}' an..." -f $LockVariableName) "Cyan"
$variableBody = @{
    name       = $LockVariableName
    properties = @{
        description = ("myAzureCost {0}: Doppelversand-Schutz (Status|Datum|Modus|UTC)" -f $CustomerName)
        isEncrypted = $false
        value       = '"none"'
    }
}
$variableBodyFile = Join-Path $tempDir "myazurecost_variable.json"
Write-JsonFile -Path $variableBodyFile -Json ($variableBody | ConvertTo-Json -Depth 5)
az rest --method put `
    --uri ("https://management.azure.com{0}/variables/{1}?api-version={2}" -f $aaResourceUri, $LockVariableName, $AutomationApiVersion) `
    --body ("@{0}" -f $variableBodyFile) `
    --headers "Content-Type=application/json" `
    --output none
Assert-AzSuccess "Sperrvariable anlegen"
Remove-Item -Path $variableBodyFile -ErrorAction SilentlyContinue
Write-Log $SymOk "Sperrvariable bereit (Wert: none)" "Green"

# --- 7d: Wochen- und Monatszeitplan anlegen + mit Runbook verknuepfen ---
$nowTarget = [System.TimeZoneInfo]::ConvertTimeFromUtc((Get-Date).ToUniversalTime(), $targetTz)
$scheduleDefs = @(
    @{
        Name      = $WeeklyScheduleName
        Frequency = "Week"
        Advanced  = @{ weekDays = @($WeeklyScheduleDay) }
        First     = (Get-NextWeekdayTime -Now $nowTarget -DayName $WeeklyScheduleDay -Time $WeeklyScheduleTime)
        Text      = ("jeden {0} {1} Uhr - Wochenreport" -f $WeeklyScheduleDay, $WeeklyScheduleTime)
    },
    @{
        Name      = $MonthlyScheduleName
        Frequency = "Month"
        Advanced  = @{ monthDays = @($MonthlyScheduleDay) }
        First     = (Get-NextMonthDayTime -Now $nowTarget -Day $MonthlyScheduleDay -Time $MonthlyScheduleTime)
        Text      = ("am {0}. des Monats {1} Uhr - Monatsabschluss" -f $MonthlyScheduleDay, $MonthlyScheduleTime)
    }
)
$scheduleBodyFile    = Join-Path $tempDir "myazurecost_schedule.json"
$jobScheduleBodyFile = Join-Path $tempDir "myazurecost_jobschedule.json"
foreach ($def in $scheduleDefs) {
    $startIso = ConvertTo-ScheduleIso -LocalTime $def.First -TimeZone $targetTz
    Write-Log $SymRun ("Erstelle Zeitplan '{0}' ({1}, erster Lauf {2})..." -f $def.Name, $def.Text, $startIso) "Cyan"
    $scheduleBody = @{
        name       = $def.Name
        properties = @{
            description      = ("myAzureCost {0}: {1}" -f $CustomerName, $def.Text)
            startTime        = $startIso
            frequency        = $def.Frequency
            interval         = 1
            timeZone         = $ScheduleTimeZone
            advancedSchedule = $def.Advanced
        }
    }
    Write-JsonFile -Path $scheduleBodyFile -Json ($scheduleBody | ConvertTo-Json -Depth 6)
    az rest --method put `
        --uri ("https://management.azure.com{0}/schedules/{1}?api-version={2}" -f $aaResourceUri, $def.Name, $AutomationApiVersion) `
        --body ("@{0}" -f $scheduleBodyFile) `
        --headers "Content-Type=application/json" `
        --output none
    Assert-AzSuccess ("Zeitplan '{0}' erstellen" -f $def.Name)

    $jobScheduleBody = @{
        properties = @{
            schedule = @{ name = $def.Name }
            runbook  = @{ name = $RunbookName }
        }
    }
    Write-JsonFile -Path $jobScheduleBodyFile -Json ($jobScheduleBody | ConvertTo-Json -Depth 5)
    az rest --method put `
        --uri ("https://management.azure.com{0}/jobSchedules/{1}?api-version={2}" -f $aaResourceUri, ([guid]::NewGuid().ToString()), $AutomationApiVersion) `
        --body ("@{0}" -f $jobScheduleBodyFile) `
        --headers "Content-Type=application/json" `
        --output none
    Assert-AzSuccess ("Zeitplan '{0}' verknuepfen" -f $def.Name)
    Write-Log $SymOk ("Zeitplan '{0}' erstellt und mit Runbook verknuepft" -f $def.Name) "Green"
}
Remove-Item -Path $scheduleBodyFile, $jobScheduleBodyFile -ErrorAction SilentlyContinue

# --- 7e: Kontrolle - naechste Laeufe laut Azure ---
foreach ($def in $scheduleDefs) {
    $nextRun = Invoke-AzQuiet -Arguments @("rest", "--method", "get",
        "--uri", ("https://management.azure.com{0}/schedules/{1}?api-version={2}" -f $aaResourceUri, $def.Name, $AutomationApiVersion),
        "--query", "properties.nextRun", "--output", "tsv")
    Assert-AzSuccess ("Zeitplan '{0}' lesen" -f $def.Name)
    Write-Log $SymInfo ("{0}: naechster Lauf laut Azure {1}" -f $def.Name, ([string](@($nextRun)[0])).Trim()) "Cyan" 4
}

# =========================================================================
# ZUSAMMENFASSUNG
# =========================================================================
Write-Host ("=" * 60) -ForegroundColor White
Write-Host "[ FERTIG ]" -ForegroundColor White
Write-Log $SymOk ("Kunde              : {0}" -f $CustomerName) "Green"
Write-Log $SymOk ("Resource Group     : {0}" -f $RGName) "Green"
Write-Log $SymOk ("Absender           : {0}" -f $SenderAddress) "Green"
Write-Log $SymOk ("Empfaenger         : {0}" -f $RecipientEmail) "Green"
Write-Log $SymOk ("Runbook            : {0} (v{1})" -f $RunbookName, $rbVersionMatch.Groups[1].Value) "Green"
Write-Log $SymOk ("Wochenzeitplan     : {0} ({1} {2} Uhr)" -f $WeeklyScheduleName, $WeeklyScheduleDay, $WeeklyScheduleTime) "Green"
Write-Log $SymOk ("Monatszeitplan     : {0} ({1}. {2} Uhr)" -f $MonthlyScheduleName, $MonthlyScheduleDay, $MonthlyScheduleTime) "Green"
Write-Log $SymOk ("Zeitzone           : {0}" -f $ScheduleTimeZone) "Green"
Write-Log $SymOk ("Sperrvariable      : {0}" -f $LockVariableName) "Green"
Write-Log $SymInfo "Faellt der 1. auf einen Montag, versendet der 08:00-Lauf den Monatsabschluss;" "Cyan"
Write-Log $SymInfo "der 08:10-Lauf erkennt die Sperre und versendet nichts." "Cyan" 4
Write-Log $SymInfo "Testlauf: Portal -> Automation Account -> Runbooks -> Bearbeiten ->" "Cyan"
Write-Log $SymInfo "`$ReportModeOverride = 'Weekly' setzen -> Testbereich -> Starten" "Cyan" 4
Write-Log $SymWarn "Override nach dem Test wieder auf 'Auto' (bzw. Setup erneut ausfuehren)." "Yellow"
Write-Log $SymInfo "Testlaeufe mit Override setzen die Sperrvariable nicht." "Cyan" 4
Write-Log $SymInfo ("Setup-Version      : {0}" -f $ScriptVersion) "Cyan"
Write-Host ("=" * 60) -ForegroundColor White
