﻿#Requires -Version 5.1
<#
.SYNOPSIS
    myAzureCost Runbook LDK - Wochen- und Monatsreport der Azure-Kosten
    (Sockelkosten vs. dynamische Kosten) per E-Mail fuer das LDK.
    Eigenstaendige Variante - nicht fuer die AOIT-Umgebung verwenden.
.DESCRIPTION
    Wird von zwei Zeitplaenen in Azure Automation gestartet
    (Setup-MyAzureCost_LDK.ps1):
      - Wochenzeitplan : jeden Montag 08:00
      - Monatszeitplan : am 1. des Monats 08:10
    Das Runbook bestimmt den Reporttyp anhand des Datums:
      - Monatsabschluss-Tag ($MonthlyReportDay, Standard: 1.)
            -> kompletter Vormonat, Vergleich mit dem Monat davor (vorlaeufig)
      - Wochentag ($WeeklyReportDay, Standard: Montag)
            -> laufender Monat bis Vortag, auf Wochenbasis (ISO-KW),
               Vergleich mit den gleichen Tagen des Vormonats
      - sonst (z.B. manueller Start) -> Ende ohne Versand
    Faellt der 1. auf einen Montag, versendet bereits der 08:00-Lauf den
    Monatsabschluss. Die Sperrvariable MyAzureCost_LDK_LastRun (Automation
    Variable, interne Cmdlets Get-/Set-AutomationVariable) sorgt dafuer,
    dass der 08:10-Lauf keine zweite Mail versendet. Schlaegt ein Lauf
    fehl, wird die Sperre freigegeben.

    Kostenklassifizierung:
      - Sockelkosten : ServiceNames aus $BaseServices (statisch erwartet)
      - Dynamisch    : alle anderen ServiceNames (z.B. AVD, Log Analytics)

    Report-Inhalt:
      - Kacheln Sockel / Dynamisch / Gesamt inkl. Vormonatsvergleich
      - Auffaelligkeiten (Sockel-Abweichung, Anstieg dynamisch, neue Posten)
      - Wochenuebersicht mit farbigen Stapelbalken (HTML)
      - Tagesverlauf als PNG (gestapelt + Vormonatslinie, inline per CID)
      - Kosten je Service (getrennt nach Sockel / dynamisch)
      - Top-Kostentreiber dynamisch (Meter-Ebene)
      - Hochrechnung Monatsende (nur Wochenreport, linear)
      - optional CSV je Ressource (Standard: nur Monatsabschluss)

    Technik:
      - Keine PowerShell-Module; reines REST + .NET Framework
      - Token: Managed Identity (Automation) ODER Azure CLI (lokaler Test)
      - Cost Management Query API inkl. nextLink-Paging und
        Throttling-Behandlung (QPU-/Retry-After-Header, ClientType-Header)
      - Versand: Azure Communication Services Email (api-version 2025-09-01)
      - Diagramm via System.Windows.Forms.DataVisualization (nur Windows
        PowerShell 5.1). Fehlt die Assembly (z.B. PowerShell 7), wird ohne
        Diagramm versendet - alle Tabellen bleiben vollstaendig.

    Erforderliche Rollen der Managed Identity:
      - Cost Management Reader auf der Subscription
      - Contributor auf der ACS-Ressource (Mailversand per Entra-Token)
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 16.09.2026
    Version     : 2.2.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Changelog:
    1.0.0 - 1.4.0 (16.09.2026): Taeglicher Report (siehe Vorversion).
    2.0.0 (23.09.2026): Neuaufbau fuer LDK-Anforderungen
      - Wochenreport (Montag) + Monatsabschluss (1. des Folgemonats),
        gesteuert durch das Runbook selbst (ein Tageszeitplan 08:00)
      - Trennung Sockelkosten / dynamische Kosten, eigene Farben
      - Vormonatsvergleich (gleiche Tage bzw. voller Monat)
      - Auffaelligkeiten: Sockel-Median-Abweichung, Anstieg dynamisch,
        neue Kostenposten
      - nextLink-Paging der Query API (bisher max. 1 Ergebnisseite)
      - Konfiguration im Script statt param() (Setup ersetzt Platzhalter)
      - Pre-Check, Versionsausgabe, Symbole/Farben nach Standard
      - $ErrorActionPreference = "Continue", fatale Fehler per throw
      - Request-Bodies explizit als UTF-8 (Umlaute unter PS 5.1)
      - Lokaler Testmodus via Azure CLI inkl. HTML-Vorschau
      - Regex ueber [regex]::Match statt Automatik-Variable
    2.1.0 (23.09.2026): LDK-Kennzeichnung
      - Scriptname RunBk_MyAzureCost_LDK, $CustomerName im Konfigblock
      - Kunde in Mail-Kopf, Betreff, Textfassung, Fusszeile
      - CSV: Kunde im Dateinamen + Kopfzeilen (Kunde, Report, Zeitraum)
    2.2.0 (23.09.2026): Zwei Zeitplaene statt Tageszeitplan
      - Wochenzeitplan Montag 08:00 + Monatszeitplan 1. 08:10
      - Doppelversand-Schutz per Automation-Variable (running/sent/failed)
    =========================================================================
.EXAMPLE
    .\RunBk_MyAzureCost_LDK.ps1
    In Azure Automation: Start per Zeitplan (ohne Parameter).
    Lokal: Werte im Abschnitt KONFIGURATION setzen, ggf. $PreviewOnly = $true.
#>

# =========================================================================
# KONFIGURATION (alle Werte im Script - keine Uebergabe per Aufruf)
# =========================================================================
$ScriptVersion  = "2.2.0"
$CustomerName   = "LDK"         # Kundenkennung: Mail-Kopf, Betreff, CSV, Dateinamen
$PowerShellMode = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = nur 7.x

# --- Umgebung: Platzhalter werden von Setup-MyAzureCost.ps1 ersetzt -------
$SubscriptionId = "__SUBSCRIPTION_ID__"
$AcsEndpoint    = "__ACS_ENDPOINT__"      # z.B. https://acs-xyz.europe.communication.azure.com
$SenderAddress  = "__SENDER_ADDRESS__"    # z.B. DoNotReply@xxxx.azurecomm.net
$RecipientEmail = "__RECIPIENT_EMAIL__"   # mehrere Adressen mit Komma trennen

# --- Report-Steuerung -----------------------------------------------------
$ReportModeOverride = "Auto"    # "Auto" | "Weekly" | "Monthly" (Testlaeufe)
$WeeklyReportDay    = "Monday"  # Wochentag fuer den Wochenreport
$MonthlyReportDay   = 1         # Tag des Folgemonats fuer den Monatsabschluss
$LockMaxAgeMinutes  = 90        # 'running'-Sperre gilt max. so lange (haengender Job)
# Sperrvariable: Name steht bewusst als Literal in Get-/Set-AutomationVariable
# (Microsoft-Empfehlung). Wird von Setup-MyAzureCost_LDK.ps1 angelegt.
$LockVariableName   = "MyAzureCost_LDK_LastRun"
$TimeZoneId         = "W. Europe Standard Time"
$TimeZoneIdIana     = "Europe/Berlin"
$CultureName        = "de-DE"
$CostType           = "ActualCost"

# --- Klassifizierung: Sockelkosten (exakte ServiceNames aus Cost Mgmt) ----
$BaseServices = @(
    "Virtual Network",
    "Azure DNS",
    "VPN Gateway"
)

# --- Schwellenwerte -------------------------------------------------------
$MinServiceCost             = 1.00   # kleinere Services -> "Sonstige"
$BaseDeviationWarnPercent   = 10     # Warnung Sockel-Abweichung (Median/Tag)
$DynamicIncreaseWarnPercent = 20     # Warnung Anstieg dynamische Kosten
$MinDaysForTrendChecks      = 3      # Mindesttage fuer Median-Pruefungen
$TopMeterCount              = 8      # Anzahl Top-Kostentreiber (Meter)
$AttachResourceCsv          = "MonthlyOnly"  # "Always" | "MonthlyOnly" | "Never"

# --- Farben ---------------------------------------------------------------
$ColorBase        = "#2F6DB5"   # Sockelkosten (Blau)
$ColorBaseTint    = "#EAF1FA"
$ColorDynamic     = "#E8710A"   # Dynamische Kosten (Orange)
$ColorDynamicTint = "#FDF1E6"
$ColorPrevLine    = "#6B7280"   # Vormonatslinie im Diagramm
$ColorHeader      = "#1F2937"   # Kopfzeilen / Gesamt
$ColorUp          = "#B42318"   # Kostenanstieg
$ColorDown        = "#067647"   # Kostensenkung

# --- Lokaler Testlauf -----------------------------------------------------
$PreviewOnly = $false           # $true = HTML-Vorschau als Datei, kein Versand
$PreviewPath = ""               # leer = Temp-Verzeichnis

# --- Technik --------------------------------------------------------------
$CostApiVersion    = "2025-03-01"
$AcsApiVersion     = "2025-09-01"   # erforderlich fuer Inline-Attachments (contentId)
$ClientTypeHeader  = "myAzureCost-AOIT"
$QueryPauseSeconds = 15             # Pause zwischen den Abfragen
$PagePauseSeconds  = 3              # Pause zwischen Ergebnisseiten (nextLink)
$MaxPages          = 30
$MinAzCliVersion   = "2.60.0"       # nur lokaler Lauf

# =========================================================================
# GRUNDKONFIGURATION (Kompatibilitaet / Ausgabe)
# =========================================================================
$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# Ausfuehrungsumgebung: Azure Automation mit Managed Identity?
$RunInAutomation = (-not [string]::IsNullOrEmpty($env:IDENTITY_ENDPOINT)) -and (-not [string]::IsNullOrEmpty($env:IDENTITY_HEADER))

$InvCulture   = [System.Globalization.CultureInfo]::InvariantCulture
$Culture      = $InvCulture
$Currency     = "EUR"
$ReportAlerts = New-Object System.Collections.ArrayList
$LockActive   = $false
$LockKey      = ""

# =========================================================================
# HILFSFUNKTIONEN - AUSGABE
# =========================================================================
# Hinweis: In Azure Automation wird Write-Output verwendet (Write-Host wird
# im Job-Log nicht zuverlaessig angezeigt, Farben gibt es dort nicht).
# Write-Log wird deshalb NIE innerhalb von Funktionen mit Rueckgabewert
# aufgerufen (Pipeline-Verschmutzung).
function Write-Log {
    param(
        [string]$Symbol,
        [string]$Message,
        [string]$Color = "Cyan",
        [int]$Indent = 0
    )
    $line = "[{0}] {1}  {2}{3}" -f (Get-Date -Format "HH:mm:ss"), $Symbol, (" " * $Indent), $Message
    if ($script:RunInAutomation) {
        Write-Output $line
    }
    else {
        Write-Host $line -ForegroundColor $Color
    }
}

function Write-Separator {
    $sep = "=" * 60
    if ($script:RunInAutomation) { Write-Output $sep }
    else { Write-Host $sep -ForegroundColor White }
}

function Write-Section {
    param([string]$Title)
    Write-Separator
    $head = "[ {0} ]" -f $Title
    if ($script:RunInAutomation) { Write-Output $head }
    else { Write-Host $head -ForegroundColor White }
}

# =========================================================================
# HILFSFUNKTIONEN - AZURE CLI (nur lokaler Lauf)
# =========================================================================
function Assert-AzSuccess {
    param([string]$Action)
    if ($LASTEXITCODE -ne 0) {
        throw ("Azure CLI Fehler bei: {0} (ExitCode {1})" -f $Action, $LASTEXITCODE)
    }
}

function Invoke-AzQuiet {
    # Fuehrt az mit unterdrueckter stderr-Ausgabe aus. Argumente als Array.
    param([string[]]$Arguments)
    $result = & az @Arguments 2>$null
    return $result
}

# =========================================================================
# HILFSFUNKTIONEN - TOKEN / REST
# =========================================================================
function Get-AccessToken {
    # Automation: Managed Identity ueber den Sandbox-Identity-Endpunkt.
    # Lokal     : Token des angemeldeten Azure-CLI-Kontos.
    param([Parameter(Mandatory = $true)][string]$Resource)
    if ($script:RunInAutomation) {
        $uri = "{0}?resource={1}" -f $env:IDENTITY_ENDPOINT, [uri]::EscapeDataString($Resource)
        $headers = @{
            "X-IDENTITY-HEADER" = $env:IDENTITY_HEADER
            "Metadata"          = "True"
        }
        try {
            $response = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers -UseBasicParsing -TimeoutSec 60 -ErrorAction Stop
        }
        catch {
            throw ("Managed-Identity-Token fuer '{0}' fehlgeschlagen: {1}" -f $Resource, $_.Exception.Message)
        }
        return [string]$response.access_token
    }
    $tokenRaw = Invoke-AzQuiet -Arguments @("account", "get-access-token", "--resource", $Resource, "--query", "accessToken", "--output", "tsv")
    Assert-AzSuccess ("az account get-access-token ({0})" -f $Resource)
    return ([string](@($tokenRaw)[0])).Trim()
}

function Get-HeaderValue {
    # Liest einen Response-Header - kompatibel mit PS 5.1 (HttpWebResponse)
    # und PS 7.x (HttpResponseMessage).
    param($Response, [string]$Name)
    try {
        if ($Response -is [System.Net.HttpWebResponse]) {
            $v = $Response.Headers[$Name]
            if ($v) { return [string]$v }
            return $null
        }
        $values = $null
        if ($Response.Headers.TryGetValues($Name, [ref]$values)) {
            return [string](@($values)[0])
        }
    }
    catch { }
    return $null
}

function Get-HeaderNames {
    param($Response)
    $names = @()
    try {
        if ($Response -is [System.Net.HttpWebResponse]) {
            $names = @($Response.Headers.AllKeys)
        }
        else {
            foreach ($h in $Response.Headers) { $names += [string]$h.Key }
        }
    }
    catch { }
    return $names
}

function Invoke-CostRequest {
    # Ein POST gegen die Query API mit Throttling-/Fehler-Retry.
    # WICHTIG: kein Write-Output (Rueckgabewert!), Meldungen per Write-Warning.
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][byte[]]$BodyBytes,
        [Parameter(Mandatory = $true)][string]$Token,
        [Parameter(Mandatory = $true)][string]$Label
    )
    $headers = @{
        "Authorization" = "Bearer {0}" -f $Token
        "ClientType"    = $script:ClientTypeHeader
    }
    # Cost Management meldet Wartezeiten in eigenen Headern (Maximum zaehlt).
    $retryHeaderNames = @(
        "Retry-After",
        "x-ms-ratelimit-microsoft.consumption-retry-after",
        "x-ms-ratelimit-microsoft.costmanagement-qpu-retry-after",
        "x-ms-ratelimit-microsoft.costmanagement-entity-retry-after",
        "x-ms-ratelimit-microsoft.costmanagement-tenant-retry-after",
        "x-ms-ratelimit-microsoft.costmanagement-client-retry-after",
        "x-ms-ratelimit-microsoft.costmanagement-clienttype-retry-after"
    )
    $maxAttempts = 6
    for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
        try {
            $response = Invoke-RestMethod -Uri $Uri -Method Post -Headers $headers -Body $BodyBytes `
                -ContentType "application/json; charset=utf-8" -UseBasicParsing -TimeoutSec 180 -ErrorAction Stop
            return $response
        }
        catch {
            $err         = $_
            $statusCode  = 0
            $retryAfter  = 0
            $webResponse = $err.Exception.Response
            if ($webResponse) {
                try { $statusCode = [int]$webResponse.StatusCode } catch { $statusCode = 0 }
                foreach ($hn in $retryHeaderNames) {
                    $hv    = Get-HeaderValue -Response $webResponse -Name $hn
                    $hvInt = 0
                    if ($hv -and [int]::TryParse($hv, [ref]$hvInt) -and $hvInt -gt $retryAfter) {
                        $retryAfter = $hvInt
                    }
                }
                if ($statusCode -eq 429) {
                    foreach ($hn in (Get-HeaderNames -Response $webResponse)) {
                        if ($hn -like "x-ms-ratelimit*") {
                            Write-Warning ("[DIAG] {0} = {1}" -f $hn, (Get-HeaderValue -Response $webResponse -Name $hn))
                        }
                    }
                }
            }
            $retryable = ($statusCode -eq 429) -or ($statusCode -ge 500)
            if ($retryable -and $attempt -lt $maxAttempts) {
                $wait = 60 * $attempt
                if (($retryAfter + 5) -gt $wait) { $wait = $retryAfter + 5 }
                if ($wait -gt 600) { $wait = 600 }
                Write-Warning ("Abfrage '{0}': HTTP {1}. Warte {2} s (Versuch {3}/{4}, gemeldet: {5} s)..." -f $Label, $statusCode, $wait, $attempt, $maxAttempts, $retryAfter)
                Start-Sleep -Seconds $wait
            }
            else {
                $detail = $err.Exception.Message
                if ($err.ErrorDetails -and $err.ErrorDetails.Message) { $detail = $err.ErrorDetails.Message }
                throw ("Cost-Management-Abfrage '{0}' fehlgeschlagen (HTTP {1}): {2}" -f $Label, $statusCode, $detail)
            }
        }
    }
    throw ("Cost-Management-Abfrage '{0}': maximale Anzahl Versuche erreicht." -f $Label)
}

function Invoke-CostQuery {
    # Fragt die Cost Management Query API ab, folgt dem nextLink (Paging)
    # und liefert Objekte (Spalten -> Properties) zurueck.
    # Der nextLink muss per POST MIT identischem Body aufgerufen werden.
    param(
        [Parameter(Mandatory = $true)][string]$Token,
        [Parameter(Mandatory = $true)][hashtable]$Body,
        [Parameter(Mandatory = $true)][string]$Label
    )
    $uri = "https://management.azure.com/subscriptions/{0}/providers/Microsoft.CostManagement/query?api-version={1}" -f $script:SubscriptionId, $script:CostApiVersion
    $json      = $Body | ConvertTo-Json -Depth 10
    $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $items     = New-Object System.Collections.Generic.List[object]
    $page      = 0
    while (-not [string]::IsNullOrWhiteSpace($uri)) {
        $page++
        if ($page -gt $script:MaxPages) {
            Write-Warning ("Abfrage '{0}': mehr als {1} Seiten - Ergebnis abgeschnitten." -f $Label, $script:MaxPages)
            break
        }
        $response = Invoke-CostRequest -Uri $uri -BodyBytes $bodyBytes -Token $Token -Label ("{0} / Seite {1}" -f $Label, $page)
        $uri = $null
        # HTTP 204 (keine Daten) -> leere Antwort
        if ($null -eq $response -or $null -eq $response.properties) { break }
        $columns = @($response.properties.columns | ForEach-Object { [string]$_.name })
        foreach ($row in @($response.properties.rows)) {
            if ($null -eq $row) { continue }
            $obj = [ordered]@{}
            for ($i = 0; $i -lt $columns.Count; $i++) {
                $obj[$columns[$i]] = $row[$i]
            }
            $items.Add([pscustomobject]$obj)
        }
        $next = [string]$response.properties.nextLink
        if (-not [string]::IsNullOrWhiteSpace($next)) {
            $uri = $next
            Start-Sleep -Seconds $script:PagePauseSeconds
        }
    }
    return $items.ToArray()
}

# =========================================================================
# HILFSFUNKTIONEN - DATEN
# =========================================================================
function Get-ReportTimeZone {
    foreach ($tzId in @($script:TimeZoneId, $script:TimeZoneIdIana)) {
        try { return [System.TimeZoneInfo]::FindSystemTimeZoneById($tzId) } catch { }
    }
    return [System.TimeZoneInfo]::Utc
}

function ConvertTo-ApiDate {
    param([datetime]$Date)
    return $Date.ToString("yyyy-MM-dd", $script:InvCulture)
}

function Convert-UsageDate {
    # UsageDate kommt als Zahl yyyyMMdd ODER als ISO-Datum.
    param([object]$Value)
    $s = ([string]$Value).Trim()
    if ([regex]::IsMatch($s, "^\d{8}$")) {
        return [datetime]::ParseExact($s, "yyyyMMdd", $script:InvCulture)
    }
    $parsed = [datetime]::MinValue
    if ([datetime]::TryParse($s, $script:InvCulture, [System.Globalization.DateTimeStyles]::None, [ref]$parsed)) {
        return $parsed.Date
    }
    throw ("UsageDate-Wert '{0}' hat ein unerwartetes Format." -f $s)
}

function Get-RowCost {
    param($Row)
    $names = @($Row.PSObject.Properties.Name)
    if ($names -contains "Cost")       { return [double]$Row.Cost }
    if ($names -contains "PreTaxCost") { return [double]$Row.PreTaxCost }
    return 0.0
}

function Get-CostCategory {
    param([string]$ServiceName)
    if ($script:BaseServices -contains $ServiceName) { return "Base" }
    return "Dynamic"
}

function Add-MapValue {
    param([hashtable]$Map, [string]$Key, [double]$Value)
    if (-not $Map.ContainsKey($Key)) { $Map[$Key] = 0.0 }
    $Map[$Key] = [double]$Map[$Key] + $Value
}

function Add-NestedMapValue {
    param([hashtable]$Map, [string]$Key, [string]$SubKey, [double]$Value)
    if (-not $Map.ContainsKey($Key)) { $Map[$Key] = @{} }
    Add-MapValue -Map $Map[$Key] -Key $SubKey -Value $Value
}

function Get-MapValue {
    param([hashtable]$Map, [string]$Key)
    if ($null -ne $Map -and $Map.ContainsKey($Key)) { return [double]$Map[$Key] }
    return 0.0
}

function Get-Median {
    param([double[]]$Values)
    if ($null -eq $Values -or $Values.Count -eq 0) { return 0.0 }
    $sorted = [double[]]$Values.Clone()
    [array]::Sort($sorted)
    $n = $sorted.Count
    if (($n % 2) -eq 1) { return $sorted[[int][math]::Floor($n / 2)] }
    $upper = [int]($n / 2)
    return ($sorted[$upper - 1] + $sorted[$upper]) / 2.0
}

function Get-DayValues {
    # Liefert je Tag des Zeitraums den Wert aus der Map (fehlend = 0).
    param([hashtable]$Map, [datetime]$Start, [int]$Days)
    $list = New-Object System.Collections.Generic.List[double]
    for ($i = 0; $i -lt $Days; $i++) {
        $key = $Start.AddDays($i).ToString("yyyyMMdd", $script:InvCulture)
        $list.Add((Get-MapValue -Map $Map -Key $key))
    }
    return $list.ToArray()
}

function Get-IsoWeekInfo {
    # ISO-8601-Kalenderwoche (Donnerstags-Regel), kompatibel mit .NET Framework.
    param([datetime]$Date)
    $dow      = (([int]$Date.DayOfWeek) + 6) % 7   # Montag = 0
    $thursday = $Date.Date.AddDays(3 - $dow)
    $week     = [int][math]::Floor(($thursday.DayOfYear - 1) / 7) + 1
    return [pscustomobject]@{ Week = $week; Year = $thursday.Year }
}

function Get-ResourceGroupName {
    param([string]$ResourceId)
    $m = [regex]::Match($ResourceId, "(?i)/resourcegroups/([^/]+)/")
    if ($m.Success) { return $m.Groups[1].Value }
    return "(ohne Resource Group)"
}

# =========================================================================
# HILFSFUNKTIONEN - FORMATIERUNG / HTML
# =========================================================================
function Format-Money {
    param([double]$Value)
    return ("{0} {1}" -f $Value.ToString("N2", $script:Culture), $script:Currency)
}

function Format-DeltaText {
    param([double]$Current, [double]$Previous)
    if ($Previous -le 0.005) {
        if ($Current -le 0.005) { return "-" }
        return "neu"
    }
    $pct  = (($Current - $Previous) / $Previous) * 100.0
    $sign = ""
    if ($pct -gt 0) { $sign = "+" }
    return ("{0}{1} %" -f $sign, $pct.ToString("N1", $script:Culture))
}

function Format-DeltaHtml {
    param([double]$Current, [double]$Previous)
    if ($Previous -le 0.005) {
        if ($Current -le 0.005) { return "<span style='color:#6B7280;'>&ndash;</span>" }
        return ("<span style='color:{0};font-weight:bold;'>neu</span>" -f $script:ColorUp)
    }
    $pct   = (($Current - $Previous) / $Previous) * 100.0
    $color = "#6B7280"
    $arrow = "&plusmn;"
    if ($pct -ge 0.5)      { $color = $script:ColorUp;   $arrow = "&#9650;" }
    elseif ($pct -le -0.5) { $color = $script:ColorDown; $arrow = "&#9660;" }
    $sign = ""
    if ($pct -gt 0) { $sign = "+" }
    return ("<span style='color:{0};white-space:nowrap;'>{1} {2}{3} %</span>" -f $color, $arrow, $sign, $pct.ToString("N1", $script:Culture))
}

function ConvertTo-HtmlText {
    param([string]$Text)
    return [System.Net.WebUtility]::HtmlEncode($Text)
}

function New-StackedBarHtml {
    # Horizontaler Stapelbalken als Tabelle (Outlook-tauglich, keine Bilder).
    param([double]$Base, [double]$Dyn, [double]$Max, [int]$Height = 12)
    if ($Max -le 0) { return "&nbsp;" }
    $wb = [int][math]::Round(($Base / $Max) * 100.0)
    $wd = [int][math]::Round(($Dyn / $Max) * 100.0)
    if ($wb -lt 0) { $wb = 0 }
    if ($wd -lt 0) { $wd = 0 }
    if (($wb + $wd) -gt 100) { $wd = 100 - $wb }
    $rest = 100 - $wb - $wd
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='border-collapse:collapse;'><tr>")
    if ($wb -gt 0) {
        [void]$sb.Append(("<td width='{0}%' bgcolor='{1}' style='background:{1};height:{2}px;font-size:0;line-height:0;'>&nbsp;</td>" -f $wb, $script:ColorBase, $Height))
    }
    if ($wd -gt 0) {
        [void]$sb.Append(("<td width='{0}%' bgcolor='{1}' style='background:{1};height:{2}px;font-size:0;line-height:0;'>&nbsp;</td>" -f $wd, $script:ColorDynamic, $Height))
    }
    if ($rest -gt 0) {
        [void]$sb.Append(("<td width='{0}%' style='height:{1}px;font-size:0;line-height:0;'>&nbsp;</td>" -f $rest, $Height))
    }
    [void]$sb.Append("</tr></table>")
    return $sb.ToString()
}

function New-TileHtml {
    param([string]$Title, [double]$Value, [double]$Previous, [string]$Background, [string]$CompareLabel)
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append(("<td width='33%' valign='top' bgcolor='{0}' style='background:{0};color:#ffffff;padding:14px 12px;font-family:Segoe UI,Arial,sans-serif;'>" -f $Background))
    [void]$sb.Append(("<div style='font-size:12px;'>{0}</div>" -f $Title))
    [void]$sb.Append(("<div style='font-size:21px;font-weight:bold;margin:4px 0 6px 0;white-space:nowrap;'>{0}</div>" -f (ConvertTo-HtmlText (Format-Money -Value $Value))))
    [void]$sb.Append(("<div style='font-size:11px;'>{0}: {1}<br/>Ver&auml;nderung: {2}</div>" -f $CompareLabel, (ConvertTo-HtmlText (Format-Money -Value $Previous)), (ConvertTo-HtmlText (Format-DeltaText -Current $Value -Previous $Previous))))
    [void]$sb.Append("</td>")
    return $sb.ToString()
}

function Add-ReportAlert {
    param([ValidateSet("warn", "info", "ok")][string]$Level, [string]$Html)
    [void]$script:ReportAlerts.Add([pscustomobject]@{ Level = $Level; Html = $Html })
}

# =========================================================================
# HILFSFUNKTIONEN - DIAGRAMM (MSChart, nur Windows PowerShell 5.1)
# =========================================================================
function Test-ChartAssemblies {
    try {
        Add-Type -AssemblyName "System.Windows.Forms" -ErrorAction Stop
        Add-Type -AssemblyName "System.Windows.Forms.DataVisualization" -ErrorAction Stop
        return $true
    }
    catch {
        try {
            [void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
            $asm = [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")
            if ($asm) { return $true }
        }
        catch { }
        return $false
    }
}

function New-DailyChartPng {
    # Gestapelte Tagessaeulen (Sockel/Dynamisch) + Vormonatslinie.
    # PrevValues < 0 = kein Vergleichswert (Punkt wird ausgeblendet).
    param(
        [string[]]$Labels,
        [double[]]$BaseValues,
        [double[]]$DynValues,
        [double[]]$PrevValues,
        [int]$Width = 700,
        [int]$Height = 300
    )
    $ns = "System.Windows.Forms.DataVisualization.Charting"
    $chart = New-Object "$ns.Chart"
    $chart.Width        = $Width
    $chart.Height       = $Height
    $chart.BackColor    = [System.Drawing.Color]::White
    $chart.AntiAliasing = [System.Windows.Forms.DataVisualization.Charting.AntiAliasingStyles]::All

    $area = New-Object "$ns.ChartArea" ("main")
    $area.BackColor                  = [System.Drawing.Color]::White
    $area.AxisX.MajorGrid.Enabled    = $false
    $area.AxisY.MajorGrid.LineColor  = [System.Drawing.Color]::FromArgb(230, 230, 230)
    $area.AxisX.Interval             = 1
    $area.AxisX.LabelStyle.Font      = New-Object System.Drawing.Font("Segoe UI", 7)
    $area.AxisY.LabelStyle.Font      = New-Object System.Drawing.Font("Segoe UI", 8)
    $area.AxisY.LabelStyle.Format    = "N0"
    $area.AxisX.LineColor            = [System.Drawing.Color]::FromArgb(160, 160, 160)
    $area.AxisY.LineColor            = [System.Drawing.Color]::FromArgb(160, 160, 160)
    [void]$chart.ChartAreas.Add($area)

    $legend = New-Object "$ns.Legend" ("leg")
    $legend.Docking   = [System.Windows.Forms.DataVisualization.Charting.Docking]::Bottom
    $legend.Alignment = [System.Drawing.StringAlignment]::Center
    $legend.Font      = New-Object System.Drawing.Font("Segoe UI", 8)
    [void]$chart.Legends.Add($legend)

    $sBase = New-Object "$ns.Series" ("Sockel")
    $sBase.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::StackedColumn
    $sBase.Color     = [System.Drawing.ColorTranslator]::FromHtml($script:ColorBase)
    $sBase.Legend    = "leg"
    $sBase["PointWidth"] = "0.75"

    $sDyn = New-Object "$ns.Series" ("Dynamisch")
    $sDyn.ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::StackedColumn
    $sDyn.Color     = [System.Drawing.ColorTranslator]::FromHtml($script:ColorDynamic)
    $sDyn.Legend    = "leg"
    $sDyn["PointWidth"] = "0.75"

    $sPrev = New-Object "$ns.Series" ("Vormonat gesamt")
    $sPrev.ChartType       = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::Line
    $sPrev.Color           = [System.Drawing.ColorTranslator]::FromHtml($script:ColorPrevLine)
    $sPrev.BorderWidth     = 2
    $sPrev.BorderDashStyle = [System.Windows.Forms.DataVisualization.Charting.ChartDashStyle]::Dash
    $sPrev.Legend          = "leg"

    [void]$chart.Series.Add($sBase)
    [void]$chart.Series.Add($sDyn)
    [void]$chart.Series.Add($sPrev)

    for ($i = 0; $i -lt $Labels.Count; $i++) {
        [void]$sBase.Points.AddXY($Labels[$i], $BaseValues[$i])
        [void]$sDyn.Points.AddXY($Labels[$i], $DynValues[$i])
        $pv  = $PrevValues[$i]
        $pvY = $pv
        if ($pvY -lt 0) { $pvY = 0.0 }
        $idx = $sPrev.Points.AddXY($Labels[$i], $pvY)
        if ($pv -lt 0) { $sPrev.Points[$idx].IsEmpty = $true }
    }

    $ms = New-Object System.IO.MemoryStream
    try {
        $chart.SaveImage($ms, [System.Windows.Forms.DataVisualization.Charting.ChartImageFormat]::Png)
        $bytes = $ms.ToArray()
    }
    finally {
        $ms.Dispose()
        $chart.Dispose()
    }
    return [Convert]::ToBase64String($bytes)
}

# =========================================================================
# HILFSFUNKTIONEN - DOPPELVERSAND-SCHUTZ (nur Azure Automation)
# =========================================================================
function Get-RunLockValue {
    # Liefert den Wert der Sperrvariable oder $null (nicht lesbar).
    try { return [string](Get-AutomationVariable -Name "MyAzureCost_LDK_LastRun" -ErrorAction Stop) }
    catch { return $null }
}

function Set-RunLock {
    # Schreibt Status|Datum|Modus|UTC-Zeit. Liefert $true bei Erfolg.
    param([ValidateSet("running", "sent", "failed")][string]$State, [string]$Key)
    $stamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", $script:InvCulture)
    try {
        Set-AutomationVariable -Name "MyAzureCost_LDK_LastRun" -Value ("{0}|{1}|{2}" -f $State, $Key, $stamp) -ErrorAction Stop
        return $true
    }
    catch { return $false }
}

# =========================================================================
# HAUPTABLAUF
# =========================================================================
try {
    # =====================================================================
    # PRE-CHECK
    # =====================================================================
    Write-Section "PRE-CHECK"

    # --- PowerShell-Version / Modus ---
    $psMajor = $PSVersionTable.PSVersion.Major
    $psMinor = $PSVersionTable.PSVersion.Minor
    if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
        throw ("PowerShellMode 'Seven' gesetzt, aber PowerShell {0}.{1} aktiv." -f $psMajor, $psMinor)
    }
    if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
        $PSNativeCommandUseErrorActionPreference = $false
    }
    Write-Log $SymOk ("PowerShell {0}.{1} (Modus: {2})" -f $psMajor, $psMinor, $PowerShellMode) "Green"

    # --- Ausfuehrungsumgebung / Azure CLI / Login ---
    if ($RunInAutomation) {
        Write-Log $SymOk "Azure Automation erkannt (Managed Identity verfuegbar)" "Green"
        Write-Log $SymInfo "Azure CLI wird hier nicht benoetigt - Token via Managed Identity" "Cyan" 4
    }
    else {
        Write-Log $SymInfo "Lokaler Lauf - pruefe Azure CLI..." "Cyan"
        if (-not (Get-Command -Name "az" -ErrorAction SilentlyContinue)) {
            throw "Azure CLI nicht gefunden (https://aka.ms/installazurecli). In Automation: Managed Identity aktiviert?"
        }
        $azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
        Assert-AzSuccess "az version"
        $azVersion = ((@($azVersionRaw) -join "`n") | ConvertFrom-Json).'azure-cli'
        Write-Log $SymOk ("Azure CLI gefunden: {0}" -f $azVersion) "Green"
        try {
            if ([version]$azVersion -lt [version]$MinAzCliVersion) {
                Write-Log $SymWarn ("Azure CLI aelter als Mindestversion {0} - bitte 'az upgrade' ausfuehren" -f $MinAzCliVersion) "Yellow"
            }
            else {
                Write-Log $SymOk ("Azure CLI >= Mindestversion {0}" -f $MinAzCliVersion) "Green"
            }
        }
        catch {
            Write-Log $SymWarn "Versionsvergleich nicht moeglich" "Yellow"
        }
        Write-Log $SymInfo "Aktuellste Version bei Bedarf mit 'az upgrade' installieren" "Cyan" 4

        Write-Log $SymInfo "Pruefe Azure Login..." "Cyan"
        $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
        if ($LASTEXITCODE -ne 0 -or -not $accountRaw) {
            Write-Log $SymWarn "Kein Login vorhanden. Starte 'az login'..." "Yellow"
            az login --output none
            Assert-AzSuccess "az login"
            $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
            Assert-AzSuccess "az account show"
        }
        $account = (@($accountRaw) -join "`n") | ConvertFrom-Json
        Write-Log $SymOk ("Login vorhanden: {0}" -f $account.user.name) "Green"
        if ([string]::IsNullOrWhiteSpace($SubscriptionId) -or $SubscriptionId -like "__*__") {
            $SubscriptionId = [string]$account.id
            Write-Log $SymInfo ("SubscriptionId aus aktuellem Login: {0}" -f $SubscriptionId) "Cyan" 4
        }
    }

    # --- Konfiguration vollstaendig? ---
    Write-Log $SymInfo "Pruefe Konfiguration..." "Cyan"
    if ([string]::IsNullOrWhiteSpace($SubscriptionId) -or $SubscriptionId -like "__*__") {
        throw "SubscriptionId ist nicht gesetzt (Platzhalter). Runbook ueber Setup-MyAzureCost.ps1 bereitstellen."
    }
    $mailConfig = [ordered]@{
        "AcsEndpoint"    = $AcsEndpoint
        "SenderAddress"  = $SenderAddress
        "RecipientEmail" = $RecipientEmail
    }
    $missingConfig = @()
    foreach ($key in $mailConfig.Keys) {
        $val = [string]$mailConfig[$key]
        if ([string]::IsNullOrWhiteSpace($val) -or $val -like "__*__") { $missingConfig += $key }
    }
    if ($missingConfig.Count -gt 0) {
        if ($PreviewOnly -and -not $RunInAutomation) {
            Write-Log $SymWarn ("Nicht gesetzt (nur Vorschau, kein Versand): {0}" -f ($missingConfig -join ", ")) "Yellow"
        }
        else {
            throw ("Konfiguration unvollstaendig: {0}" -f ($missingConfig -join ", "))
        }
    }
    $recipientList = @($RecipientEmail -split "[,;]" | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" -and $_ -notlike "__*__" })
    Write-Log $SymOk ("Subscription: {0}" -f $SubscriptionId) "Green"
    if ($recipientList.Count -gt 0) {
        Write-Log $SymOk ("Empfaenger: {0}" -f ($recipientList -join ", ")) "Green"
    }
    Write-Log $SymOk ("Kunde: {0}" -f $CustomerName) "Green"
    Write-Log $SymOk ("Sockel-Services: {0}" -f ($BaseServices -join ", ")) "Green"

    # --- Kultur / Zeitzone ---
    $Culture  = [System.Globalization.CultureInfo]::GetCultureInfo($CultureName)
    $reportTz = Get-ReportTimeZone
    if ($reportTz.Id -eq [System.TimeZoneInfo]::Utc.Id) {
        Write-Log $SymWarn ("Zeitzone '{0}' nicht gefunden - verwende UTC" -f $TimeZoneId) "Yellow"
    }
    else {
        Write-Log $SymOk ("Zeitzone: {0}" -f $reportTz.Id) "Green"
    }

    # --- Diagramm-Engine ---
    $chartsAvailable = Test-ChartAssemblies
    if ($chartsAvailable) {
        Write-Log $SymOk "Diagramm-Engine (MSChart) verfuegbar" "Green"
    }
    else {
        Write-Log $SymWarn "Diagramm-Engine nicht verfuegbar (nur Windows PowerShell 5.1) - Report ohne Diagramm" "Yellow"
    }

    # --- Script-Version (unterhalb Pre-Check) ---
    Write-Separator
    Write-Log $SymInfo ("Script-Version: {0}" -f $ScriptVersion) "Cyan"

    # =====================================================================
    # REPORTMODUS + ZEITRAEUME
    # =====================================================================
    Write-Section "REPORTMODUS"
    $nowLocal   = [System.TimeZoneInfo]::ConvertTimeFromUtc((Get-Date).ToUniversalTime(), $reportTz)
    $todayLocal = $nowLocal.Date
    $reportMode = "Skip"
    if ($ReportModeOverride -eq "Weekly") {
        $reportMode = "Weekly"
    }
    elseif ($ReportModeOverride -eq "Monthly") {
        $reportMode = "Monthly"
    }
    elseif ($todayLocal.Day -eq $MonthlyReportDay) {
        $reportMode = "Monthly"
    }
    elseif ($todayLocal.DayOfWeek.ToString() -eq $WeeklyReportDay) {
        $reportMode = "Weekly"
    }
    Write-Log $SymInfo ("Heute: {0} (Override: {1})" -f $todayLocal.ToString("dddd, dd.MM.yyyy", $Culture), $ReportModeOverride) "Cyan"

    if ($reportMode -eq "Skip") {
        Write-Log $SymOk ("Kein Reporttag (Wochenreport: {0}, Monatsabschluss: {1}. des Monats) - Ende ohne Versand" -f $WeeklyReportDay, $MonthlyReportDay) "Green"
        Write-Separator
        return
    }

    if ($reportMode -eq "Monthly") {
        $currentMonthStart = New-Object System.DateTime($todayLocal.Year, $todayLocal.Month, 1)
        $reportStart = $currentMonthStart.AddMonths(-1)
        $reportEnd   = $currentMonthStart.AddDays(-1)
        $modeText    = "Monatsabschluss"
    }
    else {
        $reportEnd   = $todayLocal.AddDays(-1)
        $reportStart = New-Object System.DateTime($reportEnd.Year, $reportEnd.Month, 1)
        $modeText    = "Wochenreport"
    }
    $compStart         = $reportStart.AddMonths(-1)
    $compEnd           = $reportStart.AddDays(-1)
    $reportDays        = ($reportEnd - $reportStart).Days + 1
    $compDays          = ($compEnd - $compStart).Days + 1
    $daysInReportMonth = [DateTime]::DaysInMonth($reportStart.Year, $reportStart.Month)
    $compSameDays      = [math]::Min($reportDays, $compDays)
    $compSameEnd       = $compStart.AddDays($compSameDays - 1)
    $isMonthComplete   = ($reportDays -eq $daysInReportMonth)

    Write-Log $SymOk ("Modus: {0}" -f $modeText) "Green"
    Write-Log $SymInfo ("Berichtszeitraum : {0} - {1} ({2} Tage)" -f $reportStart.ToString("dd.MM.yyyy"), $reportEnd.ToString("dd.MM.yyyy"), $reportDays) "Cyan" 4
    Write-Log $SymInfo ("Vergleich        : {0} - {1} (gleiche Tage), Vormonat gesamt bis {2}" -f $compStart.ToString("dd.MM.yyyy"), $compSameEnd.ToString("dd.MM.yyyy"), $compEnd.ToString("dd.MM.yyyy")) "Cyan" 4

    # =====================================================================
    # DOPPELVERSAND-SCHUTZ (nur Automation, Modus Auto, kein Preview)
    # =====================================================================
    $LockKey = "{0}|{1}" -f $todayLocal.ToString("yyyy-MM-dd", $InvCulture), $reportMode
    if ($RunInAutomation -and -not $PreviewOnly -and $ReportModeOverride -eq "Auto") {
        Write-Section "DOPPELVERSAND-SCHUTZ"
        if (-not (Get-Command -Name "Get-AutomationVariable" -ErrorAction SilentlyContinue)) {
            Write-Log $SymWarn "Interne Cmdlets nicht verfuegbar - Schutz inaktiv" "Yellow"
        }
        else {
            $lockValue = Get-RunLockValue
            if ($null -eq $lockValue) {
                Write-Log $SymWarn ("Sperrvariable '{0}' nicht lesbar - Schutz inaktiv (Setup ausfuehren)" -f $LockVariableName) "Yellow"
            }
            else {
                Write-Log $SymInfo ("Sperrvariable: {0}" -f $lockValue) "Cyan" 4
                $lockParts = $lockValue.Split("|")
                if ($lockParts.Count -ge 4 -and ("{0}|{1}" -f $lockParts[1], $lockParts[2]) -eq $LockKey) {
                    $lockAge  = 99999.0
                    $lockTime = [datetime]::MinValue
                    $lockStyles = [System.Globalization.DateTimeStyles]"AssumeUniversal, AdjustToUniversal"
                    if ([datetime]::TryParseExact($lockParts[3], "yyyy-MM-dd'T'HH:mm:ss'Z'", $InvCulture, $lockStyles, [ref]$lockTime)) {
                        $lockAge = ((Get-Date).ToUniversalTime() - $lockTime).TotalMinutes
                    }
                    if ($lockParts[0] -eq "sent") {
                        Write-Log $SymOk ("{0} fuer heute bereits versendet - Ende ohne Versand" -f $modeText) "Green"
                        Write-Separator
                        return
                    }
                    if ($lockParts[0] -eq "running" -and $lockAge -lt $LockMaxAgeMinutes) {
                        Write-Log $SymOk ("{0} wird bereits von einem anderen Job erstellt - Ende ohne Versand" -f $modeText) "Green"
                        Write-Separator
                        return
                    }
                }
                if (Set-RunLock -State "running" -Key $LockKey) {
                    $LockActive = $true
                    Write-Log $SymOk ("Sperre gesetzt: running|{0}" -f $LockKey) "Green"
                }
                else {
                    Write-Log $SymWarn "Sperre konnte nicht gesetzt werden - Schutz inaktiv" "Yellow"
                }
            }
        }
    }

    # =====================================================================
    # TOKEN
    # =====================================================================
    Write-Section "TOKEN"
    Write-Log $SymRun "Hole Token fuer Cost Management API..." "Cyan"
    $armToken = Get-AccessToken -Resource "https://management.azure.com/"
    if ([string]::IsNullOrWhiteSpace($armToken)) { throw "Leeres ARM-Token erhalten." }
    Write-Log $SymOk "ARM-Token erhalten" "Green"

    # =====================================================================
    # KOSTENABFRAGEN
    # =====================================================================
    Write-Section "KOSTENABFRAGEN"
    $needCsv = ($AttachResourceCsv -eq "Always") -or ($AttachResourceCsv -eq "MonthlyOnly" -and $reportMode -eq "Monthly")
    $queryCount = 2
    if ($needCsv) { $queryCount = 3 }
    Write-Log $SymInfo ("{0} Abfragen, {1} s Pause dazwischen" -f $queryCount, $QueryPauseSeconds) "Cyan"

    $aggregationCost = @{ totalCost = @{ name = "Cost"; function = "Sum" } }
    $fromComp   = (ConvertTo-ApiDate -Date $compStart) + "T00:00:00+00:00"
    $fromReport = (ConvertTo-ApiDate -Date $reportStart) + "T00:00:00+00:00"
    $toReport   = (ConvertTo-ApiDate -Date $reportEnd) + "T23:59:59+00:00"

    # --- Abfrage 1: Tageswerte je Service (Vormonat + Berichtszeitraum) ---
    Write-Log $SymRun "Abfrage 1: Tageswerte je Service..." "Cyan"
    $qDaily = @(Invoke-CostQuery -Token $armToken -Label "Tageswerte je Service" -Body @{
            type       = $CostType
            timeframe  = "Custom"
            timePeriod = @{ from = $fromComp; to = $toReport }
            dataset    = @{
                granularity = "Daily"
                aggregation = $aggregationCost
                grouping    = @(@{ type = "Dimension"; name = "ServiceName" })
            }
        })
    Write-Log $SymOk ("Abfrage 1 erfolgreich ({0} Zeilen)" -f $qDaily.Count) "Green"
    Start-Sleep -Seconds $QueryPauseSeconds

    # --- Abfrage 2: Kosten je Service + Meter (Berichtszeitraum) ---
    Write-Log $SymRun "Abfrage 2: Kosten je Meter..." "Cyan"
    $qMeter = @(Invoke-CostQuery -Token $armToken -Label "Kosten je Meter" -Body @{
            type       = $CostType
            timeframe  = "Custom"
            timePeriod = @{ from = $fromReport; to = $toReport }
            dataset    = @{
                granularity = "None"
                aggregation = $aggregationCost
                grouping    = @(
                    @{ type = "Dimension"; name = "ServiceName" },
                    @{ type = "Dimension"; name = "Meter" }
                )
            }
        })
    Write-Log $SymOk ("Abfrage 2 erfolgreich ({0} Zeilen)" -f $qMeter.Count) "Green"

    # --- Abfrage 3 (optional): Kosten je Ressource fuer CSV ---
    $qResource = @()
    if ($needCsv) {
        Start-Sleep -Seconds $QueryPauseSeconds
        Write-Log $SymRun "Abfrage 3: Kosten je Ressource (CSV)..." "Cyan"
        $qResource = @(Invoke-CostQuery -Token $armToken -Label "Kosten je Ressource" -Body @{
                type       = $CostType
                timeframe  = "Custom"
                timePeriod = @{ from = $fromReport; to = $toReport }
                dataset    = @{
                    granularity = "None"
                    aggregation = $aggregationCost
                    grouping    = @(
                        @{ type = "Dimension"; name = "ResourceId" },
                        @{ type = "Dimension"; name = "ServiceName" }
                    )
                }
            })
        Write-Log $SymOk ("Abfrage 3 erfolgreich ({0} Zeilen)" -f $qResource.Count) "Green"
    }

    # =====================================================================
    # AUFBEREITUNG
    # =====================================================================
    Write-Section "AUFBEREITUNG"
    $firstWithCurrency = @($qDaily + $qMeter) | Where-Object { $_.PSObject.Properties.Name -contains "Currency" } | Select-Object -First 1
    if ($firstWithCurrency -and $firstWithCurrency.Currency) { $Currency = [string]$firstWithCurrency.Currency }

    $svcReport       = @{}
    $svcCompSame     = @{}
    $svcCompFull     = @{}
    $dayBase         = @{}
    $dayDyn          = @{}
    $compDayTotal    = @{}
    $compDayBase     = @{}
    $baseSvcDayRep   = @{}
    $baseSvcDayComp  = @{}

    foreach ($r in $qDaily) {
        if (-not ($r.PSObject.Properties.Name -contains "UsageDate")) { continue }
        $d   = Convert-UsageDate -Value $r.UsageDate
        $svc = [string]$r.ServiceName
        if ([string]::IsNullOrWhiteSpace($svc)) { $svc = "(unbekannt)" }
        $cost   = Get-RowCost -Row $r
        $cat    = Get-CostCategory -ServiceName $svc
        $dayKey = $d.ToString("yyyyMMdd", $InvCulture)
        if ($d -ge $reportStart -and $d -le $reportEnd) {
            Add-MapValue -Map $svcReport -Key $svc -Value $cost
            if ($cat -eq "Base") {
                Add-MapValue -Map $dayBase -Key $dayKey -Value $cost
                Add-NestedMapValue -Map $baseSvcDayRep -Key $svc -SubKey $dayKey -Value $cost
            }
            else {
                Add-MapValue -Map $dayDyn -Key $dayKey -Value $cost
            }
        }
        elseif ($d -ge $compStart -and $d -le $compEnd) {
            Add-MapValue -Map $svcCompFull -Key $svc -Value $cost
            Add-MapValue -Map $compDayTotal -Key $dayKey -Value $cost
            if ($cat -eq "Base") {
                Add-MapValue -Map $compDayBase -Key $dayKey -Value $cost
                Add-NestedMapValue -Map $baseSvcDayComp -Key $svc -SubKey $dayKey -Value $cost
            }
            if ($d -le $compSameEnd) {
                Add-MapValue -Map $svcCompSame -Key $svc -Value $cost
            }
        }
    }

    # --- Summen ---
    $reportBaseValues = @(Get-DayValues -Map $dayBase -Start $reportStart -Days $reportDays)
    $reportDynValues  = @(Get-DayValues -Map $dayDyn -Start $reportStart -Days $reportDays)
    $reportBase = 0.0; foreach ($v in $reportBaseValues) { $reportBase += $v }
    $reportDyn  = 0.0; foreach ($v in $reportDynValues)  { $reportDyn  += $v }
    $reportTotal = $reportBase + $reportDyn

    $compSameBase = 0.0; $compSameDyn = 0.0
    foreach ($k in $svcCompSame.Keys) {
        if ((Get-CostCategory -ServiceName $k) -eq "Base") { $compSameBase += [double]$svcCompSame[$k] }
        else { $compSameDyn += [double]$svcCompSame[$k] }
    }
    $compFullBase = 0.0; $compFullDyn = 0.0
    foreach ($k in $svcCompFull.Keys) {
        if ((Get-CostCategory -ServiceName $k) -eq "Base") { $compFullBase += [double]$svcCompFull[$k] }
        else { $compFullDyn += [double]$svcCompFull[$k] }
    }
    $compSameTotal = $compSameBase + $compSameDyn
    $compFullTotal = $compFullBase + $compFullDyn

    Write-Log $SymOk ("Berichtszeitraum : Sockel {0} | Dynamisch {1} | Gesamt {2}" -f (Format-Money $reportBase), (Format-Money $reportDyn), (Format-Money $reportTotal)) "Green"
    Write-Log $SymOk ("Vormonat gl. Tage: Sockel {0} | Dynamisch {1} | Gesamt {2}" -f (Format-Money $compSameBase), (Format-Money $compSameDyn), (Format-Money $compSameTotal)) "Green"

    # --- Wochen (ISO-KW, auf den Monat begrenzt) ---
    $weekOrder = New-Object System.Collections.ArrayList
    $weekMap   = @{}
    for ($i = 0; $i -lt $reportDays; $i++) {
        $d  = $reportStart.AddDays($i)
        $wi = Get-IsoWeekInfo -Date $d
        $wk = "{0}-{1:D2}" -f $wi.Year, $wi.Week
        if (-not $weekMap.ContainsKey($wk)) {
            $weekMap[$wk] = [pscustomobject]@{ Week = $wi.Week; Start = $d; End = $d; Days = 0; Base = 0.0; Dyn = 0.0 }
            [void]$weekOrder.Add($wk)
        }
        $w = $weekMap[$wk]
        $w.End  = $d
        $w.Days = $w.Days + 1
        $w.Base = $w.Base + $reportBaseValues[$i]
        $w.Dyn  = $w.Dyn + $reportDynValues[$i]
    }
    Write-Log $SymOk ("{0} Kalenderwochen aufbereitet" -f $weekOrder.Count) "Green"

    # --- Hochrechnung (nur Wochenreport, Monat nicht vollstaendig) ---
    $medBaseReport = Get-Median -Values $reportBaseValues
    $projection = $null
    if ($reportMode -eq "Weekly" -and -not $isMonthComplete) {
        $remainingDays = $daysInReportMonth - $reportDays
        $last7Count = [math]::Min(7, $reportDays)
        $last7Sum = 0.0
        for ($i = $reportDays - $last7Count; $i -lt $reportDays; $i++) { $last7Sum += $reportDynValues[$i] }
        $avgDyn7 = 0.0
        if ($last7Count -gt 0) { $avgDyn7 = $last7Sum / $last7Count }
        $projBase = $reportBase + ($medBaseReport * $remainingDays)
        $projDyn  = $reportDyn + ($avgDyn7 * $remainingDays)
        $projection = [pscustomobject]@{
            Base  = $projBase
            Dyn   = $projDyn
            Total = $projBase + $projDyn
            Rate7 = $avgDyn7
        }
        Write-Log $SymInfo ("Hochrechnung Monat: {0} (Sockel {1} | Dynamisch {2})" -f (Format-Money $projection.Total), (Format-Money $projBase), (Format-Money $projDyn)) "Cyan"
    }

    # --- Auffaelligkeiten ---
    $compBaseValues = @(Get-DayValues -Map $compDayBase -Start $compStart -Days $compDays)
    $medBaseComp    = Get-Median -Values $compBaseValues
    if ($reportDays -ge $MinDaysForTrendChecks -and $medBaseComp -gt 0.005) {
        $baseDev = (($medBaseReport - $medBaseComp) / $medBaseComp) * 100.0
        if ([math]::Abs($baseDev) -ge $BaseDeviationWarnPercent) {
            Add-ReportAlert -Level "warn" -Html ("Sockelkosten weichen vom Vormonat ab: Median {0}/Tag statt {1}/Tag ({2})." -f (ConvertTo-HtmlText (Format-Money $medBaseReport)), (ConvertTo-HtmlText (Format-Money $medBaseComp)), (Format-DeltaHtml -Current $medBaseReport -Previous $medBaseComp))
        }
        else {
            Add-ReportAlert -Level "ok" -Html ("Sockelkosten stabil: Median {0}/Tag (Vormonat {1}/Tag)." -f (ConvertTo-HtmlText (Format-Money $medBaseReport)), (ConvertTo-HtmlText (Format-Money $medBaseComp)))
        }
        foreach ($svc in $BaseServices) {
            $mapRep  = $null
            $mapComp = $null
            if ($baseSvcDayRep.ContainsKey($svc))  { $mapRep  = $baseSvcDayRep[$svc] }
            if ($baseSvcDayComp.ContainsKey($svc)) { $mapComp = $baseSvcDayComp[$svc] }
            if ($null -eq $mapRep -and $null -eq $mapComp) { continue }
            if ($null -eq $mapRep)  { $mapRep  = @{} }
            if ($null -eq $mapComp) { $mapComp = @{} }
            $mRep  = Get-Median -Values @(Get-DayValues -Map $mapRep -Start $reportStart -Days $reportDays)
            $mComp = Get-Median -Values @(Get-DayValues -Map $mapComp -Start $compStart -Days $compDays)
            if ($mComp -le 0.005) {
                if ($mRep -gt 0.005) {
                    Add-ReportAlert -Level "warn" -Html ("Sockel-Service <b>{0}</b> ist neu (Median {1}/Tag)." -f (ConvertTo-HtmlText $svc), (ConvertTo-HtmlText (Format-Money $mRep)))
                }
                continue
            }
            $svcDev = (($mRep - $mComp) / $mComp) * 100.0
            if ([math]::Abs($svcDev) -ge $BaseDeviationWarnPercent) {
                Add-ReportAlert -Level "warn" -Html ("Sockel-Service <b>{0}</b>: Median {1}/Tag statt {2}/Tag ({3})." -f (ConvertTo-HtmlText $svc), (ConvertTo-HtmlText (Format-Money $mRep)), (ConvertTo-HtmlText (Format-Money $mComp)), (Format-DeltaHtml -Current $mRep -Previous $mComp))
            }
        }
    }
    if ($compSameDyn -gt 0.005) {
        $dynDev = (($reportDyn - $compSameDyn) / $compSameDyn) * 100.0
        if ($dynDev -ge $DynamicIncreaseWarnPercent) {
            Add-ReportAlert -Level "warn" -Html ("Dynamische Kosten gestiegen: {0} statt {1} im gleichen Zeitraum des Vormonats ({2})." -f (ConvertTo-HtmlText (Format-Money $reportDyn)), (ConvertTo-HtmlText (Format-Money $compSameDyn)), (Format-DeltaHtml -Current $reportDyn -Previous $compSameDyn))
        }
        elseif ($dynDev -le (-1 * $DynamicIncreaseWarnPercent)) {
            Add-ReportAlert -Level "ok" -Html ("Dynamische Kosten gesunken: {0} statt {1} im gleichen Zeitraum des Vormonats ({2})." -f (ConvertTo-HtmlText (Format-Money $reportDyn)), (ConvertTo-HtmlText (Format-Money $compSameDyn)), (Format-DeltaHtml -Current $reportDyn -Previous $compSameDyn))
        }
    }
    foreach ($svc in @($svcReport.Keys | Sort-Object)) {
        if ((Get-CostCategory -ServiceName $svc) -eq "Base") { continue }
        $cur = Get-MapValue -Map $svcReport -Key $svc
        if ($cur -ge $MinServiceCost -and (Get-MapValue -Map $svcCompFull -Key $svc) -le 0.005) {
            Add-ReportAlert -Level "info" -Html ("Neuer Kostenposten: <b>{0}</b> mit {1} (im Vormonat nicht vorhanden)." -f (ConvertTo-HtmlText $svc), (ConvertTo-HtmlText (Format-Money $cur)))
        }
    }
    Write-Log $SymOk ("{0} Hinweise/Auffaelligkeiten ermittelt" -f $ReportAlerts.Count) "Green"

    # --- Service-Tabelle ---
    $allServices = @{}
    foreach ($k in $svcReport.Keys)   { $allServices[$k] = $true }
    foreach ($k in $svcCompSame.Keys) { $allServices[$k] = $true }
    $serviceRows = New-Object System.Collections.ArrayList
    $smallRows   = @{
        "Base"    = [pscustomobject]@{ Count = 0; Current = 0.0; Previous = 0.0 }
        "Dynamic" = [pscustomobject]@{ Count = 0; Current = 0.0; Previous = 0.0 }
    }
    foreach ($svc in $allServices.Keys) {
        $cat  = Get-CostCategory -ServiceName $svc
        $cur  = Get-MapValue -Map $svcReport -Key $svc
        $prev = Get-MapValue -Map $svcCompSame -Key $svc
        if ($cat -eq "Base" -or $cur -ge $MinServiceCost -or $prev -ge $MinServiceCost) {
            [void]$serviceRows.Add([pscustomobject]@{ Service = $svc; Category = $cat; Current = $cur; Previous = $prev })
        }
        else {
            $s = $smallRows[$cat]
            $s.Count    = $s.Count + 1
            $s.Current  = $s.Current + $cur
            $s.Previous = $s.Previous + $prev
        }
    }

    # --- Top-Kostentreiber dynamisch (Meter) ---
    $meterRows = @($qMeter |
        Where-Object { (Get-CostCategory -ServiceName ([string]$_.ServiceName)) -eq "Dynamic" } |
        Sort-Object { Get-RowCost -Row $_ } -Descending |
        Select-Object -First $TopMeterCount)

    # =====================================================================
    # DIAGRAMM
    # =====================================================================
    Write-Section "DIAGRAMM"
    $inlineAttachments = @()
    $chartB64 = $null
    $cidDaily = "chart-daily"
    if ($chartsAvailable -and $reportDays -gt 0) {
        try {
            $labels = @(); $cBase = @(); $cDyn = @(); $cPrev = @()
            for ($i = 0; $i -lt $daysInReportMonth; $i++) {
                $labels += ($i + 1).ToString("00")
                if ($i -lt $reportDays) {
                    $cBase += [double]$reportBaseValues[$i]
                    $cDyn  += [double]$reportDynValues[$i]
                }
                else {
                    $cBase += 0.0
                    $cDyn  += 0.0
                }
                if ($i -lt $compDays) {
                    $cPrev += (Get-MapValue -Map $compDayTotal -Key ($compStart.AddDays($i).ToString("yyyyMMdd", $InvCulture)))
                }
                else {
                    $cPrev += -1.0
                }
            }
            $chartB64 = New-DailyChartPng -Labels $labels -BaseValues $cBase -DynValues $cDyn -PrevValues $cPrev -Width 700 -Height 300
            $inlineAttachments += @{
                name            = ("{0}_Tagesverlauf.png" -f $CustomerName)
                contentType     = "image/png"
                contentInBase64 = $chartB64
                contentId       = $cidDaily
            }
            Write-Log $SymOk "Diagramm 'Tagesverlauf' erzeugt" "Green"
        }
        catch {
            $chartB64 = $null
            Write-Log $SymWarn ("Diagramm fehlgeschlagen: {0}" -f $_.Exception.Message) "Yellow"
        }
    }
    else {
        Write-Log $SymInfo "Diagramm uebersprungen" "Cyan"
    }

    # =====================================================================
    # HTML-REPORT
    # =====================================================================
    Write-Section "HTML-REPORT"
    $customerHtml = ConvertTo-HtmlText $CustomerName
    $monthName   = ConvertTo-HtmlText ($reportStart.ToString("MMMM yyyy", $Culture))
    $periodHtml  = "{0}&ndash;{1}" -f $reportStart.ToString("dd.MM."), $reportEnd.ToString("dd.MM.yyyy")
    if ($reportMode -eq "Monthly") {
        $isoEnd       = $null
        $titleHtml    = "{0} &middot; Azure Monatsabschluss &ndash; {1}" -f $customerHtml, $monthName
        $subtitleHtml = "vorl&auml;ufig &middot; Zeitraum {0}" -f $periodHtml
        $compareLabel = "Vormonat"
        $compareHead  = ConvertTo-HtmlText ($compStart.ToString("MMMM", $Culture))
    }
    else {
        $isoEnd       = Get-IsoWeekInfo -Date $reportEnd
        $titleHtml    = "{0} &middot; Azure Kostenreport &ndash; KW {1}" -f $customerHtml, $isoEnd.Week
        $subtitleHtml = "{0} &middot; Zeitraum {1} (Datenbasis bis Vortag)" -f $monthName, $periodHtml
        $compareLabel = "Vormonat gl. Tage"
        $compareHead  = "Vormonat {0}&ndash;{1}" -f $compStart.ToString("dd.MM."), $compSameEnd.ToString("dd.MM.")
    }
    $fontCss = "font-family:Segoe UI,Arial,sans-serif;"
    $h3Css   = "margin:22px 0 8px 0;font-size:16px;color:{0};{1}" -f $ColorHeader, $fontCss
    $thCss   = "padding:6px 8px;font-size:12px;color:#ffffff;"
    $tdCss   = "padding:6px 8px;border-bottom:1px solid #e5e7eb;font-size:13px;"
    $tdNum   = $tdCss + "text-align:right;white-space:nowrap;"

    $html = New-Object System.Text.StringBuilder
    [void]$html.Append("<html><head><meta charset='utf-8'></head><body style='margin:0;padding:16px;background:#f3f4f6;'>")
    [void]$html.Append(("<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td align='center'>"))
    [void]$html.Append(("<table role='presentation' width='760' cellpadding='0' cellspacing='0' border='0' style='max-width:760px;width:100%;background:#ffffff;border:1px solid #e5e7eb;{0}'>" -f $fontCss))

    # --- Kopf ---
    [void]$html.Append(("<tr><td bgcolor='{0}' style='background:{0};padding:18px 20px;color:#ffffff;'>" -f $ColorHeader))
    [void]$html.Append(("<div style='font-size:20px;font-weight:bold;{0}'>{1}</div>" -f $fontCss, $titleHtml))
    [void]$html.Append(("<div style='font-size:12px;margin-top:4px;color:#d1d5db;{0}'>{1} &middot; Subscription {2}</div>" -f $fontCss, $subtitleHtml, (ConvertTo-HtmlText $SubscriptionId)))
    [void]$html.Append("</td></tr><tr><td style='padding:16px 20px 20px 20px;'>")

    # --- Legende ---
    [void]$html.Append(("<div style='font-size:12px;color:#374151;margin-bottom:8px;{0}'>" -f $fontCss))
    [void]$html.Append(("<span style='display:inline-block;width:10px;height:10px;background:{0};'></span>&nbsp;Sockelkosten (statisch) &nbsp;&nbsp; " -f $ColorBase))
    [void]$html.Append(("<span style='display:inline-block;width:10px;height:10px;background:{0};'></span>&nbsp;Dynamische Kosten</div>" -f $ColorDynamic))

    # --- Kacheln ---
    [void]$html.Append("<table role='presentation' width='100%' cellpadding='0' cellspacing='6' border='0'><tr>")
    [void]$html.Append((New-TileHtml -Title "Sockelkosten" -Value $reportBase -Previous $compSameBase -Background $ColorBase -CompareLabel $compareLabel))
    [void]$html.Append((New-TileHtml -Title "Dynamische Kosten" -Value $reportDyn -Previous $compSameDyn -Background $ColorDynamic -CompareLabel $compareLabel))
    [void]$html.Append((New-TileHtml -Title "Gesamt" -Value $reportTotal -Previous $compSameTotal -Background $ColorHeader -CompareLabel $compareLabel))
    [void]$html.Append("</tr></table>")

    # --- Anteil Sockel/Dynamisch ---
    if ($reportTotal -gt 0) {
        $shareBase = ($reportBase / $reportTotal) * 100.0
        [void]$html.Append("<div style='margin:6px 6px 0 6px;'>")
        [void]$html.Append((New-StackedBarHtml -Base $reportBase -Dyn $reportDyn -Max $reportTotal -Height 10))
        [void]$html.Append(("<div style='font-size:11px;color:#6b7280;margin-top:3px;{0}'>Anteil Sockel {1} % &middot; dynamisch {2} %</div></div>" -f $fontCss, $shareBase.ToString("N0", $Culture), (100.0 - $shareBase).ToString("N0", $Culture)))
    }

    # --- Hochrechnung ---
    if ($null -ne $projection) {
        [void]$html.Append(("<div style='margin:12px 6px 0 6px;padding:10px 12px;background:#f9fafb;border:1px solid #e5e7eb;font-size:13px;{0}'>" -f $fontCss))
        [void]$html.Append(("<b>Hochrechnung {0}:</b> {1} " -f $monthName, (ConvertTo-HtmlText (Format-Money $projection.Total))))
        [void]$html.Append(("(<span style='color:{0};'>Sockel {1}</span> &middot; <span style='color:{2};'>dynamisch {3}</span>) &middot; Vormonat gesamt: {4}" -f $ColorBase, (ConvertTo-HtmlText (Format-Money $projection.Base)), $ColorDynamic, (ConvertTo-HtmlText (Format-Money $projection.Dyn)), (ConvertTo-HtmlText (Format-Money $compFullTotal))))
        [void]$html.Append(("<div style='font-size:11px;color:#6b7280;margin-top:4px;'>Lineare Sch&auml;tzung: Sockel mit Median/Tag, dynamisch mit &Oslash; der letzten 7 Tage ({0}/Tag).</div></div>" -f (ConvertTo-HtmlText (Format-Money $projection.Rate7))))
    }

    # --- Auffaelligkeiten ---
    if ($ReportAlerts.Count -gt 0) {
        [void]$html.Append(("<div style='{0}'>Auff&auml;lligkeiten</div>" -f $h3Css))
        [void]$html.Append("<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='border-collapse:collapse;'>")
        foreach ($al in @($ReportAlerts | Sort-Object { switch ($_.Level) { "warn" { 0 } "info" { 1 } default { 2 } } })) {
            $icon = "&#9989;"; $bg = "#ecfdf3"
            if ($al.Level -eq "warn") { $icon = "&#9888;&#65039;"; $bg = "#fffaeb" }
            elseif ($al.Level -eq "info") { $icon = "&#8505;&#65039;"; $bg = "#eff6ff" }
            [void]$html.Append(("<tr><td style='background:{0};padding:7px 10px;border-bottom:1px solid #ffffff;font-size:13px;{1}'>{2}&nbsp; {3}</td></tr>" -f $bg, $fontCss, $icon, $al.Html))
        }
        [void]$html.Append("</table>")
    }

    # --- Wochenuebersicht ---
    [void]$html.Append(("<div style='{0}'>Wochen&uuml;bersicht {1}</div>" -f $h3Css, $monthName))
    [void]$html.Append("<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='border-collapse:collapse;'>")
    [void]$html.Append(("<tr><th align='left' bgcolor='{0}' style='{1}background:{0};'>KW</th><th align='left' bgcolor='{0}' style='{1}background:{0};'>Zeitraum</th>" -f $ColorHeader, $thCss))
    [void]$html.Append(("<th align='right' bgcolor='{0}' style='{1}background:{0};'>Sockel</th><th align='right' bgcolor='{2}' style='{1}background:{2};'>Dynamisch</th>" -f $ColorBase, $thCss, $ColorDynamic))
    [void]$html.Append(("<th align='right' bgcolor='{0}' style='{1}background:{0};'>Gesamt</th><th align='left' bgcolor='{0}' style='{1}background:{0};width:28%;'>Verteilung</th></tr>" -f $ColorHeader, $thCss))
    $maxWeek = 0.0
    foreach ($wk in $weekOrder) { $wt = $weekMap[$wk].Base + $weekMap[$wk].Dyn; if ($wt -gt $maxWeek) { $maxWeek = $wt } }
    foreach ($wk in $weekOrder) {
        $w = $weekMap[$wk]
        $daysNote = ""
        if ($w.Days -lt 7) { $daysNote = " <span style='color:#9ca3af;'>({0} T.)</span>" -f $w.Days }
        [void]$html.Append("<tr>")
        [void]$html.Append(("<td style='{0}'>{1}</td>" -f $tdCss, $w.Week))
        [void]$html.Append(("<td style='{0}white-space:nowrap;'>{1}&ndash;{2}{3}</td>" -f $tdCss, $w.Start.ToString("dd.MM."), $w.End.ToString("dd.MM."), $daysNote))
        [void]$html.Append(("<td style='{0}color:{1};'>{2}</td>" -f $tdNum, $ColorBase, (ConvertTo-HtmlText (Format-Money $w.Base))))
        [void]$html.Append(("<td style='{0}color:{1};'>{2}</td>" -f $tdNum, $ColorDynamic, (ConvertTo-HtmlText (Format-Money $w.Dyn))))
        [void]$html.Append(("<td style='{0}font-weight:bold;'>{1}</td>" -f $tdNum, (ConvertTo-HtmlText (Format-Money ($w.Base + $w.Dyn)))))
        [void]$html.Append(("<td style='{0}'>{1}</td>" -f $tdCss, (New-StackedBarHtml -Base $w.Base -Dyn $w.Dyn -Max $maxWeek)))
        [void]$html.Append("</tr>")
    }
    [void]$html.Append(("<tr style='background:#f9fafb;'><td style='{0}font-weight:bold;' colspan='2'>Summe</td>" -f $tdCss))
    [void]$html.Append(("<td style='{0}color:{1};font-weight:bold;'>{2}</td><td style='{0}color:{3};font-weight:bold;'>{4}</td>" -f $tdNum, $ColorBase, (ConvertTo-HtmlText (Format-Money $reportBase)), $ColorDynamic, (ConvertTo-HtmlText (Format-Money $reportDyn))))
    [void]$html.Append(("<td style='{0}font-weight:bold;'>{1}</td><td style='{2}'>&nbsp;</td></tr>" -f $tdNum, (ConvertTo-HtmlText (Format-Money $reportTotal)), $tdCss))
    [void]$html.Append(("<tr><td style='{0}color:#6b7280;' colspan='2'>{1}</td>" -f $tdCss, $compareHead))
    [void]$html.Append(("<td style='{0}color:#6b7280;'>{1}</td><td style='{0}color:#6b7280;'>{2}</td><td style='{0}color:#6b7280;'>{3}</td><td style='{4}'>{5}</td></tr>" -f $tdNum, (ConvertTo-HtmlText (Format-Money $compSameBase)), (ConvertTo-HtmlText (Format-Money $compSameDyn)), (ConvertTo-HtmlText (Format-Money $compSameTotal)), $tdCss, (Format-DeltaHtml -Current $reportTotal -Previous $compSameTotal)))
    [void]$html.Append("</table>")

    # --- Tagesverlauf (Diagramm) ---
    if ($chartB64) {
        [void]$html.Append(("<div style='{0}'>Tagesverlauf {1}</div>" -f $h3Css, $monthName))
        [void]$html.Append(("<img src='cid:{0}' width='700' alt='Tagesverlauf Sockel und dynamische Kosten' style='max-width:100%;height:auto;border:1px solid #e5e7eb;display:block;' />" -f $cidDaily))
        [void]$html.Append(("<div style='font-size:11px;color:#6b7280;margin-top:3px;{0}'>Gestrichelte Linie: Tageskosten gesamt im Vormonat am gleichen Kalendertag.</div>" -f $fontCss))
    }

    # --- Kosten je Service ---
    [void]$html.Append(("<div style='{0}'>Kosten je Service</div>" -f $h3Css))
    [void]$html.Append("<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='border-collapse:collapse;'>")
    [void]$html.Append(("<tr><th align='left' bgcolor='{0}' style='{1}background:{0};'>Service</th><th align='right' bgcolor='{0}' style='{1}background:{0};'>{2}</th><th align='right' bgcolor='{0}' style='{1}background:{0};'>{3}</th><th align='right' bgcolor='{0}' style='{1}background:{0};'>Ver&auml;nderung</th></tr>" -f $ColorHeader, $thCss, $periodHtml, $compareHead))
    foreach ($grp in @(
            [pscustomobject]@{ Cat = "Base";    Title = "Sockelkosten";      Color = $ColorBase;    Tint = $ColorBaseTint;    Cur = $reportBase; Prev = $compSameBase },
            [pscustomobject]@{ Cat = "Dynamic"; Title = "Dynamische Kosten"; Color = $ColorDynamic; Tint = $ColorDynamicTint; Cur = $reportDyn;  Prev = $compSameDyn }
        )) {
        [void]$html.Append(("<tr><td bgcolor='{0}' style='background:{0};border-left:4px solid {1};{2}font-weight:bold;color:{1};'>{3}</td>" -f $grp.Tint, $grp.Color, $tdCss, $grp.Title))
        [void]$html.Append(("<td bgcolor='{0}' style='background:{0};{1}font-weight:bold;'>{2}</td><td bgcolor='{0}' style='background:{0};{1}'>{3}</td><td bgcolor='{0}' style='background:{0};{1}'>{4}</td></tr>" -f $grp.Tint, $tdNum, (ConvertTo-HtmlText (Format-Money $grp.Cur)), (ConvertTo-HtmlText (Format-Money $grp.Prev)), (Format-DeltaHtml -Current $grp.Cur -Previous $grp.Prev)))
        $rows = @($serviceRows | Where-Object { $_.Category -eq $grp.Cat } | Sort-Object { [double]$_.Current } -Descending)
        foreach ($row in $rows) {
            [void]$html.Append(("<tr><td style='border-left:4px solid {0};{1}padding-left:14px;'>{2}</td>" -f $grp.Color, $tdCss, (ConvertTo-HtmlText $row.Service)))
            [void]$html.Append(("<td style='{0}'>{1}</td><td style='{0}color:#6b7280;'>{2}</td><td style='{0}'>{3}</td></tr>" -f $tdNum, (ConvertTo-HtmlText (Format-Money $row.Current)), (ConvertTo-HtmlText (Format-Money $row.Previous)), (Format-DeltaHtml -Current $row.Current -Previous $row.Previous)))
        }
        $small = $smallRows[$grp.Cat]
        if ($small.Count -gt 0) {
            [void]$html.Append(("<tr><td style='border-left:4px solid {0};{1}padding-left:14px;color:#6b7280;'>Sonstige ({2} Services &lt; {3})</td>" -f $grp.Color, $tdCss, $small.Count, (ConvertTo-HtmlText (Format-Money $MinServiceCost))))
            [void]$html.Append(("<td style='{0}color:#6b7280;'>{1}</td><td style='{0}color:#6b7280;'>{2}</td><td style='{0}'>{3}</td></tr>" -f $tdNum, (ConvertTo-HtmlText (Format-Money $small.Current)), (ConvertTo-HtmlText (Format-Money $small.Previous)), (Format-DeltaHtml -Current $small.Current -Previous $small.Previous)))
        }
    }
    [void]$html.Append("</table>")

    # --- Top-Kostentreiber dynamisch ---
    if ($meterRows.Count -gt 0) {
        [void]$html.Append(("<div style='{0}'>Top-Kostentreiber dynamisch (Meter)</div>" -f $h3Css))
        [void]$html.Append("<table role='presentation' width='100%' cellpadding='0' cellspacing='0' border='0' style='border-collapse:collapse;'>")
        [void]$html.Append(("<tr><th align='left' bgcolor='{0}' style='{1}background:{0};'>Meter</th><th align='left' bgcolor='{0}' style='{1}background:{0};'>Service</th><th align='right' bgcolor='{0}' style='{1}background:{0};'>Kosten</th><th align='right' bgcolor='{0}' style='{1}background:{0};'>Anteil dyn.</th></tr>" -f $ColorDynamic, $thCss))
        foreach ($m in $meterRows) {
            $mCost  = Get-RowCost -Row $m
            $mShare = 0.0
            if ($reportDyn -gt 0) { $mShare = ($mCost / $reportDyn) * 100.0 }
            [void]$html.Append(("<tr><td style='{0}'>{1}</td><td style='{0}color:#6b7280;'>{2}</td>" -f $tdCss, (ConvertTo-HtmlText ([string]$m.Meter)), (ConvertTo-HtmlText ([string]$m.ServiceName))))
            [void]$html.Append(("<td style='{0}'>{1}</td><td style='{0}'>{2} %</td></tr>" -f $tdNum, (ConvertTo-HtmlText (Format-Money $mCost)), $mShare.ToString("N1", $Culture)))
        }
        [void]$html.Append("</table>")
    }

    if ($qDaily.Count -eq 0) {
        [void]$html.Append(("<p style='color:{0};font-size:13px;{1}'>Keine Kostendaten gefunden. Rechte der Identity (Cost Management Reader) und Zeitraum pr&uuml;fen.</p>" -f $ColorUp, $fontCss))
    }

    # --- Fussnoten ---
    [void]$html.Append(("<div style='margin-top:22px;padding-top:10px;border-top:1px solid #e5e7eb;font-size:11px;color:#6b7280;line-height:1.5;{0}'>" -f $fontCss))
    [void]$html.Append(("Sockelkosten = {0}; alle anderen Services gelten als dynamisch.<br/>" -f (ConvertTo-HtmlText ($BaseServices -join ", "))))
    [void]$html.Append("Kosten sind bis zur Rechnungsstellung gesch&auml;tzt (ActualCost, Kalendermonat). Cost Management aktualisiert etwa alle 4 Stunden &ndash; der letzte Tag kann unvollst&auml;ndig sein.<br/>")
    if ($reportMode -eq "Monthly") {
        [void]$html.Append("Monatsabschluss vorl&auml;ufig: Nach Periodenende k&ouml;nnen sich Werte noch einige Tage &auml;ndern.<br/>")
    }
    [void]$html.Append(("Automatisch erstellt durch myAzureCost {0} v{1} &middot; Alexander Ortha IT Solutions</div>" -f $customerHtml, $ScriptVersion))
    [void]$html.Append("</td></tr></table></td></tr></table></body></html>")
    $htmlText = $html.ToString()
    Write-Log $SymOk ("HTML-Report erstellt ({0:N0} Zeichen)" -f $htmlText.Length) "Green"

    # --- Betreff + Textfassung ---
    $prelimWord = "vorl" + [char]0x00E4 + "ufig"
    $vsWord     = "gg" + [char]0x00FC + ". Vormonat"
    if ($reportMode -eq "Monthly") {
        $subject = "{7} | Azure Monatsabschluss {0} ({1}): {2} | Sockel {3} | Dynamisch {4} | {6} {5}" -f $reportStart.ToString("MMMM yyyy", $Culture), $prelimWord, (Format-Money $reportTotal), (Format-Money $reportBase), (Format-Money $reportDyn), (Format-DeltaText -Current $reportTotal -Previous $compSameTotal), $vsWord, $CustomerName
    }
    else {
        $subject = "{7} | Azure Kosten KW {0} ({1}): {2} | Sockel {3} | Dynamisch {4} | {6} {5}" -f $isoEnd.Week, $reportStart.ToString("MMM yyyy", $Culture), (Format-Money $reportTotal), (Format-Money $reportBase), (Format-Money $reportDyn), (Format-DeltaText -Current $reportTotal -Previous $compSameTotal), $vsWord, $CustomerName
    }
    $plainText = "{0}`r`nZeitraum: {1} - {2}`r`nSockelkosten: {3}`r`nDynamische Kosten: {4}`r`nGesamt: {5}`r`nVergleich Vormonat: {6} ({7})`r`n" -f $subject, $reportStart.ToString("dd.MM.yyyy"), $reportEnd.ToString("dd.MM.yyyy"), (Format-Money $reportBase), (Format-Money $reportDyn), (Format-Money $reportTotal), (Format-Money $compSameTotal), (Format-DeltaText -Current $reportTotal -Previous $compSameTotal)

    # =====================================================================
    # CSV-ANHANG (optional)
    # =====================================================================
    $csvAttachment = $null
    $csvBytes = $null
    $csvName = $null
    if ($needCsv) {
        Write-Section "CSV-ANHANG"
        $csvSb = New-Object System.Text.StringBuilder
        [void]$csvSb.AppendLine(("Kunde;{0}" -f $CustomerName))
        [void]$csvSb.AppendLine(("Report;{0} {1}" -f $modeText, $reportStart.ToString("MMMM yyyy", $Culture)))
        [void]$csvSb.AppendLine(("Zeitraum;{0} - {1}" -f $reportStart.ToString("dd.MM.yyyy"), $reportEnd.ToString("dd.MM.yyyy")))
        [void]$csvSb.AppendLine(("Erstellt;{0} (myAzureCost v{1})" -f $nowLocal.ToString("dd.MM.yyyy HH:mm"), $ScriptVersion))
        [void]$csvSb.AppendLine("")
        [void]$csvSb.AppendLine("Ressource;ResourceGroup;Service;Kategorie;Kosten;Waehrung")
        foreach ($r in @($qResource | Sort-Object { Get-RowCost -Row $_ } -Descending)) {
            $resId   = [string]$r.ResourceId
            $resName = $resId
            if ($resName.Contains("/")) { $resName = $resName.Split("/")[-1] }
            $catText = "Dynamisch"
            if ((Get-CostCategory -ServiceName ([string]$r.ServiceName)) -eq "Base") { $catText = "Sockel" }
            [void]$csvSb.AppendLine(("{0};{1};{2};{3};{4};{5}" -f $resName, (Get-ResourceGroupName -ResourceId $resId), $r.ServiceName, $catText, (Get-RowCost -Row $r).ToString("N4", $Culture), $Currency))
        }
        $bom      = [byte[]](0xEF, 0xBB, 0xBF)
        $csvBytes = $bom + [System.Text.Encoding]::UTF8.GetBytes($csvSb.ToString())
        $csvName  = "{0}_AzureCost_{1}_{2}.csv" -f $CustomerName, $reportStart.ToString("yyyy-MM"), $modeText
        $csvAttachment = @{
            name            = $csvName
            contentType     = "text/csv"
            contentInBase64 = [Convert]::ToBase64String($csvBytes)
        }
        Write-Log $SymOk ("CSV erstellt: {0} ({1} Zeilen)" -f $csvName, $qResource.Count) "Green"
    }

    # =====================================================================
    # VERSAND / VORSCHAU
    # =====================================================================
    Write-Section "VERSAND"
    if ($PreviewOnly) {
        if ($RunInAutomation) {
            Write-Log $SymWarn "PreviewOnly ist in Azure Automation aktiv - kein Versand, keine Datei" "Yellow"
        }
        else {
            $outDir = $PreviewPath
            if ([string]::IsNullOrWhiteSpace($outDir)) { $outDir = [System.IO.Path]::GetTempPath() }
            $previewHtml = $htmlText
            if ($chartB64) {
                $previewHtml = $previewHtml.Replace(("cid:{0}" -f $cidDaily), ("data:image/png;base64,{0}" -f $chartB64))
            }
            $previewFile = Join-Path $outDir ("{0}_myAzureCost_Preview_{1}_{2}.html" -f $CustomerName, $reportMode, $todayLocal.ToString("yyyyMMdd"))
            [System.IO.File]::WriteAllText($previewFile, $previewHtml, (New-Object System.Text.UTF8Encoding($true)))
            Write-Log $SymOk ("Vorschau gespeichert: {0}" -f $previewFile) "Green"
            if ($csvBytes) {
                $csvFile = Join-Path $outDir $csvName
                [System.IO.File]::WriteAllBytes($csvFile, $csvBytes)
                Write-Log $SymOk ("CSV gespeichert: {0}" -f $csvFile) "Green"
            }
            Write-Log $SymInfo ("Betreff: {0}" -f $subject) "Cyan" 4
        }
    }
    else {
        Write-Log $SymRun "Hole Token fuer Azure Communication Services..." "Cyan"
        $acsToken = Get-AccessToken -Resource "https://communication.azure.com/"
        if ([string]::IsNullOrWhiteSpace($acsToken)) { throw "Leeres ACS-Token erhalten." }

        $allAttachments = @()
        foreach ($a in $inlineAttachments) { $allAttachments += $a }
        if ($csvAttachment) { $allAttachments += $csvAttachment }

        $toList = @()
        foreach ($addr in $recipientList) { $toList += @{ address = $addr } }

        $mailBody = @{
            senderAddress = $SenderAddress
            recipients    = @{ to = $toList }
            content       = @{
                subject   = $subject
                html      = $htmlText
                plainText = $plainText
            }
        }
        if ($allAttachments.Count -gt 0) { $mailBody["attachments"] = $allAttachments }

        # Body explizit als UTF-8-Bytes (Umlaute unter Windows PowerShell 5.1)
        $mailBytes = [System.Text.Encoding]::UTF8.GetBytes(($mailBody | ConvertTo-Json -Depth 10))
        $sendUri   = "{0}/emails:send?api-version={1}" -f $AcsEndpoint.TrimEnd("/"), $AcsApiVersion
        $sendHdr   = @{ "Authorization" = "Bearer {0}" -f $acsToken }
        Write-Log $SymRun ("Versende E-Mail an {0} Empfaenger ({1} Anhaenge)..." -f $toList.Count, $allAttachments.Count) "Cyan"
        try {
            $sendResult = Invoke-RestMethod -Uri $sendUri -Method Post -Headers $sendHdr -Body $mailBytes `
                -ContentType "application/json; charset=utf-8" -UseBasicParsing -TimeoutSec 120 -ErrorAction Stop
        }
        catch {
            $detail = $_.Exception.Message
            if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $detail = $_.ErrorDetails.Message }
            throw ("ACS-Versand fehlgeschlagen: {0}" -f $detail)
        }
        Write-Log $SymOk ("E-Mail in Versandwarteschlange. Operation-Id: {0}, Status: {1}" -f $sendResult.id, $sendResult.status) "Green"
    }

    if ($LockActive -and -not $PreviewOnly) {
        if (Set-RunLock -State "sent" -Key $LockKey) {
            Write-Log $SymOk ("Sperre aktualisiert: sent|{0}" -f $LockKey) "Green"
        }
        else {
            Write-Log $SymWarn "Sperre konnte nicht auf 'sent' gesetzt werden" "Yellow"
        }
    }

    # =====================================================================
    # ZUSAMMENFASSUNG
    # =====================================================================
    Write-Section "ZUSAMMENFASSUNG"
    Write-Log $SymOk ("Modus            : {0}" -f $modeText) "Green"
    Write-Log $SymOk ("Zeitraum         : {0} - {1}" -f $reportStart.ToString("dd.MM.yyyy"), $reportEnd.ToString("dd.MM.yyyy")) "Green"
    Write-Log $SymOk ("Sockel/Dyn/Gesamt: {0} / {1} / {2}" -f (Format-Money $reportBase), (Format-Money $reportDyn), (Format-Money $reportTotal)) "Green"
    Write-Log $SymOk ("Vormonat gl. Tage: {0} ({1})" -f (Format-Money $compSameTotal), (Format-DeltaText -Current $reportTotal -Previous $compSameTotal)) "Green"
    Write-Log $SymOk ("Kunde            : {0}" -f $CustomerName) "Green"
    Write-Log $SymInfo ("Script-Version   : {0}" -f $ScriptVersion) "Cyan"
    Write-Separator
}
catch {
    $fatalError = $_
    Write-Log $SymErr ("Abbruch: {0}" -f $fatalError.Exception.Message) "Red"
    if ($LockActive) {
        if (Set-RunLock -State "failed" -Key $LockKey) {
            Write-Log $SymInfo "Sperre freigegeben (failed) - nachfolgender Lauf darf versenden" "Cyan" 4
        }
    }
    Write-Separator
    throw $fatalError
}
