﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Prueft alle VMs eines Azure Local / Hyper-V Clusters auf die Voraussetzungen fuer
    Virtualization-based Security (VBS) und Memory Integrity (HVCI).
.DESCRIPTION
    Das Script laeuft auf einem Cluster-Knoten (Azure Local / Hyper-V) und prueft fuer jede VM
    die von Microsoft dokumentierten Voraussetzungen fuer VBS/HVCI in Hyper-V-VMs:
      - VM-Generation 2
      - Secure Boot in der VM-Firmware aktiviert
      - Kein VBS-Opt-Out auf dem Host (Set-VMSecurity -VirtualizationBasedSecurityOptOut)
      - Keine virtuellen Fibre-Channel-Adapter
      - Keine Pass-through-Disks (AllowFullSCSICommandSet ist mit HVCI inkompatibel)
      - Gast-OS Windows 10 / Windows Server 2016 oder neuer (ueber Hyper-V KVP-Daten)
    Optional wird per WinRM im Gast der tatsaechliche VBS-Status (Win32_DeviceGuard) abgefragt.
    Ergebnis: Konsolenausgabe pro VM, Zusammenfassung und optionaler CSV-Export.
    Quelle: https://learn.microsoft.com/en-us/windows/security/hardware-security/enable-virtualization-based-protection-of-code-integrity
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-09-24
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Test-VbsReadiness.ps1
#>

# =========================================================================
# KONFIGURATION (alle Parameter im Script, keine Aufruf-Parameter)
# =========================================================================
$ScriptVersion  = "1.0.0"
$PowerShellMode = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = bricht unter 5.1 ab
$ClusterName    = ""            # "" = Cluster des lokalen Knotens; ohne Cluster = nur lokaler Hyper-V Host
$VMNameFilter   = "*"           # z.B. "AVD-*" oder "SRV-*"
$CheckGuestVbs  = $true         # VBS-Status im Gast per WinRM (Win32_DeviceGuard) abfragen
$ExportCsv      = $true
$CsvPath        = Join-Path -Path $env:TEMP -ChildPath ("VbsReadiness_{0}.csv" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
$MinOsVersion   = [Version]"10.0"   # Windows 10 / Windows Server 2016

# =========================================================================
# GRUNDEINSTELLUNGEN
# =========================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =========================================================================
# HILFSFUNKTIONEN AUSGABE
# =========================================================================
function Write-Log {
    param([string]$Symbol, [string]$Message, [string]$Color, [int]$Indent = 0)
    $ts = Get-Date -Format "HH:mm:ss"
    Write-Host ("[{0}] {1}{2}  {3}" -f $ts, (" " * $Indent), $Symbol, $Message) -ForegroundColor $Color
}
function Write-Ok   { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymOk   -Message $Message -Color Green  -Indent $Indent }
function Write-Err  { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymErr  -Message $Message -Color Red    -Indent $Indent }
function Write-Warn { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymWarn -Message $Message -Color Yellow -Indent $Indent }
function Write-Info { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymInfo -Message $Message -Color Cyan   -Indent $Indent }
function Write-Run  { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymRun  -Message $Message -Color Cyan   -Indent $Indent }
function Write-Separator { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section   { param([string]$Title) Write-Host ("[ {0} ]" -f $Title) -ForegroundColor White }

# =========================================================================
# HILFSFUNKTIONEN PRUEFUNG
# =========================================================================
function Get-GuestKvp {
    # Liest OS-Name, OS-Version und FQDN des Gastes ueber Hyper-V KVP (ohne Anmeldung im Gast)
    param([string]$ComputerName, [string]$VMName)
    $result = @{ OSName = ""; OSVersion = ""; FQDN = "" }
    try {
        $filter = "ElementName='{0}'" -f ($VMName -replace "'", "''")
        $cs = Get-CimInstance -ComputerName $ComputerName -Namespace "root\virtualization\v2" -ClassName Msvm_ComputerSystem -Filter $filter -ErrorAction Stop
        if ($cs -ne $null) {
            $kvp = Get-CimAssociatedInstance -InputObject $cs -ComputerName $ComputerName -ResultClassName Msvm_KvpExchangeComponent -ErrorAction Stop
            if ($kvp -ne $null -and $kvp.GuestIntrinsicExchangeItems -ne $null) {
                foreach ($item in $kvp.GuestIntrinsicExchangeItems) {
                    $xml  = [xml]$item
                    $name = ($xml.INSTANCE.PROPERTY | Where-Object { $_.NAME -eq "Name" }).VALUE
                    $data = ($xml.INSTANCE.PROPERTY | Where-Object { $_.NAME -eq "Data" }).VALUE
                    switch ($name) {
                        "OSName"                   { $result.OSName    = [string]$data }
                        "OSVersion"                { $result.OSVersion = [string]$data }
                        "FullyQualifiedDomainName" { $result.FQDN      = [string]$data }
                    }
                }
            }
        }
    }
    catch { }
    return $result
}

function Get-GuestVbsState {
    # Fragt Win32_DeviceGuard im Gast per WinRM ab (Kerberos, aktueller Benutzer)
    param([string]$Target)
    try {
        $dg = Invoke-Command -ComputerName $Target -ErrorAction Stop -ScriptBlock {
            Get-CimInstance -ClassName Win32_DeviceGuard -Namespace "root\Microsoft\Windows\DeviceGuard"
        }
        if ($dg -eq $null) { return $null }
        $running    = @($dg.SecurityServicesRunning)
        $configured = @($dg.SecurityServicesConfigured)
        return @{
            VbsStatus       = [int]$dg.VirtualizationBasedSecurityStatus
            HvciRunning     = ($running -contains 2)
            HvciConfigured  = ($configured -contains 2)
            CredGuardRunning = ($running -contains 1)
            SecureBootAvail = (@($dg.AvailableSecurityProperties) -contains 2)
        }
    }
    catch { return $null }
}

function Get-VbsStatusText {
    param([int]$Code)
    switch ($Code) {
        0 { return "0 - nicht aktiviert" }
        1 { return "1 - aktiviert, laeuft NICHT" }
        2 { return "2 - aktiviert und laeuft" }
        default { return "unbekannt" }
    }
}

# =========================================================================
# PRE-CHECK
# =========================================================================
Write-Separator
Write-Section "PRE-CHECK"

$psVer = $PSVersionTable.PSVersion
Write-Info ("PowerShell-Version: {0} ({1})" -f $psVer, $PSVersionTable.PSEdition)
if ($PowerShellMode -eq "Seven" -and $psVer.Major -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - Abbruch"
    exit 1
}
if ($psVer -ge [Version]"7.3") {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PSNativeCommandUseErrorActionPreference = false gesetzt (PS 7.3+)"
}
Write-Ok ("PowerShell-Modus: {0}" -f $PowerShellMode)

$identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Ok ("Ausfuehrung als Administrator: {0}" -f $identity.Name)
}
else {
    Write-Err "Script muss als Administrator ausgefuehrt werden - Abbruch"
    exit 1
}

Write-Info "Azure CLI wird nicht benoetigt (Pruefung erfolgt lokal ueber Hyper-V / CIM auf dem Cluster-Knoten)"

Write-Info "Pruefe Hyper-V PowerShell-Modul..."
if (Get-Module -ListAvailable -Name Hyper-V) {
    Import-Module Hyper-V -ErrorAction SilentlyContinue
    Write-Ok "Hyper-V Modul geladen"
}
else {
    Write-Err "Hyper-V PowerShell-Modul nicht gefunden - Script auf einem Hyper-V / Azure Local Knoten ausfuehren"
    exit 1
}

Write-Info "Pruefe FailoverClusters PowerShell-Modul..."
$clusterModule = $false
if (Get-Module -ListAvailable -Name FailoverClusters) {
    Import-Module FailoverClusters -ErrorAction SilentlyContinue
    $clusterModule = $true
    Write-Ok "FailoverClusters Modul geladen"
}
else {
    Write-Warn "FailoverClusters Modul nicht gefunden - es wird nur der lokale Host geprueft"
}

Write-Separator
Write-Section "SCRIPT"
Write-Info ("Test-VbsReadiness.ps1 - Version {0}" -f $ScriptVersion)
Write-Info ("VM-Filter: {0} | Gast-Abfrage per WinRM: {1} | CSV-Export: {2}" -f $VMNameFilter, $CheckGuestVbs, $ExportCsv)
Write-Separator

# =========================================================================
# CLUSTER-KNOTEN ERMITTELN
# =========================================================================
Write-Section "CLUSTER / HOSTS"
$Nodes = @()
if ($clusterModule) {
    try {
        if ($ClusterName -ne "") { $cluster = Get-Cluster -Name $ClusterName -ErrorAction Stop }
        else                     { $cluster = Get-Cluster -ErrorAction Stop }
        $Nodes = @(Get-ClusterNode -Cluster $cluster.Name -ErrorAction Stop | Where-Object { $_.State -eq "Up" } | ForEach-Object { $_.Name })
        Write-Ok ("Cluster gefunden: {0} ({1} Knoten online)" -f $cluster.Name, $Nodes.Count)
        foreach ($n in $Nodes) { Write-Info ("Knoten: {0}" -f $n) 4 }
    }
    catch {
        Write-Warn ("Kein Cluster erreichbar: {0}" -f $_.Exception.Message)
    }
}
if ($Nodes.Count -eq 0) {
    $Nodes = @($env:COMPUTERNAME)
    Write-Warn ("Fallback: nur lokaler Hyper-V Host {0} wird geprueft" -f $env:COMPUTERNAME)
}

# =========================================================================
# VMs EINLESEN
# =========================================================================
$AllVms = @()
foreach ($node in $Nodes) {
    Write-Run ("Lese VMs von {0}..." -f $node)
    try {
        $vms = @(Get-VM -ComputerName $node -ErrorAction Stop | Where-Object { $_.Name -like $VMNameFilter })
        $AllVms += $vms
        Write-Ok ("{0} VM(s) auf {1}" -f $vms.Count, $node) 4
    }
    catch {
        Write-Err ("VMs von {0} nicht lesbar: {1}" -f $node, $_.Exception.Message) 4
    }
}
if ($AllVms.Count -eq 0) {
    Write-Warn "Keine VMs gefunden - nichts zu pruefen"
    exit 0
}
Write-Info ("Gesamt: {0} VM(s) werden geprueft" -f $AllVms.Count)
Write-Separator

# =========================================================================
# PRUEFUNG PRO VM
# =========================================================================
Write-Section "VBS-VORAUSSETZUNGEN PRO VM"
$Results = @()

foreach ($vm in $AllVms) {
    $issues   = New-Object System.Collections.Generic.List[string]
    $warnings = New-Object System.Collections.Generic.List[string]
    $vmHost   = $vm.ComputerName
    Write-Run ("Pruefe VM: {0} (Host: {1}, Status: {2})" -f $vm.Name, $vmHost, $vm.State)

    # --- 1. Generation ---
    $gen = $vm.Generation
    if ($gen -eq 2) { Write-Ok "Generation 2" 4 }
    else {
        Write-Err "Generation 1 - VBS in Hyper-V erfordert Generation 2" 4
        $issues.Add("Generation 1")
    }

    # --- 2. Secure Boot (Firmware) ---
    $secureBoot = "n/a"
    $sbTemplate = "n/a"
    if ($gen -eq 2) {
        try {
            $fw = Get-VMFirmware -VM $vm -ErrorAction Stop
            $secureBoot = [string]$fw.SecureBoot
            $sbTemplate = [string]$fw.SecureBootTemplate
            if ($fw.SecureBoot -eq "On") { Write-Ok ("Secure Boot: On (Template: {0})" -f $sbTemplate) 4 }
            else {
                Write-Err "Secure Boot: Off - Platform Security Level 'Secure Boot' der GPO greift nicht" 4
                $issues.Add("Secure Boot Off")
            }
        }
        catch {
            Write-Warn ("VM-Firmware nicht lesbar: {0}" -f $_.Exception.Message) 4
            $warnings.Add("Firmware nicht lesbar")
        }
    }

    # --- 3. VBS-Opt-Out / vTPM auf dem Host ---
    $optOut = "n/a"
    $tpm    = "n/a"
    try {
        $sec    = Get-VMSecurity -VM $vm -ErrorAction Stop
        $optOut = [string]$sec.VirtualizationBasedSecurityOptOut
        $tpm    = [string]$sec.TpmEnabled
        if ($sec.VirtualizationBasedSecurityOptOut) {
            Write-Err "VBS-Opt-Out auf dem Host aktiv (Set-VMSecurity -VirtualizationBasedSecurityOptOut)" 4
            $issues.Add("VBS Opt-Out")
        }
        else { Write-Ok "Kein VBS-Opt-Out auf dem Host" 4 }
        Write-Info ("vTPM aktiviert: {0}" -f $tpm) 4
    }
    catch {
        Write-Warn ("VM-Security nicht lesbar: {0}" -f $_.Exception.Message) 4
        $warnings.Add("VM-Security nicht lesbar")
    }

    # --- Sicherheitstyp (Trusted launch = GuestStateIsolationType, nur informativ) ---
    $isolation = "n/a"
    $prop = $vm.PSObject.Properties["GuestStateIsolationType"]
    if ($prop -ne $null -and $prop.Value -ne $null) { $isolation = [string]$prop.Value }
    Write-Info ("Sicherheitstyp (GuestStateIsolationType): {0}" -f $isolation) 4

    # --- 4. Virtuelle Fibre-Channel-Adapter ---
    $fcCount = 0
    try { $fcCount = @(Get-VMFibreChannelHba -VM $vm -ErrorAction Stop).Count } catch { }
    if ($fcCount -gt 0) {
        Write-Err ("{0} virtuelle(r) Fibre-Channel-Adapter - nicht kompatibel mit Memory Integrity" -f $fcCount) 4
        $issues.Add("Fibre-Channel-Adapter")
    }
    else { Write-Ok "Keine virtuellen Fibre-Channel-Adapter" 4 }

    # --- 5. Pass-through-Disks ---
    $ptCount  = 0
    $fullScsi = $false
    try {
        $hdds = @(Get-VMHardDiskDrive -VM $vm -ErrorAction Stop)
        foreach ($hdd in $hdds) {
            if ($hdd.DiskNumber -ne $null) {
                $ptCount++
                $p = $hdd.PSObject.Properties["AllowFullSCSICommandSet"]
                if ($p -ne $null -and $p.Value -eq $true) { $fullScsi = $true }
            }
        }
    }
    catch { }
    if ($fullScsi) {
        Write-Err "Pass-through-Disk mit AllowFullSCSICommandSet - nicht kompatibel mit Memory Integrity" 4
        $issues.Add("Pass-through AllowFullSCSICommandSet")
    }
    elseif ($ptCount -gt 0) {
        Write-Warn ("{0} Pass-through-Disk(s) - AllowFullSCSICommandSet manuell pruefen" -f $ptCount) 4
        $warnings.Add("Pass-through-Disk vorhanden")
    }
    else { Write-Ok "Keine Pass-through-Disks" 4 }

    # --- 6. Gast-OS (KVP) ---
    $kvp  = Get-GuestKvp -ComputerName $vmHost -VMName $vm.Name
    $osOk = "unbekannt"
    if ($kvp.OSName -ne "") {
        if ($kvp.OSName -match "Windows") {
            $ver = $null
            try { $ver = [Version]$kvp.OSVersion } catch { }
            if ($ver -ne $null -and $ver -ge $MinOsVersion) {
                Write-Ok ("Gast-OS: {0} ({1})" -f $kvp.OSName, $kvp.OSVersion) 4
                $osOk = "OK"
            }
            else {
                Write-Err ("Gast-OS zu alt: {0} ({1}) - mindestens Windows 10 / Server 2016" -f $kvp.OSName, $kvp.OSVersion) 4
                $issues.Add("Gast-OS zu alt")
                $osOk = "FAIL"
            }
        }
        else {
            Write-Info ("Kein Windows-Gast ({0}) - VBS nicht relevant, VM wird uebersprungen" -f $kvp.OSName) 4
            $osOk = "SKIP"
        }
    }
    else {
        Write-Warn "Gast-OS unbekannt (VM aus oder keine KVP-Daten / Integration Services)" 4
        $warnings.Add("Gast-OS unbekannt")
    }

    # --- 7. Optional: VBS-Status im Gast ---
    $vbsStatus = "n/a"
    $hvciRun   = "n/a"
    $cgRun     = "n/a"
    if ($CheckGuestVbs -and $osOk -ne "SKIP" -and $vm.State -eq "Running") {
        $target = $kvp.FQDN
        if ($target -eq "") { $target = $vm.Name }
        $dg = Get-GuestVbsState -Target $target
        if ($dg -ne $null) {
            $vbsStatus = Get-VbsStatusText -Code $dg.VbsStatus
            $hvciRun   = [string]$dg.HvciRunning
            $cgRun     = [string]$dg.CredGuardRunning
            if ($dg.VbsStatus -eq 2) { Write-Ok ("VBS im Gast: {0}" -f $vbsStatus) 4 }
            elseif ($dg.VbsStatus -eq 1) {
                Write-Warn ("VBS im Gast: {0} - Voraussetzung fehlt (meist Secure Boot oder 'Secure Boot with DMA' gewaehlt)" -f $vbsStatus) 4
            }
            else { Write-Info ("VBS im Gast: {0} (GPO noch nicht angewendet)" -f $vbsStatus) 4 }
            Write-Info ("Memory Integrity laeuft: {0} | Credential Guard laeuft: {1}" -f $hvciRun, $cgRun) 4
        }
        else {
            Write-Warn ("VBS-Status im Gast nicht abfragbar (WinRM zu {0})" -f $target) 4
        }
    }

    # --- Ergebnis ---
    if     ($osOk -eq "SKIP")       { $verdict = "SKIP" }
    elseif ($issues.Count -gt 0)    { $verdict = "FAIL" }
    elseif ($warnings.Count -gt 0)  { $verdict = "WARN" }
    else                            { $verdict = "OK" }

    switch ($verdict) {
        "OK"   { Write-Ok   "Ergebnis: OK - alle VBS-Voraussetzungen erfuellt" 4 }
        "WARN" { Write-Warn ("Ergebnis: WARN - {0}" -f ($warnings -join "; ")) 4 }
        "FAIL" { Write-Err  ("Ergebnis: FAIL - {0}" -f ($issues -join "; ")) 4 }
        "SKIP" { Write-Info "Ergebnis: SKIP - kein Windows-Gast" 4 }
    }

    $Results += [PSCustomObject]@{
        VM              = $vm.Name
        Host            = $vmHost
        Status          = [string]$vm.State
        Generation      = $gen
        SecureBoot      = $secureBoot
        SecureBootTmpl  = $sbTemplate
        VbsOptOut       = $optOut
        vTPM            = $tpm
        Sicherheitstyp  = $isolation
        FcAdapter       = $fcCount
        PassThrough     = $ptCount
        GastOS          = $kvp.OSName
        GastOSVersion   = $kvp.OSVersion
        VbsStatusGast   = $vbsStatus
        HvciLaeuftGast  = $hvciRun
        CredGuardGast   = $cgRun
        Ergebnis        = $verdict
        Probleme        = ($issues -join "; ")
        Hinweise        = ($warnings -join "; ")
    }
}

# =========================================================================
# ZUSAMMENFASSUNG
# =========================================================================
Write-Separator
Write-Section "ZUSAMMENFASSUNG"

$table = $Results | Sort-Object Ergebnis, VM |
    Format-Table VM, Host, Generation, SecureBoot, VbsOptOut, Sicherheitstyp, GastOS, VbsStatusGast, Ergebnis -AutoSize |
    Out-String -Width 220
Write-Host $table -ForegroundColor White

$cntOk   = @($Results | Where-Object { $_.Ergebnis -eq "OK"   }).Count
$cntWarn = @($Results | Where-Object { $_.Ergebnis -eq "WARN" }).Count
$cntFail = @($Results | Where-Object { $_.Ergebnis -eq "FAIL" }).Count
$cntSkip = @($Results | Where-Object { $_.Ergebnis -eq "SKIP" }).Count
Write-Info ("VMs gesamt: {0} | OK: {1} | WARN: {2} | FAIL: {3} | SKIP (kein Windows): {4}" -f $Results.Count, $cntOk, $cntWarn, $cntFail, $cntSkip)

if ($CheckGuestVbs) {
    $cntVbsRunning = @($Results | Where-Object { $_.VbsStatusGast -like "2 -*" }).Count
    Write-Info ("VBS im Gast bereits aktiv und laufend: {0} von {1} Windows-VM(s)" -f $cntVbsRunning, ($Results.Count - $cntSkip))
}

$exitCode = 0
if ($cntFail -eq 0 -and $cntWarn -eq 0) {
    Write-Ok ("Alle {0} Windows-VM(s) erfuellen die VBS-Voraussetzungen" -f $cntOk)
}
elseif ($cntFail -eq 0) {
    Write-Warn ("Keine Verstoesse, aber {0} VM(s) mit Hinweisen (bitte pruefen):" -f $cntWarn)
    foreach ($r in ($Results | Where-Object { $_.Ergebnis -eq "WARN" })) { Write-Warn ("{0}: {1}" -f $r.VM, $r.Hinweise) 4 }
}
else {
    $exitCode = 1
    Write-Err ("{0} VM(s) erfuellen die VBS-Voraussetzungen NICHT:" -f $cntFail)
    foreach ($r in ($Results | Where-Object { $_.Ergebnis -eq "FAIL" })) { Write-Err ("{0}: {1}" -f $r.VM, $r.Probleme) 4 }
    if ($cntWarn -gt 0) {
        Write-Warn ("Zusaetzlich {0} VM(s) mit Hinweisen:" -f $cntWarn)
        foreach ($r in ($Results | Where-Object { $_.Ergebnis -eq "WARN" })) { Write-Warn ("{0}: {1}" -f $r.VM, $r.Hinweise) 4 }
    }
}

# =========================================================================
# CSV-EXPORT
# =========================================================================
if ($ExportCsv) {
    try {
        $Results | Export-Csv -Path $CsvPath -NoTypeInformation -Encoding UTF8 -Delimiter ";" -ErrorAction Stop
        Write-Ok ("CSV exportiert: {0}" -f $CsvPath)
    }
    catch {
        Write-Err ("CSV-Export fehlgeschlagen: {0}" -f $_.Exception.Message)
    }
}

Write-Separator
exit $exitCode
