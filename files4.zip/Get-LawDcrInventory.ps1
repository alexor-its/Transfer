﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Inventar eines Log Analytics Workspace: Ingestion pro Tabelle, Retention und alle
    zugehoerigen Data Collection Rules (Typ, Sampling, zugeordnete Ressourcen).
.DESCRIPTION
    Das Script liest per Azure CLI den Ist-Zustand eines Log Analytics Workspace aus,
    um Kostentreiber vor einer Umstellung (z. B. VM Insights auf OpenTelemetry,
    Change Tracking einschraenken) sichtbar zu machen:

      1. Workspace-Basisdaten (SKU, Default-Retention, Daily Cap)
      2. Abrechenbare Ingestion pro Tabelle der letzten N Tage (Usage-Tabelle)
         inkl. Tabellenplan und Retention je Tabelle
      3. Alle DCRs der Subscription mit Klassifizierung:
           MSVMI-*     VM Insights (log-basiert -> InsightsMetrics, kostenpflichtig)
           MSVMOtel-*  VM Insights (OpenTelemetry -> Azure Monitor Workspace)
           ct-dcr-*    Change Tracking & Inventory (-> ConfigurationData/-Change)
         mit Ziel-Workspaces, Performance-Counter-Sampling, Extensions und
         zugeordneten Ressourcen (VMs / Arc-Server)
      4. Zusammenfassung mit Hinweisen

    Das Script fuehrt ausschliesslich Lesezugriffe aus (kein Write/Delete).
    Alle Parameter werden im Script-Block PARAMETER hinterlegt.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-09-24
    Version     : 1.0.1
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Benoetigt die Azure CLI Extension "monitor-control-service" (wird im
    Pre-Check automatisch installiert, falls nicht vorhanden).
.EXAMPLE
    .\Get-LawDcrInventory.ps1
#>

# =============================================================================
# [ PARAMETER ] - hier anpassen, keine Uebergabe per Aufruf
# =============================================================================
$ScriptVersion        = "1.0.1"
$PowerShellMode       = "Compat"          # "Compat" (5.1 + 7.x) oder "Seven" (nur 7.x)

$SubscriptionId       = ""                # leer = aktuell angemeldete Subscription
$ResourceGroupName    = "rg-monitoring"   # Resource Group des Log Analytics Workspace
$WorkspaceName        = "law-prod"        # Name des Log Analytics Workspace

$UsageDays            = 30                # Zeitraum fuer die Usage-Auswertung in Tagen
$MaxResourcesPerDcr   = 15                # max. angezeigte zugeordnete Ressourcen je DCR
$ShowForeignDcrs      = $true             # DCRs anzeigen, die NICHT auf diesen Workspace zeigen
                                          # (z. B. MSVMOtel-* -> Azure Monitor Workspace)
$MinAzCliVersion      = "2.70.0"          # Mindestversion Azure CLI (Hinweis bei Unterschreitung)

# =============================================================================
# [ GRUNDEINSTELLUNGEN ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Write-Separator {
    Write-Host ("=" * 60) -ForegroundColor White
}

function Write-Section {
    param([string]$Title)
    Write-Separator
    Write-Host ("[ {0} ]" -f $Title) -ForegroundColor White
}

function Write-Log {
    param(
        [ValidateSet("Ok", "Err", "Warn", "Info", "Run")]
        [string]$Level,
        [string]$Message
    )
    $Stamp = Get-Date -Format "HH:mm:ss"
    switch ($Level) {
        "Ok"   { Write-Host ("[{0}] {1}  {2}" -f $Stamp, $SymOk,   $Message) -ForegroundColor Green }
        "Err"  { Write-Host ("[{0}] {1}  {2}" -f $Stamp, $SymErr,  $Message) -ForegroundColor Red }
        "Warn" { Write-Host ("[{0}] {1}  {2}" -f $Stamp, $SymWarn, $Message) -ForegroundColor Yellow }
        "Info" { Write-Host ("[{0}] {1}  {2}" -f $Stamp, $SymInfo, $Message) -ForegroundColor Cyan }
        "Run"  { Write-Host ("[{0}] {1}  {2}" -f $Stamp, $SymRun,  $Message) -ForegroundColor Cyan }
    }
}

function Write-Detail {
    # Unterinformation mit 4 Leerzeichen Einrueckung
    param(
        [string]$Message,
        [string]$Color = "Cyan",
        [int]$Level = 1
    )
    $Pad = " " * (4 * $Level)
    Write-Host ($Pad + $Message) -ForegroundColor $Color
}

function Invoke-AzQuiet {
    # Ruft az mit Argument-Array auf, unterdrueckt stderr, gibt stdout als String zurueck.
    # Exit-Code anschliessend ueber Assert-AzSuccess pruefen.
    param([string[]]$Arguments)
    $Output = & az @Arguments 2>$null
    if ($null -eq $Output) { return "" }
    return ($Output -join "`n")
}

function Assert-AzSuccess {
    # Prueft $LASTEXITCODE des letzten externen Aufrufs.
    param(
        [string]$Step,
        [switch]$Fatal
    )
    if ($LASTEXITCODE -ne 0) {
        Write-Log -Level "Err" -Message ("Azure CLI Fehler bei: {0} (ExitCode {1})" -f $Step, $LASTEXITCODE)
        if ($Fatal) {
            Write-Separator
            exit 1
        }
        return $false
    }
    return $true
}

function ConvertFrom-AzJson {
    # Sicheres Parsen der az-Ausgabe; leere Ausgabe -> $null
    param([string]$Json)
    if ([string]::IsNullOrWhiteSpace($Json)) { return $null }
    try {
        return ($Json | ConvertFrom-Json)
    }
    catch {
        Write-Log -Level "Warn" -Message ("JSON konnte nicht geparst werden: {0}" -f $_.Exception.Message)
        return $null
    }
}

function Get-DcrCategory {
    # Klassifiziert eine DCR anhand Name und Inhalt
    param($Dcr)
    $DcrName = [string]$Dcr.name
    if ($DcrName -like "MSVMI-*")    { return "VM Insights (log-basiert / InsightsMetrics)" }
    if ($DcrName -like "MSVMOtel-*") { return "VM Insights (OpenTelemetry / AMW)" }
    if ($DcrName -like "ct-dcr*")    { return "Change Tracking & Inventory" }

    # OTel-Erkennung: Name enthaelt "otel" oder Ziel ist ausschliesslich ein Azure Monitor Workspace
    $HasLaDest  = $false
    $HasAmwDest = $false
    if ($null -ne $Dcr.destinations) {
        if ($null -ne $Dcr.destinations.logAnalytics -and @($Dcr.destinations.logAnalytics).Count -gt 0) { $HasLaDest = $true }
        if ($null -ne $Dcr.destinations.monitoringAccounts -and @($Dcr.destinations.monitoringAccounts).Count -gt 0) { $HasAmwDest = $true }
    }
    if ($DcrName -like "*otel*")            { return "VM Insights (OpenTelemetry / AMW, Custom-Name)" }
    if ($HasAmwDest -and -not $HasLaDest)   { return "Metriken -> Azure Monitor Workspace (OTel/Prometheus)" }

    $HasCtExtension = $false
    $HasVmiPerf     = $false
    if ($null -ne $Dcr.dataSources) {
        if ($null -ne $Dcr.dataSources.extensions) {
            foreach ($Ext in @($Dcr.dataSources.extensions)) {
                if ([string]$Ext.extensionName -like "ChangeTracking*") { $HasCtExtension = $true }
            }
        }
        if ($null -ne $Dcr.dataSources.performanceCounters) {
            foreach ($Pc in @($Dcr.dataSources.performanceCounters)) {
                foreach ($Spec in @($Pc.counterSpecifiers)) {
                    if ([string]$Spec -like "*VmInsights*") { $HasVmiPerf = $true }
                }
            }
        }
    }
    if ($HasCtExtension) { return "Change Tracking & Inventory (Custom-Name)" }
    if ($HasVmiPerf)     { return "VM Insights (log-basiert, Custom-Name)" }
    return "Sonstige / Custom"
}

function Get-ResourceShortName {
    # Extrahiert "Typ/Name" aus einer Ressourcen-ID
    param([string]$ResourceId)
    $Parts = $ResourceId -split "/"
    if ($Parts.Count -lt 2) { return $ResourceId }
    $LastName = $Parts[$Parts.Count - 1]
    $LastType = $Parts[$Parts.Count - 2]
    return ("{0}/{1}" -f $LastType, $LastName)
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Section -Title "PRE-CHECK"

# --- PowerShell-Version ------------------------------------------------------
$PsVer = $PSVersionTable.PSVersion
Write-Log -Level "Info" -Message ("PowerShell-Version: {0} (Modus: {1})" -f $PsVer.ToString(), $PowerShellMode)
if ($PowerShellMode -eq "Seven" -and $PsVer.Major -lt 7) {
    Write-Log -Level "Err" -Message "Modus 'Seven' erfordert PowerShell 7.x - Abbruch."
    Write-Separator
    exit 1
}
if ($PsVer.Major -gt 7 -or ($PsVer.Major -eq 7 -and $PsVer.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Log -Level "Ok" -Message "PSNativeCommandUseErrorActionPreference = false gesetzt (PS 7.3+)"
}
else {
    Write-Log -Level "Ok" -Message "PowerShell-Version kompatibel"
}

# --- Azure CLI vorhanden -----------------------------------------------------
Write-Log -Level "Run" -Message "Pruefe Azure CLI..."
$AzCmd = Get-Command -Name "az" -ErrorAction SilentlyContinue
if ($null -eq $AzCmd) {
    Write-Log -Level "Err" -Message "Azure CLI (az) nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    Write-Separator
    exit 1
}
$AzVersionJson = Invoke-AzQuiet -Arguments @("version", "-o", "json")
$AzVersionOk   = Assert-AzSuccess -Step "az version" -Fatal
$AzVersionObj  = ConvertFrom-AzJson -Json $AzVersionJson
$AzCliVersion  = ""
if ($null -ne $AzVersionObj) { $AzCliVersion = [string]$AzVersionObj.'azure-cli' }
if ([string]::IsNullOrWhiteSpace($AzCliVersion)) {
    Write-Log -Level "Warn" -Message "Azure CLI Version konnte nicht ermittelt werden"
}
else {
    Write-Log -Level "Ok" -Message ("Azure CLI gefunden: {0}" -f $AzCliVersion)
    # --- Azure CLI aktuell? --------------------------------------------------
    $CurrentVer = $null
    $MinVer     = $null
    try { $CurrentVer = [System.Version]$AzCliVersion } catch { $CurrentVer = $null }
    try { $MinVer     = [System.Version]$MinAzCliVersion } catch { $MinVer = $null }
    if ($null -ne $CurrentVer -and $null -ne $MinVer) {
        if ($CurrentVer -lt $MinVer) {
            Write-Log -Level "Warn" -Message ("Azure CLI aelter als Mindestversion {0} - Update empfohlen: az upgrade" -f $MinAzCliVersion)
        }
        else {
            Write-Log -Level "Ok" -Message ("Azure CLI erfuellt Mindestversion {0}" -f $MinAzCliVersion)
        }
    }
    Write-Log -Level "Info" -Message "Hinweis: Auf neuere Versionen pruefen mit 'az upgrade' (benoetigt Internetzugang)"
}

# --- Azure CLI Extension monitor-control-service ----------------------------
Write-Log -Level "Run" -Message "Pruefe Extension 'monitor-control-service'..."
$ExtJson = Invoke-AzQuiet -Arguments @("extension", "show", "--name", "monitor-control-service", "-o", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Log -Level "Warn" -Message "Extension nicht vorhanden - installiere..."
    $null = Invoke-AzQuiet -Arguments @("extension", "add", "--name", "monitor-control-service", "--yes")
    $ExtOk = Assert-AzSuccess -Step "az extension add monitor-control-service" -Fatal
    Write-Log -Level "Ok" -Message "Extension 'monitor-control-service' installiert"
}
else {
    $ExtObj = ConvertFrom-AzJson -Json $ExtJson
    $ExtVer = ""
    if ($null -ne $ExtObj) { $ExtVer = [string]$ExtObj.version }
    Write-Log -Level "Ok" -Message ("Extension 'monitor-control-service' vorhanden: {0}" -f $ExtVer)
}

# --- Azure Login -------------------------------------------------------------
Write-Log -Level "Run" -Message "Pruefe Azure Login..."
$AccountJson = Invoke-AzQuiet -Arguments @("account", "show", "-o", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Log -Level "Warn" -Message "Kein Login vorhanden - starte 'az login'..."
    $null = Invoke-AzQuiet -Arguments @("login", "-o", "none")
    $LoginOk = Assert-AzSuccess -Step "az login" -Fatal
    $AccountJson = Invoke-AzQuiet -Arguments @("account", "show", "-o", "json")
    $AccountOk   = Assert-AzSuccess -Step "az account show" -Fatal
}
$AccountObj = ConvertFrom-AzJson -Json $AccountJson
if ($null -eq $AccountObj) {
    Write-Log -Level "Err" -Message "Account-Informationen konnten nicht gelesen werden - Abbruch."
    Write-Separator
    exit 1
}
Write-Log -Level "Ok" -Message ("Login vorhanden: {0}" -f [string]$AccountObj.user.name)

# --- Subscription ------------------------------------------------------------
if (-not [string]::IsNullOrWhiteSpace($SubscriptionId)) {
    $null = Invoke-AzQuiet -Arguments @("account", "set", "--subscription", $SubscriptionId)
    $SubOk = Assert-AzSuccess -Step "az account set" -Fatal
    $AccountJson = Invoke-AzQuiet -Arguments @("account", "show", "-o", "json")
    $AccountOk   = Assert-AzSuccess -Step "az account show" -Fatal
    $AccountObj  = ConvertFrom-AzJson -Json $AccountJson
}
$ActiveSubId   = [string]$AccountObj.id
$ActiveSubName = [string]$AccountObj.name
Write-Log -Level "Ok" -Message ("Subscription: {0} ({1})" -f $ActiveSubName, $ActiveSubId)

# =============================================================================
# [ SCRIPT-INFO ]
# =============================================================================
Write-Section -Title "SCRIPT-INFO"
Write-Log -Level "Info" -Message ("Script-Version : {0}" -f $ScriptVersion)
Write-Log -Level "Info" -Message ("Workspace      : {0} / {1}" -f $ResourceGroupName, $WorkspaceName)
Write-Log -Level "Info" -Message ("Usage-Zeitraum : letzte {0} Tage" -f $UsageDays)

# =============================================================================
# [ WORKSPACE ]
# =============================================================================
Write-Section -Title "WORKSPACE"
Write-Log -Level "Run" -Message "Lese Workspace-Eigenschaften..."
$WsJson = Invoke-AzQuiet -Arguments @(
    "monitor", "log-analytics", "workspace", "show",
    "--resource-group", $ResourceGroupName,
    "--workspace-name", $WorkspaceName,
    "-o", "json"
)
$WsOk = Assert-AzSuccess -Step "az monitor log-analytics workspace show" -Fatal
$Ws   = ConvertFrom-AzJson -Json $WsJson
if ($null -eq $Ws) {
    Write-Log -Level "Err" -Message "Workspace konnte nicht gelesen werden - Abbruch."
    Write-Separator
    exit 1
}
$WsResourceId = [string]$Ws.id
$WsCustomerId = [string]$Ws.customerId
$WsSku        = ""
if ($null -ne $Ws.sku) { $WsSku = [string]$Ws.sku.name }
$WsRetention  = [string]$Ws.retentionInDays
$WsDailyCap   = "-1"
if ($null -ne $Ws.workspaceCapping) { $WsDailyCap = [string]$Ws.workspaceCapping.dailyQuotaGb }

Write-Log -Level "Ok" -Message ("Workspace gefunden: {0}" -f [string]$Ws.name)
Write-Detail -Message ("Resource-ID     : {0}" -f $WsResourceId)
Write-Detail -Message ("Customer-ID     : {0}" -f $WsCustomerId)
Write-Detail -Message ("Region          : {0}" -f [string]$Ws.location)
Write-Detail -Message ("SKU / Tier      : {0}" -f $WsSku)
Write-Detail -Message ("Default-Retention (Analytics-Tabellen): {0} Tage" -f $WsRetention)
if ($WsDailyCap -eq "-1" -or [string]::IsNullOrWhiteSpace($WsDailyCap)) {
    Write-Detail -Message "Daily Cap       : nicht gesetzt" -Color "Yellow"
}
else {
    Write-Detail -Message ("Daily Cap       : {0} GB/Tag" -f $WsDailyCap)
}

# =============================================================================
# [ USAGE + TABELLEN ]
# =============================================================================
Write-Section -Title "USAGE PRO TABELLE (letzte $UsageDays Tage, nur abrechenbar)"

# Tabellen-Metadaten (Plan, Retention) einlesen
Write-Log -Level "Run" -Message "Lese Tabellen-Konfiguration (Plan / Retention)..."
$TablesJson = Invoke-AzQuiet -Arguments @(
    "monitor", "log-analytics", "workspace", "table", "list",
    "--resource-group", $ResourceGroupName,
    "--workspace-name", $WorkspaceName,
    "-o", "json"
)
$TablesOk  = Assert-AzSuccess -Step "az monitor log-analytics workspace table list"
$TableMap  = @{}
if ($TablesOk) {
    $TablesObj = ConvertFrom-AzJson -Json $TablesJson
    foreach ($Tbl in @($TablesObj)) {
        if ($null -ne $Tbl -and -not [string]::IsNullOrWhiteSpace([string]$Tbl.name)) {
            $TableMap[[string]$Tbl.name] = $Tbl
        }
    }
    Write-Log -Level "Ok" -Message ("{0} Tabellen im Workspace" -f $TableMap.Count)
}

# Usage-Abfrage
Write-Log -Level "Run" -Message "Fuehre Usage-Abfrage aus..."
$Kql = "Usage | where TimeGenerated > ago(" + $UsageDays + "d) and IsBillable == true " +
       "| summarize GB = round(sum(Quantity) / 1024, 3) by DataType | order by GB desc"
$Timespan  = "P" + $UsageDays + "D"
$UsageJson = Invoke-AzQuiet -Arguments @(
    "monitor", "log-analytics", "query",
    "--workspace", $WsCustomerId,
    "--analytics-query", $Kql,
    "--timespan", $Timespan,
    "-o", "json"
)
$UsageOk  = Assert-AzSuccess -Step "az monitor log-analytics query (Usage)"
$UsageRows = @()
$TotalGb   = 0.0
$InsightsMetricsGb = 0.0
$CtGb      = 0.0
if ($UsageOk) {
    $UsageObj = ConvertFrom-AzJson -Json $UsageJson
    foreach ($Row in @($UsageObj)) {
        if ($null -eq $Row) { continue }
        $Gb = 0.0
        try { $Gb = [double]$Row.GB } catch { $Gb = 0.0 }
        $UsageRows += [PSCustomObject]@{ DataType = [string]$Row.DataType; GB = $Gb }
        $TotalGb += $Gb
        if ([string]$Row.DataType -eq "InsightsMetrics") { $InsightsMetricsGb += $Gb }
        if ([string]$Row.DataType -eq "ConfigurationData" -or [string]$Row.DataType -eq "ConfigurationChange") { $CtGb += $Gb }
    }
}

if ($UsageRows.Count -eq 0) {
    Write-Log -Level "Warn" -Message "Keine abrechenbaren Usage-Daten im Zeitraum gefunden"
}
else {
    Write-Log -Level "Ok" -Message ("Gesamt abrechenbar: {0:N3} GB in {1} Tagen (ca. {2:N3} GB/Tag)" -f $TotalGb, $UsageDays, ($TotalGb / $UsageDays))
    Write-Host ""
    Write-Detail -Message ("{0,-32} {1,12} {2,8}  {3,-10} {4,-10} {5,-10}" -f "Tabelle", "GB", "Anteil", "Plan", "Analytics", "Total") -Color "White"
    Write-Detail -Message ("{0,-32} {1,12} {2,8}  {3,-10} {4,-10} {5,-10}" -f "-------", "--", "------", "----", "---------", "-----") -Color "White"
    foreach ($Row in $UsageRows) {
        $Pct = 0.0
        if ($TotalGb -gt 0) { $Pct = ($Row.GB / $TotalGb) * 100 }
        $Plan = "n/a"; $RetA = "n/a"; $RetT = "n/a"
        if ($TableMap.ContainsKey($Row.DataType)) {
            $Meta = $TableMap[$Row.DataType]
            if ($null -ne $Meta.plan)                 { $Plan = [string]$Meta.plan }
            if ($null -ne $Meta.retentionInDays)      { $RetA = [string]$Meta.retentionInDays }
            if ($null -ne $Meta.totalRetentionInDays) { $RetT = [string]$Meta.totalRetentionInDays }
        }
        $RowColor = "Cyan"
        if ($Pct -ge 50) { $RowColor = "Yellow" }
        Write-Detail -Message ("{0,-32} {1,12:N3} {2,7:N1}%  {3,-10} {4,-10} {5,-10}" -f $Row.DataType, $Row.GB, $Pct, $Plan, $RetA, $RetT) -Color $RowColor
    }
    Write-Host ""
    Write-Log -Level "Info" -Message "Analytics/Total = Retention in Tagen. 31 Tage Analytics-Retention sind im Ingestion-Preis enthalten."
}

# =============================================================================
# [ DATA COLLECTION RULES ]
# =============================================================================
Write-Section -Title "DATA COLLECTION RULES"
Write-Log -Level "Run" -Message "Lese alle DCRs der Subscription..."
$DcrJson = Invoke-AzQuiet -Arguments @("monitor", "data-collection", "rule", "list", "-o", "json")
$DcrOk   = Assert-AzSuccess -Step "az monitor data-collection rule list"
$DcrList = @()
if ($DcrOk) {
    $DcrObj  = ConvertFrom-AzJson -Json $DcrJson
    $DcrList = @($DcrObj | Where-Object { $null -ne $_ })
}
Write-Log -Level "Ok" -Message ("{0} DCRs in der Subscription gefunden" -f $DcrList.Count)

$CountVmiLog   = 0
$CountVmiOtel  = 0
$CountCt       = 0
$CountShown    = 0
$VmiLogResourceCount = 0

foreach ($Dcr in $DcrList) {
    $DcrName = [string]$Dcr.name
    $DcrRg   = [string]$Dcr.resourceGroup
    $DcrId   = [string]$Dcr.id
    $Cat     = Get-DcrCategory -Dcr $Dcr

    # Ziel-Workspaces ermitteln
    $LaTargets  = @()
    $AmwTargets = @()
    $HitsThisWs = $false
    if ($null -ne $Dcr.destinations) {
        if ($null -ne $Dcr.destinations.logAnalytics) {
            foreach ($Dest in @($Dcr.destinations.logAnalytics)) {
                $DestId = [string]$Dest.workspaceResourceId
                $LaTargets += $DestId
                if ($DestId -eq $WsResourceId) { $HitsThisWs = $true }
            }
        }
        if ($null -ne $Dcr.destinations.monitoringAccounts) {
            foreach ($Dest in @($Dcr.destinations.monitoringAccounts)) {
                $AmwTargets += [string]$Dest.accountResourceId
            }
        }
    }

    if (-not $HitsThisWs -and -not $ShowForeignDcrs) { continue }
    $CountShown++

    if ($Cat -like "VM Insights (log-basiert*") { $CountVmiLog++ }
    if ($Cat -like "VM Insights (OpenTelemetry*") { $CountVmiOtel++ }
    if ($Cat -like "Change Tracking*") { $CountCt++ }

    Write-Host ""
    $HeadColor = "White"
    if (-not $HitsThisWs) { $HeadColor = "Cyan" }
    Write-Host ("  DCR: {0}" -f $DcrName) -ForegroundColor $HeadColor
    Write-Detail -Message ("Kategorie      : {0}" -f $Cat)
    Write-Detail -Message ("Resource Group : {0}  |  Region: {1}  |  Kind: {2}" -f $DcrRg, [string]$Dcr.location, [string]$Dcr.kind)
    if ($HitsThisWs) {
        Write-Detail -Message ("Ziel           : DIESER Log Analytics Workspace") -Color "Green"
    }
    foreach ($T in $LaTargets) {
        if ($T -ne $WsResourceId) {
            Write-Detail -Message ("Ziel (LA)      : {0}" -f (Get-ResourceShortName -ResourceId $T)) -Color "Yellow"
        }
    }
    foreach ($T in $AmwTargets) {
        Write-Detail -Message ("Ziel (AMW)     : {0}" -f (Get-ResourceShortName -ResourceId $T))
    }

    # Datenquellen
    if ($null -ne $Dcr.dataSources) {
        $Ds = $Dcr.dataSources
        if ($null -ne $Ds.performanceCounters) {
            foreach ($Pc in @($Ds.performanceCounters)) {
                $Streams = ""
                if ($null -ne $Pc.streams) { $Streams = (@($Pc.streams) -join ", ") }
                $SpecCount = 0
                if ($null -ne $Pc.counterSpecifiers) { $SpecCount = @($Pc.counterSpecifiers).Count }
                Write-Detail -Message ("PerfCounter    : '{0}' | Sampling: {1}s | Streams: {2} | {3} Counter-Specifier" -f [string]$Pc.name, [string]$Pc.samplingFrequencyInSeconds, $Streams, $SpecCount)
                foreach ($Spec in @($Pc.counterSpecifiers)) {
                    if ([string]$Spec -like "*VmInsights*") {
                        Write-Detail -Message ("-> {0} (Alles-oder-Nichts-Aggregat, nicht einzeln abwaehlbar)" -f [string]$Spec) -Level 2 -Color "Yellow"
                    }
                }
            }
        }
        if ($null -ne $Ds.extensions) {
            foreach ($Ext in @($Ds.extensions)) {
                $Streams = ""
                if ($null -ne $Ext.streams) { $Streams = (@($Ext.streams) -join ", ") }
                Write-Detail -Message ("Extension      : {0} | Streams: {1}" -f [string]$Ext.extensionName, $Streams)
                if ([string]$Ext.extensionName -like "ChangeTracking*" -and $null -ne $Ext.extensionSettings) {
                    $Settings = $Ext.extensionSettings
                    foreach ($Prop in $Settings.PSObject.Properties) {
                        $Val = $Prop.Value
                        $ValText = ""
                        if ($null -eq $Val) {
                            $ValText = "null"
                        }
                        elseif ($Val -is [System.Array]) {
                            $ValText = ("[{0} Eintraege]" -f @($Val).Count)
                        }
                        elseif ($Val -is [PSCustomObject]) {
                            $Inner = @()
                            foreach ($Ip in $Val.PSObject.Properties) {
                                $IvText = [string]$Ip.Value
                                if ($Ip.Value -is [System.Array]) { $IvText = ("[{0} Eintraege]" -f @($Ip.Value).Count) }
                                $Inner += ("{0}={1}" -f $Ip.Name, $IvText)
                            }
                            $ValText = ($Inner -join "; ")
                        }
                        else {
                            $ValText = [string]$Val
                        }
                        Write-Detail -Message ("-> {0}: {1}" -f $Prop.Name, $ValText) -Level 2
                    }
                }
            }
        }
        if ($null -ne $Ds.windowsEventLogs) {
            foreach ($Wel in @($Ds.windowsEventLogs)) {
                $Cnt = 0
                if ($null -ne $Wel.xPathQueries) { $Cnt = @($Wel.xPathQueries).Count }
                Write-Detail -Message ("WindowsEvents  : '{0}' | {1} XPath-Queries" -f [string]$Wel.name, $Cnt)
            }
        }
        if ($null -ne $Ds.syslog) {
            foreach ($Sl in @($Ds.syslog)) {
                $Fac = ""
                if ($null -ne $Sl.facilityNames) { $Fac = (@($Sl.facilityNames) -join ", ") }
                Write-Detail -Message ("Syslog         : '{0}' | Facilities: {1}" -f [string]$Sl.name, $Fac)
            }
        }
        if ($null -ne $Ds.prometheusForwarder) {
            Write-Detail -Message ("Prometheus     : {0} Forwarder-Datenquelle(n)" -f @($Ds.prometheusForwarder).Count)
        }
    }

    # Transformationen in dataFlows
    if ($null -ne $Dcr.dataFlows) {
        foreach ($Flow in @($Dcr.dataFlows)) {
            if (-not [string]::IsNullOrWhiteSpace([string]$Flow.transformKql)) {
                $Kq = [string]$Flow.transformKql
                if ($Kq.Length -gt 80) { $Kq = $Kq.Substring(0, 77) + "..." }
                Write-Detail -Message ("Transformation : {0}" -f $Kq) -Color "Green"
            }
        }
    }

    # Zugeordnete Ressourcen
    $AssocJson = Invoke-AzQuiet -Arguments @(
        "monitor", "data-collection", "rule", "association", "list",
        "--rule-name", $DcrName,
        "--resource-group", $DcrRg,
        "-o", "json"
    )
    $AssocOk   = Assert-AzSuccess -Step ("association list fuer {0}" -f $DcrName)
    $Resources = @()
    if ($AssocOk) {
        $AssocObj = ConvertFrom-AzJson -Json $AssocJson
        foreach ($A in @($AssocObj)) {
            if ($null -eq $A) { continue }
            $AssocId = [string]$A.id
            $ResId   = $AssocId -replace "/providers/Microsoft\.Insights/dataCollectionRuleAssociations/.*$", ""
            $Resources += $ResId
        }
    }
    $ResCount = $Resources.Count
    if ($HitsThisWs -and $Cat -like "VM Insights (log-basiert*") { $VmiLogResourceCount += $ResCount }
    $ResColor = "Cyan"
    if ($ResCount -eq 0) { $ResColor = "Yellow" }
    Write-Detail -Message ("Zuordnungen    : {0} Ressource(n)" -f $ResCount) -Color $ResColor
    $Shown = 0
    foreach ($R in $Resources) {
        if ($Shown -ge $MaxResourcesPerDcr) {
            Write-Detail -Message ("... und {0} weitere" -f ($ResCount - $Shown)) -Level 2
            break
        }
        Write-Detail -Message ("- {0}" -f (Get-ResourceShortName -ResourceId $R)) -Level 2
        $Shown++
    }
}

if ($CountShown -eq 0) {
    Write-Log -Level "Warn" -Message "Keine passenden DCRs angezeigt (ggf. ShowForeignDcrs = true setzen)"
}

# =============================================================================
# [ ZUSAMMENFASSUNG ]
# =============================================================================
Write-Section -Title "ZUSAMMENFASSUNG"
Write-Log -Level "Info" -Message ("DCRs angezeigt: {0} | VM Insights log-basiert: {1} | VM Insights OTel: {2} | Change Tracking: {3}" -f $CountShown, $CountVmiLog, $CountVmiOtel, $CountCt)

if ($TotalGb -gt 0) {
    $ImPct = ($InsightsMetricsGb / $TotalGb) * 100
    $CtPct = ($CtGb / $TotalGb) * 100
    Write-Log -Level "Info" -Message ("InsightsMetrics: {0:N3} GB ({1:N1} %) | ConfigurationData/-Change: {2:N3} GB ({3:N1} %)" -f $InsightsMetricsGb, $ImPct, $CtGb, $CtPct)

    if ($ImPct -ge 30) {
        Write-Log -Level "Warn" -Message "InsightsMetrics ist ein Haupt-Kostentreiber (log-basierte VM Insights)."
        Write-Detail -Message "Empfehlung: VM Insights auf OpenTelemetry-Metriken (Azure Monitor Workspace) umstellen," -Color "Yellow"
        Write-Detail -Message "Standard-Counter dort kostenfrei; danach log-basierte DCR (MSVMI-*) von den VMs trennen." -Color "Yellow"
        Write-Detail -Message "Vorher pruefen: VMSS, Multi-VM-Workbooks, KQL-Korrelation, Alerts auf InsightsMetrics, Private Link." -Color "Yellow"
    }
    if ($CtPct -ge 5) {
        Write-Log -Level "Warn" -Message "Change Tracking & Inventory erzeugt nennenswertes Volumen."
        Write-Detail -Message "Empfehlung: In der ct-dcr Umfang (Software/Registry/Dienste/Dateien) und Intervalle reduzieren" -Color "Yellow"
        Write-Detail -Message "oder DCR-Zuordnung entfernen, falls das Feature nicht aktiv genutzt wird." -Color "Yellow"
    }
}
if ($CountVmiLog -gt 0 -and $CountVmiOtel -eq 0) {
    Write-Log -Level "Info" -Message ("{0} Ressource(n) haengen an log-basierten VM-Insights-DCRs, noch keine OTel-DCR vorhanden." -f $VmiLogResourceCount)
}
if ($WsDailyCap -eq "-1" -or [string]::IsNullOrWhiteSpace($WsDailyCap)) {
    Write-Log -Level "Info" -Message "Kein Daily Cap gesetzt. Laut Microsoft nur als Notbremse gegen Spitzen sinnvoll, nicht zur Kostensenkung."
}
Write-Log -Level "Ok" -Message "Inventar abgeschlossen (nur Lesezugriffe, keine Aenderungen vorgenommen)."
Write-Separator
