﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Collects Azure Monitor Agent (AMA) diagnostics on an Arc-enabled Windows session host.
.DESCRIPTION
    Runs LOCALLY on the session host as Administrator. It does not talk to Azure Resource
    Manager, so there is no Azure CLI pre-check. It collects everything Microsoft lists for
    AMA on Arc-enabled servers:
      - Arc agent state (azcmagent show / azcmagent check)
      - service and process state (himds, GCArcService, ExtensionService, AzureMonitorAgent,
        MonAgent* processes)
      - DCR configuration received by the agent (mcsconfig.latest.xml, configchunks)
      - core agent logs (C:\Resources\Directory\AMADataStore\Configuration)
      - extension logs (C:\ProgramData\GuestConfig\extension_logs\...AzureMonitorWindowsAgent)
      - MaMetricsExtensionEtw.tsf converted with table2csv.exe, Level 2 errors counted
      - AgentTroubleshooter.exe --ama output
      - TCP connectivity to the AMA control and ingestion endpoints, proxy settings
    All files are copied to an output folder and zipped. A summary with the most relevant
    error lines is printed to the console.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-27
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Get-AmaArcDiagnostics.ps1
#>

# =============================================================================
# [ PARAMETERS ] - adjust here, not via command line
# =============================================================================
$ScriptVersion          = "1.0.0"
$PowerShellMode         = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = 7.x only

$OutputRoot             = "C:\Temp\AMA-Diag"
$WorkspaceId            = "80f29cb3-df78-4327-9914-b7e247104474"   # law-LDK-AVDSessionHosts customerId
$Region                 = "westeurope"
$LogTailLines           = 400            # lines kept per log for the console scan
$RunTroubleshooter      = $true          # AgentTroubleshooter.exe --ama (takes 1-3 minutes)
$RunAzcmagentCheck      = $true          # azcmagent check (network tests, ~1 minute)

$AmaDataStore           = "C:\Resources\Directory\AMADataStore"
$ExtensionLogDir        = "C:\ProgramData\GuestConfig\extension_logs\Microsoft.Azure.Monitor.AzureMonitorWindowsAgent"
$PluginRoot             = "C:\Packages\Plugins\Microsoft.Azure.Monitor.AzureMonitorWindowsAgent"
$AzcmagentExe           = "C:\Program Files\AzureConnectedMachineAgent\azcmagent.exe"

# =============================================================================
# [ RUNTIME SETUP ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

function Write-Line { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$Title) Write-Host "[ $Title ]" -ForegroundColor White }
function Write-Log {
    param([string]$Symbol, [string]$Message, [string]$Color = "Cyan")
    $stamp = Get-Date -Format "HH:mm:ss"
    Write-Host ("[{0}] {1}  {2}" -f $stamp, $Symbol, $Message) -ForegroundColor $Color
}
function Write-Sub { param([string]$Message, [string]$Color = "Cyan") Write-Host ("    " + $Message) -ForegroundColor $Color }

$ErrorPattern = "error|fail|denied|unauthori|forbidden|403|401|certificate|proxy|timed out|unable|exception|cannot"
$script:Findings = New-Object System.Collections.Generic.List[string]
function Add-Finding { param([string]$Text) $script:Findings.Add($Text) }

function Copy-IfExists {
    param([string]$Path, [string]$Target, [string]$Filter = "*")
    if (Test-Path $Path) {
        New-Item -ItemType Directory -Path $Target -Force | Out-Null
        Copy-Item -Path (Join-Path $Path $Filter) -Destination $Target -Recurse -Force -ErrorAction SilentlyContinue
        return $true
    }
    return $false
}
function Show-LogScan {
    # Prints error-like lines from the tail of a log file and records a finding
    param([string]$File, [string]$Label)
    if (-not (Test-Path $File)) { return }
    $tail = Get-Content -Path $File -Tail $LogTailLines -ErrorAction SilentlyContinue
    $hits = @($tail | Where-Object { $_ -match $ErrorPattern })
    if ($hits.Count -eq 0) {
        Write-Sub ("{0}: no error-like lines in last {1} lines" -f $Label, $LogTailLines) "Green"
    } else {
        Write-Sub ("{0}: {1} error-like lines in last {2} lines, last 5:" -f $Label, $hits.Count, $LogTailLines) "Yellow"
        foreach ($h in ($hits | Select-Object -Last 5)) {
            $t = $h
            if ($t.Length -gt 180) { $t = $t.Substring(0, 180) + "..." }
            Write-Sub ("  " + $t) "Yellow"
        }
        Add-Finding ("{0}: {1} error-like lines (see {2})" -f $Label, $hits.Count, (Split-Path $File -Leaf))
    }
}
function Test-TcpEndpoint {
    param([string]$HostName, [int]$Port = 443, [int]$TimeoutMs = 5000)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($HostName, $Port, $null, $null)
        $ok = $async.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
        if ($ok -and $client.Connected) { $client.EndConnect($async); return $true }
        return $false
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Line
Write-Section "PRE-CHECK"

$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Log $SymInfo ("PowerShell {0}.{1}, Mode: {2}" -f $psMajor, $psMinor, $PowerShellMode)
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Log $SymErr "Script requires PowerShell 7.x (Mode Seven)" "Red"
    Write-Line
    exit 1
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Log $SymInfo "PSNativeCommandUseErrorActionPreference set to false"
}

$identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log $SymErr "Run this script as Administrator (log folders are protected)" "Red"
    Write-Line
    exit 1
}
Write-Log $SymOk "Running as Administrator on $env:COMPUTERNAME" "Green"

if (Test-Path $AzcmagentExe) {
    Write-Log $SymOk "Arc agent found: $AzcmagentExe" "Green"
} else {
    Write-Log $SymErr "azcmagent.exe not found, this is not an Arc-enabled machine?" "Red"
    Add-Finding "azcmagent.exe missing"
}
if (Test-Path $AmaDataStore) {
    Write-Log $SymOk "AMA data store found: $AmaDataStore" "Green"
} else {
    Write-Log $SymErr "AMA data store NOT found: $AmaDataStore (agent never started?)" "Red"
    Add-Finding "AMADataStore missing"
}
$osLang = (Get-WinSystemLocale).Name
Write-Log $SymInfo ("OS: {0}, system locale {1}" -f (Get-CimInstance Win32_OperatingSystem).Caption, $osLang)

Write-Line
Write-Host "Script version: $ScriptVersion" -ForegroundColor White
Write-Line

$stampDir = Get-Date -Format "yyyyMMdd-HHmmss"
$OutDir = Join-Path $OutputRoot ("ama-diag-" + $env:COMPUTERNAME + "-" + $stampDir)
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
Write-Log $SymInfo "Output folder: $OutDir"

# =============================================================================
# [ SERVICES AND PROCESSES ]
# =============================================================================
Write-Section "SERVICES AND PROCESSES"
$serviceNames = @("himds", "GCArcService", "ExtensionService", "AzureMonitorAgent")
$svcReport = New-Object System.Collections.Generic.List[string]
foreach ($sn in $serviceNames) {
    $svc = Get-Service -Name $sn -ErrorAction SilentlyContinue
    if ($null -eq $svc) {
        Write-Sub ("{0,-20} NOT INSTALLED" -f $sn) "Red"
        Add-Finding "Service $sn not installed"
        $svcReport.Add("$sn`tNOT INSTALLED")
    } elseif ($svc.Status -ne "Running") {
        Write-Sub ("{0,-20} {1} (StartType {2})" -f $sn, $svc.Status, $svc.StartType) "Red"
        Add-Finding "Service $sn is $($svc.Status)"
        $svcReport.Add("$sn`t$($svc.Status)`t$($svc.StartType)")
    } else {
        Write-Sub ("{0,-20} Running" -f $sn) "Green"
        $svcReport.Add("$sn`tRunning")
    }
}
$procNames = @("MonAgentLauncher", "MonAgentManager", "MonAgentHost", "MonAgentCore", "MetricsExtension.Native", "AMAExtHealthMonitor")
foreach ($pn in $procNames) {
    $procs = @(Get-Process -Name $pn -ErrorAction SilentlyContinue)
    if ($procs.Count -eq 0) {
        Write-Sub ("{0,-26} not running" -f $pn) "Yellow"
        $svcReport.Add("$pn`tnot running")
    } else {
        $started = $procs[0].StartTime
        Write-Sub ("{0,-26} running since {1}" -f $pn, $started) "Green"
        $svcReport.Add("$pn`trunning since $started")
    }
}
if (@(Get-Process -Name "MonAgentCore" -ErrorAction SilentlyContinue).Count -eq 0) {
    Add-Finding "MonAgentCore.exe is not running (no heartbeat possible)"
}
$svcReport | Out-File -FilePath (Join-Path $OutDir "services-processes.txt") -Encoding UTF8
Write-Line

# =============================================================================
# [ ARC AGENT ]
# =============================================================================
Write-Section "ARC AGENT"
if (Test-Path $AzcmagentExe) {
    Write-Log $SymRun "azcmagent show..."
    $show = & $AzcmagentExe show 2>&1
    $show | Out-File -FilePath (Join-Path $OutDir "azcmagent-show.txt") -Encoding UTF8
    foreach ($l in @($show | Where-Object { $_ -match "Agent Status|Agent Version|Resource Name|Location|himds|gcarcservice|extensionservice|Proxy|Tenant ID|Subscription ID|Resource Group" })) {
        Write-Sub ([string]$l).Trim()
    }
    if (@($show | Where-Object { $_ -match "Agent Status\s*:\s*Connected" }).Count -eq 0) {
        Add-Finding "azcmagent show: agent status is not Connected"
    }
    Write-Log $SymRun "azcmagent config (proxy)..."
    $proxyCfg = & $AzcmagentExe config get proxy.url 2>&1
    $proxyCfg | Out-File -FilePath (Join-Path $OutDir "azcmagent-proxy.txt") -Encoding UTF8
    Write-Sub ("proxy.url: " + (([string]($proxyCfg -join " ")).Trim()))
    if ($RunAzcmagentCheck) {
        Write-Log $SymRun "azcmagent check (network, ~1 min)..."
        $check = & $AzcmagentExe check 2>&1
        $check | Out-File -FilePath (Join-Path $OutDir "azcmagent-check.txt") -Encoding UTF8
        $bad = @($check | Where-Object { $_ -match "fail|error|unreachable|blocked" })
        if ($bad.Count -eq 0) {
            Write-Sub "azcmagent check: no failures reported" "Green"
        } else {
            Write-Sub ("azcmagent check: {0} failing lines" -f $bad.Count) "Red"
            foreach ($b in ($bad | Select-Object -First 8)) { Write-Sub ("  " + ([string]$b).Trim()) "Red" }
            Add-Finding ("azcmagent check reported {0} failures" -f $bad.Count)
        }
    }
}
Write-Line

# =============================================================================
# [ DCR CONFIGURATION ON THE HOST ]
# =============================================================================
Write-Section "DCR CONFIGURATION ON THE HOST"
$mcsConfig = Join-Path $AmaDataStore "mcs\mcsconfig.latest.xml"
if (Test-Path $mcsConfig) {
    $mcsInfo = Get-Item $mcsConfig
    Write-Log $SymOk ("mcsconfig.latest.xml present, last write {0}, {1} bytes" -f $mcsInfo.LastWriteTime, $mcsInfo.Length) "Green"
    $ageH = [math]::Round(((Get-Date) - $mcsInfo.LastWriteTime).TotalHours, 1)
    if ($ageH -gt 24) {
        Write-Sub ("WARNING: config is {0} hours old, agent may not refresh from AMCS" -f $ageH) "Yellow"
        Add-Finding ("mcsconfig.latest.xml is {0} hours old" -f $ageH)
    }
    $xmlText = Get-Content -Path $mcsConfig -Raw -ErrorAction SilentlyContinue
    $dcrIds = @([regex]::Matches($xmlText, "dcr-[0-9a-f]{32}") | ForEach-Object { $_.Value } | Sort-Object -Unique)
    Write-Sub ("DCR immutable ids referenced: {0}" -f $dcrIds.Count)
    foreach ($d in $dcrIds) { Write-Sub ("  " + $d) }
    $wsRefs = @([regex]::Matches($xmlText, "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.ods\.opinsights\.azure\.com") | ForEach-Object { $_.Value } | Sort-Object -Unique)
    Write-Sub ("Workspace ingestion endpoints referenced: {0}" -f $wsRefs.Count)
    foreach ($w in $wsRefs) { Write-Sub ("  " + $w) }
    if ($wsRefs.Count -gt 0 -and -not ($wsRefs -join " ").Contains($WorkspaceId)) {
        Write-Sub ("WARNING: expected workspace {0} is NOT among the endpoints" -f $WorkspaceId) "Red"
        Add-Finding "Configured DCRs do not point to the expected workspace"
    }
    $perfHit = @([regex]::Matches($xmlText, "Processor Information|Terminal Services")).Count
    Write-Sub ("Perf counter references (Processor Information / Terminal Services): {0}" -f $perfHit)
} else {
    Write-Log $SymErr "mcsconfig.latest.xml NOT present: the agent has not received any DCR configuration from AMCS" "Red"
    Add-Finding "mcsconfig.latest.xml missing (no DCR configuration received)"
}
$chunkDir = Join-Path $AmaDataStore "mcs\configchunks"
if (Test-Path $chunkDir) {
    $chunks = @(Get-ChildItem -Path $chunkDir -File -ErrorAction SilentlyContinue)
    Write-Log $SymInfo ("configchunks: {0} files" -f $chunks.Count)
    foreach ($c in ($chunks | Sort-Object LastWriteTime -Descending | Select-Object -First 10)) {
        Write-Sub ("{0,-60} {1}" -f $c.Name, $c.LastWriteTime)
    }
} else {
    Write-Log $SymWarn "configchunks folder not present" "Yellow"
}
Copy-IfExists -Path (Join-Path $AmaDataStore "mcs") -Target (Join-Path $OutDir "mcs") | Out-Null
Write-Line

# =============================================================================
# [ CORE AGENT LOGS ]
# =============================================================================
Write-Section "CORE AGENT LOGS"
$coreLogDir = Join-Path $AmaDataStore "Configuration"
if (Copy-IfExists -Path $coreLogDir -Target (Join-Path $OutDir "core-logs") -Filter "*.log") {
    $coreLogs = @(Get-ChildItem -Path $coreLogDir -Filter "*.log" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    Write-Log $SymInfo ("{0} log files copied, scanning newest per component" -f $coreLogs.Count)
    $seen = @{}
    foreach ($lf in $coreLogs) {
        $comp = ($lf.BaseName -split "\.")[0]
        if ($seen.ContainsKey($comp)) { continue }
        $seen[$comp] = $true
        Show-LogScan -File $lf.FullName -Label ("{0} ({1})" -f $comp, $lf.LastWriteTime.ToString("yyyy-MM-dd HH:mm"))
    }
} else {
    Write-Log $SymErr "Core log folder not present: $coreLogDir" "Red"
    Add-Finding "Core agent log folder missing"
}
Write-Line

# =============================================================================
# [ EXTENSION LOGS ]
# =============================================================================
Write-Section "EXTENSION LOGS"
if (Copy-IfExists -Path $ExtensionLogDir -Target (Join-Path $OutDir "extension-logs")) {
    $extLogs = @(Get-ChildItem -Path $ExtensionLogDir -File -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    Write-Log $SymInfo ("{0} files copied" -f $extLogs.Count)
    foreach ($lf in ($extLogs | Select-Object -First 3)) {
        Show-LogScan -File $lf.FullName -Label $lf.Name
    }
} else {
    Write-Log $SymErr "Extension log folder not present: $ExtensionLogDir" "Red"
    Add-Finding "Extension log folder missing"
}
Write-Line

# =============================================================================
# [ ETW TABLE AND TROUBLESHOOTER ]
# =============================================================================
Write-Section "ETW TABLE AND TROUBLESHOOTER"
$pluginVer = $null
if (Test-Path $PluginRoot) {
    $pluginVer = Get-ChildItem -Path $PluginRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match "^\d+(\.\d+)+$" } |
        Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1
}
if ($null -eq $pluginVer) {
    Write-Log $SymErr "Plugin folder not found under $PluginRoot (extension binaries missing?)" "Red"
    Add-Finding "AMA plugin folder missing"
} else {
    Write-Log $SymOk ("Plugin version folder: {0}" -f $pluginVer.Name) "Green"
    $table2csv = Join-Path $pluginVer.FullName "Monitoring\Agent\table2csv.exe"
    $etwTsf = Join-Path $AmaDataStore "Tables\MaMetricsExtensionEtw.tsf"
    if ((Test-Path $table2csv) -and (Test-Path $etwTsf)) {
        Write-Log $SymRun "table2csv MaMetricsExtensionEtw.tsf..."
        Push-Location (Join-Path $OutDir ".")
        & $table2csv $etwTsf 2>&1 | Out-Null
        Pop-Location
        $csv = Join-Path (Split-Path $etwTsf -Parent) "MaMetricsExtensionEtw.csv"
        if (Test-Path $csv) {
            Copy-Item $csv -Destination $OutDir -Force
            $lvl2 = @(Get-Content $csv -ErrorAction SilentlyContinue | Where-Object { $_ -match "^\s*2\s*," -or $_ -match ",\s*2\s*,.*(error|fail)" -or $_ -match "Level.?2" })
            if ($lvl2.Count -eq 0) {
                Write-Sub "MaMetricsExtensionEtw.csv: no obvious Level 2 lines (review file manually)" "Green"
            } else {
                Write-Sub ("MaMetricsExtensionEtw.csv: {0} Level 2 lines, last 5:" -f $lvl2.Count) "Yellow"
                foreach ($l in ($lvl2 | Select-Object -Last 5)) {
                    $t = $l
                    if ($t.Length -gt 180) { $t = $t.Substring(0, 180) + "..." }
                    Write-Sub ("  " + $t) "Yellow"
                }
                Add-Finding ("MaMetricsExtensionEtw: {0} Level 2 lines" -f $lvl2.Count)
            }
        } else {
            Write-Sub "table2csv produced no CSV" "Yellow"
        }
    } else {
        Write-Log $SymWarn "table2csv.exe or MaMetricsExtensionEtw.tsf not found, skipping" "Yellow"
    }
    if ($RunTroubleshooter) {
        $ts = Join-Path $pluginVer.FullName "Troubleshooter\AgentTroubleshooter.exe"
        if (Test-Path $ts) {
            Write-Log $SymRun "AgentTroubleshooter.exe --ama (1-3 min)..."
            $before = Get-Date
            Push-Location (Split-Path $ts -Parent)
            & $ts --ama 2>&1 | Out-File -FilePath (Join-Path $OutDir "troubleshooter-console.txt") -Encoding UTF8
            Pop-Location
            $tsOut = @(Get-ChildItem -Path (Split-Path $ts -Parent) -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $before.AddSeconds(-5) -and $_.Extension -in @(".log", ".txt", ".zip", ".json") })
            foreach ($f in $tsOut) { Copy-Item $f.FullName -Destination $OutDir -Force }
            Write-Log $SymOk ("Troubleshooter finished, {0} output files copied" -f $tsOut.Count) "Green"
            Show-LogScan -File (Join-Path $OutDir "troubleshooter-console.txt") -Label "Troubleshooter console"
        } else {
            Write-Log $SymWarn "AgentTroubleshooter.exe not found in plugin folder" "Yellow"
        }
    }
}
Write-Line

# =============================================================================
# [ CONNECTIVITY ]
# =============================================================================
Write-Section "CONNECTIVITY"
$endpoints = @(
    "global.handler.control.monitor.azure.com",
    ("{0}.handler.control.monitor.azure.com" -f $Region),
    ("{0}.ods.opinsights.azure.com" -f $WorkspaceId),
    ("{0}.oms.opinsights.azure.com" -f $WorkspaceId),
    "management.azure.com",
    "login.microsoftonline.com"
)
$connReport = New-Object System.Collections.Generic.List[string]
foreach ($ep in $endpoints) {
    $dns = $null
    try { $dns = [System.Net.Dns]::GetHostAddresses($ep) | Select-Object -First 1 } catch { $dns = $null }
    if ($null -eq $dns) {
        Write-Sub ("{0,-62} DNS FAILED" -f $ep) "Red"
        Add-Finding "DNS resolution failed for $ep"
        $connReport.Add("$ep`tDNS FAILED")
        continue
    }
    $ok = Test-TcpEndpoint -HostName $ep -Port 443
    if ($ok) {
        Write-Sub ("{0,-62} TCP 443 ok ({1})" -f $ep, $dns.IPAddressToString) "Green"
        $connReport.Add("$ep`tTCP ok`t$($dns.IPAddressToString)")
    } else {
        Write-Sub ("{0,-62} TCP 443 BLOCKED ({1})" -f $ep, $dns.IPAddressToString) "Red"
        Add-Finding "TCP 443 blocked to $ep"
        $connReport.Add("$ep`tTCP BLOCKED`t$($dns.IPAddressToString)")
    }
}
$winhttp = & netsh winhttp show proxy 2>&1
$connReport.Add("")
$connReport.Add("netsh winhttp show proxy:")
foreach ($l in $winhttp) { $connReport.Add([string]$l) }
$connReport.Add("")
$connReport.Add("HTTPS_PROXY env (machine): " + [System.Environment]::GetEnvironmentVariable("HTTPS_PROXY", "Machine"))
$connReport | Out-File -FilePath (Join-Path $OutDir "connectivity.txt") -Encoding UTF8
Write-Sub ("winhttp proxy: " + (([string]($winhttp -join " ")) -replace "\s+", " ").Trim())
Write-Line

# =============================================================================
# [ SUMMARY ]
# =============================================================================
Write-Section "SUMMARY"
if ($script:Findings.Count -eq 0) {
    Write-Log $SymOk "No findings. If the host still sends nothing, review the copied logs manually." "Green"
} else {
    Write-Log $SymWarn ("{0} findings:" -f $script:Findings.Count) "Yellow"
    foreach ($f in $script:Findings) { Write-Sub ("- " + $f) "Yellow" }
}
$script:Findings | Out-File -FilePath (Join-Path $OutDir "findings.txt") -Encoding UTF8

$zipPath = $OutDir + ".zip"
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($OutDir, $zipPath)
    Write-Log $SymOk "Archive: $zipPath" "Green"
} catch {
    Write-Log $SymWarn ("Could not create zip: {0}. Folder: {1}" -f $_.Exception.Message, $OutDir) "Yellow"
}
Write-Line
Write-Log $SymOk "Done" "Green"
Write-Line
