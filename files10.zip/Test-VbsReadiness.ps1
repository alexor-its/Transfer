﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Prueft alle VMs aller Azure Local Cluster auf die Voraussetzungen fuer Virtualization-based Security (VBS)
    und ermittelt den VBS-Ist-Zustand in den Windows-Gaesten (GPO-Rollout-Status).
.DESCRIPTION
    Laeuft auf einer domaenengebundenen Admin-Workstation mit RSAT (Hyper-V- und Failover-Cluster-Cmdlets)
    unter einem Konto, das Administrator auf den Azure Local Knoten UND in den VMs ist.

    Ablauf:
      1. Azure CLI: alle Azure Local Cluster (Microsoft.AzureStackHCI/clusters) aus allen Subscriptions lesen,
         On-Prem-Clustername und Knoten aus reportedProperties uebernehmen
      2. Pro Cluster: Knoten per FailoverClusters (Fallback: Azure-Knotenliste), VMs per Hyper-V-Cmdlets lesen
      3. Pro VM Voraussetzungen pruefen (Microsoft-Doku zu VBS/HVCI in Hyper-V-VMs):
           Generation 2 | Secure Boot in der Firmware | kein VBS-Opt-Out auf dem Host |
           keine Fibre-Channel-Adapter | keine Pass-through-Disks | Gast-OS >= Windows 10 / Server 2016
      4. Pro laufender Windows-VM per WinRM den Ist-Zustand lesen: GPO-Registry, Secure Boot im Gast,
         letzter Neustart, Win32_DeviceGuard (VBS-Status 0/1/2, Memory Integrity, Credential Guard)
         -> Rollout-Phase: GPO fehlt | Neustart fehlt | Voraussetzung fehlt (Status 1) | laeuft (Status 2)
      5. Zusammenfassung pro Cluster und gesamt, CSV-Export
    Quelle: https://learn.microsoft.com/en-us/windows/security/hardware-security/enable-virtualization-based-protection-of-code-integrity
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-09-24
    Version     : 2.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Test-VbsReadiness.ps1
#>

# =========================================================================
# KONFIGURATION (alle Parameter im Script, keine Aufruf-Parameter)
# =========================================================================
$ScriptVersion      = "2.0.0"
$PowerShellMode     = "Compat"  # "Compat" = 5.1 + 7.x | "Seven" = bricht unter 5.1 ab

$SubscriptionFilter = @()       # Subscription-IDs oder -Namen; leer = alle aktivierten Subscriptions des Logins
$ClusterFilter      = "*"       # Azure-Ressourcenname des Clusters, Wildcard erlaubt, z.B. "azl-*"
$DnsSuffix          = ""        # z.B. "ldkads.local" - wird an Cluster-/Knotennamen aus Azure angehaengt (leer = DNS-Suffix-Suchliste)
$VMNameFilter       = "*"       # z.B. "AVD-*"

$CheckGuestVbs      = $true     # VBS-Ist-Zustand in den Windows-Gaesten per WinRM abfragen (aktueller Benutzer)
$ThrottleLimit      = 16        # parallele WinRM-Sitzungen fuer die Gast-Abfrage

$ExportCsv          = $true
$CsvPath            = "C:\temp\VbsReadiness_{0}.csv" -f (Get-Date -Format "yyyyMMdd_HHmmss")
$MinOsVersion       = [Version]"10.0"   # Windows 10 / Windows Server 2016

# =========================================================================
# GRUNDEINSTELLUNGEN
# =========================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =========================================================================
# HILFSFUNKTIONEN AUSGABE
# =========================================================================
function Write-Log {
    param([string]$Symbol, [string]$Message, [string]$Color, [int]$Indent = 0)
    $ts = Get-Date -Format "HH:mm:ss"
    Write-Host ("[{0}] {1}{2}  {3}" -f $ts, (" " * $Indent), $Symbol, $Message) -ForegroundColor $Color
}
function Write-Ok   { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymOk   -Message $Message -Color Green  -Indent $Indent }
function Write-Err  { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymErr  -Message $Message -Color Red    -Indent $Indent }
function Write-Warn { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymWarn -Message $Message -Color Yellow -Indent $Indent }
function Write-Info { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymInfo -Message $Message -Color Cyan   -Indent $Indent }
function Write-Run  { param([string]$Message, [int]$Indent = 0) Write-Log -Symbol $SymRun  -Message $Message -Color Cyan   -Indent $Indent }
function Write-Separator { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section   { param([string]$Title) Write-Host ("[ {0} ]" -f $Title) -ForegroundColor White }

# =========================================================================
# HILFSFUNKTIONEN AZURE CLI
# =========================================================================
function Invoke-AzQuiet {
    # Fuehrt az mit Argument-Array aus, unterdrueckt stderr, gibt stdout als String zurueck. $LASTEXITCODE bleibt gesetzt.
    param([string[]]$Arguments)
    $out = & az @Arguments 2>$null
    if ($out -eq $null) { return "" }
    return (($out | ForEach-Object { [string]$_ }) -join "`n")
}
function Assert-AzSuccess {
    # Prueft $LASTEXITCODE nach einem az-Aufruf. Fatal = Abbruch.
    param([string]$Context, [bool]$Fatal = $true)
    if ($LASTEXITCODE -ne 0) {
        Write-Err ("Azure CLI Fehler bei: {0} (ExitCode {1})" -f $Context, $LASTEXITCODE)
        if ($Fatal) { exit 1 }
        return $false
    }
    return $true
}

# =========================================================================
# HILFSFUNKTIONEN PRUEFUNG
# =========================================================================
function Get-GuestKvp {
    # OS-Name, OS-Version, FQDN des Gastes ueber Hyper-V KVP (ohne Anmeldung im Gast)
    param([string]$ComputerName, [string]$VMName)
    $result = @{ OSName = ""; OSVersion = ""; FQDN = "" }
    try {
        $filter = "ElementName='{0}'" -f ($VMName -replace "'", "''")
        $cs = Get-CimInstance -ComputerName $ComputerName -Namespace "root\virtualization\v2" -ClassName Msvm_ComputerSystem -Filter $filter -ErrorAction Stop
        if ($cs -ne $null) {
            $kvp = Get-CimAssociatedInstance -InputObject $cs -ComputerName $ComputerName -ResultClassName Msvm_KvpExchangeComponent -ErrorAction Stop
            if ($kvp -ne $null -and $kvp.GuestIntrinsicExchangeItems -ne $null) {
                foreach ($item in $kvp.GuestIntrinsicExchangeItems) {
                    $xml  = [xml]$item
                    $name = ($xml.INSTANCE.PROPERTY | Where-Object { $_.NAME -eq "Name" }).VALUE
                    $data = ($xml.INSTANCE.PROPERTY | Where-Object { $_.NAME -eq "Data" }).VALUE
                    switch ($name) {
                        "OSName"                   { $result.OSName    = [string]$data }
                        "OSVersion"                { $result.OSVersion = [string]$data }
                        "FullyQualifiedDomainName" { $result.FQDN      = [string]$data }
                    }
                }
            }
        }
    }
    catch { }
    return $result
}

function Get-VbsStatusText {
    param([int]$Code)
    switch ($Code) {
        0 { return "0 - nicht aktiviert" }
        1 { return "1 - aktiviert, laeuft NICHT" }
        2 { return "2 - aktiviert und laeuft" }
        default { return "unbekannt" }
    }
}

# Scriptblock, der IN der VM ausgefuehrt wird
$GuestProbe = {
    $dg = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace "root\Microsoft\Windows\DeviceGuard" -ErrorAction SilentlyContinue
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $regVbs = $null; $regLvl = $null; $regHvci = $null; $regLock = $null
    $k1 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" -ErrorAction SilentlyContinue
    if ($k1 -ne $null) {
        $regVbs  = $k1.EnableVirtualizationBasedSecurity
        $regLvl  = $k1.RequirePlatformSecurityFeatures
        $regLock = $k1.Locked
    }
    $k2 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" -ErrorAction SilentlyContinue
    if ($k2 -ne $null) { $regHvci = $k2.Enabled }
    $sb = $null
    try { $sb = Confirm-SecureBootUEFI -ErrorAction Stop } catch { }
    $vbsStatus = -1; $run = @(); $avail = @()
    if ($dg -ne $null) {
        $vbsStatus = $dg.VirtualizationBasedSecurityStatus
        $run   = @($dg.SecurityServicesRunning)
        $avail = @($dg.AvailableSecurityProperties)
    }
    [pscustomobject]@{
        VbsStatus  = $vbsStatus
        Running    = $run
        Available  = $avail
        RegVbs     = $regVbs
        RegLevel   = $regLvl
        RegHvci    = $regHvci
        RegLocked  = $regLock
        SecureBoot = $sb
        LastBoot   = $os.LastBootUpTime
    }
}

# =========================================================================
# PRE-CHECK
# =========================================================================
Write-Separator
Write-Section "PRE-CHECK"

$psVer = $PSVersionTable.PSVersion
Write-Info ("PowerShell-Version: {0} ({1})" -f $psVer, $PSVersionTable.PSEdition)
if ($PowerShellMode -eq "Seven" -and $psVer.Major -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - Abbruch"
    exit 1
}
if ($psVer -ge [Version]"7.3") {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PSNativeCommandUseErrorActionPreference = false gesetzt (PS 7.3+)"
}
Write-Ok ("PowerShell-Modus: {0}" -f $PowerShellMode)

$identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Ok ("Ausfuehrung als Administrator: {0}" -f $identity.Name)
}
else {
    Write-Err "Script muss als Administrator ausgefuehrt werden - Abbruch"
    exit 1
}
if ($identity.Name -notmatch "\\") {
    Write-Warn "Konto ohne Domaenen-Praefix - Kerberos zu Knoten und VMs wird wahrscheinlich fehlschlagen"
}
$csys = Get-CimInstance -ClassName Win32_ComputerSystem
if ($csys.PartOfDomain) { Write-Ok ("Rechner ist Domaenenmitglied: {0}" -f $csys.Domain) }
else { Write-Warn "Rechner ist NICHT Domaenenmitglied - Kerberos zu Knoten und VMs nicht moeglich" }

Write-Info "Pruefe Azure CLI..."
$azCmd = Get-Command -Name az -ErrorAction SilentlyContinue
if ($azCmd -eq $null) {
    Write-Err "Azure CLI nicht gefunden - Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$azVerJson = Invoke-AzQuiet -Arguments @("version", "-o", "json")
Assert-AzSuccess -Context "az version" | Out-Null
$azVersion = "unbekannt"
try { $azVersion = (ConvertFrom-Json $azVerJson)."azure-cli" } catch { }
Write-Ok ("Azure CLI gefunden: {0}" -f $azVersion)
Write-Info "Aktualitaet: 'az upgrade' zeigt und installiert eine neuere Version, falls vorhanden" 4

Write-Info "Pruefe Azure Login..."
$acctJson = Invoke-AzQuiet -Arguments @("account", "show", "-o", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Kein Azure Login vorhanden - starte az login..."
    & az login -o none
    Assert-AzSuccess -Context "az login" | Out-Null
    $acctJson = Invoke-AzQuiet -Arguments @("account", "show", "-o", "json")
    Assert-AzSuccess -Context "az account show" | Out-Null
}
$acct = ConvertFrom-Json $acctJson
Write-Ok ("Login vorhanden: {0} (Tenant {1})" -f $acct.user.name, $acct.tenantId)

Write-Info "Pruefe Hyper-V PowerShell-Modul (RSAT)..."
if (Get-Module -ListAvailable -Name Hyper-V) {
    Import-Module Hyper-V -ErrorAction SilentlyContinue
    Write-Ok "Hyper-V Modul geladen"
}
else {
    Write-Err "Hyper-V PowerShell-Modul nicht gefunden"
    Write-Info "Workstation: Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-Management-PowerShell" 4
    Write-Info "Server:      Install-WindowsFeature RSAT-Hyper-V-Tools" 4
    exit 1
}
Write-Info "Pruefe FailoverClusters PowerShell-Modul (RSAT)..."
$clusterModule = $false
if (Get-Module -ListAvailable -Name FailoverClusters) {
    Import-Module FailoverClusters -ErrorAction SilentlyContinue
    $clusterModule = $true
    Write-Ok "FailoverClusters Modul geladen"
}
else {
    Write-Warn "FailoverClusters Modul nicht gefunden - Knotenliste kommt ausschliesslich aus Azure"
    Write-Info "Workstation: Add-WindowsCapability -Online -Name Rsat.FailoverCluster.Management.Tools~~~~0.0.1.0" 4
}

Write-Separator
Write-Section "SCRIPT"
Write-Info ("Test-VbsReadiness.ps1 - Version {0}" -f $ScriptVersion)
Write-Info ("Cluster-Filter: {0} | VM-Filter: {1} | DNS-Suffix: '{2}' | Gast-Abfrage: {3}" -f $ClusterFilter, $VMNameFilter, $DnsSuffix, $CheckGuestVbs)
Write-Separator

# =========================================================================
# 1. AZURE LOCAL CLUSTER AUS AZURE LESEN
# =========================================================================
Write-Section "AZURE LOCAL CLUSTER (Azure)"
$subsJson = Invoke-AzQuiet -Arguments @("account", "list", "--query", "[?state=='Enabled'].{id:id,name:name}", "-o", "json")
Assert-AzSuccess -Context "az account list" | Out-Null
$subs = @(ConvertFrom-Json $subsJson)
if ($SubscriptionFilter.Count -gt 0) {
    $subs = @($subs | Where-Object { ($SubscriptionFilter -contains $_.id) -or ($SubscriptionFilter -contains $_.name) })
}
Write-Info ("Subscriptions: {0}" -f $subs.Count)

$Clusters = @()
foreach ($sub in $subs) {
    Write-Run ("Suche Azure Local Cluster in '{0}'..." -f $sub.name)
    $listJson = Invoke-AzQuiet -Arguments @("resource", "list", "--subscription", $sub.id, "--resource-type", "Microsoft.AzureStackHCI/clusters", "--query", "[].{id:id,name:name,rg:resourceGroup}", "-o", "json")
    if (-not (Assert-AzSuccess -Context ("az resource list in " + $sub.name) -Fatal $false)) { continue }
    $found = @(ConvertFrom-Json $listJson)
    foreach ($c in $found) {
        if ($c.name -notlike $ClusterFilter) { continue }
        $showJson = Invoke-AzQuiet -Arguments @("resource", "show", "--ids", $c.id, "-o", "json")
        if (-not (Assert-AzSuccess -Context ("az resource show " + $c.name) -Fatal $false)) { continue }
        $res = ConvertFrom-Json $showJson
        $rp  = $res.properties.reportedProperties
        $onPremName = ""
        $nodeNames  = @()
        $version    = ""
        if ($rp -ne $null) {
            if ($rp.clusterName -ne $null) { $onPremName = [string]$rp.clusterName }
            if ($rp.clusterVersion -ne $null) { $version = [string]$rp.clusterVersion }
            if ($rp.nodes -ne $null) { $nodeNames = @($rp.nodes | ForEach-Object { [string]$_.name }) }
        }
        if ($onPremName -eq "") { $onPremName = $c.name }
        $fqdn = $onPremName
        if ($DnsSuffix -ne "" -and $fqdn -notmatch "\.") { $fqdn = "{0}.{1}" -f $onPremName, $DnsSuffix }
        $Clusters += [pscustomobject]@{
            AzureName    = $c.name
            ResourceGroup = $c.rg
            Subscription = $sub.name
            ClusterName  = $onPremName
            ClusterFqdn  = $fqdn
            Version      = $version
            AzureNodes   = $nodeNames
            Status       = [string]$res.properties.status
        }
        Write-Ok ("{0} -> On-Prem '{1}' | Version {2} | Knoten (Azure): {3} | Status {4}" -f $c.name, $onPremName, $version, ($nodeNames -join ", "), $res.properties.status) 4
    }
}
if ($Clusters.Count -eq 0) {
    Write-Err "Keine Azure Local Cluster gefunden (Filter/Subscriptions/Rechte pruefen) - Abbruch"
    exit 1
}
Write-Info ("Cluster gesamt: {0}" -f $Clusters.Count)
Write-Separator

# =========================================================================
# 2. VERBINDEN UND VMs EINLESEN
# =========================================================================
Write-Section "VERBINDUNG UND VMs"
$AllVms = @()   # Objekte: Cluster, VM (Hyper-V-Objekt)
foreach ($cl in $Clusters) {
    Write-Run ("Cluster {0} ({1})..." -f $cl.ClusterName, $cl.ClusterFqdn)
    $nodes = @()
    if ($clusterModule) {
        try {
            $nodes = @(Get-ClusterNode -Cluster $cl.ClusterFqdn -ErrorAction Stop | Where-Object { $_.State -eq "Up" } | ForEach-Object { $_.Name })
            Write-Ok ("Knoten online (FailoverClusters): {0}" -f ($nodes -join ", ")) 4
        }
        catch {
            Write-Warn ("Cluster-Abfrage fehlgeschlagen ({0}) - nutze Knotenliste aus Azure" -f $_.Exception.Message) 4
        }
    }
    if ($nodes.Count -eq 0) {
        $nodes = @($cl.AzureNodes | ForEach-Object {
            if ($DnsSuffix -ne "" -and $_ -notmatch "\.") { "{0}.{1}" -f $_, $DnsSuffix } else { $_ }
        })
        Write-Info ("Knoten (Azure): {0}" -f ($nodes -join ", ")) 4
    }
    if ($nodes.Count -eq 0) {
        Write-Err "Keine Knoten ermittelt - Cluster wird uebersprungen" 4
        continue
    }
    $clusterVmCount = 0
    foreach ($node in $nodes) {
        try {
            $vms = @(Get-VM -ComputerName $node -ErrorAction Stop | Where-Object { $_.Name -like $VMNameFilter })
            foreach ($v in $vms) { $AllVms += [pscustomobject]@{ Cluster = $cl.ClusterName; VM = $v } }
            $clusterVmCount += $vms.Count
            Write-Ok ("{0}: {1} VM(s)" -f $node, $vms.Count) 4
        }
        catch {
            Write-Err ("{0}: VMs nicht lesbar - {1}" -f $node, $_.Exception.Message) 4
        }
    }
    Write-Info ("Cluster {0}: {1} VM(s)" -f $cl.ClusterName, $clusterVmCount) 4
}
if ($AllVms.Count -eq 0) {
    Write-Warn "Keine VMs gefunden - nichts zu pruefen"
    exit 0
}
Write-Info ("VMs gesamt: {0}" -f $AllVms.Count)
Write-Separator

# =========================================================================
# 3. VORAUSSETZUNGEN PRO VM
# =========================================================================
Write-Section "VBS-VORAUSSETZUNGEN PRO VM"
$Results = @()

foreach ($entry in $AllVms) {
    $vm       = $entry.VM
    $issues   = New-Object System.Collections.Generic.List[string]
    $warnings = New-Object System.Collections.Generic.List[string]
    $vmHost   = $vm.ComputerName
    Write-Run ("[{0}] {1} (Host: {2}, Status: {3})" -f $entry.Cluster, $vm.Name, $vmHost, $vm.State)

    # Generation
    $gen = $vm.Generation
    if ($gen -eq 2) { Write-Ok "Generation 2" 4 }
    else { Write-Err "Generation 1 - VBS in Hyper-V erfordert Generation 2" 4; $issues.Add("Generation 1") }

    # Secure Boot (Firmware)
    $secureBoot = "n/a"; $sbTemplate = "n/a"
    if ($gen -eq 2) {
        try {
            $fw = Get-VMFirmware -VM $vm -ErrorAction Stop
            $secureBoot = [string]$fw.SecureBoot
            $sbTemplate = [string]$fw.SecureBootTemplate
            if ($fw.SecureBoot -eq "On") { Write-Ok ("Secure Boot: On (Template: {0})" -f $sbTemplate) 4 }
            else { Write-Err "Secure Boot: Off - Platform Security Level 'Secure Boot' der GPO greift nicht" 4; $issues.Add("Secure Boot Off") }
        }
        catch { Write-Warn ("VM-Firmware nicht lesbar: {0}" -f $_.Exception.Message) 4; $warnings.Add("Firmware nicht lesbar") }
    }

    # VBS-Opt-Out / vTPM
    $optOut = "n/a"; $tpm = "n/a"
    try {
        $sec    = Get-VMSecurity -VM $vm -ErrorAction Stop
        $optOut = [string]$sec.VirtualizationBasedSecurityOptOut
        $tpm    = [string]$sec.TpmEnabled
        if ($sec.VirtualizationBasedSecurityOptOut) { Write-Err "VBS-Opt-Out auf dem Host aktiv" 4; $issues.Add("VBS Opt-Out") }
        else { Write-Ok "Kein VBS-Opt-Out auf dem Host" 4 }
        Write-Info ("vTPM aktiviert: {0}" -f $tpm) 4
    }
    catch { Write-Warn ("VM-Security nicht lesbar: {0}" -f $_.Exception.Message) 4; $warnings.Add("VM-Security nicht lesbar") }

    # Sicherheitstyp (informativ)
    $isolation = "n/a"
    $prop = $vm.PSObject.Properties["GuestStateIsolationType"]
    if ($prop -ne $null -and $prop.Value -ne $null) { $isolation = [string]$prop.Value }
    Write-Info ("Sicherheitstyp (GuestStateIsolationType): {0}" -f $isolation) 4

    # Fibre-Channel
    $fcCount = 0
    try { $fcCount = @(Get-VMFibreChannelHba -VM $vm -ErrorAction Stop).Count } catch { }
    if ($fcCount -gt 0) { Write-Err ("{0} virtuelle(r) Fibre-Channel-Adapter" -f $fcCount) 4; $issues.Add("Fibre-Channel-Adapter") }
    else { Write-Ok "Keine virtuellen Fibre-Channel-Adapter" 4 }

    # Pass-through
    $ptCount = 0; $fullScsi = $false
    try {
        foreach ($hdd in @(Get-VMHardDiskDrive -VM $vm -ErrorAction Stop)) {
            if ($hdd.DiskNumber -ne $null) {
                $ptCount++
                $p = $hdd.PSObject.Properties["AllowFullSCSICommandSet"]
                if ($p -ne $null -and $p.Value -eq $true) { $fullScsi = $true }
            }
        }
    }
    catch { }
    if ($fullScsi) { Write-Err "Pass-through-Disk mit AllowFullSCSICommandSet" 4; $issues.Add("Pass-through AllowFullSCSICommandSet") }
    elseif ($ptCount -gt 0) { Write-Warn ("{0} Pass-through-Disk(s) - AllowFullSCSICommandSet manuell pruefen" -f $ptCount) 4; $warnings.Add("Pass-through-Disk vorhanden") }
    else { Write-Ok "Keine Pass-through-Disks" 4 }

    # Gast-OS (KVP)
    $kvp  = Get-GuestKvp -ComputerName $vmHost -VMName $vm.Name
    $osOk = "unbekannt"
    if ($kvp.OSName -ne "") {
        if ($kvp.OSName -match "Windows") {
            $ver = $null
            try { $ver = [Version]$kvp.OSVersion } catch { }
            if ($ver -ne $null -and $ver -ge $MinOsVersion) { Write-Ok ("Gast-OS: {0} ({1})" -f $kvp.OSName, $kvp.OSVersion) 4; $osOk = "OK" }
            else { Write-Err ("Gast-OS zu alt: {0} ({1})" -f $kvp.OSName, $kvp.OSVersion) 4; $issues.Add("Gast-OS zu alt"); $osOk = "FAIL" }
        }
        else { Write-Info ("Kein Windows-Gast ({0}) - VBS nicht relevant" -f $kvp.OSName) 4; $osOk = "SKIP" }
    }
    else { Write-Warn "Gast-OS unbekannt (VM aus oder keine KVP-Daten)" 4; $warnings.Add("Gast-OS unbekannt") }

    if     ($osOk -eq "SKIP")      { $verdict = "SKIP" }
    elseif ($issues.Count -gt 0)   { $verdict = "FAIL" }
    elseif ($warnings.Count -gt 0) { $verdict = "WARN" }
    else                           { $verdict = "OK" }
    switch ($verdict) {
        "OK"   { Write-Ok   "Voraussetzungen: OK" 4 }
        "WARN" { Write-Warn ("Voraussetzungen: WARN - {0}" -f ($warnings -join "; ")) 4 }
        "FAIL" { Write-Err  ("Voraussetzungen: FAIL - {0}" -f ($issues -join "; ")) 4 }
        "SKIP" { Write-Info "Voraussetzungen: SKIP - kein Windows-Gast" 4 }
    }

    $target = $kvp.FQDN
    if ($target -eq "") { $target = $vm.Name }
    $Results += [pscustomobject]@{
        Cluster         = $entry.Cluster
        VM              = $vm.Name
        Host            = $vmHost
        Status          = [string]$vm.State
        Generation      = $gen
        SecureBoot      = $secureBoot
        SecureBootTmpl  = $sbTemplate
        VbsOptOut       = $optOut
        vTPM            = $tpm
        Sicherheitstyp  = $isolation
        FcAdapter       = $fcCount
        PassThrough     = $ptCount
        GastOS          = $kvp.OSName
        GastOSVersion   = $kvp.OSVersion
        GastFQDN        = $target
        Voraussetzungen = $verdict
        Probleme        = ($issues -join "; ")
        Hinweise        = ($warnings -join "; ")
        GastAbfrage     = "nicht durchgefuehrt"
        GastFehler      = ""
        GpoRegistry     = "n/a"
        UefiLock        = "n/a"
        SecureBootGast  = "n/a"
        LetzterNeustart = "n/a"
        VbsStatusGast   = "n/a"
        HvciLaeuft      = "n/a"
        CredGuardLaeuft = "n/a"
        VbsPhase        = "n/a"
    }
}
Write-Separator

# =========================================================================
# 4. VBS-IST-ZUSTAND IN DEN GAESTEN (WinRM, parallel)
# =========================================================================
if ($CheckGuestVbs) {
    Write-Section "VBS-IST-ZUSTAND (Gast-Abfrage per WinRM)"
    $probeRows = @($Results | Where-Object { $_.Voraussetzungen -ne "SKIP" -and $_.Status -eq "Running" })
    if ($probeRows.Count -gt 0) {
        $names = @($probeRows | ForEach-Object { $_.GastFQDN } | Select-Object -Unique)
        Write-Run ("Frage {0} laufende Windows-VM(s) ab (parallel {1})..." -f $names.Count, $ThrottleLimit)
        $errLog = @()
        $raw = @(Invoke-Command -ComputerName $names -ScriptBlock $GuestProbe -ThrottleLimit $ThrottleLimit -ErrorAction SilentlyContinue -ErrorVariable errLog)
        Write-Ok ("Antworten: {0} von {1}" -f $raw.Count, $names.Count)
        $errByTarget = @{}
        foreach ($e in $errLog) {
            $t = ""
            if ($e.TargetObject -ne $null) { $t = [string]$e.TargetObject }
            if ($t -eq "" -and $e.OriginInfo -ne $null) { $t = [string]$e.OriginInfo.PSComputerName }
            $m = $e.Exception.Message -replace "\s+", " "
            if ($m.Length -gt 160) { $m = $m.Substring(0, 160) + "..." }
            if ($t -ne "") { $errByTarget[$t.ToLower()] = $m }
        }

        foreach ($row in $probeRows) {
            $r = $raw | Where-Object { $_.PSComputerName -ieq $row.GastFQDN } | Select-Object -First 1
            if ($r -eq $null) {
                $msg = "keine Antwort"
                $key = $row.GastFQDN.ToLower()
                if ($errByTarget.ContainsKey($key)) { $msg = $errByTarget[$key] }
                $row.GastAbfrage = "FEHLER"; $row.GastFehler = $msg; $row.VbsPhase = "unbekannt"
                Write-Err ("[{0}] {1}: nicht erreichbar - {2}" -f $row.Cluster, $row.VM, $msg)
                continue
            }
            $gpoSet  = ($r.RegVbs -eq 1)
            $regText = "nicht gesetzt"
            if ($r.RegVbs -ne $null -or $r.RegHvci -ne $null) { $regText = "EnableVBS={0} PlatformLevel={1} HVCI={2}" -f $r.RegVbs, $r.RegLevel, $r.RegHvci }
            $lastBoot = "n/a"
            if ($r.LastBoot -ne $null) { $lastBoot = ([datetime]$r.LastBoot).ToString("yyyy-MM-dd HH:mm") }
            $hvci = (@($r.Running) -contains 2)
            $cg   = (@($r.Running) -contains 1)
            $sbText = "n/a";   if ($r.SecureBoot -ne $null) { $sbText = [string]$r.SecureBoot }
            $lockText = "n/a"; if ($r.RegLocked -ne $null)  { $lockText = [string]$r.RegLocked }
            $statusText = Get-VbsStatusText -Code ([int]$r.VbsStatus)
            if     ([int]$r.VbsStatus -eq 2) { $phase = "laeuft" }
            elseif ([int]$r.VbsStatus -eq 1) { $phase = "Voraussetzung fehlt" }
            elseif ($gpoSet)                 { $phase = "Neustart fehlt" }
            else                             { $phase = "GPO fehlt" }
            switch ($phase) {
                "laeuft"              { Write-Ok   ("[{0}] {1}: VBS {2} | HVCI={3} CredGuard={4}" -f $row.Cluster, $row.VM, $statusText, $hvci, $cg) }
                "Voraussetzung fehlt" { Write-Warn ("[{0}] {1}: VBS {2} | {3} | Secure Boot im Gast: {4} (PlatformLevel 1=Secure Boot, 3=Secure Boot+DMA)" -f $row.Cluster, $row.VM, $statusText, $regText, $sbText) }
                "Neustart fehlt"      { Write-Warn ("[{0}] {1}: VBS {2} | GPO gesetzt ({3}) | letzter Neustart {4}" -f $row.Cluster, $row.VM, $statusText, $regText, $lastBoot) }
                "GPO fehlt"           { Write-Info ("[{0}] {1}: VBS {2} | GPO-Registry {3}" -f $row.Cluster, $row.VM, $statusText, $regText) }
            }
            $row.GastAbfrage = "OK"; $row.GpoRegistry = $regText; $row.UefiLock = $lockText; $row.SecureBootGast = $sbText
            $row.LetzterNeustart = $lastBoot; $row.VbsStatusGast = $statusText; $row.HvciLaeuft = [string]$hvci
            $row.CredGuardLaeuft = [string]$cg; $row.VbsPhase = $phase
        }
    }
    else { Write-Info "Keine laufenden Windows-VMs fuer die Gast-Abfrage" }
    Write-Separator
}

# =========================================================================
# 5. ZUSAMMENFASSUNG
# =========================================================================
Write-Section "ZUSAMMENFASSUNG"
$table = $Results | Sort-Object Cluster, VbsPhase, VM |
    Format-Table Cluster, VM, Generation, SecureBoot, GastOS, Voraussetzungen, GpoRegistry, VbsStatusGast, VbsPhase -AutoSize |
    Out-String -Width 280
Write-Host $table -ForegroundColor White

foreach ($cl in ($Results | Select-Object -ExpandProperty Cluster -Unique)) {
    $rows   = @($Results | Where-Object { $_.Cluster -eq $cl })
    $win    = @($rows | Where-Object { $_.Voraussetzungen -ne "SKIP" })
    $cOk    = @($win | Where-Object { $_.Voraussetzungen -eq "OK" }).Count
    $cWarn  = @($win | Where-Object { $_.Voraussetzungen -eq "WARN" }).Count
    $cFail  = @($win | Where-Object { $_.Voraussetzungen -eq "FAIL" }).Count
    $cRun   = @($win | Where-Object { $_.VbsPhase -eq "laeuft" }).Count
    $cReb   = @($win | Where-Object { $_.VbsPhase -eq "Neustart fehlt" }).Count
    $cPre   = @($win | Where-Object { $_.VbsPhase -eq "Voraussetzung fehlt" }).Count
    $cNoGpo = @($win | Where-Object { $_.VbsPhase -eq "GPO fehlt" }).Count
    $cErr   = @($win | Where-Object { $_.GastAbfrage -eq "FEHLER" }).Count
    Write-Section ("CLUSTER {0}" -f $cl)
    Write-Info ("Windows-VMs: {0} | Voraussetzungen OK: {1} WARN: {2} FAIL: {3}" -f $win.Count, $cOk, $cWarn, $cFail)
    if ($CheckGuestVbs) {
        if ($cRun -eq $win.Count -and $win.Count -gt 0) { Write-Ok ("VBS laeuft auf allen {0} Windows-VMs" -f $win.Count) }
        else {
            Write-Info ("VBS laeuft: {0} | Neustart fehlt: {1} | Voraussetzung fehlt (Status 1): {2} | GPO fehlt: {3} | nicht abfragbar: {4}" -f $cRun, $cReb, $cPre, $cNoGpo, $cErr)
        }
        if ($cReb -gt 0) { foreach ($x in ($win | Where-Object { $_.VbsPhase -eq "Neustart fehlt" })) { Write-Warn ("Neustart fehlt: {0} (letzter Neustart {1})" -f $x.VM, $x.LetzterNeustart) 4 } }
        if ($cPre -gt 0) { foreach ($x in ($win | Where-Object { $_.VbsPhase -eq "Voraussetzung fehlt" })) { Write-Warn ("Status 1: {0} ({1}, Secure Boot im Gast: {2})" -f $x.VM, $x.GpoRegistry, $x.SecureBootGast) 4 } }
        if ($cErr -gt 0) { foreach ($x in ($win | Where-Object { $_.GastAbfrage -eq "FEHLER" })) { Write-Err ("Nicht abfragbar: {0} - {1}" -f $x.VM, $x.GastFehler) 4 } }
    }
    if ($cFail -gt 0) { foreach ($x in ($win | Where-Object { $_.Voraussetzungen -eq "FAIL" })) { Write-Err ("Voraussetzung FAIL: {0} - {1}" -f $x.VM, $x.Probleme) 4 } }
}

Write-Separator
Write-Section "GESAMT"
$winAll  = @($Results | Where-Object { $_.Voraussetzungen -ne "SKIP" })
$tFail   = @($winAll | Where-Object { $_.Voraussetzungen -eq "FAIL" }).Count
$tRun    = @($winAll | Where-Object { $_.VbsPhase -eq "laeuft" }).Count
$exitCode = 0
Write-Info ("Cluster: {0} | VMs: {1} | Windows-VMs: {2}" -f $Clusters.Count, $Results.Count, $winAll.Count)
if ($tFail -eq 0) { Write-Ok ("Voraussetzungen: alle {0} Windows-VM(s) VBS-faehig" -f $winAll.Count) }
else { Write-Err ("Voraussetzungen: {0} Windows-VM(s) NICHT VBS-faehig" -f $tFail); $exitCode = 1 }
if ($CheckGuestVbs) {
    if ($tRun -eq $winAll.Count -and $winAll.Count -gt 0) { Write-Ok ("Ist-Zustand: VBS laeuft auf allen {0} Windows-VM(s)" -f $winAll.Count) }
    else { Write-Warn ("Ist-Zustand: VBS laeuft auf {0} von {1} Windows-VM(s)" -f $tRun, $winAll.Count); $exitCode = 1 }
}

if ($ExportCsv) {
    try {
        $csvDir = Split-Path -Path $CsvPath -Parent
        if (-not (Test-Path -Path $csvDir)) { New-Item -Path $csvDir -ItemType Directory -Force | Out-Null }
        $Results | Export-Csv -Path $CsvPath -NoTypeInformation -Encoding UTF8 -Delimiter ";" -ErrorAction Stop
        Write-Ok ("CSV exportiert: {0}" -f $CsvPath)
    }
    catch { Write-Err ("CSV-Export fehlgeschlagen: {0}" -f $_.Exception.Message) }
}
Write-Separator
exit $exitCode
