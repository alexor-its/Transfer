﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Setzt den Arbeitsspeicher (RAM) aller AVD Session Hosts auf Azure Local (Azure Stack HCI) auf einen Zielwert.
.DESCRIPTION
    Ermittelt subscription-weit alle AVD Host Pools und deren Session Hosts, filtert auf VMs,
    die als Arc-VM auf Azure Local (Microsoft.AzureStackHCI/virtualMachineInstances) laufen,
    und zeigt eine Uebersicht mit aktuellem RAM (MB), Dynamic-Memory-Bereich, Power State und
    aktiven Sessions an. Danach kann gewaehlt werden, ob alle Host Pools oder nur ein bestimmter
    Host Pool angepasst werden soll. Nach einer finalen Bestaetigung wird der RAM (Standard:
    16384 MB) gesetzt - unabhaengig von Resource Group oder Host Pool.

    Ablauf pro Session Host:
      - RAM bereits auf Zielwert        -> wird uebersprungen
      - VM ausgeschaltet                -> RAM wird direkt angepasst
      - VM eingeschaltet                -> VM wird gestoppt (KEIN Drain-Mode, aktive Sessions
                                           werden getrennt), RAM angepasst, optional wieder gestartet
      - Dynamic Memory aktiv und Zielwert ausserhalb Min/Max -> wird uebersprungen (konfigurierbar)

    Die Ermittlung laeuft standardmaessig ueber Azure Resource Graph (2 Abfragen per az rest);
    bei Fehlern erfolgt automatisch ein Fallback auf Einzelabfragen pro Host Pool / Session Host.
    Es wird ausschliesslich Azure CLI (az rest) verwendet - keine Az-Module, keine CLI-Extensions.
    Benoetigte Rechte: Lesen auf Microsoft.DesktopVirtualization (Host Pools / Session Hosts) sowie
    Schreiben auf Microsoft.AzureStackHCI/virtualMachineInstances (z.B. Azure Stack HCI VM Contributor).
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-27
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Set-AvdAzureLocalSessionHostMemory.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - Alle Parameter werden hier im Script hinterlegt
# =============================================================================
$ScriptVersion        = "1.0.0"
$PowerShellMode       = "Compat"        # "Compat" = PS 5.1 + 7.x | "Seven" = nur PS 7.x
$SubscriptionId       = ""              # leer = aktuell gewaehlte Subscription (az account show)
$TargetMemoryMB       = 16384           # Ziel-RAM pro Session Host in MB (z.B. 16384 = 16 GB)
$SkipOnDynamicMemoryMismatch = $true    # $true = VM ueberspringen, wenn Dynamic Memory aktiv ist und Ziel ausserhalb Min/Max liegt
$CustomLocationFilter = ""              # optional: Name der Custom Location (Azure Local Cluster); leer = alle
$StartAfterChange     = $true           # VMs, die vorher liefen, nach der Anpassung wieder starten
$WhatIfMode           = $false          # $true = nur anzeigen, keine Aenderungen durchfuehren
$StopTimeoutSec       = 600             # max. Wartezeit auf "Stopped"
$UpdateTimeoutSec     = 600             # max. Wartezeit auf abgeschlossene RAM-Aenderung
$StartTimeoutSec      = 300             # max. Wartezeit auf "Running" (nur Info, kein Abbruch)
$PollIntervalSec      = 10              # Abfrageintervall beim Warten
$ApiVersionAvd        = "2024-04-03"    # Microsoft.DesktopVirtualization
$ApiVersionHci        = "2024-01-01"    # Microsoft.AzureStackHCI virtualMachineInstances
$ApiVersionArg        = "2022-10-01"    # Microsoft.ResourceGraph
$UseResourceGraph     = $true           # $true = Ermittlung ueber Resource Graph (2 Abfragen), $false = Einzelabfragen pro Host
$MinAzCliVersion      = "2.60.0"        # Mindestversion Azure CLI
$ArmEndpoint          = "https://management.azure.com"

# =============================================================================
# [ INITIALISIERUNG ]
# =============================================================================
$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

# Terminierende Fehler sichtbar machen statt stillem Abbruch
trap {
    Write-Host ("[{0}] TERMINIERENDER FEHLER: {1}" -f (Get-Date -Format "HH:mm:ss"), $_.Exception.Message) -ForegroundColor Red
    if ($_.InvocationInfo) { Write-Host ("    Position: {0}" -f $_.InvocationInfo.PositionMessage) -ForegroundColor Red }
    exit 99
}

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Write-Separator {
    Write-Host ("=" * 60) -ForegroundColor White
}

function Write-Section {
    param([string]$Title)
    Write-Separator
    Write-Host "[ $Title ]" -ForegroundColor White
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("Ok", "Error", "Warn", "Info", "Run")]
        [string]$Level = "Info",
        [int]$Indent = 0
    )
    $ts = Get-Date -Format "HH:mm:ss"
    switch ($Level) {
        "Ok"    { $sym = $SymOk;   $color = "Green"  }
        "Error" { $sym = $SymErr;  $color = "Red"    }
        "Warn"  { $sym = $SymWarn; $color = "Yellow" }
        "Run"   { $sym = $SymRun;  $color = "Cyan"   }
        default { $sym = $SymInfo; $color = "Cyan"   }
    }
    $pad = " " * $Indent
    Write-Host ("[{0}] {1}{2}  {3}" -f $ts, $pad, $sym, $Message) -ForegroundColor $color
}

# Fuehrt az aus und unterdrueckt stderr. Argumente als Array uebergeben.
$script:LastAzError = ""
function Invoke-AzQuiet {
    param([string[]]$Arguments)
    $prevPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $output = & az @Arguments 2>$null
    $ErrorActionPreference = $prevPref
    return $output
}

# Prueft $LASTEXITCODE nach einem externen Aufruf
function Assert-AzSuccess {
    param(
        [string]$Action,
        [switch]$Fatal
    )
    if ($LASTEXITCODE -ne 0) {
        Write-Log "$Action fehlgeschlagen (ExitCode: $LASTEXITCODE)" "Error"
        if ($Fatal) { exit 1 }
        return $false
    }
    return $true
}

# az rest Wrapper: Query-Parameter immer ueber --uri-parameters, Body immer als Datei
function Invoke-AzRest {
    param(
        [ValidateSet("GET", "POST", "PATCH", "PUT", "DELETE")]
        [string]$Method,
        [string]$Url,
        [string[]]$UriParameters = @(),
        [hashtable]$Body = $null
    )
    $azArgs = @("rest", "--method", $Method, "--url", $Url, "--output", "json")
    if ($UriParameters.Count -gt 0) {
        $azArgs += "--uri-parameters"
        $azArgs += $UriParameters
    }
    $bodyFile = $null
    if ($Body) {
        $bodyFile = Join-Path ([System.IO.Path]::GetTempPath()) ("azbody_" + [Guid]::NewGuid().ToString() + ".json")
        $json = $Body | ConvertTo-Json -Depth 10 -Compress
        [System.IO.File]::WriteAllText($bodyFile, $json, (New-Object System.Text.UTF8Encoding($false)))
        $azArgs += @("--body", "@$bodyFile")
    }

    $raw = Invoke-AzQuiet -Arguments $azArgs
    $exitCode = $LASTEXITCODE

    if ($bodyFile -and (Test-Path $bodyFile)) {
        Remove-Item $bodyFile -Force -ErrorAction SilentlyContinue
    }

    $result = New-Object PSObject -Property @{
        Success  = ($exitCode -eq 0)
        ExitCode = $exitCode
        Data     = $null
        Error    = $script:LastAzError
    }
    if ($exitCode -eq 0 -and $raw) {
        $text = ($raw -join "`n").Trim()
        if ($text) {
            try { $result.Data = $text | ConvertFrom-Json } catch { $result.Data = $text }
        }
    }
    return $result
}

# Listet eine ARM-Collection inkl. nextLink-Paging. nextLink wird in URL + uri-parameters zerlegt.
function Get-AzRestList {
    param(
        [string]$Url,
        [string]$ApiVersion
    )
    $items = @()
    $nextUrl = $Url
    $nextParams = @("api-version=$ApiVersion")
    while ($nextUrl) {
        $res = Invoke-AzRest -Method GET -Url $nextUrl -UriParameters $nextParams
        if (-not $res.Success) { return $null }
        if ($res.Data -and $res.Data.value) { $items += @($res.Data.value) }
        $nextUrl = $null
        if ($res.Data -and $res.Data.nextLink) {
            $parts = ([string]$res.Data.nextLink).Split("?", 2)
            $nextUrl = $parts[0]
            $nextParams = @()
            if ($parts.Count -gt 1) {
                foreach ($kv in $parts[1].Split("&")) {
                    if (-not $kv) { continue }
                    $pair = $kv.Split("=", 2)
                    $k = [System.Uri]::UnescapeDataString($pair[0])
                    $v = ""
                    if ($pair.Count -gt 1) { $v = [System.Uri]::UnescapeDataString($pair[1]) }
                    $nextParams += "$k=$v"
                }
            }
        }
    }
    return ,$items
}

# Azure Resource Graph Abfrage ueber az rest (keine Extension), inkl. $skipToken-Paging
function Invoke-ArgQuery {
    param([string]$Query)
    $all = @()
    $skipToken = $null
    do {
        $body = @{
            subscriptions = @($SubscriptionId)
            query         = $Query
            options       = @{ resultFormat = "objectArray"; '$top' = 1000 }
        }
        if ($skipToken) { $body.options['$skipToken'] = $skipToken }
        $res = Invoke-AzRest -Method POST -Url "/providers/Microsoft.ResourceGraph/resources" -UriParameters @("api-version=$ApiVersionArg") -Body $body
        if (-not $res.Success -or -not $res.Data) { return $null }
        if ($res.Data.data) { $all += @($res.Data.data) }
        $skipToken = $null
        $stProp = $res.Data.PSObject.Properties['$skipToken']
        if ($stProp -and $stProp.Value) { $skipToken = [string]$stProp.Value }
    } while ($skipToken)
    return ,$all
}

function Get-HciVmInstanceUrl {
    param([string]$ArcMachineId)
    return "$ArcMachineId/providers/Microsoft.AzureStackHCI/virtualMachineInstances/default"
}

function Get-HciVmInstance {
    param([string]$VmInstanceUrl)
    return Invoke-AzRest -Method GET -Url $VmInstanceUrl -UriParameters @("api-version=$ApiVersionHci")
}

# Wartet bis der Power State einem der erwarteten Werte entspricht
function Wait-HciVmPowerState {
    param(
        [string]$VmInstanceUrl,
        [string[]]$ExpectedStates,
        [int]$TimeoutSec
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
        Start-Sleep -Seconds $PollIntervalSec
        $vm = Get-HciVmInstance -VmInstanceUrl $VmInstanceUrl
        if ($vm.Success -and $vm.Data) {
            $state = [string]$vm.Data.properties.status.powerState
            if ($ExpectedStates -contains $state) { return $state }
            Write-Log ("Status: {0} ({1}s)" -f $state, [int]$sw.Elapsed.TotalSeconds) "Run" 4
        }
    }
    return $null
}

# Wartet bis die RAM-Aenderung uebernommen wurde (provisioningState Succeeded + memoryMB = Ziel)
function Wait-HciVmMemoryUpdate {
    param(
        [string]$VmInstanceUrl,
        [int]$ExpectedMemoryMB,
        [int]$TimeoutSec
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
        Start-Sleep -Seconds $PollIntervalSec
        $vm = Get-HciVmInstance -VmInstanceUrl $VmInstanceUrl
        if ($vm.Success -and $vm.Data) {
            $prov = [string]$vm.Data.properties.provisioningState
            $mem  = [int]$vm.Data.properties.hardwareProfile.memoryMB
            if ($prov -eq "Failed") { return "Failed" }
            if ($prov -eq "Succeeded" -and $mem -eq $ExpectedMemoryMB) { return "Succeeded" }
            Write-Log ("Provisioning: {0} | RAM: {1} MB ({2}s)" -f $prov, $mem, [int]$sw.Elapsed.TotalSeconds) "Run" 4
        }
    }
    return $null
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Section "PRE-CHECK"

# --- PowerShell Version / Modus -------------------------------------------------
$psVer = $PSVersionTable.PSVersion
Write-Log "PowerShell Version: $psVer (Modus: $PowerShellMode)" "Info"
if ($PowerShellMode -eq "Seven" -and $psVer.Major -lt 7) {
    Write-Log "Modus 'Seven' erfordert PowerShell 7.x - Abbruch" "Error"
    exit 1
}
if ($psVer -ge [Version]"7.3") {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Log "PSNativeCommandUseErrorActionPreference deaktiviert (PS 7.3+)" "Info" 4
}

# --- Azure CLI vorhanden? ---------------------------------------------------------
Write-Log "Pruefe Azure CLI..." "Info"
$azCmd = Get-Command az -ErrorAction SilentlyContinue
if (-not $azCmd) {
    Write-Log "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecli" "Error"
    exit 1
}
$azVerRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $azVerRaw) {
    Write-Log "Azure CLI Version konnte nicht ermittelt werden (az --version)" "Error"
    exit 1
}
$azCliVersion = "0.0.0"
try {
    $azVerObj = ($azVerRaw -join "`n") | ConvertFrom-Json
    $azCliVersion = [string]$azVerObj.'azure-cli'
} catch { }
Write-Log "Azure CLI gefunden: $azCliVersion" "Ok"

# --- Azure CLI aktuell? -----------------------------------------------------------
$azVerParsed = $null
try { $azVerParsed = [Version]($azCliVersion -replace "[^0-9\.].*$", "") } catch { }
if ($azVerParsed -and $azVerParsed -lt [Version]$MinAzCliVersion) {
    Write-Log "Azure CLI $azCliVersion ist aelter als Mindestversion $MinAzCliVersion - bitte 'az upgrade' ausfuehren" "Error"
    exit 1
}
$latestAzCli = $null
try {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/Azure/azure-cli/releases/latest" -TimeoutSec 10 -ErrorAction Stop
    $latestAzCli = ([string]$rel.tag_name) -replace "^azure-cli-", ""
} catch { }
if ($latestAzCli -and $azVerParsed) {
    $latestParsed = $null
    try { $latestParsed = [Version]$latestAzCli } catch { }
    if ($latestParsed -and $latestParsed -gt $azVerParsed) {
        Write-Log "Neuere Azure CLI Version verfuegbar: $latestAzCli (installiert: $azCliVersion) - 'az upgrade'" "Warn"
    } else {
        Write-Log "Azure CLI ist aktuell" "Ok"
    }
} else {
    Write-Log "Aktualitaet konnte nicht online geprueft werden - ggf. 'az upgrade' ausfuehren" "Info"
}

# --- Azure Login vorhanden? -------------------------------------------------------
Write-Log "Pruefe Azure Login (az account show)..." "Info"
$acctRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json", "--only-show-errors")
$acctExit = $LASTEXITCODE
Write-Log "az account show beendet (ExitCode: $acctExit)" "Info" 4
Write-Log ("Ausgabe erhalten: {0} Zeile(n)" -f @($acctRaw).Count) "Info" 4
if ($acctExit -ne 0 -or -not $acctRaw) {
    Write-Log "Kein gueltiger Login vorhanden - starte 'az login'" "Warn"
    & az login --output none --only-show-errors
    if (-not (Assert-AzSuccess -Action "az login")) { exit 1 }
    $acctRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json", "--only-show-errors")
    if (-not (Assert-AzSuccess -Action "az account show")) { exit 1 }
}
$acct = $null
try {
    $acct = ($acctRaw -join "`n") | ConvertFrom-Json
} catch {
    Write-Log "Ausgabe von 'az account show' konnte nicht als JSON gelesen werden" "Error"
    Write-Host ($acctRaw -join "`n") -ForegroundColor Red
    exit 1
}
Write-Log "JSON ausgewertet" "Info" 4
if (-not $acct -or -not $acct.id) {
    Write-Log "Keine Subscription-Informationen erhalten - bitte 'az account show' manuell pruefen" "Error"
    exit 1
}

if ($SubscriptionId -and ($acct.id -ne $SubscriptionId)) {
    Write-Log "Wechsle Subscription auf $SubscriptionId" "Info"
    & az account set --subscription $SubscriptionId --output none
    if (-not (Assert-AzSuccess -Action "az account set")) { exit 1 }
    $acctRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    if (-not (Assert-AzSuccess -Action "az account show")) { exit 1 }
    $acct = ($acctRaw -join "`n") | ConvertFrom-Json
}
$SubscriptionId = [string]$acct.id
Write-Log ("Login vorhanden: {0}" -f $acct.user.name) "Ok"
Write-Log ("Subscription: {0} ({1})" -f $acct.name, $acct.id) "Info" 4

# =============================================================================
# [ VERSION ]
# =============================================================================
Write-Section "VERSION"
Write-Log "Script-Version: $ScriptVersion" "Info"
Write-Log "Ziel-RAM: $TargetMemoryMB MB | Nach Aenderung starten: $StartAfterChange | WhatIf: $WhatIfMode" "Info"
if ($CustomLocationFilter) { Write-Log "Filter Custom Location: $CustomLocationFilter" "Info" }
Write-Log "Drain-Mode wird NICHT gesetzt - aktive Sessions laufender Hosts werden beim Stopp getrennt" "Warn"

# =============================================================================
# [ ERMITTLUNG ] - Host Pools, Session Hosts, Azure Local VMs
# =============================================================================
Write-Section "ERMITTLUNG"
$inventory      = @()
$skippedNonHci  = 0
$skippedNoVm    = 0
$skippedFilter  = 0
$argOk          = $false

$QuerySessionHosts = "desktopvirtualizationresources " +
    "| where type =~ 'microsoft.desktopvirtualization/hostpools/sessionhosts' " +
    "| project id, arcResourceId = tostring(properties.resourceId), avdStatus = tostring(properties.status), sessions = toint(properties.sessions)"
$QueryHciVms = "resources " +
    "| where type =~ 'microsoft.azurestackhci/virtualmachineinstances' " +
    "| project id, resourceGroup, customLocation = tostring(extendedLocation.name), " +
    "processors = toint(properties.hardwareProfile.processors), memoryMB = toint(properties.hardwareProfile.memoryMB), " +
    "vmSize = tostring(properties.hardwareProfile.vmSize), powerState = tostring(properties.status.powerState), " +
    "dynMinMB = toint(properties.hardwareProfile.dynamicMemoryConfig.minimumMemoryMB), " +
    "dynMaxMB = toint(properties.hardwareProfile.dynamicMemoryConfig.maximumMemoryMB)"

if ($UseResourceGraph) {
    Write-Log "Lese AVD Session Hosts ueber Azure Resource Graph..." "Run"
    $argHosts = Invoke-ArgQuery -Query $QuerySessionHosts
    Write-Log "Lese Azure Local VM-Instanzen ueber Azure Resource Graph..." "Run"
    $argVms = Invoke-ArgQuery -Query $QueryHciVms

    if (($null -ne $argHosts) -and ($null -ne $argVms)) {
        $argOk = $true
        Write-Log ("{0} Session Host(s) und {1} Azure Local VM(s) in der Subscription gefunden" -f $argHosts.Count, $argVms.Count) "Ok"

        # Zuordnung: Arc-Maschinen-ID (ohne VM-Instanz-Suffix) bzw. VM-Name -> VM-Instanz
        $vmById   = @{}
        $vmByName = @{}
        foreach ($v in $argVms) {
            $arcId = ([string]$v.id) -replace '(?i)/providers/Microsoft\.AzureStackHCI/virtualMachineInstances/default$', ''
            $vmById[$arcId.ToLower()] = $v
            $vmByName[($arcId.Split("/")[-1]).ToLower()] = $v
        }

        foreach ($sh in $argHosts) {
            $segs       = ([string]$sh.id).Split("/")
            $shFullName = $segs[-1]
            $hpName     = $segs[-3]
            $vmName     = $shFullName.Split(".")[0]
            $resourceId = [string]$sh.arcResourceId
            $v = $null

            if ($resourceId) {
                if ($resourceId -notmatch "/providers/Microsoft\.HybridCompute/machines/") {
                    # z.B. klassische Azure VM -> nicht Azure Local
                    $skippedNonHci++
                    continue
                }
                if ($vmById.ContainsKey($resourceId.ToLower())) { $v = $vmById[$resourceId.ToLower()] }
            } elseif ($vmByName.ContainsKey($vmName.ToLower())) {
                $v = $vmByName[$vmName.ToLower()]
            }

            if (-not $v) {
                $skippedNoVm++
                Write-Log "$shFullName : keine Azure Local VM-Instanz gefunden - uebersprungen" "Warn" 4
                continue
            }

            $arcId   = ([string]$v.id) -replace '(?i)/providers/Microsoft\.AzureStackHCI/virtualMachineInstances/default$', ''
            $custLoc = ""
            if ($v.customLocation) { $custLoc = ([string]$v.customLocation).Split("/")[-1] }
            if ($CustomLocationFilter -and ($custLoc -ne $CustomLocationFilter)) {
                $skippedFilter++
                continue
            }
            $powerState = [string]$v.powerState
            if (-not $powerState) { $powerState = "Unknown" }

            $inventory += [PSCustomObject]@{
                HostPool       = $hpName
                SessionHost    = $shFullName
                VmName         = $vmName
                VmRG           = [string]$v.resourceGroup
                CustomLocation = $custLoc
                MemoryMB       = [int]$v.memoryMB
                DynMinMB       = [int]$v.dynMinMB
                DynMaxMB       = [int]$v.dynMaxMB
                vCPU           = [int]$v.processors
                VmSize         = [string]$v.vmSize
                PowerState     = $powerState
                AvdStatus      = [string]$sh.avdStatus
                Sessions       = [int]$sh.sessions
                ArcMachineId   = $arcId
                VmInstanceUrl  = (Get-HciVmInstanceUrl -ArcMachineId $arcId)
            }
        }
        Write-Log "Hinweis: Power State aus Resource Graph kann wenige Minuten verzoegert sein - vor jeder Aenderung wird die VM aktuell geprueft" "Info"
    } else {
        Write-Log "Resource Graph Abfrage fehlgeschlagen - Fallback auf Einzelabfragen pro Host Pool / Session Host" "Warn"
    }
}

if (-not $argOk) {
Write-Log "Lese AVD Host Pools der Subscription (Einzelabfragen)..." "Run"
$hostPools = Get-AzRestList -Url "/subscriptions/$SubscriptionId/providers/Microsoft.DesktopVirtualization/hostPools" -ApiVersion $ApiVersionAvd
if ($null -eq $hostPools) {
    Write-Log "Host Pools konnten nicht gelesen werden" "Error"
    exit 1
}
Write-Log ("{0} Host Pool(s) gefunden" -f $hostPools.Count) "Ok"

foreach ($hp in $hostPools) {
    $hpName = [string]$hp.name
    $hpRg   = ([string]$hp.id).Split("/")[4]
    Write-Log "Host Pool: $hpName (RG: $hpRg)" "Run"

    $sessionHosts = Get-AzRestList -Url "$($hp.id)/sessionHosts" -ApiVersion $ApiVersionAvd
    if ($null -eq $sessionHosts) {
        Write-Log "Session Hosts von $hpName konnten nicht gelesen werden" "Warn" 4
        continue
    }
    Write-Log ("{0} Session Host(s)" -f $sessionHosts.Count) "Info" 4

    foreach ($sh in $sessionHosts) {
        $shFullName = ([string]$sh.name).Split("/")[-1]
        $vmName     = $shFullName.Split(".")[0]
        $resourceId = [string]$sh.properties.resourceId

        # Fallback: resourceId leer -> Arc-Maschine ueber den Namen suchen
        if (-not $resourceId) {
            $arcRaw = Invoke-AzQuiet -Arguments @("resource", "list", "--resource-type", "Microsoft.HybridCompute/machines", "--name", $vmName, "--query", "[0].id", "--output", "tsv")
            if ($LASTEXITCODE -eq 0 -and $arcRaw) { $resourceId = ([string]($arcRaw -join "")).Trim() }
        }

        if (-not $resourceId -or ($resourceId -notmatch "/providers/Microsoft\.HybridCompute/machines/")) {
            # Kein Arc-Host -> z.B. klassische Azure VM -> nicht Azure Local
            $skippedNonHci++
            continue
        }

        $vmInstanceUrl = Get-HciVmInstanceUrl -ArcMachineId $resourceId
        $vmRes = Get-HciVmInstance -VmInstanceUrl $vmInstanceUrl
        if (-not $vmRes.Success -or -not $vmRes.Data) {
            # Arc-Maschine ohne Azure Local VM-Instanz (z.B. physischer Server)
            $skippedNoVm++
            Write-Log "$shFullName : keine Azure Local VM-Instanz gefunden - uebersprungen" "Warn" 4
            continue
        }

        $vm       = $vmRes.Data
        $vmRg     = $resourceId.Split("/")[4]
        $custLoc  = ""
        if ($vm.extendedLocation -and $vm.extendedLocation.name) {
            $custLoc = ([string]$vm.extendedLocation.name).Split("/")[-1]
        }
        if ($CustomLocationFilter -and ($custLoc -ne $CustomLocationFilter)) {
            $skippedFilter++
            continue
        }

        $cpu      = 0
        $memMb    = 0
        $dynMin   = 0
        $dynMax   = 0
        $vmSize   = ""
        if ($vm.properties.hardwareProfile) {
            $cpu    = [int]$vm.properties.hardwareProfile.processors
            $memMb  = [int]$vm.properties.hardwareProfile.memoryMB
            $vmSize = [string]$vm.properties.hardwareProfile.vmSize
            if ($vm.properties.hardwareProfile.dynamicMemoryConfig) {
                $dynMin = [int]$vm.properties.hardwareProfile.dynamicMemoryConfig.minimumMemoryMB
                $dynMax = [int]$vm.properties.hardwareProfile.dynamicMemoryConfig.maximumMemoryMB
            }
        }
        $powerState = [string]$vm.properties.status.powerState
        if (-not $powerState) { $powerState = "Unknown" }

        $inventory += [PSCustomObject]@{
            HostPool       = $hpName
            SessionHost    = $shFullName
            VmName         = $vmName
            VmRG           = $vmRg
            CustomLocation = $custLoc
            MemoryMB       = $memMb
            DynMinMB       = $dynMin
            DynMaxMB       = $dynMax
            vCPU           = $cpu
            VmSize         = $vmSize
            PowerState     = $powerState
            AvdStatus      = [string]$sh.properties.status
            Sessions       = [int]$sh.properties.sessions
            ArcMachineId   = $resourceId
            VmInstanceUrl  = $vmInstanceUrl
        }
    }
}
}

if ($skippedNonHci -gt 0) { Write-Log "$skippedNonHci Session Host(s) uebersprungen: keine Azure Local VM (z.B. Azure VM)" "Info" }
if ($skippedNoVm -gt 0)   { Write-Log "$skippedNoVm Session Host(s) uebersprungen: Arc-Host ohne VM-Instanz" "Info" }
if ($skippedFilter -gt 0) { Write-Log "$skippedFilter Session Host(s) uebersprungen: Custom Location Filter" "Info" }

if ($inventory.Count -eq 0) {
    Write-Log "Keine AVD Session Hosts auf Azure Local gefunden - nichts zu tun" "Warn"
    exit 0
}

# =============================================================================
# [ UEBERSICHT ]
# =============================================================================
Write-Section "UEBERSICHT"
$inventory | Sort-Object HostPool, VmName |
    Format-Table HostPool, VmRG, VmName, CustomLocation, MemoryMB, DynMinMB, DynMaxMB, vCPU, PowerState, AvdStatus, Sessions -AutoSize |
    Out-String -Width 220 | Write-Host

$needChange = @($inventory | Where-Object { $_.MemoryMB -ne $TargetMemoryMB })
$alreadyOk  = @($inventory | Where-Object { $_.MemoryMB -eq $TargetMemoryMB })
$dynMismatch = @($needChange | Where-Object { ($_.DynMaxMB -gt 0) -and (($TargetMemoryMB -gt $_.DynMaxMB) -or ($TargetMemoryMB -lt $_.DynMinMB)) })
$running    = @($needChange | Where-Object { $_.PowerState -notin @("Stopped", "Deallocated") })

Write-Log ("Gesamt: {0} | Bereits auf {1} MB: {2} | Anzupassen: {3} | davon eingeschaltet: {4}" -f $inventory.Count, $TargetMemoryMB, $alreadyOk.Count, $needChange.Count, $running.Count) "Info"
if ($dynMismatch.Count -gt 0) {
    if ($SkipOnDynamicMemoryMismatch) {
        Write-Log ("{0} VM(s) mit Dynamic Memory, deren Min/Max-Bereich den Zielwert nicht einschliesst - werden uebersprungen" -f $dynMismatch.Count) "Warn"
    } else {
        Write-Log ("{0} VM(s) mit Dynamic Memory, deren Min/Max-Bereich den Zielwert nicht einschliesst - Update wird trotzdem versucht" -f $dynMismatch.Count) "Warn"
    }
}
$activeSessions = ($running | Measure-Object -Property Sessions -Sum).Sum
if ($activeSessions -gt 0) {
    Write-Log "$activeSessions aktive Session(s) auf eingeschalteten Hosts werden beim Stopp getrennt (kein Drain)" "Warn"
}

if ($needChange.Count -eq 0) {
    Write-Log "Alle Session Hosts haben bereits $TargetMemoryMB MB RAM - nichts zu tun" "Ok"
    exit 0
}

# =============================================================================
# [ AUSWAHL ] - Alle Host Pools oder nur ein bestimmter
# =============================================================================
Write-Section "AUSWAHL"
$hpList = @($needChange | Group-Object HostPool | Sort-Object Name)
Write-Host "Host Pools mit anzupassenden Session Hosts:" -ForegroundColor White
$idx = 1
foreach ($g in $hpList) {
    $cntRun = @($g.Group | Where-Object { $_.PowerState -notin @("Stopped", "Deallocated") }).Count
    $rgs    = (@($g.Group | Select-Object -ExpandProperty VmRG -Unique) -join ", ")
    Write-Host ("    [{0}] {1}  ({2} anzupassen, davon {3} eingeschaltet | RG: {4})" -f $idx, $g.Name, $g.Count, $cntRun, $rgs) -ForegroundColor Cyan
    $idx++
}
Write-Host "    [A] Alle Host Pools" -ForegroundColor Cyan
Write-Host "    [Q] Abbrechen" -ForegroundColor Cyan

$targets = $null
while ($null -eq $targets) {
    $choice = (Read-Host "Auswahl (Nummer / A / Q)").Trim().ToUpper()
    if ($choice -eq "Q") {
        Write-Log "Abbruch durch Benutzer" "Warn"
        exit 0
    } elseif ($choice -eq "A") {
        $targets = $needChange
        Write-Log "Auswahl: ALLE Host Pools" "Info"
    } elseif ($choice -match "^\d+$" -and [int]$choice -ge 1 -and [int]$choice -le $hpList.Count) {
        $selHp = $hpList[[int]$choice - 1].Name
        $targets = @($needChange | Where-Object { $_.HostPool -eq $selHp })
        Write-Log "Auswahl: nur Host Pool '$selHp'" "Info"
    } else {
        Write-Log "Ungueltige Eingabe" "Warn"
    }
}

Write-Host ""
Write-Host "Folgende Session Hosts werden auf $TargetMemoryMB MB RAM angepasst:" -ForegroundColor White
$targets | Sort-Object HostPool, VmName |
    Format-Table HostPool, VmRG, VmName, MemoryMB, DynMinMB, DynMaxMB, PowerState, Sessions -AutoSize |
    Out-String -Width 220 | Write-Host

if ($WhatIfMode) {
    Write-Log "WhatIf-Modus aktiv - es werden keine Aenderungen durchgefuehrt" "Warn"
    exit 0
}

$confirm = Read-Host ("Zum Fortfahren 'JA' eingeben ({0} Session Host(s), kein Drain, laufende VMs werden gestoppt)" -f $targets.Count)
if ($confirm -ne "JA") {
    Write-Log "Keine Bestaetigung - Abbruch" "Warn"
    exit 0
}

# =============================================================================
# [ VERARBEITUNG ]
# =============================================================================
Write-Section "VERARBEITUNG"
$results = @()
$counter = 0

foreach ($t in ($targets | Sort-Object HostPool, VmName)) {
    $counter++
    $wasRunning = $false
    $outcome    = "Unbekannt"
    $memAfter   = $t.MemoryMB

    Write-Host ""
    Write-Log ("[{0}/{1}] {2} (HostPool: {3}, RG: {4}) - aktuell {5} MB RAM, {6}" -f $counter, $targets.Count, $t.VmName, $t.HostPool, $t.VmRG, $t.MemoryMB, $t.PowerState) "Run"

    # --- Aktuellen Zustand frisch lesen ---------------------------------------------
    $cur = Get-HciVmInstance -VmInstanceUrl $t.VmInstanceUrl
    if (-not $cur.Success -or -not $cur.Data) {
        Write-Log "VM-Instanz konnte nicht gelesen werden - uebersprungen" "Error" 4
        $results += [PSCustomObject]@{ VmName = $t.VmName; HostPool = $t.HostPool; Vorher = $t.MemoryMB; Nachher = $t.MemoryMB; Ergebnis = "Fehler: Lesen" }
        continue
    }
    $powerState = [string]$cur.Data.properties.status.powerState
    $memNow     = [int]$cur.Data.properties.hardwareProfile.memoryMB
    $cpuNow     = [int]$cur.Data.properties.hardwareProfile.processors
    $dynMin     = 0
    $dynMax     = 0
    if ($cur.Data.properties.hardwareProfile.dynamicMemoryConfig) {
        $dynMin = [int]$cur.Data.properties.hardwareProfile.dynamicMemoryConfig.minimumMemoryMB
        $dynMax = [int]$cur.Data.properties.hardwareProfile.dynamicMemoryConfig.maximumMemoryMB
    }

    if ($memNow -eq $TargetMemoryMB) {
        Write-Log "Bereits auf $TargetMemoryMB MB RAM - uebersprungen" "Ok" 4
        $results += [PSCustomObject]@{ VmName = $t.VmName; HostPool = $t.HostPool; Vorher = $memNow; Nachher = $memNow; Ergebnis = "Bereits OK" }
        continue
    }

    if (($dynMax -gt 0) -and (($TargetMemoryMB -gt $dynMax) -or ($TargetMemoryMB -lt $dynMin))) {
        if ($SkipOnDynamicMemoryMismatch) {
            Write-Log "Dynamic Memory aktiv (Min: $dynMin MB / Max: $dynMax MB), Zielwert ausserhalb des Bereichs - uebersprungen" "Warn" 4
            $results += [PSCustomObject]@{ VmName = $t.VmName; HostPool = $t.HostPool; Vorher = $memNow; Nachher = $memNow; Ergebnis = "Uebersprungen: Dynamic Memory" }
            continue
        }
        Write-Log "Dynamic Memory aktiv (Min: $dynMin MB / Max: $dynMax MB), Zielwert ausserhalb des Bereichs - Update wird versucht" "Warn" 4
    }

    # --- Stoppen falls eingeschaltet ------------------------------------------------
    if ($powerState -notin @("Stopped", "Deallocated")) {
        $wasRunning = $true
        Write-Log "VM ist '$powerState' - wird gestoppt (kein Drain)" "Warn" 4
        $stopRes = Invoke-AzRest -Method POST -Url "$($t.VmInstanceUrl)/stop" -UriParameters @("api-version=$ApiVersionHci")
        if (-not $stopRes.Success) {
            Write-Log "Stop-Befehl fehlgeschlagen (ExitCode: $($stopRes.ExitCode)) - uebersprungen" "Error" 4
            $results += [PSCustomObject]@{ VmName = $t.VmName; HostPool = $t.HostPool; Vorher = $memNow; Nachher = $memNow; Ergebnis = "Fehler: Stop" }
            continue
        }
        $state = Wait-HciVmPowerState -VmInstanceUrl $t.VmInstanceUrl -ExpectedStates @("Stopped", "Deallocated") -TimeoutSec $StopTimeoutSec
        if (-not $state) {
            Write-Log "VM wurde innerhalb von $StopTimeoutSec s nicht gestoppt - uebersprungen" "Error" 4
            $results += [PSCustomObject]@{ VmName = $t.VmName; HostPool = $t.HostPool; Vorher = $memNow; Nachher = $memNow; Ergebnis = "Fehler: Stop-Timeout" }
            continue
        }
        Write-Log "VM gestoppt ($state)" "Ok" 4
    } else {
        Write-Log "VM ist bereits ausgeschaltet ($powerState)" "Ok" 4
    }

    # --- RAM anpassen -----------------------------------------------------------------
    # vmSize "Custom" ist fuer frei definierte Werte erforderlich; processors wird mitgegeben,
    # damit die vCPU-Anzahl beim Wechsel auf Custom unveraendert bleibt.
    Write-Log "Setze RAM von $memNow MB auf $TargetMemoryMB MB..." "Run" 4
    $body = @{
        properties = @{
            hardwareProfile = @{
                vmSize     = "Custom"
                processors = $cpuNow
                memoryMB   = $TargetMemoryMB
            }
        }
    }
    $patchRes = Invoke-AzRest -Method PATCH -Url $t.VmInstanceUrl -UriParameters @("api-version=$ApiVersionHci") -Body $body
    if (-not $patchRes.Success) {
        Write-Log "Update-Befehl fehlgeschlagen (ExitCode: $($patchRes.ExitCode))" "Error" 4
        $outcome = "Fehler: Update"
    } else {
        $upd = Wait-HciVmMemoryUpdate -VmInstanceUrl $t.VmInstanceUrl -ExpectedMemoryMB $TargetMemoryMB -TimeoutSec $UpdateTimeoutSec
        $verify = Get-HciVmInstance -VmInstanceUrl $t.VmInstanceUrl
        if ($verify.Success -and $verify.Data) { $memAfter = [int]$verify.Data.properties.hardwareProfile.memoryMB }
        if ($upd -eq "Succeeded" -and $memAfter -eq $TargetMemoryMB) {
            Write-Log "RAM erfolgreich auf $memAfter MB gesetzt" "Ok" 4
            $outcome = "Angepasst"
        } elseif ($upd -eq "Failed") {
            Write-Log "Update fehlgeschlagen (provisioningState Failed) - RAM aktuell: $memAfter MB" "Error" 4
            $outcome = "Fehler: Provisioning"
        } else {
            Write-Log "Update nicht innerhalb von $UpdateTimeoutSec s bestaetigt - RAM aktuell: $memAfter MB" "Warn" 4
            $outcome = "Unbestaetigt"
        }
    }

    # --- Optional wieder starten ------------------------------------------------------
    if ($wasRunning -and $StartAfterChange) {
        Write-Log "Starte VM wieder..." "Run" 4
        $startRes = Invoke-AzRest -Method POST -Url "$($t.VmInstanceUrl)/start" -UriParameters @("api-version=$ApiVersionHci")
        if (-not $startRes.Success) {
            Write-Log "Start-Befehl fehlgeschlagen (ExitCode: $($startRes.ExitCode))" "Error" 4
            $outcome += " / Start-Fehler"
        } else {
            $state = Wait-HciVmPowerState -VmInstanceUrl $t.VmInstanceUrl -ExpectedStates @("Running") -TimeoutSec $StartTimeoutSec
            if ($state) {
                Write-Log "VM laeuft wieder" "Ok" 4
            } else {
                Write-Log "VM-Start innerhalb von $StartTimeoutSec s nicht bestaetigt - bitte pruefen" "Warn" 4
                $outcome += " / Start unbestaetigt"
            }
        }
    } elseif ($wasRunning) {
        Write-Log "VM bleibt ausgeschaltet (StartAfterChange = false)" "Info" 4
    }

    $results += [PSCustomObject]@{ VmName = $t.VmName; HostPool = $t.HostPool; Vorher = $memNow; Nachher = $memAfter; Ergebnis = $outcome }
}

# =============================================================================
# [ ZUSAMMENFASSUNG ]
# =============================================================================
Write-Section "ZUSAMMENFASSUNG"
$results | Format-Table VmName, HostPool, Vorher, Nachher, Ergebnis -AutoSize | Out-String -Width 220 | Write-Host

$okCount   = @($results | Where-Object { $_.Ergebnis -like "Angepasst*" }).Count
$skipCount = @($results | Where-Object { $_.Ergebnis -eq "Bereits OK" -or $_.Ergebnis -like "Uebersprungen*" }).Count
$errCount  = @($results | Where-Object { $_.Ergebnis -like "Fehler*" -or $_.Ergebnis -like "Unbestaetigt*" }).Count

Write-Log "Angepasst: $okCount | Bereits OK / Uebersprungen: $skipCount | Fehler/Unbestaetigt: $errCount" "Info"
if ($errCount -gt 0) {
    Write-Log "Mindestens ein Session Host konnte nicht (vollstaendig) angepasst werden - bitte pruefen" "Warn"
    Write-Separator
    exit 2
}
Write-Log "Alle ausgewaehlten Session Hosts wurden verarbeitet" "Ok"
Write-Separator
exit 0
