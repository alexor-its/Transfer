﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Weist fuer jede Host-Pool- bzw. Session-Host-Resource-Group die Built-in Azure Policy
    zur Zuordnung der Standard-AVD-Insights-DCR (microsoft-avdi-<region>) zu.

.DESCRIPTION
    Das Script
      1. prueft, ob die Insights-DCR "microsoft-avdi-<region>" existiert (sonst Abbruch mit Hinweis)
      2. prueft bzw. erstellt eine User-assigned Managed Identity fuer die Policy-Zuweisungen
      3. ermittelt alle AVD Host Pools der Subscription (optional gefiltert) und leitet daraus
         die Resource Groups der Session Hosts ab (ueber die VM-Resource-IDs der Session Hosts;
         hat ein Host Pool noch keine Session Hosts, wird die RG des Host Pools verwendet)
      4. weist pro ermittelter Resource Group die Built-in Policy
         "Configure Windows Machines to be associated with a Data Collection Rule
          or a Data Collection Endpoint" (DeployIfNotExists) mit der Insights-DCR zu
      5. vergibt die benoetigten Rollen an die Managed Identity
      6. erstellt pro Zuweisung einen Remediation Task fuer bestehende Session Hosts

    MODUS "Cleanup" ($Mode): entfernt die Policy-Zuweisungen inkl. Remediation Tasks je RG,
    optional die Associations zur Insights-DCR und die Managed Identity. Die Insights-DCR
    selbst bleibt immer bestehen. Obsolete Zuweisungen frueherer Versionen (-NN) werden in
    jedem Modus automatisch entfernt.

    Alternativ kann die Liste der Resource Groups manuell vorgegeben werden
    (Variable $ManualResourceGroupNames), dann entfaellt die automatische Ermittlung.

    Alle Azure-Aufrufe erfolgen ueber die Azure CLI (az) in PowerShell. Die Host-Pool-
    und Session-Host-Abfragen laufen ueber "az rest", damit keine CLI-Extension noetig ist.

.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-20
    Version     : 2.2.1
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================

    Changelog
    2.2.1  Fix Windows/az.cmd: Query-Parameter per --uri-parameters statt in der URL
           (ein & in der URL zerlegte den Aufruf: Zuweisungslisten scheiterten)
    2.2.0  Cleanup entfernt die Managed Identity standardmaessig (sofern nicht mehr in
           Benutzung); Restbestand an Insights-Associations wird ausgewiesen
    2.1.3  Remediation-Loeschung wartet per Polling auf den Endzustand nach Cancel
    2.1.2  Subscription immer aus dem aktiven az-Login-Kontext (kein Hardcoding)
    2.1.1  Fix: leere ARM-Listen sind kein Fehler; Lesefehler zeigen die az-Meldung;
           Zuweisungslisten ohne $filter, Scope-Abgleich clientseitig
    2.1.0  Pflicht-Bereinigung obsoleter Zuweisungen (-NN) in jedem Modus, Entfernung
           abgeschlossener Remediation Tasks vor jeder neuen Remediation
    2.0.0  Cleanup-Modus (Zuweisungen inkl. Remediations, Legacy-Namen, optional
           Associations und Managed Identity)
    1.3.0  Remediation-Modus "Auto" (neu -> ReEvaluateCompliance, bestehend ->
           ExistingNonCompliant), kein blockierender Scan mehr
    1.2.0  Remediation-Modus konfigurierbar (Standard ExistingNonCompliant),
           optionaler Compliance-Scan vor der Remediation, Arc-aware Ausgabe
    1.1.0  Policy-Zuweisung, Identity-Nachruestung und Remediation ueber az rest
           (ARM-API) statt az policy, da das aaz-basierte Policy-Modul der CLI
           Built-in-Definitionen nicht zuverlaessig aufloest; korrekte Built-in-GUID
    1.0.0  Erstversion

.EXAMPLE
    .\Set-AvdInsightsDcrPolicy.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - Parameter werden im Script hinterlegt
# =============================================================================
$ScriptName     = "Set-AvdInsightsDcrPolicy.ps1"
$ScriptVersion  = "2.2.1"
$PowerShellMode = "Compat"      # "Compat" = PS 5.1 + 7.x | "Seven" = nur PS 7.x

# --- Betriebsmodus ------------------------------------------------------------
$Mode = "Deploy"                # "Deploy" | "Cleanup"

# --- Azure Ziel ---------------------------------------------------------------
# Subscription: aktuelle Subscription des az-Login-Kontexts
$Location     = "westeurope"                # ARM-Kurzname, bestimmt den Insights-DCR-Namen

# --- Insights-DCR (Voraussetzung) --------------------------------------------
$InsightsDcrName              = "microsoft-avdi-$Location"
$InsightsDcrResourceGroupName = "rg-avdmgmt"   # leer lassen = subscriptionweit suchen

# --- Host-Pool-Ermittlung -----------------------------------------------------
$HostPoolNameFilter        = @()            # leer = alle Host Pools; sonst z.B. @("hostpool1-test")
$ManualResourceGroupNames  = @()            # gesetzt = keine automatische Ermittlung, z.B. @("rg-avd-hosts-01")
$UseHostPoolRgIfNoSessionHosts = $true      # Host Pool ohne Session Hosts -> RG des Host Pools verwenden
$DesktopVirtualizationApiVersion = "2024-04-03"

# --- Managed Identity (user-assigned) -----------------------------------------
$ManagedIdentityName              = "id-avd-dcr-policy"
$ManagedIdentityResourceGroupName = "rg-avdmgmt"

# --- Azure Policy -------------------------------------------------------------
$PolicyAssignmentName        = "avd-insights-dcr-assoc"
$PolicyAssignmentDisplayName = "AVD Insights - Session Hosts mit Insights-DCR verknuepfen"
$RemediationNamePrefix       = "rem-avd-insights-dcr"
$CreateRemediationTask       = $true
$RemediationDiscoveryMode    = "Auto"      # "Auto": neue Zuweisung -> ReEvaluateCompliance (laeuft serverseitig),
                             #         bestehende Zuweisung -> ExistingNonCompliant
                             # oder fest: "ExistingNonCompliant" | "ReEvaluateCompliance"
$TriggerComplianceScanFirst  = $false     # optional: Scan je RG asynchron anstossen (az rest, NICHT blockierend)

$DcrPolicyDisplayName    = "Configure Windows Machines to be associated with a Data Collection Rule or a Data Collection Endpoint"
$DcrPolicyDefinitionGuid = "eab1f514-22e3-42e3-9a1f-e1dc9199355c"
$PolicyApiVersion        = "2023-04-01"      # Microsoft.Authorization/policyAssignments + policyDefinitions
$RemediationApiVersion   = "2021-10-01"      # Microsoft.PolicyInsights/remediations
$PolicyRoleNames         = @("Monitoring Contributor", "Log Analytics Contributor")

# --- Pflicht-Bereinigung (laeuft in JEDEM Modus, kein Schalter) ---------------
# Obsolete Zuweisungen frueherer Script-Versionen (avd-insights-dcr-assoc-NN) und
# abgeschlossene Remediation Tasks werden immer entfernt.
$LegacyAssignmentPattern = "^avd-insights-dcr-assoc-\d{2}$"

# --- Cleanup-Optionen (nur bei Mode = "Cleanup") ------------------------------
$CleanupRemoveInsightsAssignments  = $true      # avd-insights-dcr-assoc je RG inkl. Remediation Tasks
$CleanupRemoveInsightsAssociations = $false     # Associations zur Insights-DCR (Vorsicht: Insights-Daten stoppen)
$CleanupRemoveManagedIdentity      = $true      # id-avd-dcr-policy inkl. Rollenzuweisungen - nur wenn keine andere Zuweisung sie mehr nutzt
$DcrApiVersion                     = "2022-06-01"

# --- Arbeitsverzeichnis -------------------------------------------------------
$WorkDirectory = Join-Path ([System.IO.Path]::GetTempPath()) "avd-insights-dcr-policy"

# =============================================================================
# [ GRUNDEINSTELLUNGEN ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Get-Timestamp { return (Get-Date -Format "HH:mm:ss") }
function Write-Line    { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$Title) Write-Host "[ $Title ]" -ForegroundColor White }
function Write-Ok      { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymOk,   $Message) -ForegroundColor Green }
function Write-Err     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymErr,  $Message) -ForegroundColor Red }
function Write-Warn    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymWarn, $Message) -ForegroundColor Yellow }
function Write-Info    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymInfo, $Message) -ForegroundColor Cyan }
function Write-Run     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymRun,  $Message) -ForegroundColor Cyan }
function Write-Sub     { param([string]$Message) Write-Host ("    {0}" -f $Message) -ForegroundColor Cyan }
function Write-SubErr  { param([string]$Message) Write-Host ("    {0}" -f $Message) -ForegroundColor Red }

# Wrapper: az-Aufruf mit unterdruecktem stderr, Argumente als Array
function Invoke-AzQuiet {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $output = & az @Arguments 2>$null
    return $output
}

# Prueft $LASTEXITCODE nach externem Aufruf
function Assert-AzSuccess {
    param([Parameter(Mandatory = $true)][string]$Action, [switch]$Fatal)
    if ($LASTEXITCODE -ne 0) {
        Write-Err "$Action fehlgeschlagen (ExitCode: $LASTEXITCODE)"
        if ($Fatal) { Write-Line; exit 1 }
        return $false
    }
    return $true
}

function Write-JsonFile {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Content)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function ConvertFrom-AzJson {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return $null }
    $text = ($RawOutput -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    return ($text | ConvertFrom-Json)
}

function ConvertFrom-AzText {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return "" }
    return (($RawOutput -join "")).Trim()
}

function Get-ResourceGroupFromId {
    param([string]$ResourceId)
    if ($ResourceId -match "/resourceGroups/([^/]+)/") { return $Matches[1] }
    return $null
}

# Baut die az-rest-Argumente fuer eine URL: Query-Parameter werden ueber --uri-parameters uebergeben.
# Grund: Unter Windows ist az eine .cmd-Datei; ein '&' in einem Argument wird von cmd.exe als
# Befehlstrenner interpretiert ('category' is not recognized...). Daher nie '&' in --url.
function Get-AzRestUrlArgs {
    param([Parameter(Mandatory = $true)][string]$Url)
    $base  = $Url
    $query = ""
    $q = $Url.IndexOf("?")
    if ($q -ge 0) {
        $base  = $Url.Substring(0, $q)
        $query = $Url.Substring($q + 1)
    }
    $restArgs = @("--url", $base)
    if (-not [string]::IsNullOrWhiteSpace($query)) {
        $restArgs += "--uri-parameters"
        foreach ($pair in $query.Split("&")) {
            if ([string]::IsNullOrWhiteSpace($pair)) { continue }
            $kv = $pair.Split("=", 2)
            $k = [System.Uri]::UnescapeDataString($kv[0])
            $v = ""
            if ($kv.Count -gt 1) { $v = [System.Uri]::UnescapeDataString($kv[1]) }
            $restArgs += ($k + "=" + $v)
        }
    }
    return ,$restArgs
}

# ARM-GET ueber az rest inkl. Paging (nextLink)
# Liefert IMMER ein Array (auch leer); $null nur bei einem echten Fehler (Meldung wird ausgegeben)
function Invoke-ArmGetAll {
    param([Parameter(Mandatory = $true)][string]$Url)
    $items = @()
    $nextUrl = $Url
    while (-not [string]::IsNullOrWhiteSpace($nextUrl)) {
        $raw = Invoke-AzQuiet -Arguments (@("rest", "--method", "get") + (Get-AzRestUrlArgs -Url $nextUrl) + @("--output", "json"))
        if ($LASTEXITCODE -ne 0) {
            # Fehler sichtbar machen: Aufruf wiederholen, stderr diesmal anzeigen
            Write-Sub "ARM GET fehlgeschlagen: $nextUrl"
            $retryArgs = @("rest", "--method", "get") + (Get-AzRestUrlArgs -Url $nextUrl) + @("--output", "none")
            & az @retryArgs
            return $null
        }
        $page = ConvertFrom-AzJson -RawOutput $raw
        if ($null -ne $page -and $null -ne $page.value) {
            foreach ($v in $page.value) { $items += $v }
        }
        $nextUrl = ""
        if ($null -ne $page -and $null -ne $page.nextLink) { $nextUrl = [string]$page.nextLink }
    }
    return ,$items
}

# ARM-GET einer einzelnen Ressource; $null wenn nicht vorhanden
function Invoke-ArmGet {
    param([Parameter(Mandatory = $true)][string]$Url)
    $raw = Invoke-AzQuiet -Arguments (@("rest", "--method", "get") + (Get-AzRestUrlArgs -Url $Url) + @("--output", "json"))
    if ($LASTEXITCODE -ne 0) { return $null }
    return (ConvertFrom-AzJson -RawOutput $raw)
}

# ARM-DELETE / POST ohne Body ueber az rest
function Invoke-ArmAction {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$Action
    )
    $actionArgs = @("rest", "--method", $Method) + (Get-AzRestUrlArgs -Url $Url) + @("--output", "none")
    & az @actionArgs
    return (Assert-AzSuccess -Action $Action)
}

# ARM-Schreibzugriff (PUT/PATCH) ueber az rest mit Body-Datei; liefert Antwortobjekt oder $null
function Invoke-ArmWrite {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][hashtable]$Body,
        [Parameter(Mandatory = $true)][string]$BodyFilePath,
        [Parameter(Mandatory = $true)][string]$Action
    )
    Write-JsonFile -Path $BodyFilePath -Content ($Body | ConvertTo-Json -Depth 10)
    $writeArgs = @("rest", "--method", $Method) + (Get-AzRestUrlArgs -Url $Url) + @("--body", "@$BodyFilePath", "--headers", "Content-Type=application/json", "--output", "json")
    $raw = & az @writeArgs
    if (-not (Assert-AzSuccess -Action $Action)) { return $null }
    return (ConvertFrom-AzJson -RawOutput $raw)
}

# Built-in Policy-Definition per GUID (ARM-GET) oder DisplayName ermitteln
# Hinweis: Bewusst ueber az rest, da das az-policy-Modul (aaz) Built-in-Definitionen
# in einigen CLI-Versionen nicht korrekt aufloest (PolicyDefinitionNotFound + NoneType-Traceback).
function Get-BuiltinPolicyDefinitionId {
    param([string]$DefinitionGuid, [Parameter(Mandatory = $true)][string]$DisplayName)
    $definitionId = $null
    if (-not [string]::IsNullOrWhiteSpace($DefinitionGuid)) {
        $url = "https://management.azure.com/providers/Microsoft.Authorization/policyDefinitions/${DefinitionGuid}?api-version=$PolicyApiVersion"
        $raw = Invoke-AzQuiet -Arguments (@("rest", "--method", "get") + (Get-AzRestUrlArgs -Url $url) + @("--output", "json"))
        if ($LASTEXITCODE -eq 0) {
            $def = ConvertFrom-AzJson -RawOutput $raw
            if ($null -ne $def -and -not [string]::IsNullOrWhiteSpace([string]$def.id)) {
                $definitionId = [string]$def.id
                Write-Sub "Built-in: $($def.properties.displayName)"
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) {
        Write-Sub "GUID-Lookup ohne Treffer - suche per DisplayName (kann etwas dauern)..."
        $query = "[?displayName=='$DisplayName'].id | [0]"
        $raw = Invoke-AzQuiet -Arguments @("policy", "definition", "list", "--query", $query, "--output", "tsv")
        if ($LASTEXITCODE -eq 0) { $definitionId = ConvertFrom-AzText -RawOutput $raw }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) { return $null }
    return $definitionId
}

function Set-RoleAssignmentWithRetry {
    param(
        [Parameter(Mandatory = $true)][string]$PrincipalId,
        [Parameter(Mandatory = $true)][string]$RoleName,
        [Parameter(Mandatory = $true)][string]$Scope,
        [int]$MaxAttempts = 6,
        [int]$DelaySeconds = 15
    )
    $attempt = 0
    $done = $false
    while (-not $done -and $attempt -lt $MaxAttempts) {
        $attempt++
        Invoke-AzQuiet -Arguments @(
            "role", "assignment", "create",
            "--assignee-object-id", $PrincipalId,
            "--assignee-principal-type", "ServicePrincipal",
            "--role", $RoleName,
            "--scope", $Scope,
            "--output", "none"
        ) | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $done = $true
            Write-Ok "Rolle '$RoleName' auf: $Scope"
        }
        else {
            Write-Warn "Rollenzuweisung '$RoleName' Versuch $attempt/$MaxAttempts fehlgeschlagen - warte $DelaySeconds s"
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $done
}

# Policy-Zuweisung anlegen oder wiederverwenden (ARM-API via az rest); MI nachruesten falls fehlend
function Invoke-DcrPolicyAssignment {
    param(
        [Parameter(Mandatory = $true)][string]$AssignmentName,
        [Parameter(Mandatory = $true)][string]$DisplayName,
        [Parameter(Mandatory = $true)][string]$Description,
        [Parameter(Mandatory = $true)][string]$Scope,
        [Parameter(Mandatory = $true)][string]$PolicyDefinitionId,
        [Parameter(Mandatory = $true)][string]$IdentityResourceId,
        [Parameter(Mandatory = $true)][hashtable]$PolicyParameters,
        [string[]]$NotScopes = @()
    )
    $assignmentUrl = "https://management.azure.com${Scope}/providers/Microsoft.Authorization/policyAssignments/${AssignmentName}?api-version=$PolicyApiVersion"
    $bodyPath = Join-Path $WorkDirectory ("assignment-" + $AssignmentName + ".json")
    $identityBlock = @{
        type                   = "UserAssigned"
        userAssignedIdentities = @{ $IdentityResourceId = @{} }
    }

    Write-Run "Pruefe Policy-Zuweisung '$AssignmentName'..."
    $existingRaw = Invoke-AzQuiet -Arguments (@("rest", "--method", "get") + (Get-AzRestUrlArgs -Url $assignmentUrl) + @("--output", "json"))
    $assignment = $null
    if ($LASTEXITCODE -eq 0) { $assignment = ConvertFrom-AzJson -RawOutput $existingRaw }

    if ($null -ne $assignment -and -not [string]::IsNullOrWhiteSpace([string]$assignment.id)) {
        Write-Warn "Zuweisung existiert bereits - wird wiederverwendet (Parameter werden nicht aktualisiert)"
        $script:LastAssignmentWasNew = $false
        $identityType = ""
        if ($null -ne $assignment.identity -and $null -ne $assignment.identity.type) { $identityType = [string]$assignment.identity.type }
        if ([string]::IsNullOrWhiteSpace($identityType) -or $identityType -eq "None") {
            Write-Warn "Zuweisung hat KEINE Managed Identity - ruestet User-assigned MI nach (PATCH)..."
            $patchBody = @{ location = $Location; identity = $identityBlock }
            $patched = Invoke-ArmWrite -Method "patch" -Url $assignmentUrl -Body $patchBody -BodyFilePath $bodyPath -Action "Identity nachruesten ($AssignmentName)"
            if ($null -ne $patched) {
                Write-Ok "Managed Identity an Zuweisung angehaengt"
                $assignment = $patched
            }
        }
        else {
            Write-Ok "Zuweisung hat bereits eine Managed Identity ($identityType)"
        }
        return $assignment
    }

    Write-Run "Erstelle Policy-Zuweisung '$AssignmentName' (ARM PUT, User-assigned MI)..."
    $props = @{
        displayName        = $DisplayName
        description        = $Description
        policyDefinitionId = $PolicyDefinitionId
        parameters         = $PolicyParameters
        enforcementMode    = "Default"
    }
    if ($NotScopes.Count -gt 0) { $props["notScopes"] = $NotScopes }
    $body = @{ location = $Location; identity = $identityBlock; properties = $props }
    $assignment = Invoke-ArmWrite -Method "put" -Url $assignmentUrl -Body $body -BodyFilePath $bodyPath -Action "Policy-Zuweisung erstellen ($AssignmentName)"
    if ($null -eq $assignment) { return $null }
    $script:LastAssignmentWasNew = $true
    Write-Ok "Policy-Zuweisung erstellt: $AssignmentName"
    Write-Sub "ID: $($assignment.id)"
    return $assignment
}

# Remediation Task starten (ARM-API via az rest); ohne ResourceGroupName = Subscription-Scope
function Start-PolicyRemediation {
    param(
        [Parameter(Mandatory = $true)][string]$NamePrefix,
        [Parameter(Mandatory = $true)][string]$AssignmentId,
        [string]$ResourceGroupName = "",
        [bool]$AssignmentIsNew = $false
    )
    $remediationName = $NamePrefix + "-" + (Get-Date -Format "yyyyMMddHHmmss")
    $baseUrl = "https://management.azure.com/subscriptions/$SubscriptionId"
    if (-not [string]::IsNullOrWhiteSpace($ResourceGroupName)) { $baseUrl += "/resourceGroups/$ResourceGroupName" }

    # Modus bestimmen
    $mode = $RemediationDiscoveryMode
    if ($mode -eq "Auto") {
        if ($AssignmentIsNew) { $mode = "ReEvaluateCompliance" } else { $mode = "ExistingNonCompliant" }
    }

    # Optional: Compliance-Scan asynchron anstossen (kein Warten)
    if ($TriggerComplianceScanFirst -and $mode -eq "ExistingNonCompliant") {
        $scanUrl = "$baseUrl/providers/Microsoft.PolicyInsights/policyStates/latest/triggerEvaluation?api-version=2019-10-01"
        Invoke-AzQuiet -Arguments (@("rest", "--method", "post") + (Get-AzRestUrlArgs -Url $scanUrl) + @("--output", "none")) | Out-Null
        if ($LASTEXITCODE -eq 0) { Write-Info "Compliance-Scan asynchron angestossen (laeuft im Hintergrund)" }
        else { Write-Warn "Compliance-Scan konnte nicht angestossen werden" }
    }

    # Obsolete Remediations dieser Zuweisung (Endzustand) entfernen, laufende bleiben
    $existingRems = Invoke-ArmGetAll -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations?api-version=$RemediationApiVersion"
    if ($null -ne $existingRems) {
        foreach ($rem in $existingRems) {
            if (([string]$rem.properties.policyAssignmentId).ToLower() -ne $AssignmentId.ToLower()) { continue }
            $remState = [string]$rem.properties.provisioningState
            if ($remState -notin @("Succeeded", "Failed", "Canceled")) { continue }
            $oldName = [string]$rem.name
            if (Invoke-ArmAction -Method "delete" -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${oldName}?api-version=$RemediationApiVersion" -Action "Alte Remediation loeschen ($oldName)") {
                Write-Info "Alte Remediation entfernt: $oldName ($remState)"
            }
        }
    }

    $url = "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${remediationName}?api-version=$RemediationApiVersion"
    $body = @{
        properties = @{
            policyAssignmentId    = $AssignmentId
            resourceDiscoveryMode = $mode
        }
    }
    $bodyPath = Join-Path $WorkDirectory ("remediation-" + $remediationName + ".json")
    Write-Run "Starte Remediation '$remediationName' (Modus: $mode)..."
    $rem = Invoke-ArmWrite -Method "put" -Url $url -Body $body -BodyFilePath $bodyPath -Action "Remediation erstellen ($remediationName)"
    if ($null -ne $rem) {
        Write-Ok "Remediation Task gestartet: $remediationName"
        if ($mode -eq "ReEvaluateCompliance") { Write-Sub "Status 'Evaluating' ist normal - Auswertung laeuft serverseitig (ca. 10-30 Min bei Arc)" }
        return $remediationName
    }
    return $null
}

# --- Cleanup-Hilfsfunktionen --------------------------------------------------

# Wartet, bis eine Remediation einen Endzustand erreicht; liefert den letzten provisioningState
function Wait-RemediationTerminal {
    param([Parameter(Mandatory = $true)][string]$RemediationUrl, [int]$TimeoutSeconds = 120, [int]$PollSeconds = 5)
    $elapsed = 0
    $state = ""
    while ($elapsed -lt $TimeoutSeconds) {
        Start-Sleep -Seconds $PollSeconds
        $elapsed += $PollSeconds
        $rem = Invoke-ArmGet -Url $RemediationUrl
        if ($null -eq $rem) { return "Unknown" }
        $state = [string]$rem.properties.provisioningState
        if ($state -in @("Succeeded", "Failed", "Canceled")) { return $state }
        Write-Sub "warte auf Endzustand... ($state, ${elapsed}s)"
    }
    return $state
}

# Prueft, ob die Managed Identity noch von einer Policy-Zuweisung in der Subscription verwendet wird
function Test-ManagedIdentityInUse {
    param([Parameter(Mandatory = $true)][string]$IdentityResourceId)
    $all = Invoke-ArmGetAll -Url "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.Authorization/policyAssignments?api-version=$PolicyApiVersion"
    if ($null -eq $all) { return $true }   # im Zweifel: in Benutzung
    $users = @()
    foreach ($pa in $all) {
        if ($null -eq $pa.identity -or $null -eq $pa.identity.userAssignedIdentities) { continue }
        foreach ($prop in $pa.identity.userAssignedIdentities.PSObject.Properties) {
            if ($prop.Name.ToLower() -eq $IdentityResourceId.ToLower()) { $users += [string]$pa.id }
        }
    }
    if ($users.Count -gt 0) {
        Write-Warn "Managed Identity wird noch von $($users.Count) Zuweisung(en) verwendet:"
        foreach ($u in $users) { Write-Sub "- $u" }
        return $true
    }
    return $false
}

# Entfernt eine Policy-Zuweisung inkl. zugehoeriger Remediation Tasks; liefert $true wenn etwas entfernt wurde
function Remove-PolicyAssignmentWithRemediations {
    param(
        [Parameter(Mandatory = $true)][string]$AssignmentName,
        [Parameter(Mandatory = $true)][string]$Scope,
        [string]$ResourceGroupName = ""
    )
    $assignmentUrl = "https://management.azure.com${Scope}/providers/Microsoft.Authorization/policyAssignments/${AssignmentName}?api-version=$PolicyApiVersion"
    $assignment = Invoke-ArmGet -Url $assignmentUrl
    if ($null -eq $assignment -or [string]::IsNullOrWhiteSpace([string]$assignment.id)) {
        Write-Sub "Zuweisung '$AssignmentName' nicht vorhanden - uebersprungen"
        return $false
    }
    $assignmentId = [string]$assignment.id

    # Remediations am Scope, die zu dieser Zuweisung gehoeren
    $baseUrl = "https://management.azure.com/subscriptions/$SubscriptionId"
    if (-not [string]::IsNullOrWhiteSpace($ResourceGroupName)) { $baseUrl += "/resourceGroups/$ResourceGroupName" }
    $remediations = Invoke-ArmGetAll -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations?api-version=$RemediationApiVersion"
    if ($null -ne $remediations) {
        foreach ($rem in $remediations) {
            $remAssignment = [string]$rem.properties.policyAssignmentId
            if ($remAssignment.ToLower() -ne $assignmentId.ToLower()) { continue }
            $remName  = [string]$rem.name
            $remState = [string]$rem.properties.provisioningState
            $remUrl   = "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${remName}?api-version=$RemediationApiVersion"
            if ($remState -notin @("Succeeded", "Failed", "Canceled")) {
                if ($remState -ne "Canceling") {
                    Write-Run "Breche Remediation '$remName' ab ($remState)..."
                    Invoke-ArmAction -Method "post" -Url "$baseUrl/providers/Microsoft.PolicyInsights/remediations/${remName}/cancel?api-version=$RemediationApiVersion" -Action "Remediation abbrechen ($remName)" | Out-Null
                }
                # Auf Endzustand warten (Azure loescht nur Succeeded/Failed/Canceled)
                $remState = Wait-RemediationTerminal -RemediationUrl $remUrl -TimeoutSeconds 120
            }
            if ($remState -notin @("Succeeded", "Failed", "Canceled")) {
                Write-Warn "Remediation '$remName' noch im Zustand '$remState' - wird uebersprungen (spaeter erneut ausfuehren)"
                continue
            }
            Write-Run "Loesche Remediation '$remName' ($remState)..."
            if (Invoke-ArmAction -Method "delete" -Url $remUrl -Action "Remediation loeschen ($remName)") {
                Write-Ok "Remediation geloescht: $remName"
            }
        }
    }

    Write-Run "Loesche Policy-Zuweisung '$AssignmentName'..."
    if (Invoke-ArmAction -Method "delete" -Url $assignmentUrl -Action "Policy-Zuweisung loeschen ($AssignmentName)") {
        Write-Ok "Policy-Zuweisung geloescht: $AssignmentName"
        return $true
    }
    return $false
}

# Entfernt alle DCR-Associations einer DCR; liefert Anzahl
function Remove-DcrAssociations {
    param([Parameter(Mandatory = $true)][string]$DcrResourceId)
    $assocs = Invoke-ArmGetAll -Url "https://management.azure.com${DcrResourceId}/associations?api-version=$DcrApiVersion"
    if ($null -eq $assocs) {
        Write-Warn "Associations konnten nicht gelesen werden"
        return 0
    }
    if ($assocs.Count -eq 0) {
        Write-Info "Keine Associations vorhanden"
        return 0
    }
    $removed = 0
    foreach ($assoc in $assocs) {
        $assocId = [string]$assoc.id
        $machineId = ($assocId -split "(?i)/providers/Microsoft\.Insights/")[0]
        $machineName = ($machineId -split "/")[-1]
        if (Invoke-ArmAction -Method "delete" -Url "https://management.azure.com${assocId}?api-version=$DcrApiVersion" -Action "Association loeschen ($machineName)") {
            $removed++
            Write-Ok "Association entfernt: $machineName"
        }
    }
    return $removed
}


# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Line
Write-Section "PRE-CHECK"

$psVersion = $PSVersionTable.PSVersion
Write-Info "PowerShell Version: $psVersion (Modus: $PowerShellMode)"
if ($psVersion.Major -lt 5 -or ($psVersion.Major -eq 5 -and $psVersion.Minor -lt 1)) {
    Write-Err "PowerShell 5.1 oder hoeher wird benoetigt."; Write-Line; exit 1
}
if ($PowerShellMode -eq "Seven" -and $psVersion.Major -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - aktuell: $psVersion"; Write-Line; exit 1
}
if (($psVersion.Major -gt 7) -or ($psVersion.Major -eq 7 -and $psVersion.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PS 7.3+ erkannt: PSNativeCommandUseErrorActionPreference = false"
}

Write-Info "Pruefe Azure CLI..."
$azCommand = Get-Command az -ErrorAction SilentlyContinue
if ($null -eq $azCommand) {
    Write-Err "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"; Write-Line; exit 1
}
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
Assert-AzSuccess -Action "az version" -Fatal | Out-Null
$azVersionObj = ConvertFrom-AzJson -RawOutput $azVersionRaw
$azCliVersion = [string]$azVersionObj.'azure-cli'
Write-Ok "Azure CLI gefunden: $azCliVersion"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $latestInfo    = Invoke-RestMethod -Uri "https://pypi.org/pypi/azure-cli/json" -TimeoutSec 10 -ErrorAction Stop
    $latestVersion = [string]$latestInfo.info.version
    if ([Version]$azCliVersion -lt [Version]$latestVersion) {
        Write-Warn "Neuere Version verfuegbar: $latestVersion (Update mit: az upgrade)"
    }
    else {
        Write-Ok "Azure CLI ist aktuell"
    }
}
catch {
    Write-Warn "Versionsvergleich nicht moeglich - bitte manuell pruefen (az upgrade)"
}

Write-Info "Pruefe Azure Login..."
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Kein Login vorhanden - starte az login..."
    & az login --output none
    Assert-AzSuccess -Action "az login" -Fatal | Out-Null
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess -Action "az account show" -Fatal | Out-Null
}
$account = ConvertFrom-AzJson -RawOutput $accountRaw
Write-Ok "Login vorhanden: $($account.user.name)"

$SubscriptionId = [string]$account.id
Write-Ok "Aktive Subscription: $($account.name) ($SubscriptionId)"

if ($Mode -ne "Deploy" -and $Mode -ne "Cleanup") {
    Write-Err "Ungueltiger Mode '$Mode' - erlaubt: Deploy | Cleanup"; Write-Line; exit 1
}

Write-Line
Write-Section "SCRIPT-VERSION"
Write-Info "$ScriptName - Version $ScriptVersion"
Write-Info "Modus: $Mode"
Write-Line

# =============================================================================
# [ VORAUSSETZUNG: INSIGHTS-DCR ]
# =============================================================================
Write-Section "VORAUSSETZUNG: AVD INSIGHTS DCR"
if (-not (Test-Path -Path $WorkDirectory)) { New-Item -Path $WorkDirectory -ItemType Directory -Force | Out-Null }

$insightsDcrResourceId = ""
if (-not [string]::IsNullOrWhiteSpace($InsightsDcrResourceGroupName)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' in RG '$InsightsDcrResourceGroupName'..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $InsightsDcrResourceGroupName, "--name", $InsightsDcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' subscriptionweit..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "list", "--resource-type", "Microsoft.Insights/dataCollectionRules", "--name", $InsightsDcrName, "--query", "[0].id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId) -and $Mode -eq "Cleanup") {
    Write-Warn "Insights-DCR '$InsightsDcrName' nicht gefunden - Association-Cleanup entfaellt"
}
elseif ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    Write-Err "Insights-DCR '$InsightsDcrName' NICHT gefunden - Abbruch."
    Write-SubErr "Dieser Schritt ist zuerst notwendig:"
    Write-SubErr "  1. Azure Portal > Azure Virtual Desktop > Insights > Konfigurations-Workbook (CheckAMAConfiguration)"
    Write-SubErr "  2. Workspace und DCR-Resource-Group waehlen, 'Create data collection rule' klicken"
    Write-SubErr "  3. Dabei entsteht die DCR '$InsightsDcrName'"
    Write-SubErr "  4. Anschliessend dieses Script erneut starten"
    Write-Line
    exit 1
}
$insightsDcrResourceGroupName = ""
if (-not [string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    $insightsDcrResourceGroupName = Get-ResourceGroupFromId -ResourceId $insightsDcrResourceId
    Write-Ok "Insights-DCR gefunden: $InsightsDcrName (RG: $insightsDcrResourceGroupName)"
    Write-Sub "ID: $insightsDcrResourceId"
}
Write-Line

# =============================================================================
# [ HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS ]
# =============================================================================
Write-Section "HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS"

$targetRgMap = @{}   # RG-Name -> Liste der Host Pools, die dort Session Hosts haben

if ($ManualResourceGroupNames.Count -gt 0) {
    Write-Info "Manuelle Resource-Group-Liste wird verwendet - keine automatische Ermittlung."
    foreach ($rg in $ManualResourceGroupNames) { $targetRgMap[$rg] = @("manuell") }
}
else {
    Write-Run "Ermittle AVD Host Pools in der Subscription..."
    $hpUrl = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.DesktopVirtualization/hostPools?api-version=$DesktopVirtualizationApiVersion"
    $hostPools = Invoke-ArmGetAll -Url $hpUrl
    if ($null -eq $hostPools) {
        Write-Err "Host Pools konnten nicht abgefragt werden (az rest)."; Write-Line; exit 1
    }
    if ($hostPools.Count -eq 0) {
        Write-Err "Keine Host Pools in der Subscription gefunden."; Write-Line; exit 1
    }
    Write-Ok "$($hostPools.Count) Host Pool(s) gefunden"

    foreach ($hp in $hostPools) {
        $hpName = [string]$hp.name
        $hpRg   = Get-ResourceGroupFromId -ResourceId ([string]$hp.id)

        if ($HostPoolNameFilter.Count -gt 0 -and $HostPoolNameFilter -notcontains $hpName) {
            Write-Sub "Uebersprungen (Filter): $hpName"
            continue
        }

        Write-Run "Host Pool '$hpName' (RG: $hpRg) - lese Session Hosts..."
        $shUrl = "https://management.azure.com$($hp.id)/sessionHosts?api-version=$DesktopVirtualizationApiVersion"
        $sessionHosts = Invoke-ArmGetAll -Url $shUrl
        if ($null -eq $sessionHosts) {
            Write-Warn "Session Hosts von '$hpName' konnten nicht gelesen werden - uebersprungen"
            continue
        }

        $rgsOfPool = @()
        $arcHosts = 0
        $azureHosts = 0
        foreach ($sh in $sessionHosts) {
            $vmId = ""
            if ($null -ne $sh.properties -and $null -ne $sh.properties.resourceId) { $vmId = [string]$sh.properties.resourceId }
            if ([string]::IsNullOrWhiteSpace($vmId)) { continue }
            $vmRg = Get-ResourceGroupFromId -ResourceId $vmId
            if ($vmId -match "(?i)/Microsoft\.HybridCompute/machines/") { $arcHosts++ } else { $azureHosts++ }
            if (-not [string]::IsNullOrWhiteSpace($vmRg) -and $rgsOfPool -notcontains $vmRg) { $rgsOfPool += $vmRg }
        }

        if ($rgsOfPool.Count -eq 0) {
            if ($UseHostPoolRgIfNoSessionHosts) {
                Write-Warn "'$hpName' hat keine Session Hosts mit VM-Resource-ID - verwende Host-Pool-RG '$hpRg'"
                $rgsOfPool += $hpRg
            }
            else {
                Write-Warn "'$hpName' hat keine Session Hosts - uebersprungen"
                continue
            }
        }
        else {
            Write-Ok "'$hpName': $($sessionHosts.Count) Session Host(s) [$arcHosts Arc, $azureHosts Azure-VM] in RG: $($rgsOfPool -join ', ')"
        }

        foreach ($rg in $rgsOfPool) {
            if (-not $targetRgMap.ContainsKey($rg)) { $targetRgMap[$rg] = @() }
            $targetRgMap[$rg] += $hpName
        }
    }
}

$targetResourceGroups = @($targetRgMap.Keys | Sort-Object)
if ($targetResourceGroups.Count -eq 0) {
    Write-Err "Keine Ziel-Resource-Groups ermittelt."; Write-Line; exit 1
}
Write-Host ""
Write-Info "Ziel-Resource-Groups ($($targetResourceGroups.Count)):"
foreach ($rg in $targetResourceGroups) {
    Write-Sub "- $rg  (Host Pools: $(($targetRgMap[$rg] | Sort-Object -Unique) -join ', '))"
}
Write-Line

# =============================================================================
# [ BEREINIGUNG OBSOLETER OBJEKTE ]  (Pflichtschritt, in jedem Modus)
# =============================================================================
Write-Section "BEREINIGUNG OBSOLETER OBJEKTE"
$obsoleteRemoved = 0
foreach ($rg in $targetResourceGroups) {
    $scope = "/subscriptions/$SubscriptionId/resourceGroups/$rg"
    $listUrl = "https://management.azure.com${scope}/providers/Microsoft.Authorization/policyAssignments?api-version=$PolicyApiVersion"
    $allAssignments = Invoke-ArmGetAll -Url $listUrl
    if ($null -eq $allAssignments) { Write-Warn "Zuweisungen an $rg konnten nicht gelesen werden"; continue }
    foreach ($pa in $allAssignments) {
        $paName = [string]$pa.name
        if (([string]$pa.properties.scope).ToLower() -ne $scope.ToLower()) { continue }   # nur exakt dieser Scope (keine geerbten)
        if ($paName -notmatch $LegacyAssignmentPattern) { continue }
        Write-Warn "Obsolete Zuweisung: $paName @ $rg"
        if (Remove-PolicyAssignmentWithRemediations -AssignmentName $paName -Scope $scope -ResourceGroupName $rg) { $obsoleteRemoved++ }
    }
}
if ($obsoleteRemoved -eq 0) { Write-Ok "Keine obsoleten Objekte vorhanden" }
else { Write-Ok "$obsoleteRemoved obsolete Zuweisung(en) entfernt" }
Write-Line

# #############################################################################
# ######################         MODUS: CLEANUP          ######################
# #############################################################################
if ($Mode -eq "Cleanup") {
    $cleanupSummary = @()

    Write-Section "CLEANUP: POLICY-ZUWEISUNGEN"
    foreach ($rg in $targetResourceGroups) {
        $scope = "/subscriptions/$SubscriptionId/resourceGroups/$rg"
        Write-Host ""
        Write-Info "Resource Group: $rg"
        if ($CleanupRemoveInsightsAssignments) {
            if (Remove-PolicyAssignmentWithRemediations -AssignmentName $PolicyAssignmentName -Scope $scope -ResourceGroupName $rg) {
                $cleanupSummary += "Policy '$PolicyAssignmentName' @ $rg"
            }
        }
    }
    Write-Line

    if ($CleanupRemoveInsightsAssociations -and -not [string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
        Write-Section "CLEANUP: DCR-ASSOCIATIONS (INSIGHTS)"
        Write-Warn "Insights-Associations werden entfernt - AVD Insights erhaelt danach keine Perf-/Event-Daten mehr!"
        $n = Remove-DcrAssociations -DcrResourceId $insightsDcrResourceId
        Write-Ok "$n Association(s) entfernt"
        if ($n -gt 0) { $cleanupSummary += "$n Association(s) von '$InsightsDcrName'" }
        Write-Line
    }

    if ($CleanupRemoveManagedIdentity) {
        Write-Section "CLEANUP: MANAGED IDENTITY"
        $miRaw = Invoke-AzQuiet -Arguments @("identity", "show", "--name", $ManagedIdentityName, "--resource-group", $ManagedIdentityResourceGroupName, "--output", "json")
        $miExists = ($LASTEXITCODE -eq 0 -and $null -ne $miRaw)
        if ($miExists) {
            $mi = ConvertFrom-AzJson -RawOutput $miRaw
            $miPrincipal = [string]$mi.principalId
            if (Test-ManagedIdentityInUse -IdentityResourceId ([string]$mi.id)) {
                Write-Info "Managed Identity bleibt bestehen (noch in Benutzung)"
                Write-Line
                $miKeep = $true
            }
            else { $miKeep = $false }
        }
        else { $miKeep = $true }
        if (-not $miKeep) {
            Write-Run "Entferne Rollenzuweisungen der MI ($miPrincipal)..."
            $raList = Invoke-AzQuiet -Arguments @("role", "assignment", "list", "--assignee", $miPrincipal, "--all", "--query", "[].id", "--output", "tsv")
            if ($LASTEXITCODE -eq 0 -and $null -ne $raList) {
                foreach ($raId in @($raList)) {
                    if ([string]::IsNullOrWhiteSpace($raId)) { continue }
                    Invoke-AzQuiet -Arguments @("role", "assignment", "delete", "--ids", $raId.Trim(), "--output", "none") | Out-Null
                    if ($LASTEXITCODE -eq 0) { Write-Ok "Rollenzuweisung entfernt: $(($raId.Trim() -split '/')[-1])" }
                }
            }
            Write-Run "Loesche Managed Identity '$ManagedIdentityName'..."
            & az identity delete --name $ManagedIdentityName --resource-group $ManagedIdentityResourceGroupName --output none
            if (Assert-AzSuccess -Action "az identity delete") {
                Write-Ok "Managed Identity geloescht"
                $cleanupSummary += "Managed Identity '$ManagedIdentityName'"
            }
            Write-Line
        }
        elseif (-not $miExists) {
            Write-Info "Managed Identity '$ManagedIdentityName' nicht vorhanden"
            Write-Line
        }
    }

    Write-Section "ERGEBNIS CLEANUP"
    if ($cleanupSummary.Count -eq 0) {
        Write-Info "Nichts entfernt - keine passenden Objekte gefunden."
    }
    else {
        Write-Ok "$($cleanupSummary.Count) Objekt(e) entfernt:"
        foreach ($c in $cleanupSummary) { Write-Sub "- $c" }
    }
    Write-Info "Nicht entfernt (bewusst): Insights-DCR selbst, Log Analytics Workspace"
    if (-not $CleanupRemoveInsightsAssociations -and -not [string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
        $remainingAssocs = Invoke-ArmGetAll -Url "https://management.azure.com${insightsDcrResourceId}/associations?api-version=$DcrApiVersion"
        if ($null -ne $remainingAssocs -and $remainingAssocs.Count -gt 0) {
            Write-Warn "Verbleibend: $($remainingAssocs.Count) Association(s) zur Insights-DCR auf den Maschinen"
            Write-Sub "Zum Entfernen: CleanupRemoveInsightsAssociations = true (stoppt die AVD-Insights-Datensammlung)"
        }
    }
    Write-Line
    exit 0
}

# #############################################################################
# ######################         MODUS: DEPLOY           ######################
# #############################################################################

# =============================================================================
# [ MANAGED IDENTITY ]
# =============================================================================
Write-Section "MANAGED IDENTITY"
Write-Run "Pruefe User-assigned Managed Identity '$ManagedIdentityName'..."
$miRaw = Invoke-AzQuiet -Arguments @("identity", "show", "--name", $ManagedIdentityName, "--resource-group", $ManagedIdentityResourceGroupName, "--output", "json")
$managedIdentity = $null
if ($LASTEXITCODE -eq 0 -and $null -ne $miRaw) { $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw }
$identityIsNew = $false
if ($null -ne $managedIdentity) {
    Write-Ok "Managed Identity vorhanden: $ManagedIdentityName"
}
else {
    Write-Warn "Managed Identity nicht vorhanden - wird erstellt..."
    $miRaw = & az identity create --name $ManagedIdentityName --resource-group $ManagedIdentityResourceGroupName --location $Location --output json
    Assert-AzSuccess -Action "az identity create" -Fatal | Out-Null
    $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw
    $identityIsNew = $true
    Write-Ok "Managed Identity erstellt: $ManagedIdentityName"
}
$identityResourceId  = [string]$managedIdentity.id
$identityPrincipalId = [string]$managedIdentity.principalId
Write-Sub "Resource-ID : $identityResourceId"
Write-Sub "Principal-ID: $identityPrincipalId"
if ($identityIsNew) {
    Write-Info "Warte 20 s auf Replikation der neuen Identity..."
    Start-Sleep -Seconds 20
}

# Rollen: auf jeder Ziel-RG (DCRA anlegen) + RG der Insights-DCR (DCR lesen)
Write-Run "Vergebe Rollen an die Managed Identity..."
$roleScopes = @()
foreach ($rg in $targetResourceGroups) { $roleScopes += "/subscriptions/$SubscriptionId/resourceGroups/$rg" }
$dcrScope = "/subscriptions/$SubscriptionId/resourceGroups/$insightsDcrResourceGroupName"
if ($roleScopes -notcontains $dcrScope) { $roleScopes += $dcrScope }

$roleErrors = 0
foreach ($roleScope in $roleScopes) {
    foreach ($roleName in $PolicyRoleNames) {
        $result = Set-RoleAssignmentWithRetry -PrincipalId $identityPrincipalId -RoleName $roleName -Scope $roleScope
        if (-not $result) { $roleErrors++ }
    }
}
if ($roleErrors -gt 0) { Write-Warn "$roleErrors Rollenzuweisung(en) fehlgeschlagen - Remediation wird moeglicherweise scheitern." }
Write-Line

# =============================================================================
# [ AZURE POLICY - INSIGHTS-DCR ASSOCIATION ]
# =============================================================================
Write-Section "AZURE POLICY - INSIGHTS-DCR ASSOCIATION"

Write-Run "Ermittle Built-in Policy-Definition..."
$dcrPolicyDefinitionId = Get-BuiltinPolicyDefinitionId -DefinitionGuid $DcrPolicyDefinitionGuid -DisplayName $DcrPolicyDisplayName
if ($null -eq $dcrPolicyDefinitionId) {
    Write-Err "Policy-Definition '$DcrPolicyDisplayName' nicht gefunden."; Write-Line; exit 1
}
Write-Ok "Policy-Definition gefunden"
Write-Sub "$dcrPolicyDefinitionId"

$policyParams = @{
    dcrResourceId = @{ value = $insightsDcrResourceId }
    resourceType  = @{ value = "Microsoft.Insights/dataCollectionRules" }
    effect        = @{ value = "DeployIfNotExists" }
}

$results = @()
foreach ($rg in $targetResourceGroups) {
    $scope = "/subscriptions/$SubscriptionId/resourceGroups/$rg"
    Write-Host ""
    Write-Info "Resource Group: $rg"
    $assignment = Invoke-DcrPolicyAssignment `
        -AssignmentName $PolicyAssignmentName `
        -DisplayName $PolicyAssignmentDisplayName `
        -Description "Verknuepft Windows Session Hosts in '$rg' mit der AVD-Insights-DCR ($InsightsDcrName)." `
        -Scope $scope `
        -PolicyDefinitionId $dcrPolicyDefinitionId `
        -IdentityResourceId $identityResourceId `
        -PolicyParameters $policyParams
    $remName = $null
    $status = "FEHLER"
    if ($null -ne $assignment) {
        $status = "OK"
        if ($CreateRemediationTask) {
            $remName = Start-PolicyRemediation -NamePrefix $RemediationNamePrefix -AssignmentId ([string]$assignment.id) -ResourceGroupName $rg -AssignmentIsNew $script:LastAssignmentWasNew
        }
    }
    $results += New-Object PSObject -Property @{
        ResourceGroup = $rg
        HostPools     = (($targetRgMap[$rg] | Sort-Object -Unique) -join ", ")
        Status        = $status
        Remediation   = $remName
    }
}
Write-Line

# =============================================================================
# [ ERGEBNIS ]
# =============================================================================
Write-Section "ERGEBNIS"
Write-Ok "Insights-DCR     : $InsightsDcrName"
Write-Sub $insightsDcrResourceId
Write-Ok "Managed Identity : $ManagedIdentityName"
Write-Sub $identityResourceId
Write-Host ""
Write-Info "Policy-Zuweisung '$PolicyAssignmentName' je Resource Group:"
foreach ($r in $results) {
    $remText = "keine"
    if (-not [string]::IsNullOrWhiteSpace($r.Remediation)) { $remText = $r.Remediation }
    if ($r.Status -eq "OK") {
        Write-Ok "$($r.ResourceGroup)  (Host Pools: $($r.HostPools))"
    }
    else {
        Write-Err "$($r.ResourceGroup)  (Host Pools: $($r.HostPools))"
    }
    Write-Sub "Remediation: $remText"
}
Write-Host ""
Write-Info "Validierung (Resource Graph) - jeder Session Host sollte die Insights-DCR haben:"
Write-Sub "insightsresources"
Write-Sub "| where type == 'microsoft.insights/datacollectionruleassociations'"
Write-Sub "| extend Machine = tolower(tostring(split(id, '/providers/Microsoft.Insights/')[0])), Dcr = tostring(properties.dataCollectionRuleId)"
Write-Sub "| where Machine contains '/machines/' or Machine contains '/virtualmachines/'"
Write-Sub "| extend Kind = iff(Machine contains '/microsoft.hybridcompute/', 'Arc', 'AzureVM')"
Write-Sub "| summarize Rules = make_set(Dcr) by Machine, Kind"
Write-Host ""
Write-Info "Remediation-Status: az policy remediation list --resource-group <rg> --output table"
Write-Line
