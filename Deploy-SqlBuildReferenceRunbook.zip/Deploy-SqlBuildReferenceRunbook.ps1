﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Deploys the "Update-SqlBuildReference" runbook into an Azure Automation account.
.DESCRIPTION
    Collects all required information, prepares the Automation account and installs the
    runbook with a weekly schedule. Steps:
      1. Locates the workbook by display name (subscription-wide) and reads its resource name (GUID).
      2. Creates the Automation account if missing and enables the system-assigned managed identity.
      3. Assigns "Workbook Contributor" on the workbook resource group to that identity.
      4. Injects subscription, resource group and workbook GUID into the runbook source,
         uploads it as PowerShell 7.2 runbook and publishes it.
      5. Creates a weekly schedule and links it to the runbook.
      6. Optionally starts a test job and prints its output.

    All Azure calls use Azure CLI (az rest against ARM), no az extensions required.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-15
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Deploy-SqlBuildReferenceRunbook.ps1
#>

# =============================================================================
# PARAMETERS (edit here, no call parameters)
# =============================================================================
$ScriptVersion                 = "1.0.0"
$PowerShellMode                = "Compat"       # Compat (5.1 + 7.x) or Seven (7.x only)

$SubscriptionId                = ""             # "" = use the subscription of the current az login
$WorkbookDisplayName           = "LDK SQL Inventory Dashboard"

$AutomationResourceGroup       = "rg-automation"
$AutomationAccountName         = "aa-ldk-ops"
$AutomationLocation            = "westeurope"
$CreateAutomationAccount       = $true          # create account + resource group if missing

$RunbookName                   = "Update-SqlBuildReference"
$RunbookSourcePath             = "C:\Scripts\Update-SqlBuildReference-Runbook.ps1"
$RunbookDescription            = "Keeps the SQL Server build reference table of the LDK SQL Inventory Dashboard workbook current (source: Microsoft KB321185)."

$ScheduleName                  = "Weekly-Wednesday-0600"
$ScheduleWeekDay               = "Wednesday"    # Monday..Sunday
$ScheduleTime                  = "06:00"        # HH:mm in the time zone below
$ScheduleTimeZone              = "W. Europe Standard Time"

$RoleName                      = "Workbook Contributor"
$StartTestJob                  = $true          # start the runbook once after deployment and show its output
$TestJobTimeoutMinutes         = 10

$AutomationApiVersion          = "2023-11-01"
$WorkbookApiVersion            = "2023-06-01"

# =============================================================================
# RUNTIME SETUP
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

function Write-Line  { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Head  { param([string]$Text) Write-Host "[ $Text ]" -ForegroundColor White }
function Write-Ok    { param([string]$Text) Write-Host ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymOk,   $Text) -ForegroundColor Green }
function Write-Err   { param([string]$Text) Write-Host ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymErr,  $Text) -ForegroundColor Red }
function Write-Warn  { param([string]$Text) Write-Host ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymWarn, $Text) -ForegroundColor Yellow }
function Write-Info  { param([string]$Text) Write-Host ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymInfo, $Text) -ForegroundColor Cyan }
function Write-Run   { param([string]$Text) Write-Host ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymRun,  $Text) -ForegroundColor Cyan }
function Write-Sub   { param([string]$Text) Write-Host ("    {0}" -f $Text) -ForegroundColor Cyan }

function Invoke-AzQuiet {
    param([string[]]$Arguments)
    $output = & az @Arguments 2>$null
    return ($output -join "`n")
}

function Assert-AzSuccess {
    param([string]$Action)
    if ($LASTEXITCODE -ne 0) {
        Write-Err "$Action failed (exit code $LASTEXITCODE)"
        exit 1
    }
}

function Invoke-ArmRest {
    # Calls ARM via az rest. Body (object) is written to a temp file to avoid quoting issues.
    # Returns the parsed JSON response (or $null for empty responses). Sets $script:LastArmExit.
    param([string]$Method, [string]$Url, $Body = $null, [string]$ContentType = "application/json")
    $azArgs = @("rest", "--method", $Method, "--url", $Url, "--output", "json")
    $tmp = $null
    if ($null -ne $Body) {
        $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ("armbody-{0}.tmp" -f ([guid]::NewGuid().ToString("N")))
        if ($Body -is [string]) { $text = $Body } else { $text = ConvertTo-Json $Body -Depth 20 -Compress }
        [System.IO.File]::WriteAllText($tmp, $text, (New-Object System.Text.UTF8Encoding($false)))
        $azArgs += @("--body", "@$tmp", "--headers", "Content-Type=$ContentType")
    }
    $raw = Invoke-AzQuiet -Arguments $azArgs
    $script:LastArmExit = $LASTEXITCODE
    if ($null -ne $tmp) { Remove-Item -Path $tmp -Force -ErrorAction SilentlyContinue }
    if ($script:LastArmExit -ne 0) { return $null }
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    try { return (ConvertFrom-Json $raw) } catch { return $raw }
}

# =============================================================================
# PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Info "PowerShell $($PSVersionTable.PSVersion) ($($PSVersionTable.PSEdition))"
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) { Write-Err "Script mode 'Seven' requires PowerShell 7.x"; exit 1 }
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) { $PSNativeCommandUseErrorActionPreference = $false }

Write-Info "Checking Azure CLI..."
$azVersionJson = Invoke-AzQuiet -Arguments @("version", "--output", "json")
if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($azVersionJson)) {
    Write-Err "Azure CLI not found. Install: https://aka.ms/installazurecli"
    exit 1
}
$azCliVersion = "unknown"
try { $azCliVersion = (ConvertFrom-Json $azVersionJson).'azure-cli' } catch { }
Write-Ok "Azure CLI found: $azCliVersion"
try {
    $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/Azure/azure-cli/releases/latest" -UseBasicParsing -TimeoutSec 15
    $latestCli = ($rel.tag_name -replace "^azure-cli-", "")
    if ($latestCli -and $azCliVersion -ne "unknown" -and ([version]$latestCli -gt [version]$azCliVersion)) {
        Write-Warn "Newer Azure CLI available: $latestCli (run: az upgrade)"
    } else {
        Write-Ok "Azure CLI is current"
    }
} catch {
    Write-Info "Azure CLI version comparison skipped (no access to GitHub API)"
}

Write-Info "Checking Azure login..."
$accountJson = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Run "No login found, starting az login..."
    & az login --output none
    Assert-AzSuccess "az login"
    $accountJson = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess "az account show"
}
$account = ConvertFrom-Json $accountJson
Write-Ok "Login found: $($account.user.name)"

if ([string]::IsNullOrWhiteSpace($SubscriptionId)) { $SubscriptionId = $account.id }
& az account set --subscription $SubscriptionId --output none 2>$null
Assert-AzSuccess "az account set"
$account = ConvertFrom-Json (Invoke-AzQuiet -Arguments @("account", "show", "--output", "json"))
Write-Ok "Subscription: $($account.name) ($SubscriptionId)"

if (-not (Test-Path -Path $RunbookSourcePath)) { Write-Err "Runbook source not found: $RunbookSourcePath"; exit 1 }
Write-Ok "Runbook source found: $RunbookSourcePath"

Write-Line
Write-Info "Script version: $ScriptVersion"
Write-Line

# =============================================================================
# STEP 1: LOCATE WORKBOOK
# =============================================================================
Write-Head "STEP 1: LOCATE WORKBOOK"
Write-Run "Searching workbook '$WorkbookDisplayName' in subscription..."
$wbListUrl = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.Insights/workbooks?api-version=$WorkbookApiVersion&category=workbook&canFetchContent=false"
$wbList = Invoke-ArmRest -Method get -Url $wbListUrl
if ($script:LastArmExit -ne 0 -or $null -eq $wbList) { Write-Err "Could not list workbooks"; exit 1 }
$matchesWb = @($wbList.value | Where-Object { $_.properties.displayName -eq $WorkbookDisplayName })
if ($matchesWb.Count -eq 0) {
    Write-Err "No workbook with display name '$WorkbookDisplayName' found. Import the workbook first (Portal > Workbooks > Advanced Editor) and save it as shared workbook."
    exit 1
}
if ($matchesWb.Count -gt 1) {
    Write-Warn "$($matchesWb.Count) workbooks with this name found, using the first one:"
    foreach ($m in $matchesWb) { Write-Sub $m.id }
}
$workbook = $matchesWb[0]
$WorkbookResourceName = $workbook.name
$WorkbookResourceGroup = ($workbook.id -split "/")[4]
Write-Ok "Workbook found"
Write-Sub "Resource name (GUID): $WorkbookResourceName"
Write-Sub "Resource group      : $WorkbookResourceGroup"
Write-Sub "Location            : $($workbook.location)"
Write-Line

# =============================================================================
# STEP 2: AUTOMATION ACCOUNT + MANAGED IDENTITY
# =============================================================================
Write-Head "STEP 2: AUTOMATION ACCOUNT"
$aaUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName" + "?api-version=$AutomationApiVersion"
$aa = Invoke-ArmRest -Method get -Url $aaUrl
if ($script:LastArmExit -ne 0 -or $null -eq $aa) {
    if (-not $CreateAutomationAccount) { Write-Err "Automation account '$AutomationAccountName' not found and creation disabled"; exit 1 }

    $rgExists = Invoke-AzQuiet -Arguments @("group", "exists", "--name", $AutomationResourceGroup)
    if ($rgExists -ne "true") {
        Write-Run "Creating resource group $AutomationResourceGroup ($AutomationLocation)..."
        & az group create --name $AutomationResourceGroup --location $AutomationLocation --output none 2>$null
        Assert-AzSuccess "az group create"
        Write-Ok "Resource group created"
    }
    Write-Run "Creating automation account $AutomationAccountName..."
    $aaBody = @{
        location   = $AutomationLocation
        identity   = @{ type = "SystemAssigned" }
        properties = @{ sku = @{ name = "Basic" } }
    }
    $aa = Invoke-ArmRest -Method put -Url $aaUrl -Body $aaBody
    if ($script:LastArmExit -ne 0 -or $null -eq $aa) { Write-Err "Automation account creation failed"; exit 1 }
    Write-Ok "Automation account created"
} else {
    Write-Ok "Automation account found: $AutomationAccountName ($($aa.location))"
}

$principalId = $null
if ($null -ne $aa.identity -and $aa.identity.type -match "SystemAssigned" -and $aa.identity.principalId) {
    $principalId = $aa.identity.principalId
    Write-Ok "System-assigned identity present"
} else {
    Write-Run "Enabling system-assigned managed identity..."
    $aa = Invoke-ArmRest -Method patch -Url $aaUrl -Body @{ identity = @{ type = "SystemAssigned" } }
    if ($script:LastArmExit -ne 0 -or $null -eq $aa -or -not $aa.identity.principalId) { Write-Err "Enabling managed identity failed"; exit 1 }
    $principalId = $aa.identity.principalId
    Write-Ok "Managed identity enabled"
}
Write-Sub "Principal ID: $principalId"
Write-Line

# =============================================================================
# STEP 3: ROLE ASSIGNMENT
# =============================================================================
Write-Head "STEP 3: ROLE ASSIGNMENT"
$scope = "/subscriptions/$SubscriptionId/resourceGroups/$WorkbookResourceGroup"
$existing = Invoke-AzQuiet -Arguments @("role", "assignment", "list", "--assignee", $principalId, "--role", $RoleName, "--scope", $scope, "--output", "json")
$existingCount = 0
if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($existing)) {
    try { $existingCount = @(ConvertFrom-Json $existing).Count } catch { $existingCount = 0 }
}
if ($existingCount -gt 0) {
    Write-Ok "'$RoleName' already assigned on $WorkbookResourceGroup"
} else {
    Write-Run "Assigning '$RoleName' on resource group $WorkbookResourceGroup..."
    # Identity propagation can take a moment after creation: retry a few times
    $assigned = $false
    for ($i = 1; $i -le 6; $i++) {
        & az role assignment create --assignee-object-id $principalId --assignee-principal-type ServicePrincipal --role $RoleName --scope $scope --output none 2>$null
        if ($LASTEXITCODE -eq 0) { $assigned = $true; break }
        Write-Info "Retry $i/6 in 10 seconds (identity propagation)..."
        Start-Sleep -Seconds 10
    }
    if (-not $assigned) { Write-Err "Role assignment failed. You need Owner or User Access Administrator on the resource group."; exit 1 }
    Write-Ok "Role assigned"
}
Write-Line

# =============================================================================
# STEP 4: RUNBOOK
# =============================================================================
Write-Head "STEP 4: RUNBOOK"
Write-Run "Preparing runbook content..."
$source = [System.IO.File]::ReadAllText($RunbookSourcePath, [System.Text.Encoding]::UTF8)
$content = $source
$content = [regex]::Replace($content, '(?m)^(\$SubscriptionId\s*=\s*)"[^"]*"',       ('${1}"' + $SubscriptionId + '"'))
$content = [regex]::Replace($content, '(?m)^(\$ResourceGroupName\s*=\s*)"[^"]*"',    ('${1}"' + $WorkbookResourceGroup + '"'))
$content = [regex]::Replace($content, '(?m)^(\$WorkbookResourceName\s*=\s*)"[^"]*"', ('${1}"' + $WorkbookResourceName + '"'))
$content = [regex]::Replace($content, '(?m)^(\$UseManagedIdentity\s*=\s*)\$(true|false)', '${1}$$true')
foreach ($name in @('$SubscriptionId', '$ResourceGroupName', '$WorkbookResourceName')) {
    if ($content -notmatch ('(?m)^' + [regex]::Escape($name) + '\s*=')) { Write-Err "Parameter line $name not found in runbook source"; exit 1 }
}
Write-Ok "Parameters injected (subscription, resource group, workbook GUID, managed identity)"

$rbUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/runbooks/$RunbookName" + "?api-version=$AutomationApiVersion"
Write-Run "Creating/updating runbook $RunbookName (PowerShell 7.2)..."
$rbBody = @{
    location   = $aa.location
    properties = @{
        runbookType = "PowerShell72"
        logProgress = $false
        logVerbose  = $false
        description = $RunbookDescription
    }
}
$rb = Invoke-ArmRest -Method put -Url $rbUrl -Body $rbBody
if ($script:LastArmExit -ne 0 -or $null -eq $rb) { Write-Err "Runbook creation failed"; exit 1 }
Write-Ok "Runbook resource ready"

Write-Run "Uploading draft content..."
$draftUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/runbooks/$RunbookName/draft/content?api-version=$AutomationApiVersion"
$null = Invoke-ArmRest -Method put -Url $draftUrl -Body $content -ContentType "text/powershell"
if ($script:LastArmExit -ne 0) { Write-Err "Draft upload failed"; exit 1 }
Write-Ok "Draft uploaded ($($content.Length) characters)"

Write-Run "Publishing runbook..."
$publishUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/runbooks/$RunbookName/publish?api-version=$AutomationApiVersion"
$null = Invoke-ArmRest -Method post -Url $publishUrl
if ($script:LastArmExit -ne 0) { Write-Err "Publish failed"; exit 1 }
Write-Ok "Runbook published"
Write-Line

# =============================================================================
# STEP 5: SCHEDULE
# =============================================================================
Write-Head "STEP 5: SCHEDULE"
$offsetText = "+00:00"
try {
    $tz = [TimeZoneInfo]::FindSystemTimeZoneById($ScheduleTimeZone)
    $probe = (Get-Date).Date.AddDays(7)
    $off = $tz.GetUtcOffset($probe)
    $sign = "+"; if ($off.TotalMinutes -lt 0) { $sign = "-" }
    $offsetText = "{0}{1:00}:{2:00}" -f $sign, [math]::Abs($off.Hours), [math]::Abs($off.Minutes)
} catch {
    Write-Warn "Time zone '$ScheduleTimeZone' not resolvable on this machine, using UTC offset +00:00 for the start time"
}
$targetDay = [System.DayOfWeek]$ScheduleWeekDay
$start = (Get-Date).Date.AddDays(1)
while ($start.DayOfWeek -ne $targetDay) { $start = $start.AddDays(1) }
$startTime = "{0}T{1}:00{2}" -f $start.ToString("yyyy-MM-dd"), $ScheduleTime, $offsetText

$schUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/schedules/$ScheduleName" + "?api-version=$AutomationApiVersion"
$sch = Invoke-ArmRest -Method get -Url $schUrl
if ($script:LastArmExit -eq 0 -and $null -ne $sch) {
    Write-Ok "Schedule '$ScheduleName' already exists (next run: $($sch.properties.nextRun))"
} else {
    Write-Run "Creating schedule '$ScheduleName' (every $ScheduleWeekDay $ScheduleTime $ScheduleTimeZone)..."
    $schBody = @{
        name       = $ScheduleName
        properties = @{
            description      = "Weekly refresh of the SQL Server build reference in the workbook"
            startTime        = $startTime
            frequency        = "Week"
            interval         = 1
            timeZone         = $ScheduleTimeZone
            advancedSchedule = @{ weekDays = @($ScheduleWeekDay) }
        }
    }
    $sch = Invoke-ArmRest -Method put -Url $schUrl -Body $schBody
    if ($script:LastArmExit -ne 0 -or $null -eq $sch) { Write-Err "Schedule creation failed"; exit 1 }
    Write-Ok "Schedule created, first run: $startTime"
}

# Link schedule to runbook (job schedule) if not linked yet
$jsListUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/jobSchedules?api-version=$AutomationApiVersion"
$jsList = Invoke-ArmRest -Method get -Url $jsListUrl
$linked = $false
if ($null -ne $jsList -and $null -ne $jsList.value) {
    $linked = (@($jsList.value | Where-Object { $_.properties.runbook.name -eq $RunbookName -and $_.properties.schedule.name -eq $ScheduleName })).Count -gt 0
}
if ($linked) {
    Write-Ok "Schedule already linked to runbook"
} else {
    Write-Run "Linking schedule to runbook..."
    $jsId = [guid]::NewGuid().ToString()
    $jsUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/jobSchedules/$jsId" + "?api-version=$AutomationApiVersion"
    $jsBody = @{ properties = @{ schedule = @{ name = $ScheduleName }; runbook = @{ name = $RunbookName } } }
    $js = Invoke-ArmRest -Method put -Url $jsUrl -Body $jsBody
    if ($script:LastArmExit -ne 0 -or $null -eq $js) { Write-Err "Linking schedule failed"; exit 1 }
    Write-Ok "Schedule linked"
}
Write-Line

# =============================================================================
# STEP 6: TEST JOB (optional)
# =============================================================================
if ($StartTestJob) {
    Write-Head "STEP 6: TEST JOB"
    $jobId = [guid]::NewGuid().ToString()
    $jobUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/jobs/$jobId" + "?api-version=$AutomationApiVersion"
    Write-Run "Starting job $jobId..."
    $job = Invoke-ArmRest -Method put -Url $jobUrl -Body @{ properties = @{ runbook = @{ name = $RunbookName } } }
    if ($script:LastArmExit -ne 0 -or $null -eq $job) { Write-Err "Job start failed"; exit 1 }

    $deadline = (Get-Date).AddMinutes($TestJobTimeoutMinutes)
    $status = "New"
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds 15
        $job = Invoke-ArmRest -Method get -Url $jobUrl
        if ($null -ne $job) { $status = $job.properties.status }
        Write-Info "Job status: $status"
        if ($status -in @("Completed", "Failed", "Stopped", "Suspended")) { break }
    }

    $outUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$AutomationResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/jobs/$jobId/output?api-version=$AutomationApiVersion"
    $jobOutput = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--url", $outUrl, "--output", "tsv")
    if (-not [string]::IsNullOrWhiteSpace($jobOutput)) {
        Write-Info "Job output:"
        foreach ($line in ($jobOutput -split "`n")) { Write-Sub $line }
    }
    if ($status -eq "Completed") { Write-Ok "Test job completed" }
    elseif ($status -eq "Failed") { Write-Err "Test job failed. Check the job in the portal (Automation account > Jobs > $jobId) for the exception." }
    else { Write-Warn "Test job ended with status '$status' (timeout $TestJobTimeoutMinutes min)" }
    Write-Line
}

# =============================================================================
# SUMMARY
# =============================================================================
Write-Head "SUMMARY"
Write-Sub "Subscription        : $($account.name) ($SubscriptionId)"
Write-Sub "Workbook            : $WorkbookDisplayName"
Write-Sub "Workbook GUID       : $WorkbookResourceName"
Write-Sub "Workbook RG         : $WorkbookResourceGroup"
Write-Sub "Automation account  : $AutomationAccountName ($AutomationResourceGroup)"
Write-Sub "Identity principal  : $principalId"
Write-Sub "Role                : $RoleName on $WorkbookResourceGroup"
Write-Sub "Runbook             : $RunbookName (PowerShell 7.2, published)"
Write-Sub "Schedule            : $ScheduleName, every $ScheduleWeekDay $ScheduleTime $ScheduleTimeZone"
Write-Line
Write-Ok "Deployment finished"
Write-Line
