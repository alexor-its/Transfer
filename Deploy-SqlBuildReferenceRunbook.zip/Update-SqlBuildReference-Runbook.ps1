﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Azure Automation runbook: keeps the SQL Server build reference table of the
    "LDK SQL Inventory Dashboard" workbook up to date.
.DESCRIPTION
    Runs in the Azure Automation cloud sandbox (no Hybrid Worker, no Azure CLI).
    Authenticates with the system-assigned managed identity of the Automation account,
    downloads the official Microsoft build list (KB321185), determines the latest CU-branch
    and GDR-branch build per SQL Server major version and writes these values into the
    case() blocks of the workbook query "sql-instances-detail" via Invoke-AzRestMethod.

    Idempotent: if nothing changed, nothing is written. The patched JSON is validated
    before it is sent to Azure.

    Requirements:
      - Automation account with system-assigned managed identity
      - Role "Workbook Contributor" (or "Monitoring Contributor") for that identity on the
        resource group of the workbook
      - Runtime: PowerShell 7.2 or 7.4 with module Az.Accounts (Invoke-AzRestMethod)
      - Schedule: weekly (e.g. Wednesday 06:00)

    Note: This runbook deliberately uses Az modules instead of Azure CLI, because the
    Automation cloud sandbox does not ship Azure CLI. Running the script locally with
    Az.Accounts installed is also supported ($UseManagedIdentity = $false).
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-15
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Update-SqlBuildReference-Runbook.ps1
#>

# =============================================================================
# PARAMETERS (edit here, no call parameters)
# =============================================================================
$ScriptVersion        = "1.0.0"
$PowerShellMode       = "Compat"        # Compat (5.1 + 7.x) or Seven (7.x only)

$SubscriptionId       = "00000000-0000-0000-0000-000000000000"
$ResourceGroupName    = "rg-monitoring"
$WorkbookResourceName = "00000000-0000-0000-0000-000000000000"   # GUID name of the Microsoft.Insights/workbooks resource
$UseManagedIdentity   = $true           # $true in Azure Automation, $false for local test with Connect-AzAccount

$BuildListUrl         = "https://support.microsoft.com/en-us/servicing/sql/kb321185-download-and-install-latest-updates"
$ApiVersion           = "2023-06-01"
$MajorVersionsToTrack = @(17, 16, 15, 14, 13, 12, 11)             # 2025, 2022, 2019, 2017, 2016, 2014, 2012
$MinimumRowsExpected  = 50              # sanity check: abort if the page delivers fewer build rows

# =============================================================================
# RUNTIME SETUP
# =============================================================================
$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# Inside Azure Automation, Write-Output is the reliable stream; locally Write-Host gives colors.
$InAutomation = $false
if ($null -ne $PSPrivateMetadata -and $null -ne $PSPrivateMetadata.JobId) { $InAutomation = $true }

function Write-Msg {
    param([string]$Text, [string]$Color = "White")
    if ($InAutomation) { Write-Output $Text } else { Write-Host $Text -ForegroundColor $Color }
}
function Write-Line  { Write-Msg ("=" * 60) "White" }
function Write-Head  { param([string]$Text) Write-Msg "[ $Text ]" "White" }
function Write-Ok    { param([string]$Text) Write-Msg ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymOk,   $Text) "Green" }
function Write-Err   { param([string]$Text) Write-Msg ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymErr,  $Text) "Red" }
function Write-Warn  { param([string]$Text) Write-Msg ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymWarn, $Text) "Yellow" }
function Write-Info  { param([string]$Text) Write-Msg ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymInfo, $Text) "Cyan" }
function Write-Run   { param([string]$Text) Write-Msg ("[{0}] {1}  {2}" -f (Get-Date -Format "HH:mm:ss"), $SymRun,  $Text) "Cyan" }

function Stop-Runbook {
    param([string]$Reason)
    Write-Err $Reason
    Write-Line
    throw $Reason     # throw marks the Automation job as Failed
}

# =============================================================================
# PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Info "PowerShell $($PSVersionTable.PSVersion) ($($PSVersionTable.PSEdition))"
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) { Stop-Runbook "Script mode 'Seven' requires PowerShell 7.x" }
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) { $PSNativeCommandUseErrorActionPreference = $false }
if ($psMajor -lt 6) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
}
if ($InAutomation) { Write-Info "Running inside Azure Automation (JobId $($PSPrivateMetadata.JobId))" }

Write-Info "Checking Az.Accounts module..."
$azAccounts = Get-Module -ListAvailable -Name Az.Accounts | Sort-Object Version -Descending | Select-Object -First 1
if ($null -eq $azAccounts) { Stop-Runbook "Module Az.Accounts not available. Add it to the runtime environment / modules of the Automation account." }
Import-Module Az.Accounts -ErrorAction SilentlyContinue | Out-Null
Write-Ok "Az.Accounts found: $($azAccounts.Version)"

Write-Info "Checking Azure login..."
$ctx = Get-AzContext -ErrorAction SilentlyContinue
if ($null -eq $ctx -or $null -eq $ctx.Account) {
    if ($UseManagedIdentity) {
        Write-Run "Connecting with managed identity..."
        $null = Connect-AzAccount -Identity -ErrorAction SilentlyContinue
    } else {
        Write-Run "Starting interactive Connect-AzAccount..."
        $null = Connect-AzAccount -ErrorAction SilentlyContinue
    }
    $ctx = Get-AzContext -ErrorAction SilentlyContinue
    if ($null -eq $ctx -or $null -eq $ctx.Account) { Stop-Runbook "Azure login failed" }
}
Write-Ok "Login found: $($ctx.Account.Id)"

$null = Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction SilentlyContinue
$ctx = Get-AzContext -ErrorAction SilentlyContinue
if ($null -eq $ctx -or $ctx.Subscription.Id -ne $SubscriptionId) { Stop-Runbook "Subscription $SubscriptionId not accessible with this identity" }
Write-Ok "Subscription set: $($ctx.Subscription.Name)"

Write-Line
Write-Info "Script version: $ScriptVersion"
Write-Line

# =============================================================================
# FUNCTIONS
# =============================================================================
function Remove-HtmlTags {
    param([string]$Text)
    $t = [regex]::Replace($Text, "<[^>]+>", "")
    $t = [System.Net.WebUtility]::HtmlDecode($t)
    return ($t -replace "\s+", " ").Trim()
}

function ConvertTo-ReleaseDate {
    param([string]$Text)
    foreach ($f in @("MMMM dd, yyyy", "MMMM d, yyyy")) {
        try { return [datetime]::ParseExact($Text.Trim(), $f, [System.Globalization.CultureInfo]::InvariantCulture) } catch { }
    }
    return $null
}

function New-BuildRow {
    param([string]$Build, [string]$ServicePack, [string]$Update, [string]$Kb, [string]$DateText)
    if ($Build -notmatch "^(\d+)\.(\d+)\.(\d+)\.(\d+)$") { return $null }
    $row = New-Object psobject -Property @{
        Build       = $Build
        Major       = [int]$Matches[1]
        BuildNumber = [int]$Matches[3]
        ServicePack = $ServicePack
        Update      = $Update
        Kb          = $Kb
        DateText    = $DateText
        ReleaseDate = (ConvertTo-ReleaseDate $DateText)
    }
    return $row
}

function Get-BuildRowsFromHtml {
    param([string]$Html)
    $rows = New-Object System.Collections.Generic.List[object]
    $opt  = [System.Text.RegularExpressions.RegexOptions]::Singleline
    foreach ($tr in [regex]::Matches($Html, "<tr[^>]*>(.*?)</tr>", $opt)) {
        $cells = [regex]::Matches($tr.Groups[1].Value, "<td[^>]*>(.*?)</td>", $opt)
        if ($cells.Count -lt 5) { continue }
        $row = New-BuildRow -Build (Remove-HtmlTags $cells[0].Groups[1].Value) `
                            -ServicePack (Remove-HtmlTags $cells[1].Groups[1].Value) `
                            -Update (Remove-HtmlTags $cells[2].Groups[1].Value) `
                            -Kb (Remove-HtmlTags $cells[3].Groups[1].Value) `
                            -DateText (Remove-HtmlTags $cells[4].Groups[1].Value)
        if ($null -ne $row) { $rows.Add($row) }
    }
    return $rows
}

function Get-BuildRowsFromMarkdown {
    param([string]$Text)
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($line in ($Text -split "`n")) {
        if ($line -notmatch "^\|\s*\d+\.\d+\.\d+\.\d+\s*\|") { continue }
        $parts = $line.Trim().Trim("|") -split "\|"
        if ($parts.Count -lt 5) { continue }
        $kb  = [regex]::Replace($parts[3], "\[([^\]]+)\]\([^)]+\)", '$1').Trim()
        $row = New-BuildRow -Build $parts[0].Trim() -ServicePack $parts[1].Trim() -Update $parts[2].Trim() -Kb $kb -DateText $parts[4].Trim()
        if ($null -ne $row) { $rows.Add($row) }
    }
    return $rows
}

function Test-IsGdrBranch {
    param([string]$Update)
    if ($Update -notmatch "GDR") { return $false }
    if ($Update -match "CU\d") { return $false }
    if ($Update -match "Azure Connect") { return $false }
    return $true
}

function Get-LatestBuildsPerMajor {
    param($Rows, [int[]]$Majors)
    $result = @{}
    foreach ($major in $Majors) {
        $candidates = @($Rows | Where-Object { $_.Major -eq $major -and $null -ne $_.ReleaseDate })
        if ($candidates.Count -eq 0) { Write-Warn "No rows found for major version $major"; continue }
        $sorted = @($candidates | Sort-Object -Property @{Expression = "ReleaseDate"; Descending = $true}, @{Expression = "BuildNumber"; Descending = $true})
        $gdrRow = $sorted | Where-Object { Test-IsGdrBranch $_.Update } | Select-Object -First 1
        $cuRow  = $sorted | Where-Object { -not (Test-IsGdrBranch $_.Update) } | Select-Object -First 1
        if ($null -eq $cuRow -or ($null -ne $gdrRow -and $cuRow.ReleaseDate -lt $gdrRow.ReleaseDate)) { $cuRow = $sorted[0] }

        $entry = New-Object psobject -Property @{
            Major = $major; CuBuild = $cuRow.Build; CuNumber = $cuRow.BuildNumber; CuLabel = $cuRow.Update; CuDate = $cuRow.ReleaseDate
            GdrBuild = $null; GdrNumber = $null; GdrLabel = $null
        }
        if ($null -ne $gdrRow) { $entry.GdrBuild = $gdrRow.Build; $entry.GdrNumber = $gdrRow.BuildNumber; $entry.GdrLabel = $gdrRow.Update }
        $result[$major] = $entry
    }
    return $result
}

function Update-CaseBlock {
    param([string]$Text, [string]$BlockName, [string]$NextBlockName, [int]$Major, [string]$NewValue)
    $startIdx = $Text.IndexOf("$BlockName = case(")
    if ($startIdx -lt 0) { Write-Warn "Block '$BlockName' not found"; return $Text }
    $endIdx = $Text.IndexOf("$NextBlockName = case(", $startIdx)
    if ($endIdx -lt 0) { $endIdx = $Text.Length }
    $block   = $Text.Substring($startIdx, $endIdx - $startIdx)
    $pattern = "(majorNum == $Major,\s*)([^,]+)(,)"
    if ($block -notmatch $pattern) { Write-Warn "Major $Major not found in block '$BlockName'"; return $Text }
    $newBlock = [regex]::Replace($block, $pattern, ('${1}' + $NewValue + '${3}'), 1)
    return $Text.Substring(0, $startIdx) + $newBlock + $Text.Substring($endIdx)
}

function Update-WorkbookText {
    param([string]$Text, $Latest, [datetime]$ReferenceDate)
    $t = $Text
    foreach ($major in $Latest.Keys) {
        $e = $Latest[$major]
        $t = Update-CaseBlock -Text $t -BlockName "LatestCU"      -NextBlockName "LatestGDR"      -Major $major -NewValue ("'" + $e.CuBuild + " (" + $e.CuLabel + ")'")
        $t = Update-CaseBlock -Text $t -BlockName "LatestCUBuild" -NextBlockName "LatestGDRBuild" -Major $major -NewValue ([string]$e.CuNumber)
        if ($null -ne $e.GdrBuild) {
            $t = Update-CaseBlock -Text $t -BlockName "LatestGDR"      -NextBlockName "LatestCUBuild" -Major $major -NewValue ("'" + $e.GdrBuild + " (" + $e.GdrLabel + ")'")
            $t = Update-CaseBlock -Text $t -BlockName "LatestGDRBuild" -NextBlockName "SupportEnd"    -Major $major -NewValue ([string]$e.GdrNumber)
        }
    }
    $t = [regex]::Replace($t, "(source: Microsoft KB321185, state )\d{4}-\d{2}-\d{2}", ('${1}' + $ReferenceDate.ToString("yyyy-MM-dd")))
    return $t
}

# =============================================================================
# STEP 1: FETCH BUILD LIST
# =============================================================================
Write-Head "FETCH BUILD LIST"
Write-Run "Downloading $BuildListUrl"
$content = $null
try {
    $response = Invoke-WebRequest -Uri $BuildListUrl -UseBasicParsing -TimeoutSec 60
    $content  = $response.Content
} catch {
    Stop-Runbook "Download failed: $($_.Exception.Message)"
}
if ([string]::IsNullOrWhiteSpace($content)) { Stop-Runbook "Empty response from Microsoft" }

$rows = Get-BuildRowsFromHtml -Html $content
if ($rows.Count -eq 0) {
    Write-Info "No HTML table rows found, trying markdown parser"
    $rows = Get-BuildRowsFromMarkdown -Text $content
}
if ($rows.Count -lt $MinimumRowsExpected) { Stop-Runbook "Parsed only $($rows.Count) build rows. Page structure may have changed. No changes written." }
Write-Ok "Parsed $($rows.Count) build rows"

$latest = Get-LatestBuildsPerMajor -Rows $rows -Majors $MajorVersionsToTrack
if ($latest.Count -lt $MajorVersionsToTrack.Count) { Stop-Runbook "Not all tracked major versions found. No changes written." }

$newestDate = ($rows | Where-Object { $null -ne $_.ReleaseDate } | Sort-Object ReleaseDate -Descending | Select-Object -First 1).ReleaseDate
Write-Info "Newest release on page: $($newestDate.ToString('yyyy-MM-dd'))"
foreach ($major in ($latest.Keys | Sort-Object -Descending)) {
    $e = $latest[$major]
    $gdrText = "n/a"
    if ($null -ne $e.GdrBuild) { $gdrText = "$($e.GdrBuild) ($($e.GdrLabel))" }
    Write-Msg ("    {0}.0  CU: {1} ({2})  GDR: {3}" -f $major, $e.CuBuild, $e.CuLabel, $gdrText) "Cyan"
}
Write-Line

# =============================================================================
# STEP 2: UPDATE WORKBOOK
# =============================================================================
Write-Head "UPDATE WORKBOOK"
$path = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.Insights/workbooks/$WorkbookResourceName" + "?api-version=$ApiVersion"

Write-Run "Reading workbook $WorkbookResourceName"
$getResp = Invoke-AzRestMethod -Path $path -Method GET -ErrorAction SilentlyContinue
if ($null -eq $getResp -or $getResp.StatusCode -ne 200) {
    $code = "n/a"
    if ($null -ne $getResp) { $code = $getResp.StatusCode }
    Stop-Runbook "GET workbook failed (HTTP $code). Check resource name and role assignment of the managed identity."
}
$wb = ConvertFrom-Json $getResp.Content
Write-Ok "Workbook found: $($wb.properties.displayName)"

$original = [string]$wb.properties.serializedData
$updated  = Update-WorkbookText -Text $original -Latest $latest -ReferenceDate $newestDate

if ($updated -eq $original) {
    Write-Ok "Workbook already up to date. No changes written."
} else {
    try { $null = ConvertFrom-Json $updated } catch { Stop-Runbook "Updated serializedData is not valid JSON. Nothing written." }

    $props = @{
        displayName    = $wb.properties.displayName
        serializedData = $updated
        category       = $wb.properties.category
        sourceId       = $wb.properties.sourceId
        version        = $wb.properties.version
    }
    if ($wb.properties.PSObject.Properties.Name -contains "description" -and $wb.properties.description) { $props["description"] = $wb.properties.description }
    $body = @{ location = $wb.location; kind = $wb.kind; properties = $props }
    if ($wb.PSObject.Properties.Name -contains "tags" -and $wb.tags) { $body["tags"] = $wb.tags }

    Write-Run "Writing workbook"
    $putResp = Invoke-AzRestMethod -Path $path -Method PUT -Payload (ConvertTo-Json $body -Depth 20 -Compress) -ErrorAction SilentlyContinue
    if ($null -eq $putResp -or ($putResp.StatusCode -ne 200 -and $putResp.StatusCode -ne 201)) {
        $code = "n/a"; $detail = ""
        if ($null -ne $putResp) { $code = $putResp.StatusCode; $detail = $putResp.Content }
        Stop-Runbook "PUT workbook failed (HTTP $code) $detail"
    }
    Write-Ok "Workbook updated in Azure (reference state $($newestDate.ToString('yyyy-MM-dd')))"
    foreach ($major in ($latest.Keys | Sort-Object -Descending)) {
        Write-Msg ("    {0}.0 -> {1}" -f $major, $latest[$major].CuBuild) "Green"
    }
}

Write-Line
Write-Ok "Done"
Write-Line
