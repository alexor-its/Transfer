\xEF\xBB\xBF#Requires -Version 5.1
<#
.SYNOPSIS
    Setzt die vCPU-Anzahl aller AVD Session Hosts auf Azure Local (Azure Stack HCI) auf einen Zielwert.
.DESCRIPTION
    Ermittelt subscription-weit alle AVD Host Pools und deren Session Hosts, filtert auf VMs,
    die als Arc-VM auf Azure Local (Microsoft.AzureStackHCI/virtualMachineInstances) laufen,
    und zeigt eine Uebersicht mit aktueller vCPU-Anzahl, Power State und aktiven Sessions an.
    Danach kann gewaehlt werden, ob alle Resource Groups oder nur eine bestimmte Resource Group
    angepasst werden soll. Nach einer finalen Bestaetigung wird die vCPU-Anzahl (Standard: 6)
    gesetzt - unabhaengig von Resource Group oder Host Pool.

    Ablauf pro Session Host:
      - vCPU bereits auf Zielwert       -> wird uebersprungen
      - VM ausgeschaltet                -> vCPU wird direkt angepasst
      - VM eingeschaltet                -> VM wird gestoppt (KEIN Drain-Mode, aktive Sessions
                                           werden getrennt), vCPU angepasst, optional wieder gestartet

    Es wird ausschliesslich Azure CLI (az rest) verwendet - keine Az-Module, keine CLI-Extensions.
    Benoetigte Rechte: Lesen auf Microsoft.DesktopVirtualization (Host Pools / Session Hosts) sowie
    Schreiben auf Microsoft.AzureStackHCI/virtualMachineInstances (z.B. Azure Stack HCI VM Contributor).
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-27
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Set-AvdAzureLocalSessionHostCpu.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - Alle Parameter werden hier im Script hinterlegt
# =============================================================================
$ScriptVersion        = "1.0.0"
$PowerShellMode       = "Compat"        # "Compat" = PS 5.1 + 7.x | "Seven" = nur PS 7.x
$SubscriptionId       = ""              # leer = aktuell gewaehlte Subscription (az account show)
$TargetCpuCount       = 6               # Ziel-vCPU-Anzahl pro Session Host
$CustomLocationFilter = ""              # optional: Name der Custom Location (Azure Local Cluster); leer = alle
$StartAfterChange     = $true           # VMs, die vorher liefen, nach der Anpassung wieder starten
$WhatIfMode           = $false          # $true = nur anzeigen, keine Aenderungen durchfuehren
$StopTimeoutSec       = 600             # max. Wartezeit auf "Stopped"
$UpdateTimeoutSec     = 600             # max. Wartezeit auf abgeschlossene vCPU-Aenderung
$StartTimeoutSec      = 300             # max. Wartezeit auf "Running" (nur Info, kein Abbruch)
$PollIntervalSec      = 10              # Abfrageintervall beim Warten
$ApiVersionAvd        = "2024-04-03"    # Microsoft.DesktopVirtualization
$ApiVersionHci        = "2024-01-01"    # Microsoft.AzureStackHCI virtualMachineInstances
$MinAzCliVersion      = "2.60.0"        # Mindestversion Azure CLI
$ArmEndpoint          = "https://management.azure.com"

# =============================================================================
# [ INITIALISIERUNG ]
# =============================================================================
$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Write-Separator {
    Write-Host ("=" * 60) -ForegroundColor White
}

function Write-Section {
    param([string]$Title)
    Write-Separator
    Write-Host "[ $Title ]" -ForegroundColor White
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("Ok", "Error", "Warn", "Info", "Run")]
        [string]$Level = "Info",
        [int]$Indent = 0
    )
    $ts = Get-Date -Format "HH:mm:ss"
    switch ($Level) {
        "Ok"    { $sym = $SymOk;   $color = "Green"  }
        "Error" { $sym = $SymErr;  $color = "Red"    }
        "Warn"  { $sym = $SymWarn; $color = "Yellow" }
        "Run"   { $sym = $SymRun;  $color = "Cyan"   }
        default { $sym = $SymInfo; $color = "Cyan"   }
    }
    $pad = " " * $Indent
    Write-Host ("[{0}] {1}{2}  {3}" -f $ts, $pad, $sym, $Message) -ForegroundColor $color
}

# Fuehrt az aus und unterdrueckt stderr. Argumente als Array uebergeben.
function Invoke-AzQuiet {
    param([string[]]$Arguments)
    $prevPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $output = & az @Arguments 2>$null
    $ErrorActionPreference = $prevPref
    return $output
}

# Prueft $LASTEXITCODE nach einem externen Aufruf
function Assert-AzSuccess {
    param(
        [string]$Action,
        [switch]$Fatal
    )
    if ($LASTEXITCODE -ne 0) {
        Write-Log "$Action fehlgeschlagen (ExitCode: $LASTEXITCODE)" "Error"
        if ($Fatal) { exit 1 }
        return $false
    }
    return $true
}

# az rest Wrapper: Query-Parameter immer ueber --uri-parameters, Body immer als Datei
function Invoke-AzRest {
    param(
        [ValidateSet("GET", "POST", "PATCH", "PUT", "DELETE")]
        [string]$Method,
        [string]$Url,
        [string[]]$UriParameters = @(),
        [hashtable]$Body = $null
    )
    $azArgs = @("rest", "--method", $Method, "--url", $Url, "--output", "json")
    if ($UriParameters.Count -gt 0) {
        $azArgs += "--uri-parameters"
        $azArgs += $UriParameters
    }
    $bodyFile = $null
    if ($Body) {
        $bodyFile = Join-Path ([System.IO.Path]::GetTempPath()) ("azbody_" + [Guid]::NewGuid().ToString() + ".json")
        $json = $Body | ConvertTo-Json -Depth 10 -Compress
        [System.IO.File]::WriteAllText($bodyFile, $json, (New-Object System.Text.UTF8Encoding($false)))
        $azArgs += @("--body", "@$bodyFile")
    }

    $raw = Invoke-AzQuiet -Arguments $azArgs
    $exitCode = $LASTEXITCODE

    if ($bodyFile -and (Test-Path $bodyFile)) {
        Remove-Item $bodyFile -Force -ErrorAction SilentlyContinue
    }

    $result = New-Object PSObject -Property @{
        Success  = ($exitCode -eq 0)
        ExitCode = $exitCode
        Data     = $null
    }
    if ($exitCode -eq 0 -and $raw) {
        $text = ($raw -join "`n").Trim()
        if ($text) {
            try { $result.Data = $text | ConvertFrom-Json } catch { $result.Data = $text }
        }
    }
    return $result
}

# Listet eine ARM-Collection inkl. nextLink-Paging. nextLink wird in URL + uri-parameters zerlegt.
function Get-AzRestList {
    param(
        [string]$Url,
        [string]$ApiVersion
    )
    $items = @()
    $nextUrl = $Url
    $nextParams = @("api-version=$ApiVersion")
    while ($nextUrl) {
        $res = Invoke-AzRest -Method GET -Url $nextUrl -UriParameters $nextParams
        if (-not $res.Success) { return $null }
        if ($res.Data -and $res.Data.value) { $items += @($res.Data.value) }
        $nextUrl = $null
        if ($res.Data -and $res.Data.nextLink) {
            $parts = ([string]$res.Data.nextLink).Split("?", 2)
            $nextUrl = $parts[0]
            $nextParams = @()
            if ($parts.Count -gt 1) {
                foreach ($kv in $parts[1].Split("&")) {
                    if (-not $kv) { continue }
                    $pair = $kv.Split("=", 2)
                    $k = [System.Uri]::UnescapeDataString($pair[0])
                    $v = ""
                    if ($pair.Count -gt 1) { $v = [System.Uri]::UnescapeDataString($pair[1]) }
                    $nextParams += "$k=$v"
                }
            }
        }
    }
    return ,$items
}

function Get-HciVmInstanceUrl {
    param([string]$ArcMachineId)
    return "$ArcMachineId/providers/Microsoft.AzureStackHCI/virtualMachineInstances/default"
}

function Get-HciVmInstance {
    param([string]$VmInstanceUrl)
    return Invoke-AzRest -Method GET -Url $VmInstanceUrl -UriParameters @("api-version=$ApiVersionHci")
}

# Wartet bis der Power State einem der erwarteten Werte entspricht
function Wait-HciVmPowerState {
    param(
        [string]$VmInstanceUrl,
        [string[]]$ExpectedStates,
        [int]$TimeoutSec
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
        Start-Sleep -Seconds $PollIntervalSec
        $vm = Get-HciVmInstance -VmInstanceUrl $VmInstanceUrl
        if ($vm.Success -and $vm.Data) {
            $state = [string]$vm.Data.properties.status.powerState
            if ($ExpectedStates -contains $state) { return $state }
            Write-Log ("Status: {0} ({1}s)" -f $state, [int]$sw.Elapsed.TotalSeconds) "Run" 4
        }
    }
    return $null
}

# Wartet bis die vCPU-Aenderung uebernommen wurde (provisioningState Succeeded + processors = Ziel)
function Wait-HciVmCpuUpdate {
    param(
        [string]$VmInstanceUrl,
        [int]$ExpectedCpu,
        [int]$TimeoutSec
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
        Start-Sleep -Seconds $PollIntervalSec
        $vm = Get-HciVmInstance -VmInstanceUrl $VmInstanceUrl
        if ($vm.Success -and $vm.Data) {
            $prov = [string]$vm.Data.properties.provisioningState
            $cpu  = [int]$vm.Data.properties.hardwareProfile.processors
            if ($prov -eq "Failed") { return "Failed" }
            if ($prov -eq "Succeeded" -and $cpu -eq $ExpectedCpu) { return "Succeeded" }
            Write-Log ("Provisioning: {0} | vCPU: {1} ({2}s)" -f $prov, $cpu, [int]$sw.Elapsed.TotalSeconds) "Run" 4
        }
    }
    return $null
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Section "PRE-CHECK"

# --- PowerShell Version / Modus -------------------------------------------------
$psVer = $PSVersionTable.PSVersion
Write-Log "PowerShell Version: $psVer (Modus: $PowerShellMode)" "Info"
if ($PowerShellMode -eq "Seven" -and $psVer.Major -lt 7) {
    Write-Log "Modus 'Seven' erfordert PowerShell 7.x - Abbruch" "Error"
    exit 1
}
if ($psVer -ge [Version]"7.3") {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Log "PSNativeCommandUseErrorActionPreference deaktiviert (PS 7.3+)" "Info" 4
}

# --- Azure CLI vorhanden? ---------------------------------------------------------
Write-Log "Pruefe Azure CLI..." "Info"
$azCmd = Get-Command az -ErrorAction SilentlyContinue
if (-not $azCmd) {
    Write-Log "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecli" "Error"
    exit 1
}
$azVerRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $azVerRaw) {
    Write-Log "Azure CLI Version konnte nicht ermittelt werden (az --version)" "Error"
    exit 1
}
$azCliVersion = "0.0.0"
try {
    $azVerObj = ($azVerRaw -join "`n") | ConvertFrom-Json
    $azCliVersion = [string]$azVerObj.'azure-cli'
} catch { }
Write-Log "Azure CLI gefunden: $azCliVersion" "Ok"

# --- Azure CLI aktuell? -----------------------------------------------------------
$azVerParsed = $null
try { $azVerParsed = [Version]($azCliVersion -replace "[^0-9\.].*$", "") } catch { }
if ($azVerParsed -and $azVerParsed -lt [Version]$MinAzCliVersion) {
    Write-Log "Azure CLI $azCliVersion ist aelter als Mindestversion $MinAzCliVersion - bitte 'az upgrade' ausfuehren" "Error"
    exit 1
}
$latestAzCli = $null
try {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/Azure/azure-cli/releases/latest" -TimeoutSec 10 -ErrorAction Stop
    $latestAzCli = ([string]$rel.tag_name) -replace "^azure-cli-", ""
} catch { }
if ($latestAzCli -and $azVerParsed) {
    $latestParsed = $null
    try { $latestParsed = [Version]$latestAzCli } catch { }
    if ($latestParsed -and $latestParsed -gt $azVerParsed) {
        Write-Log "Neuere Azure CLI Version verfuegbar: $latestAzCli (installiert: $azCliVersion) - 'az upgrade'" "Warn"
    } else {
        Write-Log "Azure CLI ist aktuell" "Ok"
    }
} else {
    Write-Log "Aktualitaet konnte nicht online geprueft werden - ggf. 'az upgrade' ausfuehren" "Info"
}

# --- Azure Login vorhanden? -------------------------------------------------------
Write-Log "Pruefe Azure Login..." "Info"
$acctRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Log "Kein Login vorhanden - starte 'az login'" "Warn"
    & az login --output none
    if (-not (Assert-AzSuccess -Action "az login")) { exit 1 }
    $acctRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    if (-not (Assert-AzSuccess -Action "az account show")) { exit 1 }
}
$acct = ($acctRaw -join "`n") | ConvertFrom-Json

if ($SubscriptionId -and ($acct.id -ne $SubscriptionId)) {
    Write-Log "Wechsle Subscription auf $SubscriptionId" "Info"
    & az account set --subscription $SubscriptionId --output none
    if (-not (Assert-AzSuccess -Action "az account set")) { exit 1 }
    $acctRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    if (-not (Assert-AzSuccess -Action "az account show")) { exit 1 }
    $acct = ($acctRaw -join "`n") | ConvertFrom-Json
}
$SubscriptionId = [string]$acct.id
Write-Log ("Login vorhanden: {0}" -f $acct.user.name) "Ok"
Write-Log ("Subscription: {0} ({1})" -f $acct.name, $acct.id) "Info" 4

# =============================================================================
# [ VERSION ]
# =============================================================================
Write-Section "VERSION"
Write-Log "Script-Version: $ScriptVersion" "Info"
Write-Log "Ziel-vCPU: $TargetCpuCount | Nach Aenderung starten: $StartAfterChange | WhatIf: $WhatIfMode" "Info"
if ($CustomLocationFilter) { Write-Log "Filter Custom Location: $CustomLocationFilter" "Info" }
Write-Log "Drain-Mode wird NICHT gesetzt - aktive Sessions laufender Hosts werden beim Stopp getrennt" "Warn"

# =============================================================================
# [ ERMITTLUNG ] - Host Pools, Session Hosts, Azure Local VMs
# =============================================================================
Write-Section "ERMITTLUNG"
Write-Log "Lese AVD Host Pools der Subscription..." "Run"
$hostPools = Get-AzRestList -Url "/subscriptions/$SubscriptionId/providers/Microsoft.DesktopVirtualization/hostPools" -ApiVersion $ApiVersionAvd
if ($null -eq $hostPools) {
    Write-Log "Host Pools konnten nicht gelesen werden" "Error"
    exit 1
}
Write-Log ("{0} Host Pool(s) gefunden" -f $hostPools.Count) "Ok"

$inventory      = @()
$skippedNonHci  = 0
$skippedNoVm    = 0
$skippedFilter  = 0

foreach ($hp in $hostPools) {
    $hpName = [string]$hp.name
    $hpRg   = ([string]$hp.id).Split("/")[4]
    Write-Log "Host Pool: $hpName (RG: $hpRg)" "Run"

    $sessionHosts = Get-AzRestList -Url "$($hp.id)/sessionHosts" -ApiVersion $ApiVersionAvd
    if ($null -eq $sessionHosts) {
        Write-Log "Session Hosts von $hpName konnten nicht gelesen werden" "Warn" 4
        continue
    }
    Write-Log ("{0} Session Host(s)" -f $sessionHosts.Count) "Info" 4

    foreach ($sh in $sessionHosts) {
        $shFullName = ([string]$sh.name).Split("/")[-1]
        $vmName     = $shFullName.Split(".")[0]
        $resourceId = [string]$sh.properties.resourceId

        # Fallback: resourceId leer -> Arc-Maschine ueber den Namen suchen
        if (-not $resourceId) {
            $arcRaw = Invoke-AzQuiet -Arguments @("resource", "list", "--resource-type", "Microsoft.HybridCompute/machines", "--name", $vmName, "--query", "[0].id", "--output", "tsv")
            if ($LASTEXITCODE -eq 0 -and $arcRaw) { $resourceId = ([string]($arcRaw -join "")).Trim() }
        }

        if (-not $resourceId -or ($resourceId -notmatch "/providers/Microsoft\.HybridCompute/machines/")) {
            # Kein Arc-Host -> z.B. klassische Azure VM -> nicht Azure Local
            $skippedNonHci++
            continue
        }

        $vmInstanceUrl = Get-HciVmInstanceUrl -ArcMachineId $resourceId
        $vmRes = Get-HciVmInstance -VmInstanceUrl $vmInstanceUrl
        if (-not $vmRes.Success -or -not $vmRes.Data) {
            # Arc-Maschine ohne Azure Local VM-Instanz (z.B. physischer Server)
            $skippedNoVm++
            Write-Log "$shFullName : keine Azure Local VM-Instanz gefunden - uebersprungen" "Warn" 4
            continue
        }

        $vm       = $vmRes.Data
        $vmRg     = $resourceId.Split("/")[4]
        $custLoc  = ""
        if ($vm.extendedLocation -and $vm.extendedLocation.name) {
            $custLoc = ([string]$vm.extendedLocation.name).Split("/")[-1]
        }
        if ($CustomLocationFilter -and ($custLoc -ne $CustomLocationFilter)) {
            $skippedFilter++
            continue
        }

        $cpu      = 0
        $memMb    = 0
        $vmSize   = ""
        if ($vm.properties.hardwareProfile) {
            $cpu    = [int]$vm.properties.hardwareProfile.processors
            $memMb  = [int]$vm.properties.hardwareProfile.memoryMB
            $vmSize = [string]$vm.properties.hardwareProfile.vmSize
        }
        $powerState = [string]$vm.properties.status.powerState
        if (-not $powerState) { $powerState = "Unknown" }

        $inventory += [PSCustomObject]@{
            HostPool       = $hpName
            SessionHost    = $shFullName
            VmName         = $vmName
            VmRG           = $vmRg
            CustomLocation = $custLoc
            vCPU           = $cpu
            MemoryMB       = $memMb
            VmSize         = $vmSize
            PowerState     = $powerState
            AvdStatus      = [string]$sh.properties.status
            Sessions       = [int]$sh.properties.sessions
            ArcMachineId   = $resourceId
            VmInstanceUrl  = $vmInstanceUrl
        }
    }
}

if ($skippedNonHci -gt 0) { Write-Log "$skippedNonHci Session Host(s) uebersprungen: keine Azure Local VM (z.B. Azure VM)" "Info" }
if ($skippedNoVm -gt 0)   { Write-Log "$skippedNoVm Session Host(s) uebersprungen: Arc-Host ohne VM-Instanz" "Info" }
if ($skippedFilter -gt 0) { Write-Log "$skippedFilter Session Host(s) uebersprungen: Custom Location Filter" "Info" }

if ($inventory.Count -eq 0) {
    Write-Log "Keine AVD Session Hosts auf Azure Local gefunden - nichts zu tun" "Warn"
    exit 0
}

# =============================================================================
# [ UEBERSICHT ]
# =============================================================================
Write-Section "UEBERSICHT"
$inventory | Sort-Object VmRG, HostPool, VmName |
    Format-Table HostPool, VmRG, VmName, CustomLocation, vCPU, MemoryMB, PowerState, AvdStatus, Sessions -AutoSize |
    Out-String -Width 220 | Write-Host

$needChange = @($inventory | Where-Object { $_.vCPU -ne $TargetCpuCount })
$alreadyOk  = @($inventory | Where-Object { $_.vCPU -eq $TargetCpuCount })
$running    = @($needChange | Where-Object { $_.PowerState -notin @("Stopped", "Deallocated") })

Write-Log ("Gesamt: {0} | Bereits auf {1} vCPU: {2} | Anzupassen: {3} | davon eingeschaltet: {4}" -f $inventory.Count, $TargetCpuCount, $alreadyOk.Count, $needChange.Count, $running.Count) "Info"
$activeSessions = ($running | Measure-Object -Property Sessions -Sum).Sum
if ($activeSessions -gt 0) {
    Write-Log "$activeSessions aktive Session(s) auf eingeschalteten Hosts werden beim Stopp getrennt (kein Drain)" "Warn"
}

if ($needChange.Count -eq 0) {
    Write-Log "Alle Session Hosts haben bereits $TargetCpuCount vCPU - nichts zu tun" "Ok"
    exit 0
}

# =============================================================================
# [ AUSWAHL ] - Alle Resource Groups oder nur eine bestimmte
# =============================================================================
Write-Section "AUSWAHL"
$rgList = @($needChange | Group-Object VmRG | Sort-Object Name)
Write-Host "Resource Groups mit anzupassenden Session Hosts:" -ForegroundColor White
$idx = 1
foreach ($g in $rgList) {
    $cntRun = @($g.Group | Where-Object { $_.PowerState -notin @("Stopped", "Deallocated") }).Count
    Write-Host ("    [{0}] {1}  ({2} anzupassen, davon {3} eingeschaltet)" -f $idx, $g.Name, $g.Count, $cntRun) -ForegroundColor Cyan
    $idx++
}
Write-Host "    [A] Alle Resource Groups" -ForegroundColor Cyan
Write-Host "    [Q] Abbrechen" -ForegroundColor Cyan

$targets = $null
while ($null -eq $targets) {
    $choice = (Read-Host "Auswahl (Nummer / A / Q)").Trim().ToUpper()
    if ($choice -eq "Q") {
        Write-Log "Abbruch durch Benutzer" "Warn"
        exit 0
    } elseif ($choice -eq "A") {
        $targets = $needChange
        Write-Log "Auswahl: ALLE Resource Groups" "Info"
    } elseif ($choice -match "^\d+$" -and [int]$choice -ge 1 -and [int]$choice -le $rgList.Count) {
        $selRg = $rgList[[int]$choice - 1].Name
        $targets = @($needChange | Where-Object { $_.VmRG -eq $selRg })
        Write-Log "Auswahl: nur Resource Group '$selRg'" "Info"
    } else {
        Write-Log "Ungueltige Eingabe" "Warn"
    }
}

Write-Host ""
Write-Host "Folgende Session Hosts werden auf $TargetCpuCount vCPU angepasst:" -ForegroundColor White
$targets | Sort-Object VmRG, VmName |
    Format-Table HostPool, VmRG, VmName, vCPU, PowerState, Sessions -AutoSize |
    Out-String -Width 220 | Write-Host

if ($WhatIfMode) {
    Write-Log "WhatIf-Modus aktiv - es werden keine Aenderungen durchgefuehrt" "Warn"
    exit 0
}

$confirm = Read-Host ("Zum Fortfahren 'JA' eingeben ({0} Session Host(s), kein Drain, laufende VMs werden gestoppt)" -f $targets.Count)
if ($confirm -ne "JA") {
    Write-Log "Keine Bestaetigung - Abbruch" "Warn"
    exit 0
}

# =============================================================================
# [ VERARBEITUNG ]
# =============================================================================
Write-Section "VERARBEITUNG"
$results = @()
$counter = 0

foreach ($t in ($targets | Sort-Object VmRG, VmName)) {
    $counter++
    $wasRunning = $false
    $outcome    = "Unbekannt"
    $cpuAfter   = $t.vCPU

    Write-Host ""
    Write-Log ("[{0}/{1}] {2} (RG: {3}, HostPool: {4}) - aktuell {5} vCPU, {6}" -f $counter, $targets.Count, $t.VmName, $t.VmRG, $t.HostPool, $t.vCPU, $t.PowerState) "Run"

    # --- Aktuellen Zustand frisch lesen ---------------------------------------------
    $cur = Get-HciVmInstance -VmInstanceUrl $t.VmInstanceUrl
    if (-not $cur.Success -or -not $cur.Data) {
        Write-Log "VM-Instanz konnte nicht gelesen werden - uebersprungen" "Error" 4
        $results += [PSCustomObject]@{ VmName = $t.VmName; VmRG = $t.VmRG; Vorher = $t.vCPU; Nachher = $t.vCPU; Ergebnis = "Fehler: Lesen" }
        continue
    }
    $powerState = [string]$cur.Data.properties.status.powerState
    $memMb      = [int]$cur.Data.properties.hardwareProfile.memoryMB
    $cpuNow     = [int]$cur.Data.properties.hardwareProfile.processors

    if ($cpuNow -eq $TargetCpuCount) {
        Write-Log "Bereits auf $TargetCpuCount vCPU - uebersprungen" "Ok" 4
        $results += [PSCustomObject]@{ VmName = $t.VmName; VmRG = $t.VmRG; Vorher = $cpuNow; Nachher = $cpuNow; Ergebnis = "Bereits OK" }
        continue
    }

    # --- Stoppen falls eingeschaltet ------------------------------------------------
    if ($powerState -notin @("Stopped", "Deallocated")) {
        $wasRunning = $true
        Write-Log "VM ist '$powerState' - wird gestoppt (kein Drain)" "Warn" 4
        $stopRes = Invoke-AzRest -Method POST -Url "$($t.VmInstanceUrl)/stop" -UriParameters @("api-version=$ApiVersionHci")
        if (-not $stopRes.Success) {
            Write-Log "Stop-Befehl fehlgeschlagen (ExitCode: $($stopRes.ExitCode)) - uebersprungen" "Error" 4
            $results += [PSCustomObject]@{ VmName = $t.VmName; VmRG = $t.VmRG; Vorher = $cpuNow; Nachher = $cpuNow; Ergebnis = "Fehler: Stop" }
            continue
        }
        $state = Wait-HciVmPowerState -VmInstanceUrl $t.VmInstanceUrl -ExpectedStates @("Stopped", "Deallocated") -TimeoutSec $StopTimeoutSec
        if (-not $state) {
            Write-Log "VM wurde innerhalb von $StopTimeoutSec s nicht gestoppt - uebersprungen" "Error" 4
            $results += [PSCustomObject]@{ VmName = $t.VmName; VmRG = $t.VmRG; Vorher = $cpuNow; Nachher = $cpuNow; Ergebnis = "Fehler: Stop-Timeout" }
            continue
        }
        Write-Log "VM gestoppt ($state)" "Ok" 4
    } else {
        Write-Log "VM ist bereits ausgeschaltet ($powerState)" "Ok" 4
    }

    # --- vCPU anpassen ----------------------------------------------------------------
    # vmSize "Custom" ist fuer frei definierte Werte erforderlich; memoryMB wird mitgegeben,
    # damit die Speicherkonfiguration beim Wechsel auf Custom unveraendert bleibt.
    Write-Log "Setze vCPU von $cpuNow auf $TargetCpuCount..." "Run" 4
    $body = @{
        properties = @{
            hardwareProfile = @{
                vmSize     = "Custom"
                processors = $TargetCpuCount
                memoryMB   = $memMb
            }
        }
    }
    $patchRes = Invoke-AzRest -Method PATCH -Url $t.VmInstanceUrl -UriParameters @("api-version=$ApiVersionHci") -Body $body
    if (-not $patchRes.Success) {
        Write-Log "Update-Befehl fehlgeschlagen (ExitCode: $($patchRes.ExitCode))" "Error" 4
        $outcome = "Fehler: Update"
    } else {
        $upd = Wait-HciVmCpuUpdate -VmInstanceUrl $t.VmInstanceUrl -ExpectedCpu $TargetCpuCount -TimeoutSec $UpdateTimeoutSec
        $verify = Get-HciVmInstance -VmInstanceUrl $t.VmInstanceUrl
        if ($verify.Success -and $verify.Data) { $cpuAfter = [int]$verify.Data.properties.hardwareProfile.processors }
        if ($upd -eq "Succeeded" -and $cpuAfter -eq $TargetCpuCount) {
            Write-Log "vCPU erfolgreich auf $cpuAfter gesetzt" "Ok" 4
            $outcome = "Angepasst"
        } elseif ($upd -eq "Failed") {
            Write-Log "Update fehlgeschlagen (provisioningState Failed) - vCPU aktuell: $cpuAfter" "Error" 4
            $outcome = "Fehler: Provisioning"
        } else {
            Write-Log "Update nicht innerhalb von $UpdateTimeoutSec s bestaetigt - vCPU aktuell: $cpuAfter" "Warn" 4
            $outcome = "Unbestaetigt"
        }
    }

    # --- Optional wieder starten ------------------------------------------------------
    if ($wasRunning -and $StartAfterChange) {
        Write-Log "Starte VM wieder..." "Run" 4
        $startRes = Invoke-AzRest -Method POST -Url "$($t.VmInstanceUrl)/start" -UriParameters @("api-version=$ApiVersionHci")
        if (-not $startRes.Success) {
            Write-Log "Start-Befehl fehlgeschlagen (ExitCode: $($startRes.ExitCode))" "Error" 4
            $outcome += " / Start-Fehler"
        } else {
            $state = Wait-HciVmPowerState -VmInstanceUrl $t.VmInstanceUrl -ExpectedStates @("Running") -TimeoutSec $StartTimeoutSec
            if ($state) {
                Write-Log "VM laeuft wieder" "Ok" 4
            } else {
                Write-Log "VM-Start innerhalb von $StartTimeoutSec s nicht bestaetigt - bitte pruefen" "Warn" 4
                $outcome += " / Start unbestaetigt"
            }
        }
    } elseif ($wasRunning) {
        Write-Log "VM bleibt ausgeschaltet (StartAfterChange = false)" "Info" 4
    }

    $results += [PSCustomObject]@{ VmName = $t.VmName; VmRG = $t.VmRG; Vorher = $cpuNow; Nachher = $cpuAfter; Ergebnis = $outcome }
}

# =============================================================================
# [ ZUSAMMENFASSUNG ]
# =============================================================================
Write-Section "ZUSAMMENFASSUNG"
$results | Format-Table VmName, VmRG, Vorher, Nachher, Ergebnis -AutoSize | Out-String -Width 220 | Write-Host

$okCount   = @($results | Where-Object { $_.Ergebnis -like "Angepasst*" }).Count
$skipCount = @($results | Where-Object { $_.Ergebnis -eq "Bereits OK" }).Count
$errCount  = @($results | Where-Object { $_.Ergebnis -like "Fehler*" -or $_.Ergebnis -like "Unbestaetigt*" }).Count

Write-Log "Angepasst: $okCount | Bereits OK: $skipCount | Fehler/Unbestaetigt: $errCount" "Info"
if ($errCount -gt 0) {
    Write-Log "Mindestens ein Session Host konnte nicht (vollstaendig) angepasst werden - bitte pruefen" "Warn"
    Write-Separator
    exit 2
}
Write-Log "Alle ausgewaehlten Session Hosts wurden verarbeitet" "Ok"
Write-Separator
exit 0
