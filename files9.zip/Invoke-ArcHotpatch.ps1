﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Zeigt fuer alle Azure Arc-Maschinen den VBS-Status, den Hotpatch-Schalter,
    den Hotpatch-Enablement-Status und das Hotpatch-Lizenz-Feature aus Azure an.
.DESCRIPTION
    Datenquellen (alle aus Azure, nicht aus dem lokalen OS):
      - Azure Resource Graph (microsoft.hybridcompute/machines):
          properties.osSku
          properties.detectedProperties.virtualizationBasedSecurityStatus
              -> "VbsEnabledSecureKernelRunning" = VBS laeuft (gruener Haken im Portal)
          properties.osProfile.windowsConfiguration.patchSettings.enableHotpatching
              -> Schalter "Enable hotpatching"
          properties.osProfile.windowsConfiguration.patchSettings.status.hotpatchEnablementStatus
              -> Unknown | PendingEvaluation | Disabled | ActionRequired | Enabled
      - Lizenzprofil (machines/{name}/licenseProfiles/default):
          productProfile.productFeatures[name=Hotpatch].subscriptionStatus
              -> Checkbox "Receive monthly Hotpatch updates"

    Modus "Report" (Standard): nur lesen, Tabelle + Zusammenfassung + CSV.
    Modus "Enable": zusaetzlich fuer Kandidaten (Windows Server 2025 Standard/Datacenter,
    VBS laeuft, enableHotpatching noch nicht true) die beiden Portal-Klicks per REST:
      1. PATCH licenseProfiles/default  -> productFeatures[Hotpatch] = Enable
      2. PATCH machine                  -> patchSettings.enableHotpatching = true
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-09-24
    Version     : 1.1.2
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Invoke-ArcHotpatch.ps1
#>

# =============================================================================
# [ PARAMETER ]
# =============================================================================
$ScriptVersion          = "1.1.2"
$PowerShellMode         = "Compat"          # "Compat" (5.1 + 7.x) oder "Seven" (nur 7.x)

$SubscriptionIds        = @()               # leer = alle Subscriptions des Logins; sonst z.B. @("33207861-9482-4afb-9786-eba3a0265bef")
$ResourceGroupFilter    = ""                # leer = alle RGs; sonst exakter RG-Name
$MachineNameFilter      = ""                # leer = alle; sonst Teilstring, z.B. "tskkr"

# Nur Windows Server 2025 ist fuer Arc-Hotpatch relevant. WS2022 und aelter melden
# zudem keinen virtualizationBasedSecurityStatus und werden deshalb direkt in der
# Graph-Abfrage ausgefiltert (nicht erst im Report).
$OsSkuFilter            = "Windows Server 2025"
$IncludeAzureEdition    = $false            # "Datacenter Azure Edition" hat Hotpatch ab Werk und meldet keinen VBS-Wert -> standardmaessig raus

$Mode                   = "Report"          # "Report" | "Enable"
$ConfirmBeforeEnable    = $true

$IncludeLicenseProfile  = $false            # $true = Lizenzprofil fuer JEDE Maschine per REST lesen (langsam bei vielen Maschinen)
                                            # im Enable-Modus wird es fuer Kandidaten immer gelesen

$VbsOkValues            = @("VbsEnabledSecureKernelRunning")   # verifizierter Wert bei laufendem VBS

$ExportCsv              = $true
$CsvDelimiter           = ";"
$CsvPath                = Join-Path -Path $PSScriptRoot -ChildPath ("ArcHotpatch_{0}.csv" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

$ApiVersion             = "2024-07-10"
$ArmEndpoint            = "https://management.azure.com"

# =============================================================================
# [ GRUNDEINSTELLUNGEN ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Write-Line { Write-Host ("=" * 60) -ForegroundColor White }

function Write-Section {
    param([string]$Title)
    Write-Line
    Write-Host ("[ {0} ]" -f $Title) -ForegroundColor White
}

function Write-Log {
    param(
        [ValidateSet("OK","ERR","WARN","INFO","RUN")][string]$Level,
        [string]$Message,
        [int]$Indent = 0
    )
    $stamp = Get-Date -Format "HH:mm:ss"
    $pad   = " " * $Indent
    switch ($Level) {
        "OK"   { Write-Host ("[{0}] {1}{2}  {3}" -f $stamp, $pad, $SymOk,   $Message) -ForegroundColor Green }
        "ERR"  { Write-Host ("[{0}] {1}{2}  {3}" -f $stamp, $pad, $SymErr,  $Message) -ForegroundColor Red }
        "WARN" { Write-Host ("[{0}] {1}{2}  {3}" -f $stamp, $pad, $SymWarn, $Message) -ForegroundColor Yellow }
        "INFO" { Write-Host ("[{0}] {1}{2}  {3}" -f $stamp, $pad, $SymInfo, $Message) -ForegroundColor Cyan }
        "RUN"  { Write-Host ("[{0}] {1}{2}  {3}" -f $stamp, $pad, $SymRun,  $Message) -ForegroundColor Cyan }
    }
}

function Assert-AzSuccess {
    param([string]$Action, [switch]$Fatal)
    if ($LASTEXITCODE -ne 0) {
        Write-Log -Level "ERR" -Message ("{0} fehlgeschlagen (ExitCode {1})" -f $Action, $LASTEXITCODE)
        if ($Fatal) { exit 1 }
        return $false
    }
    return $true
}

function Invoke-AzQuiet {
    param([string[]]$Arguments)
    $savedPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $result = & az @Arguments 2>$null
    $ErrorActionPreference = $savedPref
    return $result
}

function Invoke-AzVerbose {
    # Wie Invoke-AzQuiet, aber stderr wird gesammelt und bei ExitCode <> 0 ausgegeben.
    param([string[]]$Arguments)
    $savedPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $all = & az @Arguments 2>&1
    $code = $LASTEXITCODE
    $ErrorActionPreference = $savedPref
    $stdout = @()
    $stderr = @()
    foreach ($item in @($all)) {
        if ($item -is [System.Management.Automation.ErrorRecord]) { $stderr += [string]$item }
        else { $stdout += [string]$item }
    }
    if ($code -ne 0 -and $stderr.Count -gt 0) {
        foreach ($line in $stderr) {
            if (-not [string]::IsNullOrWhiteSpace($line)) { Write-Host ("    az> " + $line) -ForegroundColor Red }
        }
    }
    $global:LASTEXITCODE = $code
    return $stdout
}

function ConvertFrom-AzJson {
    param($RawOutput)
    if ($null -eq $RawOutput) { return $null }
    $text = ($RawOutput -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    try { return ($text | ConvertFrom-Json) } catch { return $null }
}

function Invoke-ArmRequest {
    param(
        [ValidateSet("get","put","patch")][string]$Method,
        [string]$Url,
        [object]$Body = $null,
        [switch]$Silent
    )
    $args = @("rest", "--method", $Method, "--url", $Url, "--output", "json")
    $tmp  = $null
    if ($null -ne $Body) {
        $tmp  = [System.IO.Path]::GetTempFileName()
        [System.IO.File]::WriteAllText($tmp, ($Body | ConvertTo-Json -Depth 10), [System.Text.UTF8Encoding]::new($false))
        $args += @("--headers", "Content-Type=application/json", "--body", ("@" + $tmp))
    }
    $raw  = Invoke-AzQuiet -Arguments $args
    $code = $LASTEXITCODE
    if ($null -ne $tmp -and (Test-Path -Path $tmp)) { Remove-Item -Path $tmp -Force -ErrorAction SilentlyContinue }
    if ($code -ne 0) {
        if (-not $Silent) { Write-Log -Level "ERR" -Message ("ARM {0} fehlgeschlagen (ExitCode {1}): {2}" -f $Method.ToUpper(), $code, $Url) }
        return $null
    }
    return (ConvertFrom-AzJson -RawOutput $raw)
}

function Get-PropertySafe {
    param($Object, [string[]]$Path)
    $current = $Object
    foreach ($segment in $Path) {
        if ($null -eq $current) { return $null }
        $prop = $current.PSObject.Properties[$segment]
        if ($null -eq $prop) { return $null }
        $current = $prop.Value
    }
    return $current
}

function Get-HotpatchLicenseFeature {
    # Liest subscriptionStatus des Product-Features "Hotpatch" aus licenseProfiles/default.
    param([string]$SubscriptionId, [string]$ResourceGroup, [string]$MachineName)
    $url = "{0}/subscriptions/{1}/resourceGroups/{2}/providers/Microsoft.HybridCompute/machines/{3}/licenseProfiles/default?api-version={4}" -f $ArmEndpoint, $SubscriptionId, $ResourceGroup, $MachineName, $ApiVersion
    $lp  = Invoke-ArmRequest -Method "get" -Url $url -Silent
    if ($null -eq $lp) { return "NoProfile" }
    $features = Get-PropertySafe -Object $lp -Path @("properties", "productProfile", "productFeatures")
    if ($null -eq $features) { return "NotEnrolled" }
    foreach ($f in @($features)) {
        if ([string]$f.name -eq "Hotpatch") { return [string]$f.subscriptionStatus }
    }
    return "NotEnrolled"
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Section -Title "PRE-CHECK"

$psVer = $PSVersionTable.PSVersion
Write-Log -Level "INFO" -Message ("PowerShell {0} ({1})" -f $psVer.ToString(), $PSVersionTable.PSEdition)
if ($PowerShellMode -eq "Seven" -and $psVer.Major -lt 7) {
    Write-Log -Level "ERR" -Message "PowerShellMode = Seven, aber PowerShell 7.x ist nicht aktiv. Abbruch."
    exit 1
}
if ($psVer.Major -gt 7 -or ($psVer.Major -eq 7 -and $psVer.Minor -ge 3)) {
    Set-Variable -Name "PSNativeCommandUseErrorActionPreference" -Value $false -Scope Global -ErrorAction SilentlyContinue
}

Write-Log -Level "INFO" -Message "Pruefe Azure CLI..."
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
if (-not (Assert-AzSuccess -Action "az version")) {
    Write-Log -Level "ERR" -Message "Azure CLI nicht gefunden: https://aka.ms/installazurecliwindows"
    exit 1
}
$azCliVersion = [string](Get-PropertySafe -Object (ConvertFrom-AzJson -RawOutput $azVersionRaw) -Path @("azure-cli"))
Write-Log -Level "OK" -Message ("Azure CLI gefunden: {0}" -f $azCliVersion)

try {
    $pypi   = Invoke-RestMethod -Uri "https://pypi.org/pypi/azure-cli/json" -TimeoutSec 10 -ErrorAction Stop
    $latest = [string]$pypi.info.version
    if ([version]$latest -gt [version]$azCliVersion) {
        Write-Log -Level "WARN" -Message ("Neuere Version verfuegbar: {0} (az upgrade)" -f $latest)
    } else {
        Write-Log -Level "OK" -Message "Azure CLI ist aktuell"
    }
} catch {
    Write-Log -Level "INFO" -Message "Versionsvergleich nicht moeglich (pypi.org nicht erreichbar)" -Indent 4
}

Write-Log -Level "INFO" -Message "Pruefe Azure Login..."
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Log -Level "RUN" -Message "Kein Login vorhanden - starte az login..."
    $null = & az login --output none
    if (-not (Assert-AzSuccess -Action "az login" -Fatal)) { exit 1 }
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    if (-not (Assert-AzSuccess -Action "az account show" -Fatal)) { exit 1 }
}
$account = ConvertFrom-AzJson -RawOutput $accountRaw
Write-Log -Level "OK" -Message ("Login vorhanden: {0}" -f [string](Get-PropertySafe -Object $account -Path @("user", "name")))

Write-Log -Level "INFO" -Message "Pruefe Extension resource-graph..."
$extRaw = Invoke-AzQuiet -Arguments @("extension", "show", "--name", "resource-graph", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Log -Level "RUN" -Message "Installiere Extension resource-graph..." -Indent 4
    $null = Invoke-AzQuiet -Arguments @("extension", "add", "--name", "resource-graph", "--yes")
    if (-not (Assert-AzSuccess -Action "az extension add resource-graph" -Fatal)) { exit 1 }
}
Write-Log -Level "OK" -Message "Extension resource-graph vorhanden"
Write-Line

# =============================================================================
# [ SCRIPT-VERSION ]
# =============================================================================
Write-Host ("Script-Version : {0}" -f $ScriptVersion) -ForegroundColor White
Write-Host ("Modus          : {0}" -f $Mode) -ForegroundColor White
Write-Host ("Subscriptions  : {0}" -f $(if ($SubscriptionIds.Count -eq 0) { "alle" } else { $SubscriptionIds -join ", " })) -ForegroundColor White
Write-Host ("OS-Filter      : {0}{1}" -f $OsSkuFilter, $(if ($IncludeAzureEdition) { "" } else { " (ohne Azure Edition)" })) -ForegroundColor White
Write-Line

# =============================================================================
# [ RESOURCE GRAPH ABFRAGE ]
# =============================================================================
Write-Section -Title "RESOURCE GRAPH ABFRAGE"

$azureEditionClause = ""
if (-not $IncludeAzureEdition) { $azureEditionClause = "| where properties.osSku !contains 'Azure Edition'" }

$kql = @"
Resources
| where type == 'microsoft.hybridcompute/machines'
| where properties.osType == 'windows'
| where properties.osSku contains '$OsSkuFilter'
$azureEditionClause
| project
    name,
    resourceGroup,
    subscriptionId,
    location,
    machineKind      = tostring(['kind']),
    agentStatus      = tostring(properties.status),
    osSku            = tostring(properties.osSku),
    osVersion        = tostring(properties.osVersion),
    vbsStatus        = tostring(properties.detectedProperties.virtualizationBasedSecurityStatus),
    hotpatchEnabled  = tostring(properties.osProfile.windowsConfiguration.patchSettings.enableHotpatching),
    hotpatchStatus   = tostring(properties.osProfile.windowsConfiguration.patchSettings.status.hotpatchEnablementStatus),
    hotpatchError    = tostring(properties.osProfile.windowsConfiguration.patchSettings.status.error.message)
| order by name asc
"@
$kql = ($kql -split "`r?`n" | ForEach-Object { $_.Trim() }) -join " "

$rows      = @()
$skipToken = ""
do {
    $graphArgs = @("graph", "query", "-q", $kql, "--first", "1000", "--output", "json")
    if ($SubscriptionIds.Count -gt 0) { $graphArgs += @("--subscriptions"); $graphArgs += $SubscriptionIds }
    if (-not [string]::IsNullOrWhiteSpace($skipToken)) { $graphArgs += @("--skip-token", $skipToken) }

    Write-Log -Level "RUN" -Message "Lese Arc-Maschinen ueber Resource Graph..."
    $raw   = Invoke-AzVerbose -Arguments $graphArgs
    if ($LASTEXITCODE -ne 0) {
        Write-Log -Level "ERR" -Message ("az graph query fehlgeschlagen (ExitCode {0})" -f $LASTEXITCODE)
        Write-Host "    Verwendete KQL-Abfrage:" -ForegroundColor White
        Write-Host ("    " + $kql) -ForegroundColor DarkGray
        exit 1
    }
    $page  = ConvertFrom-AzJson -RawOutput $raw
    $data  = Get-PropertySafe -Object $page -Path @("data")
    if ($null -ne $data) { $rows += @($data) }
    $skipToken = [string](Get-PropertySafe -Object $page -Path @("skip_token"))
} while (-not [string]::IsNullOrWhiteSpace($skipToken))

Write-Log -Level "OK" -Message ("{0} Arc-Maschine(n) mit '{1}' geladen (WS2022 und aelter bereits in der Abfrage ausgefiltert)" -f $rows.Count, $OsSkuFilter)

if (-not [string]::IsNullOrWhiteSpace($ResourceGroupFilter)) { $rows = @($rows | Where-Object { $_.resourceGroup -eq $ResourceGroupFilter }) }
if (-not [string]::IsNullOrWhiteSpace($MachineNameFilter))   { $rows = @($rows | Where-Object { $_.name -like ("*" + $MachineNameFilter + "*") }) }
if ($rows.Count -eq 0) {
    Write-Log -Level "WARN" -Message "Keine Maschinen im Filter. Ende."
    exit 0
}

# =============================================================================
# [ AUSWERTUNG ]
# =============================================================================
Write-Section -Title "AUSWERTUNG"

$report = @()
foreach ($r in $rows) {
    $vbsOk   = ($VbsOkValues -contains [string]$r.vbsStatus)
    $vbsText = if ([string]::IsNullOrWhiteSpace($r.vbsStatus)) { "n/a" } elseif ($vbsOk) { "ON" } else { "OFF" }

    $osOk = ($r.osSku -match "Windows Server 2025") -and ($r.osSku -notmatch "Azure Edition") -and ($r.osSku -match "Standard|Datacenter")

    $lic = "-"
    if ($IncludeLicenseProfile) {
        $lic = Get-HotpatchLicenseFeature -SubscriptionId $r.subscriptionId -ResourceGroup $r.resourceGroup -MachineName $r.name
    }

    $candidate = $osOk -and $vbsOk -and ([string]$r.hotpatchEnabled -ne "true")

    $report += [PSCustomObject]@{
        Machine          = $r.name
        ResourceGroup    = $r.resourceGroup
        SubscriptionId   = $r.subscriptionId
        Location         = $r.location
        Kind             = $r.machineKind
        AgentStatus      = $r.agentStatus
        OsSku            = $r.osSku
        OsVersion        = $r.osVersion
        OsEligible       = $osOk
        VBS              = $vbsText
        VbsRaw           = $r.vbsStatus
        LicenseHotpatch  = $lic
        HotpatchEnabled  = $r.hotpatchEnabled
        HotpatchStatus   = $r.hotpatchStatus
        HotpatchError    = $r.hotpatchError
        Candidate        = $candidate
        Action           = ""
    }
}

$report | Select-Object Machine, ResourceGroup, OsSku, OsEligible, VBS, VbsRaw, LicenseHotpatch, HotpatchEnabled, HotpatchStatus, Candidate |
    Format-Table -AutoSize | Out-String -Width 250 | Write-Host

# =============================================================================
# [ HOTPATCH AKTIVIEREN ]
# =============================================================================
if ($Mode -eq "Enable") {
    Write-Section -Title "HOTPATCH AKTIVIEREN"
    $candidates = @($report | Where-Object { $_.Candidate })
    Write-Log -Level "INFO" -Message ("{0} Kandidat(en): WS2025 Std/DC, VBS laeuft, Hotpatch noch nicht aktiviert" -f $candidates.Count)

    foreach ($c in $candidates) {
        $name = $c.Machine
        if ($ConfirmBeforeEnable) {
            $answer = Read-Host ("Hotpatch fuer '{0}' ({1}) aktivieren? (j/N)" -f $name, $c.ResourceGroup)
            if ($answer -notmatch "^(j|y)$") { $c.Action = "Skipped-User"; continue }
        }

        $machineUrl = "{0}/subscriptions/{1}/resourceGroups/{2}/providers/Microsoft.HybridCompute/machines/{3}" -f $ArmEndpoint, $c.SubscriptionId, $c.ResourceGroup, $name
        $licUrl     = "{0}/licenseProfiles/default?api-version={1}" -f $machineUrl, $ApiVersion
        $patchUrl   = "{0}?api-version={1}" -f $machineUrl, $ApiVersion

        # --- 1. Lizenz-Feature "Receive monthly Hotpatch updates" -------------
        $licState = Get-HotpatchLicenseFeature -SubscriptionId $c.SubscriptionId -ResourceGroup $c.ResourceGroup -MachineName $name
        $c.LicenseHotpatch = $licState
        if ($licState -ne "Enabled") {
            $licMethod = "patch"
            if ($licState -eq "NoProfile") { $licMethod = "put" }
            Write-Log -Level "RUN" -Message ("{0}: Lizenz-Feature Hotpatch aktivieren ({1})" -f $name, $licMethod.ToUpper())
            $licBody = @{
                location   = $c.Location
                properties = @{
                    productProfile = @{
                        productType     = "WindowsServer"
                        productFeatures = @(@{ name = "Hotpatch"; subscriptionStatus = "Enable" })
                    }
                }
            }
            $licResult = Invoke-ArmRequest -Method $licMethod -Url $licUrl -Body $licBody
            if ($null -eq $licResult) { $c.Action = "Failed-License"; continue }
            Write-Log -Level "OK" -Message ("{0}: Lizenz-Feature gesetzt" -f $name) -Indent 4
        } else {
            Write-Log -Level "OK" -Message ("{0}: Lizenz-Feature Hotpatch bereits Enabled" -f $name) -Indent 4
        }

        # --- 2. Schalter "Enable hotpatching" ----------------------------------
        Write-Log -Level "RUN" -Message ("{0}: enableHotpatching = true" -f $name)
        $patchBody = @{ properties = @{ osProfile = @{ windowsConfiguration = @{ patchSettings = @{ enableHotpatching = $true } } } } }
        $patchResult = Invoke-ArmRequest -Method "patch" -Url $patchUrl -Body $patchBody
        if ($null -eq $patchResult) { $c.Action = "Failed-Enable"; continue }

        $c.HotpatchEnabled = "true"
        $c.HotpatchStatus  = [string](Get-PropertySafe -Object $patchResult -Path @("properties", "osProfile", "windowsConfiguration", "patchSettings", "status", "hotpatchEnablementStatus"))
        $c.Action          = "Enabled-Requested"
        Write-Log -Level "OK" -Message ("{0}: Aktivierung angefordert, Status: {1} (final nach ca. 10 Min., spaeter im Report-Modus pruefen)" -f $name, $c.HotpatchStatus) -Indent 4
    }
}

# =============================================================================
# [ ZUSAMMENFASSUNG ]
# =============================================================================
Write-Section -Title "ZUSAMMENFASSUNG"

$vbsOn    = @($report | Where-Object { $_.VBS -eq "ON" })
$vbsOff   = @($report | Where-Object { $_.VBS -eq "OFF" })
$vbsNa    = @($report | Where-Object { $_.VBS -eq "n/a" })
$hpOn     = @($report | Where-Object { $_.HotpatchStatus -eq "Enabled" })
$hpAction = @($report | Where-Object { $_.HotpatchStatus -eq "ActionRequired" -or -not [string]::IsNullOrWhiteSpace($_.HotpatchError) })
$cand     = @($report | Where-Object { $_.Candidate })

Write-Log -Level "INFO" -Message ("Maschinen gesamt        : {0}" -f $report.Count)
Write-Log -Level "OK"   -Message ("VBS laeuft              : {0}" -f $vbsOn.Count)
Write-Log -Level "ERR"  -Message ("VBS NICHT laufend       : {0}" -f $vbsOff.Count)
Write-Log -Level "WARN" -Message ("VBS-Wert nicht gemeldet : {0}" -f $vbsNa.Count)
Write-Log -Level "OK"   -Message ("Hotpatch Enabled        : {0}" -f $hpOn.Count)
Write-Log -Level "WARN" -Message ("Hotpatch ActionRequired : {0}" -f $hpAction.Count)
Write-Log -Level "INFO" -Message ("Kandidaten (WS2025+VBS) : {0}" -f $cand.Count)

if ($vbsOff.Count -gt 0) {
    Write-Host ""
    Write-Host "[ REPORT: VBS NICHT LAUFEND ]" -ForegroundColor White
    $vbsOff | Select-Object Machine, ResourceGroup, OsSku, VbsRaw | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
}
if ($vbsNa.Count -gt 0) {
    Write-Host "[ REPORT: KEIN VBS-WERT IN AZURE ]" -ForegroundColor White
    Write-Log -Level "INFO" -Message "WS2025 ohne gemeldeten VBS-Wert: Agent-Status pruefen (Disconnected/Expired) oder Agent-Version aktualisieren." -Indent 4
    $vbsNa | Select-Object Machine, ResourceGroup, AgentStatus, OsSku | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
}
if ($hpAction.Count -gt 0) {
    Write-Host "[ REPORT: HOTPATCH ACTIONREQUIRED / FEHLER ]" -ForegroundColor White
    $hpAction | Select-Object Machine, ResourceGroup, HotpatchStatus, HotpatchError | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
}

if ($ExportCsv) {
    try {
        $report | Export-Csv -Path $CsvPath -NoTypeInformation -Delimiter $CsvDelimiter -Encoding UTF8
        Write-Log -Level "OK" -Message ("CSV exportiert: {0}" -f $CsvPath)
    } catch {
        Write-Log -Level "ERR" -Message ("CSV-Export fehlgeschlagen: {0}" -f $_.Exception.Message)
    }
}
Write-Line
