﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Vervollstaendigt die Diagnostic Settings aller AVD Host Pools: Ergaenzt fehlende
    Log-Kategorien im bestehenden Setting, das auf den Session-Host-Workspace zeigt.

.DESCRIPTION
    Hintergrund: Das Extended-Workbook (AVD Sessionhosts Monitoring 2.0) benoetigt im
    Session-Host-Workspace die Tabellen WVDAgentHealthStatus, WVDHostRegistrations und
    WVDSessionHostManagement. Diese werden nur befuellt, wenn die Host-Pool-Diagnostic-
    Settings die Kategorien AgentHealthStatus, HostRegistration und SessionHostManagement
    an diesen Workspace senden.

    Ablauf je Host Pool:
      1. Verfuegbare Log-Kategorien des Host Pools abfragen (diagnosticSettingsCategories)
      2. Bestehendes Diagnostic Setting mit Ziel = $WorkspaceName suchen
      3. Fehlende Kategorien ergaenzen (vorhandene Kategorien, Metriken und andere Settings
         bleiben unveraendert); existiert kein Setting fuer den Workspace, wird eines angelegt
      4. Setting per ARM PUT (az rest) zurueckschreiben

    Mit $WhatIf = $true werden nur die geplanten Aenderungen angezeigt.
    Es wird die aktuelle Subscription des az-Login-Kontexts verwendet.

.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-20
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================

.EXAMPLE
    .\Set-AvdHostPoolDiagnostics.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - Parameter werden im Script hinterlegt
# =============================================================================
$ScriptName     = "Set-AvdHostPoolDiagnostics.ps1"
$ScriptVersion  = "1.0.0"
$PowerShellMode = "Compat"      # "Compat" = PS 5.1 + 7.x | "Seven" = nur PS 7.x

# --- Ziel-Workspace (Session-Host-Workspace, auf den Insights-DCR und Workbook zeigen) --
$WorkspaceResourceGroupName = "rg-avdmgmt"
$WorkspaceName              = "law-LDK-AVDSessionHosts"

# --- Diagnostic Setting -------------------------------------------------------
$DiagnosticSettingName = "diag-avd-hostpool"   # Name fuer NEUE Settings; bestehende Settings zum Workspace werden unabhaengig vom Namen erkannt
$CategoryMode          = "All"                 # "All"      = alle verfuegbaren Log-Kategorien des Host Pools aktivieren
                                               # "Required" = nur $RequiredCategories ergaenzen
$RequiredCategories    = @("Checkpoint", "Error", "Management", "Connection", "HostRegistration", "AgentHealthStatus", "SessionHostManagement")
$HostPoolNameFilter    = @()                   # leer = alle Host Pools; sonst z.B. @("HostPool1-Test")
$WhatIf                = $false                # $true = nur anzeigen, nichts aendern

$DiagnosticsApiVersion           = "2021-05-01-preview"
$DesktopVirtualizationApiVersion = "2024-04-03"

# --- Arbeitsverzeichnis -------------------------------------------------------
$WorkDirectory = Join-Path ([System.IO.Path]::GetTempPath()) "avd-hostpool-diagnostics"

# =============================================================================
# [ GRUNDEINSTELLUNGEN ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Get-Timestamp { return (Get-Date -Format "HH:mm:ss") }
function Write-Line    { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$Title) Write-Host "[ $Title ]" -ForegroundColor White }
function Write-Ok      { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymOk,   $Message) -ForegroundColor Green }
function Write-Err     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymErr,  $Message) -ForegroundColor Red }
function Write-Warn    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymWarn, $Message) -ForegroundColor Yellow }
function Write-Info    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymInfo, $Message) -ForegroundColor Cyan }
function Write-Run     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymRun,  $Message) -ForegroundColor Cyan }
function Write-Sub     { param([string]$Message) Write-Host ("    {0}" -f $Message) -ForegroundColor Cyan }

# Wrapper: az-Aufruf mit unterdruecktem stderr, Argumente als Array
function Invoke-AzQuiet {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $output = & az @Arguments 2>$null
    return $output
}

# Prueft $LASTEXITCODE nach externem Aufruf
function Assert-AzSuccess {
    param([Parameter(Mandatory = $true)][string]$Action, [switch]$Fatal)
    if ($LASTEXITCODE -ne 0) {
        Write-Err "$Action fehlgeschlagen (ExitCode: $LASTEXITCODE)"
        if ($Fatal) { Write-Line; exit 1 }
        return $false
    }
    return $true
}

function Write-JsonFile {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Content)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function ConvertFrom-AzJson {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return $null }
    $text = ($RawOutput -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    return ($text | ConvertFrom-Json)
}

function ConvertFrom-AzText {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return "" }
    return (($RawOutput -join "")).Trim()
}

# az-rest-Argumente: Query-Parameter per --uri-parameters (kein '&' in --url wegen az.cmd)
function Get-AzRestUrlArgs {
    param([Parameter(Mandatory = $true)][string]$Url)
    $base  = $Url
    $query = ""
    $q = $Url.IndexOf("?")
    if ($q -ge 0) {
        $base  = $Url.Substring(0, $q)
        $query = $Url.Substring($q + 1)
    }
    $restArgs = @("--url", $base)
    if (-not [string]::IsNullOrWhiteSpace($query)) {
        $restArgs += "--uri-parameters"
        foreach ($pair in $query.Split("&")) {
            if ([string]::IsNullOrWhiteSpace($pair)) { continue }
            $kv = $pair.Split("=", 2)
            $k = [System.Uri]::UnescapeDataString($kv[0])
            $v = ""
            if ($kv.Count -gt 1) { $v = [System.Uri]::UnescapeDataString($kv[1]) }
            $restArgs += ($k + "=" + $v)
        }
    }
    return ,$restArgs
}

# ARM-GET inkl. Paging; liefert immer ein Array, $null nur bei Fehler
function Invoke-ArmGetAll {
    param([Parameter(Mandatory = $true)][string]$Url)
    $items = @()
    $nextUrl = $Url
    while (-not [string]::IsNullOrWhiteSpace($nextUrl)) {
        $raw = Invoke-AzQuiet -Arguments (@("rest", "--method", "get") + (Get-AzRestUrlArgs -Url $nextUrl) + @("--output", "json"))
        if ($LASTEXITCODE -ne 0) {
            Write-Sub "ARM GET fehlgeschlagen: $nextUrl"
            $retryArgs = @("rest", "--method", "get") + (Get-AzRestUrlArgs -Url $nextUrl) + @("--output", "none")
            & az @retryArgs
            return $null
        }
        $page = ConvertFrom-AzJson -RawOutput $raw
        if ($null -ne $page -and $null -ne $page.value) {
            foreach ($v in $page.value) { $items += $v }
        }
        $nextUrl = ""
        if ($null -ne $page -and $null -ne $page.nextLink) { $nextUrl = [string]$page.nextLink }
    }
    return ,$items
}

# ARM-PUT mit Body-Datei
function Invoke-ArmPut {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][hashtable]$Body,
        [Parameter(Mandatory = $true)][string]$BodyFilePath,
        [Parameter(Mandatory = $true)][string]$Action
    )
    Write-JsonFile -Path $BodyFilePath -Content ($Body | ConvertTo-Json -Depth 10)
    $putArgs = @("rest", "--method", "put") + (Get-AzRestUrlArgs -Url $Url) + @("--body", "@$BodyFilePath", "--headers", "Content-Type=application/json", "--output", "json")
    $raw = & az @putArgs
    if (-not (Assert-AzSuccess -Action $Action)) { return $null }
    return (ConvertFrom-AzJson -RawOutput $raw)
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Line
Write-Section "PRE-CHECK"

$psVersion = $PSVersionTable.PSVersion
Write-Info "PowerShell Version: $psVersion (Modus: $PowerShellMode)"
if ($psVersion.Major -lt 5 -or ($psVersion.Major -eq 5 -and $psVersion.Minor -lt 1)) {
    Write-Err "PowerShell 5.1 oder hoeher wird benoetigt."; Write-Line; exit 1
}
if ($PowerShellMode -eq "Seven" -and $psVersion.Major -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - aktuell: $psVersion"; Write-Line; exit 1
}
if (($psVersion.Major -gt 7) -or ($psVersion.Major -eq 7 -and $psVersion.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PS 7.3+ erkannt: PSNativeCommandUseErrorActionPreference = false"
}

Write-Info "Pruefe Azure CLI..."
$azCommand = Get-Command az -ErrorAction SilentlyContinue
if ($null -eq $azCommand) {
    Write-Err "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"; Write-Line; exit 1
}
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
Assert-AzSuccess -Action "az version" -Fatal | Out-Null
$azVersionObj = ConvertFrom-AzJson -RawOutput $azVersionRaw
$azCliVersion = [string]$azVersionObj.'azure-cli'
Write-Ok "Azure CLI gefunden: $azCliVersion"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $latestInfo    = Invoke-RestMethod -Uri "https://pypi.org/pypi/azure-cli/json" -TimeoutSec 10 -ErrorAction Stop
    $latestVersion = [string]$latestInfo.info.version
    if ([Version]$azCliVersion -lt [Version]$latestVersion) {
        Write-Warn "Neuere Version verfuegbar: $latestVersion (Update mit: az upgrade)"
    }
    else {
        Write-Ok "Azure CLI ist aktuell"
    }
}
catch {
    Write-Warn "Versionsvergleich nicht moeglich - bitte manuell pruefen (az upgrade)"
}

Write-Info "Pruefe Azure Login..."
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Kein Login vorhanden - starte az login..."
    & az login --output none
    Assert-AzSuccess -Action "az login" -Fatal | Out-Null
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess -Action "az account show" -Fatal | Out-Null
}
$account = ConvertFrom-AzJson -RawOutput $accountRaw
Write-Ok "Login vorhanden: $($account.user.name)"
$SubscriptionId = [string]$account.id
Write-Ok "Aktive Subscription: $($account.name) ($SubscriptionId)"

if ($CategoryMode -ne "All" -and $CategoryMode -ne "Required") {
    Write-Err "Ungueltiger CategoryMode '$CategoryMode' - erlaubt: All | Required"; Write-Line; exit 1
}
if (-not (Test-Path -Path $WorkDirectory)) { New-Item -Path $WorkDirectory -ItemType Directory -Force | Out-Null }

Write-Line
Write-Section "SCRIPT-VERSION"
Write-Info "$ScriptName - Version $ScriptVersion"
if ($WhatIf) { Write-Warn "WhatIf aktiv - es werden keine Aenderungen geschrieben" }
Write-Line

# =============================================================================
# [ WORKSPACE ]
# =============================================================================
Write-Section "WORKSPACE"
$WorkspaceResourceId = "/subscriptions/$SubscriptionId/resourceGroups/$WorkspaceResourceGroupName/providers/Microsoft.OperationalInsights/workspaces/$WorkspaceName"
Write-Run "Pruefe Workspace '$WorkspaceName'..."
$wsNameRaw = Invoke-AzQuiet -Arguments @("resource", "show", "--ids", $WorkspaceResourceId, "--query", "name", "--output", "tsv")
if (-not (Assert-AzSuccess -Action "Workspace-Pruefung")) {
    Write-Err "Workspace nicht gefunden: $WorkspaceResourceId"; Write-Line; exit 1
}
Write-Ok "Workspace gefunden: $(ConvertFrom-AzText -RawOutput $wsNameRaw)"
Write-Sub $WorkspaceResourceId
Write-Line

# =============================================================================
# [ HOST POOLS ]
# =============================================================================
Write-Section "HOST POOLS"
Write-Run "Ermittle AVD Host Pools..."
$hostPools = Invoke-ArmGetAll -Url "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.DesktopVirtualization/hostPools?api-version=$DesktopVirtualizationApiVersion"
if ($null -eq $hostPools) { Write-Err "Host Pools konnten nicht abgefragt werden."; Write-Line; exit 1 }
if ($hostPools.Count -eq 0) { Write-Err "Keine Host Pools in der Subscription gefunden."; Write-Line; exit 1 }
Write-Ok "$($hostPools.Count) Host Pool(s) gefunden"
Write-Line

# =============================================================================
# [ DIAGNOSTIC SETTINGS ]
# =============================================================================
Write-Section "DIAGNOSTIC SETTINGS"
$results = @()

foreach ($hp in $hostPools) {
    $hpName = [string]$hp.name
    $hpId   = [string]$hp.id
    if ($HostPoolNameFilter.Count -gt 0 -and $HostPoolNameFilter -notcontains $hpName) { continue }

    Write-Host ""
    Write-Info "Host Pool: $hpName"

    # 1. Verfuegbare Log-Kategorien
    $catItems = Invoke-ArmGetAll -Url "https://management.azure.com${hpId}/providers/Microsoft.Insights/diagnosticSettingsCategories?api-version=$DiagnosticsApiVersion"
    if ($null -eq $catItems) {
        Write-Warn "Kategorien konnten nicht gelesen werden - uebersprungen"
        $results += New-Object PSObject -Property @{ HostPool = $hpName; Status = "Fehler (Kategorien)"; Added = "" }
        continue
    }
    $availableLogs = @()
    foreach ($c in $catItems) {
        if ([string]$c.properties.categoryType -eq "Logs") { $availableLogs += [string]$c.name }
    }
    Write-Sub "Verfuegbare Log-Kategorien: $($availableLogs -join ', ')"

    $targetCategories = @()
    if ($CategoryMode -eq "All") {
        $targetCategories = $availableLogs
    }
    else {
        foreach ($r in $RequiredCategories) {
            if ($availableLogs -contains $r) { $targetCategories += $r }
            else { Write-Warn "Kategorie '$r' ist fuer diesen Host Pool nicht verfuegbar" }
        }
    }

    # 2. Bestehende Settings; das Setting mit Ziel = unser Workspace finden
    $settings = Invoke-ArmGetAll -Url "https://management.azure.com${hpId}/providers/Microsoft.Insights/diagnosticSettings?api-version=$DiagnosticsApiVersion"
    if ($null -eq $settings) {
        Write-Warn "Diagnostic Settings konnten nicht gelesen werden - uebersprungen"
        $results += New-Object PSObject -Property @{ HostPool = $hpName; Status = "Fehler (Settings)"; Added = "" }
        continue
    }
    $target = $null
    foreach ($s in $settings) {
        $wsId = [string]$s.properties.workspaceId
        if ($wsId.ToLower() -eq $WorkspaceResourceId.ToLower()) { $target = $s; break }
    }

    $settingName    = $DiagnosticSettingName
    $existingLogs   = @()
    $existingMetric = @()
    $enabledNow     = @()
    if ($null -ne $target) {
        $settingName = [string]$target.name
        if ($null -ne $target.properties.logs)    { $existingLogs   = @($target.properties.logs) }
        if ($null -ne $target.properties.metrics) { $existingMetric = @($target.properties.metrics) }
        foreach ($l in $existingLogs) {
            if ([bool]$l.enabled) {
                if (-not [string]::IsNullOrWhiteSpace([string]$l.category))      { $enabledNow += [string]$l.category }
                if (-not [string]::IsNullOrWhiteSpace([string]$l.categoryGroup)) { $enabledNow += ("group:" + [string]$l.categoryGroup) }
            }
        }
        Write-Sub "Bestehendes Setting '$settingName' -> aktiv: $($enabledNow -join ', ')"
        if ($enabledNow -contains "group:allLogs") {
            Write-Ok "Setting nutzt bereits 'allLogs' - nichts zu tun"
            $results += New-Object PSObject -Property @{ HostPool = $hpName; Status = "OK (allLogs)"; Added = "" }
            continue
        }
    }
    else {
        Write-Warn "Kein Setting fuer den Ziel-Workspace vorhanden - wird neu angelegt als '$settingName'"
    }

    # 3. Fehlende Kategorien ermitteln
    $missing = @()
    foreach ($t in $targetCategories) { if ($enabledNow -notcontains $t) { $missing += $t } }
    if ($missing.Count -eq 0) {
        Write-Ok "Alle Ziel-Kategorien bereits aktiv - nichts zu tun"
        $results += New-Object PSObject -Property @{ HostPool = $hpName; Status = "OK"; Added = "" }
        continue
    }
    Write-Run "Zu ergaenzen: $($missing -join ', ')"

    # Neues logs-Array: bestehende Eintraege beibehalten, fehlende ergaenzen
    $newLogs = @()
    foreach ($l in $existingLogs) {
        $entry = @{ enabled = [bool]$l.enabled }
        if (-not [string]::IsNullOrWhiteSpace([string]$l.category))      { $entry["category"] = [string]$l.category }
        if (-not [string]::IsNullOrWhiteSpace([string]$l.categoryGroup)) { $entry["categoryGroup"] = [string]$l.categoryGroup }
        # Bereits vorhandene, aber deaktivierte Ziel-Kategorie -> aktivieren statt doppelt anlegen
        if ($entry.ContainsKey("category") -and $missing -contains $entry["category"]) { $entry["enabled"] = $true }
        $newLogs += $entry
    }
    foreach ($m in $missing) {
        $already = $false
        foreach ($e in $newLogs) { if ($e.ContainsKey("category") -and $e["category"] -eq $m) { $already = $true } }
        if (-not $already) { $newLogs += @{ category = $m; enabled = $true } }
    }
    $newMetrics = @()
    foreach ($mt in $existingMetric) {
        $newMetrics += @{ category = [string]$mt.category; enabled = [bool]$mt.enabled }
    }

    if ($WhatIf) {
        Write-Info "WhatIf: Setting '$settingName' wuerde um $($missing.Count) Kategorie(n) ergaenzt"
        $results += New-Object PSObject -Property @{ HostPool = $hpName; Status = "WhatIf"; Added = ($missing -join ", ") }
        continue
    }

    # 4. Setting schreiben
    $body = @{
        properties = @{
            workspaceId = $WorkspaceResourceId
            logs        = $newLogs
            metrics     = $newMetrics
        }
    }
    $url = "https://management.azure.com${hpId}/providers/Microsoft.Insights/diagnosticSettings/${settingName}?api-version=$DiagnosticsApiVersion"
    $bodyPath = Join-Path $WorkDirectory ("diag-" + $hpName + ".json")
    $resp = Invoke-ArmPut -Url $url -Body $body -BodyFilePath $bodyPath -Action "Diagnostic Setting schreiben ($hpName)"
    if ($null -ne $resp) {
        Write-Ok "Setting '$settingName' aktualisiert: +$($missing -join ', +')"
        $results += New-Object PSObject -Property @{ HostPool = $hpName; Status = "Aktualisiert"; Added = ($missing -join ", ") }
    }
    else {
        $results += New-Object PSObject -Property @{ HostPool = $hpName; Status = "Fehler (PUT)"; Added = ($missing -join ", ") }
    }
}
Write-Line

# =============================================================================
# [ ERGEBNIS ]
# =============================================================================
Write-Section "ERGEBNIS"
foreach ($r in ($results | Sort-Object HostPool)) {
    $line = "{0,-28} {1,-20} {2}" -f $r.HostPool, $r.Status, $r.Added
    if ($r.Status -like "Fehler*") { Write-Err $line }
    elseif ($r.Status -eq "WhatIf") { Write-Info $line }
    else { Write-Ok $line }
}
Write-Host ""
Write-Info "Kontrolle in Log Analytics (Daten laufen innerhalb weniger Minuten ein):"
Write-Sub "WVDAgentHealthStatus | where TimeGenerated > ago(30m) | summarize Hosts = dcount(SessionHostName) by _ResourceId"
Write-Line
