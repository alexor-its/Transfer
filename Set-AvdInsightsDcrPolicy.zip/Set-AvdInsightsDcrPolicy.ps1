﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Weist fuer jede Host-Pool- bzw. Session-Host-Resource-Group die Built-in Azure Policy
    zur Zuordnung der Standard-AVD-Insights-DCR (microsoft-avdi-<region>) zu.

.DESCRIPTION
    Das Script
      1. prueft, ob die Insights-DCR "microsoft-avdi-<region>" existiert (sonst Abbruch mit Hinweis)
      2. prueft bzw. erstellt eine User-assigned Managed Identity fuer die Policy-Zuweisungen
      3. ermittelt alle AVD Host Pools der Subscription (optional gefiltert) und leitet daraus
         die Resource Groups der Session Hosts ab (ueber die VM-Resource-IDs der Session Hosts;
         hat ein Host Pool noch keine Session Hosts, wird die RG des Host Pools verwendet)
      4. weist pro ermittelter Resource Group die Built-in Policy
         "Configure Windows Machines to be associated with a Data Collection Rule
          or a Data Collection Endpoint" (DeployIfNotExists) mit der Insights-DCR zu
      5. vergibt die benoetigten Rollen an die Managed Identity
      6. erstellt pro Zuweisung einen Remediation Task fuer bestehende Session Hosts

    Alternativ kann die Liste der Resource Groups manuell vorgegeben werden
    (Variable $ManualResourceGroupNames), dann entfaellt die automatische Ermittlung.

    Alle Azure-Aufrufe erfolgen ueber die Azure CLI (az) in PowerShell. Die Host-Pool-
    und Session-Host-Abfragen laufen ueber "az rest", damit keine CLI-Extension noetig ist.

.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-10-20
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================

.EXAMPLE
    .\Set-AvdInsightsDcrPolicy.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - Parameter werden im Script hinterlegt
# =============================================================================
$ScriptName     = "Set-AvdInsightsDcrPolicy.ps1"
$ScriptVersion  = "1.0.0"
$PowerShellMode = "Compat"      # "Compat" = PS 5.1 + 7.x | "Seven" = nur PS 7.x

# --- Azure Ziel ---------------------------------------------------------------
$Subscription = "Azure Local"               # Subscription-Name oder -ID
$Location     = "westeurope"                # ARM-Kurzname, bestimmt den Insights-DCR-Namen

# --- Insights-DCR (Voraussetzung) --------------------------------------------
$InsightsDcrName              = "microsoft-avdi-$Location"
$InsightsDcrResourceGroupName = "rg-avdmgmt"   # leer lassen = subscriptionweit suchen

# --- Host-Pool-Ermittlung -----------------------------------------------------
$HostPoolNameFilter        = @()            # leer = alle Host Pools; sonst z.B. @("hostpool1-test")
$ManualResourceGroupNames  = @()            # gesetzt = keine automatische Ermittlung, z.B. @("rg-avd-hosts-01")
$UseHostPoolRgIfNoSessionHosts = $true      # Host Pool ohne Session Hosts -> RG des Host Pools verwenden
$DesktopVirtualizationApiVersion = "2024-04-03"

# --- Managed Identity (user-assigned) -----------------------------------------
$ManagedIdentityName              = "id-avd-dcr-policy"
$ManagedIdentityResourceGroupName = "rg-avdmgmt"

# --- Azure Policy -------------------------------------------------------------
$PolicyAssignmentName        = "avd-insights-dcr-assoc"
$PolicyAssignmentDisplayName = "AVD Insights - Session Hosts mit Insights-DCR verknuepfen"
$RemediationNamePrefix       = "rem-avd-insights-dcr"
$CreateRemediationTask       = $true

$DcrPolicyDisplayName    = "Configure Windows Machines to be associated with a Data Collection Rule or a Data Collection Endpoint"
$DcrPolicyDefinitionGuid = "eab1f514-22e3-42e3-9a1f-e1dc05199355"
$PolicyRoleNames         = @("Monitoring Contributor", "Log Analytics Contributor")

# --- Arbeitsverzeichnis -------------------------------------------------------
$WorkDirectory = Join-Path ([System.IO.Path]::GetTempPath()) "avd-insights-dcr-policy"

# =============================================================================
# [ GRUNDEINSTELLUNGEN ]
# =============================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =============================================================================
# [ HILFSFUNKTIONEN ]
# =============================================================================
function Get-Timestamp { return (Get-Date -Format "HH:mm:ss") }
function Write-Line    { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$Title) Write-Host "[ $Title ]" -ForegroundColor White }
function Write-Ok      { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymOk,   $Message) -ForegroundColor Green }
function Write-Err     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymErr,  $Message) -ForegroundColor Red }
function Write-Warn    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymWarn, $Message) -ForegroundColor Yellow }
function Write-Info    { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymInfo, $Message) -ForegroundColor Cyan }
function Write-Run     { param([string]$Message) Write-Host ("[{0}] {1}  {2}" -f (Get-Timestamp), $SymRun,  $Message) -ForegroundColor Cyan }
function Write-Sub     { param([string]$Message) Write-Host ("    {0}" -f $Message) -ForegroundColor Cyan }
function Write-SubErr  { param([string]$Message) Write-Host ("    {0}" -f $Message) -ForegroundColor Red }

# Wrapper: az-Aufruf mit unterdruecktem stderr, Argumente als Array
function Invoke-AzQuiet {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $output = & az @Arguments 2>$null
    return $output
}

# Prueft $LASTEXITCODE nach externem Aufruf
function Assert-AzSuccess {
    param([Parameter(Mandatory = $true)][string]$Action, [switch]$Fatal)
    if ($LASTEXITCODE -ne 0) {
        Write-Err "$Action fehlgeschlagen (ExitCode: $LASTEXITCODE)"
        if ($Fatal) { Write-Line; exit 1 }
        return $false
    }
    return $true
}

function Write-JsonFile {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Content)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function ConvertFrom-AzJson {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return $null }
    $text = ($RawOutput -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    return ($text | ConvertFrom-Json)
}

function ConvertFrom-AzText {
    param([object]$RawOutput)
    if ($null -eq $RawOutput) { return "" }
    return (($RawOutput -join "")).Trim()
}

function Get-ResourceGroupFromId {
    param([string]$ResourceId)
    if ($ResourceId -match "/resourceGroups/([^/]+)/") { return $Matches[1] }
    return $null
}

# ARM-GET ueber az rest inkl. Paging (nextLink)
function Invoke-ArmGetAll {
    param([Parameter(Mandatory = $true)][string]$Url)
    $items = @()
    $nextUrl = $Url
    while (-not [string]::IsNullOrWhiteSpace($nextUrl)) {
        $raw = Invoke-AzQuiet -Arguments @("rest", "--method", "get", "--url", $nextUrl, "--output", "json")
        if ($LASTEXITCODE -ne 0) { return $null }
        $page = ConvertFrom-AzJson -RawOutput $raw
        if ($null -ne $page -and $null -ne $page.value) {
            foreach ($v in $page.value) { $items += $v }
        }
        $nextUrl = ""
        if ($null -ne $page -and $null -ne $page.nextLink) { $nextUrl = [string]$page.nextLink }
    }
    return $items
}

function Get-BuiltinPolicyDefinitionId {
    param([string]$DefinitionGuid, [Parameter(Mandatory = $true)][string]$DisplayName)
    $definitionId = $null
    if (-not [string]::IsNullOrWhiteSpace($DefinitionGuid)) {
        $raw = Invoke-AzQuiet -Arguments @("policy", "definition", "show", "--name", $DefinitionGuid, "--query", "id", "--output", "tsv")
        if ($LASTEXITCODE -eq 0) { $definitionId = ConvertFrom-AzText -RawOutput $raw }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) {
        Write-Sub "GUID-Lookup ohne Treffer - suche per DisplayName (kann etwas dauern)..."
        $query = "[?displayName=='$DisplayName'].id | [0]"
        $raw = Invoke-AzQuiet -Arguments @("policy", "definition", "list", "--query", $query, "--output", "tsv")
        if ($LASTEXITCODE -eq 0) { $definitionId = ConvertFrom-AzText -RawOutput $raw }
    }
    if ([string]::IsNullOrWhiteSpace($definitionId)) { return $null }
    return $definitionId
}

function Set-RoleAssignmentWithRetry {
    param(
        [Parameter(Mandatory = $true)][string]$PrincipalId,
        [Parameter(Mandatory = $true)][string]$RoleName,
        [Parameter(Mandatory = $true)][string]$Scope,
        [int]$MaxAttempts = 6,
        [int]$DelaySeconds = 15
    )
    $attempt = 0
    $done = $false
    while (-not $done -and $attempt -lt $MaxAttempts) {
        $attempt++
        Invoke-AzQuiet -Arguments @(
            "role", "assignment", "create",
            "--assignee-object-id", $PrincipalId,
            "--assignee-principal-type", "ServicePrincipal",
            "--role", $RoleName,
            "--scope", $Scope,
            "--output", "none"
        ) | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $done = $true
            Write-Ok "Rolle '$RoleName' auf: $Scope"
        }
        else {
            Write-Warn "Rollenzuweisung '$RoleName' Versuch $attempt/$MaxAttempts fehlgeschlagen - warte $DelaySeconds s"
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $done
}

# Policy-Zuweisung anlegen oder wiederverwenden; MI nachruesten falls fehlend
function Invoke-DcrPolicyAssignment {
    param(
        [Parameter(Mandatory = $true)][string]$AssignmentName,
        [Parameter(Mandatory = $true)][string]$DisplayName,
        [Parameter(Mandatory = $true)][string]$Description,
        [Parameter(Mandatory = $true)][string]$Scope,
        [Parameter(Mandatory = $true)][string]$PolicyDefinitionId,
        [Parameter(Mandatory = $true)][string]$IdentityResourceId,
        [Parameter(Mandatory = $true)][string]$ParamsFilePath
    )
    Write-Run "Pruefe Policy-Zuweisung '$AssignmentName'..."
    $existingRaw = Invoke-AzQuiet -Arguments @("policy", "assignment", "show", "--name", $AssignmentName, "--scope", $Scope, "--output", "json")
    $assignment = $null
    if ($LASTEXITCODE -eq 0 -and $null -ne $existingRaw) { $assignment = ConvertFrom-AzJson -RawOutput $existingRaw }

    if ($null -ne $assignment) {
        Write-Warn "Zuweisung existiert bereits - wird wiederverwendet (Parameter werden nicht aktualisiert)"
        $identityType = ""
        if ($null -ne $assignment.identity -and $null -ne $assignment.identity.type) { $identityType = [string]$assignment.identity.type }
        if ([string]::IsNullOrWhiteSpace($identityType) -or $identityType -eq "None") {
            Write-Warn "Zuweisung hat KEINE Managed Identity - ruestet User-assigned MI nach..."
            & az policy assignment identity assign --name $AssignmentName --scope $Scope --user-assigned $IdentityResourceId --output none
            if (Assert-AzSuccess -Action "az policy assignment identity assign") {
                Write-Ok "Managed Identity an Zuweisung angehaengt"
                $existingRaw = Invoke-AzQuiet -Arguments @("policy", "assignment", "show", "--name", $AssignmentName, "--scope", $Scope, "--output", "json")
                if ($LASTEXITCODE -eq 0) { $assignment = ConvertFrom-AzJson -RawOutput $existingRaw }
            }
            else {
                Write-SubErr "Hinweis: Zuweisungen ohne Location koennen keine MI erhalten - Zuweisung loeschen und Script erneut ausfuehren."
            }
        }
        else {
            Write-Ok "Zuweisung hat bereits eine Managed Identity ($identityType)"
        }
        return $assignment
    }

    Write-Run "Erstelle Policy-Zuweisung '$AssignmentName' (User-assigned MI)..."
    $createdRaw = & az policy assignment create `
        --name $AssignmentName `
        --display-name $DisplayName `
        --description $Description `
        --scope $Scope `
        --policy $PolicyDefinitionId `
        --params $ParamsFilePath `
        --mi-user-assigned $IdentityResourceId `
        --location $Location `
        --output json
    if (-not (Assert-AzSuccess -Action "az policy assignment create ($AssignmentName)")) { return $null }
    $assignment = ConvertFrom-AzJson -RawOutput $createdRaw
    Write-Ok "Policy-Zuweisung erstellt: $AssignmentName"
    return $assignment
}

function Start-PolicyRemediation {
    param(
        [Parameter(Mandatory = $true)][string]$NamePrefix,
        [Parameter(Mandatory = $true)][string]$AssignmentId,
        [Parameter(Mandatory = $true)][string]$ResourceGroupName
    )
    $remediationName = $NamePrefix + "-" + (Get-Date -Format "yyyyMMddHHmmss")
    Write-Run "Starte Remediation '$remediationName'..."
    & az policy remediation create `
        --name $remediationName `
        --policy-assignment $AssignmentId `
        --resource-group $ResourceGroupName `
        --resource-discovery-mode ReEvaluateCompliance `
        --output none
    if (Assert-AzSuccess -Action "az policy remediation create ($remediationName)") {
        Write-Ok "Remediation Task gestartet: $remediationName"
        return $remediationName
    }
    return $null
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Line
Write-Section "PRE-CHECK"

$psVersion = $PSVersionTable.PSVersion
Write-Info "PowerShell Version: $psVersion (Modus: $PowerShellMode)"
if ($psVersion.Major -lt 5 -or ($psVersion.Major -eq 5 -and $psVersion.Minor -lt 1)) {
    Write-Err "PowerShell 5.1 oder hoeher wird benoetigt."; Write-Line; exit 1
}
if ($PowerShellMode -eq "Seven" -and $psVersion.Major -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - aktuell: $psVersion"; Write-Line; exit 1
}
if (($psVersion.Major -gt 7) -or ($psVersion.Major -eq 7 -and $psVersion.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PS 7.3+ erkannt: PSNativeCommandUseErrorActionPreference = false"
}

Write-Info "Pruefe Azure CLI..."
$azCommand = Get-Command az -ErrorAction SilentlyContinue
if ($null -eq $azCommand) {
    Write-Err "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"; Write-Line; exit 1
}
$azVersionRaw = Invoke-AzQuiet -Arguments @("version", "--output", "json")
Assert-AzSuccess -Action "az version" -Fatal | Out-Null
$azVersionObj = ConvertFrom-AzJson -RawOutput $azVersionRaw
$azCliVersion = [string]$azVersionObj.'azure-cli'
Write-Ok "Azure CLI gefunden: $azCliVersion"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $latestInfo    = Invoke-RestMethod -Uri "https://pypi.org/pypi/azure-cli/json" -TimeoutSec 10 -ErrorAction Stop
    $latestVersion = [string]$latestInfo.info.version
    if ([Version]$azCliVersion -lt [Version]$latestVersion) {
        Write-Warn "Neuere Version verfuegbar: $latestVersion (Update mit: az upgrade)"
    }
    else {
        Write-Ok "Azure CLI ist aktuell"
    }
}
catch {
    Write-Warn "Versionsvergleich nicht moeglich - bitte manuell pruefen (az upgrade)"
}

Write-Info "Pruefe Azure Login..."
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Kein Login vorhanden - starte az login..."
    & az login --output none
    Assert-AzSuccess -Action "az login" -Fatal | Out-Null
    $accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
    Assert-AzSuccess -Action "az account show" -Fatal | Out-Null
}
$account = ConvertFrom-AzJson -RawOutput $accountRaw
Write-Ok "Login vorhanden: $($account.user.name)"

Write-Run "Setze Subscription '$Subscription'..."
& az account set --subscription $Subscription --output none
Assert-AzSuccess -Action "az account set" -Fatal | Out-Null
$accountRaw = Invoke-AzQuiet -Arguments @("account", "show", "--output", "json")
Assert-AzSuccess -Action "az account show" -Fatal | Out-Null
$account = ConvertFrom-AzJson -RawOutput $accountRaw
$SubscriptionId = [string]$account.id
Write-Ok "Aktive Subscription: $($account.name) ($SubscriptionId)"

Write-Line
Write-Section "SCRIPT-VERSION"
Write-Info "$ScriptName - Version $ScriptVersion"
Write-Line

# =============================================================================
# [ VORAUSSETZUNG: INSIGHTS-DCR ]
# =============================================================================
Write-Section "VORAUSSETZUNG: AVD INSIGHTS DCR"
if (-not (Test-Path -Path $WorkDirectory)) { New-Item -Path $WorkDirectory -ItemType Directory -Force | Out-Null }

$insightsDcrResourceId = ""
if (-not [string]::IsNullOrWhiteSpace($InsightsDcrResourceGroupName)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' in RG '$InsightsDcrResourceGroupName'..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "show", "--resource-group", $InsightsDcrResourceGroupName, "--name", $InsightsDcrName, "--resource-type", "Microsoft.Insights/dataCollectionRules", "--query", "id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    Write-Run "Suche Insights-DCR '$InsightsDcrName' subscriptionweit..."
    $raw = Invoke-AzQuiet -Arguments @("resource", "list", "--resource-type", "Microsoft.Insights/dataCollectionRules", "--name", $InsightsDcrName, "--query", "[0].id", "--output", "tsv")
    if ($LASTEXITCODE -eq 0) { $insightsDcrResourceId = ConvertFrom-AzText -RawOutput $raw }
}
if ([string]::IsNullOrWhiteSpace($insightsDcrResourceId)) {
    Write-Err "Insights-DCR '$InsightsDcrName' NICHT gefunden - Abbruch."
    Write-SubErr "Dieser Schritt ist zuerst notwendig:"
    Write-SubErr "  1. Azure Portal > Azure Virtual Desktop > Insights > Konfigurations-Workbook (CheckAMAConfiguration)"
    Write-SubErr "  2. Workspace und DCR-Resource-Group waehlen, 'Create data collection rule' klicken"
    Write-SubErr "  3. Dabei entsteht die DCR '$InsightsDcrName'"
    Write-SubErr "  4. Anschliessend dieses Script erneut starten"
    Write-Line
    exit 1
}
$insightsDcrResourceGroupName = Get-ResourceGroupFromId -ResourceId $insightsDcrResourceId
Write-Ok "Insights-DCR gefunden: $InsightsDcrName (RG: $insightsDcrResourceGroupName)"
Write-Sub "ID: $insightsDcrResourceId"
Write-Line

# =============================================================================
# [ HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS ]
# =============================================================================
Write-Section "HOST POOLS UND SESSION-HOST-RESOURCE-GROUPS"

$targetRgMap = @{}   # RG-Name -> Liste der Host Pools, die dort Session Hosts haben

if ($ManualResourceGroupNames.Count -gt 0) {
    Write-Info "Manuelle Resource-Group-Liste wird verwendet - keine automatische Ermittlung."
    foreach ($rg in $ManualResourceGroupNames) { $targetRgMap[$rg] = @("manuell") }
}
else {
    Write-Run "Ermittle AVD Host Pools in der Subscription..."
    $hpUrl = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.DesktopVirtualization/hostPools?api-version=$DesktopVirtualizationApiVersion"
    $hostPools = Invoke-ArmGetAll -Url $hpUrl
    if ($null -eq $hostPools) {
        Write-Err "Host Pools konnten nicht abgefragt werden (az rest)."; Write-Line; exit 1
    }
    if ($hostPools.Count -eq 0) {
        Write-Err "Keine Host Pools in der Subscription gefunden."; Write-Line; exit 1
    }
    Write-Ok "$($hostPools.Count) Host Pool(s) gefunden"

    foreach ($hp in $hostPools) {
        $hpName = [string]$hp.name
        $hpRg   = Get-ResourceGroupFromId -ResourceId ([string]$hp.id)

        if ($HostPoolNameFilter.Count -gt 0 -and $HostPoolNameFilter -notcontains $hpName) {
            Write-Sub "Uebersprungen (Filter): $hpName"
            continue
        }

        Write-Run "Host Pool '$hpName' (RG: $hpRg) - lese Session Hosts..."
        $shUrl = "https://management.azure.com$($hp.id)/sessionHosts?api-version=$DesktopVirtualizationApiVersion"
        $sessionHosts = Invoke-ArmGetAll -Url $shUrl
        if ($null -eq $sessionHosts) {
            Write-Warn "Session Hosts von '$hpName' konnten nicht gelesen werden - uebersprungen"
            continue
        }

        $rgsOfPool = @()
        foreach ($sh in $sessionHosts) {
            $vmId = ""
            if ($null -ne $sh.properties -and $null -ne $sh.properties.resourceId) { $vmId = [string]$sh.properties.resourceId }
            if ([string]::IsNullOrWhiteSpace($vmId)) { continue }
            $vmRg = Get-ResourceGroupFromId -ResourceId $vmId
            if (-not [string]::IsNullOrWhiteSpace($vmRg) -and $rgsOfPool -notcontains $vmRg) { $rgsOfPool += $vmRg }
        }

        if ($rgsOfPool.Count -eq 0) {
            if ($UseHostPoolRgIfNoSessionHosts) {
                Write-Warn "'$hpName' hat keine Session Hosts mit VM-Resource-ID - verwende Host-Pool-RG '$hpRg'"
                $rgsOfPool += $hpRg
            }
            else {
                Write-Warn "'$hpName' hat keine Session Hosts - uebersprungen"
                continue
            }
        }
        else {
            Write-Ok "'$hpName': $($sessionHosts.Count) Session Host(s) in RG: $($rgsOfPool -join ', ')"
        }

        foreach ($rg in $rgsOfPool) {
            if (-not $targetRgMap.ContainsKey($rg)) { $targetRgMap[$rg] = @() }
            $targetRgMap[$rg] += $hpName
        }
    }
}

$targetResourceGroups = @($targetRgMap.Keys | Sort-Object)
if ($targetResourceGroups.Count -eq 0) {
    Write-Err "Keine Ziel-Resource-Groups ermittelt."; Write-Line; exit 1
}
Write-Host ""
Write-Info "Ziel-Resource-Groups ($($targetResourceGroups.Count)):"
foreach ($rg in $targetResourceGroups) {
    Write-Sub "- $rg  (Host Pools: $(($targetRgMap[$rg] | Sort-Object -Unique) -join ', '))"
}
Write-Line

# =============================================================================
# [ MANAGED IDENTITY ]
# =============================================================================
Write-Section "MANAGED IDENTITY"
Write-Run "Pruefe User-assigned Managed Identity '$ManagedIdentityName'..."
$miRaw = Invoke-AzQuiet -Arguments @("identity", "show", "--name", $ManagedIdentityName, "--resource-group", $ManagedIdentityResourceGroupName, "--output", "json")
$managedIdentity = $null
if ($LASTEXITCODE -eq 0 -and $null -ne $miRaw) { $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw }
$identityIsNew = $false
if ($null -ne $managedIdentity) {
    Write-Ok "Managed Identity vorhanden: $ManagedIdentityName"
}
else {
    Write-Warn "Managed Identity nicht vorhanden - wird erstellt..."
    $miRaw = & az identity create --name $ManagedIdentityName --resource-group $ManagedIdentityResourceGroupName --location $Location --output json
    Assert-AzSuccess -Action "az identity create" -Fatal | Out-Null
    $managedIdentity = ConvertFrom-AzJson -RawOutput $miRaw
    $identityIsNew = $true
    Write-Ok "Managed Identity erstellt: $ManagedIdentityName"
}
$identityResourceId  = [string]$managedIdentity.id
$identityPrincipalId = [string]$managedIdentity.principalId
Write-Sub "Resource-ID : $identityResourceId"
Write-Sub "Principal-ID: $identityPrincipalId"
if ($identityIsNew) {
    Write-Info "Warte 20 s auf Replikation der neuen Identity..."
    Start-Sleep -Seconds 20
}

# Rollen: auf jeder Ziel-RG (DCRA anlegen) + RG der Insights-DCR (DCR lesen)
Write-Run "Vergebe Rollen an die Managed Identity..."
$roleScopes = @()
foreach ($rg in $targetResourceGroups) { $roleScopes += "/subscriptions/$SubscriptionId/resourceGroups/$rg" }
$dcrScope = "/subscriptions/$SubscriptionId/resourceGroups/$insightsDcrResourceGroupName"
if ($roleScopes -notcontains $dcrScope) { $roleScopes += $dcrScope }

$roleErrors = 0
foreach ($roleScope in $roleScopes) {
    foreach ($roleName in $PolicyRoleNames) {
        $result = Set-RoleAssignmentWithRetry -PrincipalId $identityPrincipalId -RoleName $roleName -Scope $roleScope
        if (-not $result) { $roleErrors++ }
    }
}
if ($roleErrors -gt 0) { Write-Warn "$roleErrors Rollenzuweisung(en) fehlgeschlagen - Remediation wird moeglicherweise scheitern." }
Write-Line

# =============================================================================
# [ AZURE POLICY - INSIGHTS-DCR ASSOCIATION ]
# =============================================================================
Write-Section "AZURE POLICY - INSIGHTS-DCR ASSOCIATION"

Write-Run "Ermittle Built-in Policy-Definition..."
$dcrPolicyDefinitionId = Get-BuiltinPolicyDefinitionId -DefinitionGuid $DcrPolicyDefinitionGuid -DisplayName $DcrPolicyDisplayName
if ($null -eq $dcrPolicyDefinitionId) {
    Write-Err "Policy-Definition '$DcrPolicyDisplayName' nicht gefunden."; Write-Line; exit 1
}
Write-Ok "Policy-Definition gefunden"
Write-Sub "$dcrPolicyDefinitionId"

$paramsPath = Join-Path $WorkDirectory "policy-params-insights-dcr.json"
$policyParams = @{
    dcrResourceId = @{ value = $insightsDcrResourceId }
    resourceType  = @{ value = "Microsoft.Insights/dataCollectionRules" }
    effect        = @{ value = "DeployIfNotExists" }
}
Write-JsonFile -Path $paramsPath -Content ($policyParams | ConvertTo-Json -Depth 5)
Write-Info "Parameter-Datei geschrieben: $paramsPath"

$results = @()
foreach ($rg in $targetResourceGroups) {
    $scope = "/subscriptions/$SubscriptionId/resourceGroups/$rg"
    Write-Host ""
    Write-Info "Resource Group: $rg"
    $assignment = Invoke-DcrPolicyAssignment `
        -AssignmentName $PolicyAssignmentName `
        -DisplayName $PolicyAssignmentDisplayName `
        -Description "Verknuepft Windows Session Hosts in '$rg' mit der AVD-Insights-DCR ($InsightsDcrName)." `
        -Scope $scope `
        -PolicyDefinitionId $dcrPolicyDefinitionId `
        -IdentityResourceId $identityResourceId `
        -ParamsFilePath $paramsPath
    $remName = $null
    $status = "FEHLER"
    if ($null -ne $assignment) {
        $status = "OK"
        if ($CreateRemediationTask) {
            $remName = Start-PolicyRemediation -NamePrefix $RemediationNamePrefix -AssignmentId ([string]$assignment.id) -ResourceGroupName $rg
        }
    }
    $results += New-Object PSObject -Property @{
        ResourceGroup = $rg
        HostPools     = (($targetRgMap[$rg] | Sort-Object -Unique) -join ", ")
        Status        = $status
        Remediation   = $remName
    }
}
Write-Line

# =============================================================================
# [ ERGEBNIS ]
# =============================================================================
Write-Section "ERGEBNIS"
Write-Ok "Insights-DCR     : $InsightsDcrName"
Write-Sub $insightsDcrResourceId
Write-Ok "Managed Identity : $ManagedIdentityName"
Write-Sub $identityResourceId
Write-Host ""
Write-Info "Policy-Zuweisung '$PolicyAssignmentName' je Resource Group:"
foreach ($r in $results) {
    $remText = "keine"
    if (-not [string]::IsNullOrWhiteSpace($r.Remediation)) { $remText = $r.Remediation }
    if ($r.Status -eq "OK") {
        Write-Ok "$($r.ResourceGroup)  (Host Pools: $($r.HostPools))"
    }
    else {
        Write-Err "$($r.ResourceGroup)  (Host Pools: $($r.HostPools))"
    }
    Write-Sub "Remediation: $remText"
}
Write-Host ""
Write-Info "Validierung (Resource Graph) - jeder Session Host sollte die Insights-DCR haben:"
Write-Sub "insightsresources"
Write-Sub "| where type == 'microsoft.insights/datacollectionruleassociations'"
Write-Sub "| extend Vm = tolower(tostring(split(id, '/providers/Microsoft.Insights/')[0])), Dcr = tostring(properties.dataCollectionRuleId)"
Write-Sub "| where Vm contains '/virtualmachines/'"
Write-Sub "| summarize Rules = make_set(Dcr) by Vm"
Write-Host ""
Write-Info "Remediation-Status: az policy remediation list --resource-group <rg> --output table"
Write-Line
